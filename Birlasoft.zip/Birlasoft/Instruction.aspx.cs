﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;

using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


public partial class Instruction : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        string str = "";
        if (!Page.IsPostBack)
        {
            if (Session["UserType"] == null)
            {
                Response.Redirect("CandidateLogin.aspx");
            }
            else
            {
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");
            }

            str = Session["UserType"].ToString();
            if (str != "Hiring")
            {
                Response.Redirect("CandidateLogin.aspx");
            }
        }
        BtnAgree.Enabled = true;
        string strclient = "Omega Healthcare";
  

        DIV1.InnerHtml = "I understand that " + strclient + " may use an outside agency to verify and validate the information I have provided including myemployment, my personal background, professional standing, work history and qualifications.<br /><br />I understand that an outside background agency may obtain information it deems appropriate from various sources including, but not limited to, the following: current and past employers, criminal conviction records, school records, College records and professional and personal references.<br /><br />I authorize, without reservation, any individual, corporation or other private or public entity to furnish " + strclient + " and the outside background agency all information about me.<br /><br />I unconditionally release and hold harmless any individual, corporation, or private or public entity from any and all causes of action that might arise from furnishing to " + strclient + " and the outside agency information that they may request pursuant to this release.<br /><br />This authorization and release, in original, faxed or photocopied form, shall be valid for this and any future reports and updates that may be requested.<br />";



    }

    protected void BtnAgree_Click(object sender, EventArgs e)
    {
        string strRefId = Session["RefID"].ToString();
        string category = Session["category"].ToString();
        string strRefIdd = Encript(strRefId);
        Response.Redirect("BGCForm.aspx?cid=" + strRefIdd + "&mode=Update" + "&category=" + category);
        BtnAgree.Enabled = false;
    }

    public string Encript(String RefId)
    {
        ValidateLogin obj = new ValidateLogin();
        string val = obj.Encrypt(RefId);
        return val;
    }
}

﻿using System;
using System.Configuration;
using System.Data;
//using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
//using System.Xml.Linq;
using System.Data.SqlClient;
using IISERVZCLASS;
using DataAccess;
using classgen1;
using EmployeeInfonamespace;
using CandidateInfonamespace;


public partial class forgetpassword : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
    CandidateInfonamespace.CandidateDetails candidateobj = new CandidateInfonamespace.CandidateDetails();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsend_Click(object sender, EventArgs e)
    {
        if (txtemail.Text == "")
        {
            Response.Write("<script>alert('Please Enter Email')</script>");
        }
        else
        {
            candidateobj.UserName = txtemail.Text.ToString();
            int dtInsert = candidateobj.forgetpassword(candidateobj);

            if (dtInsert == 0)
            {
                Response.Write("<Script Language='javascript'> alert('UserName and Password Sent to Your ID')</Script>");
                Server.Transfer("hrlogin.aspx");

            }
            else if (dtInsert == -2)
            {

                Response.Write("<Script Language='javascript'> alert('Already Data Saved !')</Script>");
            }
            else if (dtInsert == -1)
            {

                Response.Write("<Script Language='javascript'> alert('Error In Procedure...InsertEmployeeInfo!')</Script>");
            }


        }
        
    }
}

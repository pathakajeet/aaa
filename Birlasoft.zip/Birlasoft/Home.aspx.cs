﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        tdhome.Visible = false;
        string str = "";
        if (!Page.IsPostBack)
        {
            if (Session["UserType"] == null)
            {
                Response.Redirect("HRLogin.aspx");
            }
            else
            {
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");
            }

            str = Session["UserType"].ToString();
            if (str == "Hiring")
            {
                Response.Redirect("CandidateLogin.aspx");
            }
        }
        if (str == "Admin")
        {
            td1.Visible = false;
            td2.Visible = true;
            rj.Visible = false;
            fc.Visible = false;
            rj.Visible = false;
           
        }
        if (str == "Hiring")
        {
            td1.Visible = false;
            td2.Visible = false;
            rj.Visible = false;
            fc.Visible = false;
            rj.Visible = false;
        }
        if (str == "ClientPlusReject")
        {
            td1.Visible = false;
            td2.Visible = false;
            rj.Visible = true;
            fc.Visible = true;
   
        }
   
    }
}

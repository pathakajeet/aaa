﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DataAccess;
using procall1;
using Casestatus;
using System.Drawing;
using IISERVZCLASS;
using System.Text;


public partial class Rejected : System.Web.UI.Page
{
    procall pc = new procall();
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        //tdhome.Visible = false;

        string str = Session["UserType"].ToString();
        string username = Session["UserName"].ToString();
        if (username == "Client" && str == "ClientPlusReject")
        {
            fc.Visible = true;
            //Rd.Visible = true;
        }
        else
        {
            fc.Visible = false;
            //Rd.Visible = false;
        }
        if (!IsPostBack)
        {
            Page.Validate();

        }

        if (!IsPostBack)
        {
            procall pc = new procall();
            DataSet ds = new DataSet();

          //  ds = pc.rejected(username);
            GridView1.DataSource = ds;
            GridView1.DataBind();
            Label2.Text = this.GridView1.Rows.Count.ToString();
        }


		
		if (str == "Hiring")
        {
          //  td1.Visible = true;
           // td2.Visible = false;
            fc.Visible = false;
           // Rd.Visible = true;


        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "btn1")
        {

            procall pc = new procall();
            DataSet ds = new DataSet();
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                GridViewRow row = GridView1.Rows[i];
                bool isrevert = ((CheckBox)row.FindControl("chkrevertback")).Checked;
                if (isrevert)
                {

                    Status st = new Status();
                    string candidateid = GridView1.Rows[i].Cells[3].Text;
                    string ii = st.ReallocateCase(candidateid);



                }
            }
        //    ds = pc.rejected(Session["UserName"].ToString());
            GridView1.DataSource = ds;
            GridView1.DataBind();

        }
    }
    protected void btnexporttoexcel_Click(object sender, EventArgs e)
    {

        if (GridView1.Rows.Count > 0)
        {

            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                GridView1.HeaderRow.Cells[0].Visible = false;
                GridView1.HeaderRow.Cells[1].Visible = false;

                GridViewRow row = GridView1.Rows[i];
                row.Cells[0].Visible = false;
                row.Cells[1].Visible = false;

            }

            GridView1.HeaderStyle.BackColor = System.Drawing.Color.White;
            GridView1.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            GridView1.ForeColor = System.Drawing.Color.Black;
            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=Rejected-cases" + DateTime.Now.ToString("dd-MM-yyyy") + ".xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.xls";
            this.EnableViewState = false;
            System.IO.StringWriter stringWrite = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
            HtmlForm form1 = new HtmlForm();
            this.Controls.Add(form1);

            form1.Controls.Add(GridView1);
            form1.RenderControl(htmlWrite);

            Response.Write(stringWrite.ToString());
            Response.End();
        }
        else
        {
            Response.Write("<Script Language='javascript'> alert('No Rows!')</Script>");
        }
    }
}

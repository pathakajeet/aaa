﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Globalization;
using System.IO;
using System.Collections.Generic;
using System.Reflection;
//using System.Linq;


public partial class OldReports : System.Web.UI.Page
{
   
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        string str = Session["UserType"].ToString();
        string username = Session["UserName"].ToString();

        if (Session["UserType"] == null)
        {
            Response.Redirect("HrLogin.aspx");
        }

        if (Session["UserName"] == "iiservz")
        {
            Response.Redirect("HrLogin.aspx");
        }
      


        if (!IsPostBack)
        {

            ViewState["ReportList"] = ds;
            DirectoryInfo df = new DirectoryInfo(Server.MapPath("~/Report/"));
            FileInfo[] fi = df.GetFiles();
            SortFileByName(ref fi);
            List<ListItem> files = new List<ListItem>();
            foreach (FileInfo f in fi)
            {
                files.Add(new ListItem(f.Name, f.FullName));
            }

            GridView1.DataSource = files;
            //ListtoDataTableConverter converter = new ListtoDataTableConverter();
            DataTable dt = ToDataTable(files);
            
            ViewState["ReportList"] = dt;
            
            GridView1.DataBind();
            //dt.Columns.RemoveAt(1);
            //dt.Columns.RemoveAt(2);
            //dt.Columns.RemoveAt(3);
            //dt.Columns.RemoveAt(4);
            lblCountReport.Text = "Total Count = " + GridView1.Rows.Count.ToString();
           
        }

    }

    private void SortFileByName(ref FileInfo[] arrFi)
    {
        Array.Sort(arrFi, delegate(FileInfo fi1, FileInfo fi2) { return fi2.CreationTime.CompareTo(fi1.CreationTime); });
    }

    protected void DownloadFile(object sender, EventArgs e)
    {
        string filePath = (sender as LinkButton).CommandArgument;
        Response.ContentType = ContentType;
        Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
        Response.WriteFile(filePath);
        Response.End();
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {

       
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        //required to avoid the run time error "  
        //Control 'GridView1' of type 'Grid View' must be placed inside a form tag with runat=server."  
    } 
    protected void btnexporttoexcel_Click(object sender, EventArgs e)
    {


        GridView grdi = new GridView();
        grdi.DataSource = ViewState["ReportList"] as DataTable;
        grdi.DataBind();
        if (grdi.Rows.Count > 0)
        {
            for (int i = 0; i < grdi.Rows.Count; i++)
            {
                grdi.HeaderRow.Cells[0].Visible = false;
                grdi.HeaderRow.Cells[0].Visible = false;
                grdi.HeaderRow.Cells[0].Visible = false;
                grdi.HeaderRow.Cells[0].Visible = false;
                grdi.HeaderRow.Cells[2].Visible = false;
                grdi.HeaderRow.Cells[2].Visible = false;
                //grdi.HeaderRow.Cells[3].Visible = false;
                //grdi.HeaderRow.Cells[3].Visible = false;
                grdi.HeaderRow.Cells[4].Visible = false;
                grdi.HeaderRow.Cells[4].Visible = false;
                //grdi.HeaderRow.Cells[5].Visible = false;
                //grdi.HeaderRow.Cells[5].Visible = false;

                GridViewRow row = grdi.Rows[i];
                row.Cells[0].Visible = false;
                row.Cells[0].Visible = false;
                row.Cells[1].Visible = false;
                row.Cells[1].Visible = false;
                row.Cells[2].Visible = false;
                row.Cells[2].Visible = false;
                //row.Cells[3].Visible = false;
                //row.Cells[3].Visible = false;
                row.Cells[4].Visible = false;
                row.Cells[4].Visible = false;
                //row.Cells[5].Visible = false;
                //row.Cells[5].Visible = false;

            }


            Response.Clear();
            Response.Buffer = true;
            Response.ClearContent();
            Response.ClearHeaders();
            Response.Charset = "";
            string FileName = "ReportList" + DateTime.Now + ".xls";
            StringWriter strwritter = new StringWriter();
            HtmlTextWriter htmltextwrtter = new HtmlTextWriter(strwritter);
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = "application/vnd.ms-excel";
            Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName);
            GridView1.GridLines = GridLines.Both;
            GridView1.HeaderStyle.Font.Bold = true;
            GridView1.RenderControl(htmltextwrtter);
            Response.Write(strwritter.ToString());
            Response.End();
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //string fromdate = "";
        //string todate = "";
        //fromdate = txtFromDate.Text;
        //todate = txtToDate.Text;
        //ds = pc.CoforgeBgcPostSearch(fromdate, todate);
        //GridView1.DataSource = ds;
        //GridView1.DataBind();
        //lblCountReport.Text = "Total Count = " + ds.Tables[0].Rows.Count.ToString();
    }
    protected void btnMisDtExcel_Click(object sender, EventArgs e)
    {
        string filename = "CoforgeMIS.xls";




        if (filename != "")
        {

            string FolderPath = Server.MapPath("~\\UplodedWiproExcel\\");
            string path = FolderPath + filename;

            System.IO.FileInfo file = new System.IO.FileInfo(path);

            if (file.Exists)
            {

                Response.Clear();

                Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);

                Response.AddHeader("Content-Length", file.Length.ToString());

                Response.ContentType = "application/octet-stream";

                Response.WriteFile(file.FullName);

                Response.End();

            }

            else


                Response.Write("");



        }
    }

    public DataTable ToDataTable<T>(List<T> items)
    {
        DataTable dataTable = new DataTable(typeof(T).Name);
        //Get all the properties
        PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
        foreach (PropertyInfo prop in Props)
        {
            //Setting column names as Property names
            dataTable.Columns.Add(prop.Name);
        }
        foreach (T item in items)
        {
            var values = new object[Props.Length];
            for (int i = 0; i < Props.Length; i++)
            {
                //inserting property values to datatable rows
                values[i] = Props[i].GetValue(item, null);
            }
            dataTable.Rows.Add(values);
        }
        //put a breakpoint here and check datatable
        return dataTable;
    }
}
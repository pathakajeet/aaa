﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using CandidateInfonamespace;
using System.Data.SqlClient;
using DataAccess;
using System.Security.Principal;
using System.Collections.Generic;
using System.Text;
using System.IO;


public partial class Hiring_BGCForm : System.Web.UI.Page
{
    CandidateInfonamespace.CandidateDetails candidateobj = new CandidateInfonamespace.CandidateDetails();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
    DataSet ds = new DataSet();
    string cid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        //JQueryUtils.RegisterTextBoxForDatePicker(Page, txtcandidateDOB); 
        // userlbl.Text=Session["loginuser"].ToString();
        //userlbl.Text = Session["role"].ToString();
        //userlbl.Text = Session["HR"].ToString();
        //string str=Roles.GetRolesForUser(HttpContext.Current.User.Identity.Name).ToString();
        //userlbl.Text = str;
        //   TextBox1.Text = Roles.GetRolesForUser(User.Identity.Name).ToString();

        Page.Form.DefaultButton = btnSave.ClientID;
        Page.Form.DefaultButton = btnSave.UniqueID;

        imageedu.Attributes.Add("onclick", "openPopUpEdu('PopUp.aspx')");
        imageEmp.Attributes.Add("onclick", "openPopUpEmp('PopUp.aspx')");
        image2.Attributes.Add("onclick", "openPopUpRef('PopUp.aspx')");
        imageadd.Attributes.Add("onclick", "openPopUpAdd('PopUp.aspx')");
        image3.Attributes.Add("onclick", "openPopUpCibil('PopUp.aspx')");

        if (Session["UserType"] == null || Request.QueryString["cid"] == null)
        {
            Response.Redirect("HRLogin.aspx");
        }
        try
        {

             ValidateLogin obj = new ValidateLogin();
        if (Request.QueryString["cid"].ToString() != "0" && Request.QueryString["cid"].ToString() != "")
            cid = obj.Decrypt(HttpUtility.UrlDecode(Request.QueryString["cid"].ToString()));
        else
            cid = Request.QueryString["cid"].ToString();

        if (!Page.IsPostBack)
        {
            string category = Request.QueryString["category"];
            switch (category)
            {
                case "Experienced":


                    dropFresherexp.SelectedIndex = 3;
                    dropFresherexp.SelectedIndex = 1;
                    empdetail.Visible = true;


                    break;
                case "Fresher":
                    dropFresherexp.SelectedIndex = 0;
                    empdetail.Visible = false;
                    break;

                case "MS":
                    dropFresherexp.SelectedIndex = 0;
                    empdetail.Visible = false;
                    break;

            }

            ddlcibil.Enabled = true;
            edu1.Visible = true;
            edu2.Visible = true;
            ref1.Visible = true;
            ref2.Visible = true;
            ad1.Visible = true;
            Page.Validate();
            drpnoofcompany.Enabled = true;
            if (Request.QueryString["mode"] == "View" && Request.QueryString["bgcview"] != "fresh")
            {

                RejectedRemark1.Enabled = false;
                RejectedRemark2.Enabled = false;
                RejectedRemark3.Enabled = false;
                RejectedRemark4.Enabled = false;
                RejectedRemark5.Enabled = false;



            }

            RequiredFieldValidatorrej1.EnableClientScript = false;


            //ddlcibil.SelectedItem.Text = "CIBIL Check";
            //cibil.Visible = true;
            //ddlcibil.Enabled = false;

            //ddlref.SelectedItem.Text = "Reference Checks";
            //ddlref.Enabled = false;
            // ref1.Visible = true;
            // ref2.Visible = true;

            //edu1.Visible = true;
            //drpeducation.SelectedItem.Text = "Highest Qualification";



            txtcandidateDOB.Attributes.Add("readonly", "readonly");



            ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");

            //etab2.Visible = false;
            //etab3.Visible = false;
            //DateTime dt = System.DateTime.Now.AddDays(21);
            //string str = dt.ToString("dd/MM/yyyy");
            //txtDateOfJoining.Text = str;
            Page.Validate();
            //ref1.Visible = false;
            //ad1.Visible = false;
            //Cmp1.Visible = false;
            //Cmp2.Visible = false;
            //Cmp3.Visible = false;
            Cmp4.Visible = false;
            Cmp5.Visible = false;

            //edu1.Visible = false;
            //edu2.Visible = false;
            //edu3.Visible = false;

            // Drug.Visible = false;

            //ref1.Visible = false;
            //ref2.Visible = false;




            //criminal1.Visible = false;
            //Reference1.Visible = false;
            //Reference2.Visible = false;
            //Reference3.Visible = false;
            //drug.Visible = false;
            //Identity.Visible = false;
            RejectedRemark1.ReadOnly = true;
            RejectedRemark2.ReadOnly = true;
            RejectedRemark3.ReadOnly = true;
            RejectedRemark4.ReadOnly = true;
            RejectedRemark5.ReadOnly = true;

            txtcmpny1expinyear.ReadOnly = true;
            txtemp2experience.ReadOnly = true;
            txtemp3experienceinyear.ReadOnly = true;
            txtemp4experience.ReadOnly = true;
            txtemp5experience.ReadOnly = true;
            if (dropFresherexp.SelectedItem.Text == "Fresher")
            {
                drpnoofcompany.Enabled = false;
            }
            else
            {
                drpnoofcompany.Enabled = true;
            }
            emp1agencydetail.ReadOnly = true;
            emp2agencydetail.ReadOnly = true;

            emp3agencydetail.ReadOnly = true;
            emp4agencydetail.ReadOnly = true;
            emp5agencydetail.ReadOnly = true;
            radiobuttoncurrentemp.Enabled = false;
            //chkcriminal1.Enabled = false;
            //chkcriminal2.Enabled = false;
            //chkcriminal3.Enabled = false;


            txtCOE.Visible = false;
            drpBand.SelectedItem.Text = "Campus Drive";

            txtcmp1Std.Text = "+91";
            txt_parmanetSTD.Text = "+91";
            txtlogstaySTd.Text = "+91";
            txtaddcurentSTD.Text = "+91";
            txtemp1supervisorlevel1STD.Text = "+91";
            txtemp1supervisorlevel2STD.Text = "+91";

            emp2referenceYN.CausesValidation = false;
            emp3referenceYN.CausesValidation = false;
            emp4referenceYN.CausesValidation = false;
            emp5referenceYN.CausesValidation = false;

            //RequiredFieldValidator63.EnableClientScript = false;
            //RequiredFieldValidator70.EnableClientScript = false;
            //RequiredFieldValidator71.EnableClientScript = false;
            //RequiredFieldValidator72.EnableClientScript = false;

            drpBand.Enabled = false;

            ds = getDataset("select COEID,COEName from COElist where activestatus=1 ");
            drpCOE.DataTextField = "COEName";
            drpCOE.DataValueField = "COEID";
            drpCOE.DataSource = ds;
            drpCOE.DataBind();
            drpCOE.Items.Insert(0, new ListItem("Select", "0"));
            drpCOE.Items.Insert(1, new ListItem("Others"));

            RList.Visible = false;

            if (Request.QueryString["mode"] == "View" && Request.QueryString["bgcview"] == "fresh")
            {

                //RequiredFieldValidatorcomment1.EnableClientScript = false;
                empdetail.Visible = true;
                string usertype1 = Session["UserType"].ToString();
                if (usertype1 == "ClientPlusReject")
                {
                    rc.Visible = true;



                }

            }
            else
            {
                if (Session["MobileNo"] == null)
                {
                    txtcandidatemobile.Text = "";
                }
                else
                {
                    txtcandidatemobile.Text = Session["MobileNo"].ToString();
                    txtcandidatemobile.Enabled = false;
                }
                if (Session["UserName"] == null)
                {
                    txtFirstName.Text = "";
                }
                else
                {
                    txtFirstName.Text = Session["UserName"].ToString();
                    //txtFirstName.Enabled = false;
                }
                if (Session["MiddleName"] == null)
                {
                    txtMiddleName.Text = "";
                }
                else
                {
                    txtMiddleName.Text = Session["MiddleName"].ToString();
                    //txtMiddleName.Enabled = false;
                }
                if (Session["LastName"] == null)
                {
                    txtLastName.Text = "";
                }
                else
                {
                    txtLastName.Text = Session["LastName"].ToString();
                    // txtLastName.Enabled = false;
                }
                if (Session["DateofBirth"] == null)
                {
                    txtcandidateDOB.Text = "";
                }
                else
                {
                    txtcandidateDOB.Text = Session["DateofBirth"].ToString();
                    // txtcandidateDOB.Enabled = false;
                }
                if (Session["FatherName"] == null)
                {
                    txtfathername.Text = "";
                }
                else
                {
                    txtfathername.Text = Session["FatherName"].ToString();
                    // txtfathername.Enabled = false;
                }

                if (Session["dateofjoining"] == null)
                {
                    txtDateOfJoining.Text = "";
                }
                else
                {
                    txtDateOfJoining.Text = Session["dateofjoining"].ToString();
                    //txtDateOfJoining.Enabled = false;
                }
                if (Session["placeofjoining"] == null)
                {
                    drpPOJ.SelectedItem.Text = "";
                }
                else
                {
                    drpPOJ.SelectedItem.Text = Session["placeofjoining"].ToString();
                    //drpPOJ.Enabled = false;
                    CompareValidator2.EnableClientScript = false;
                }

            }




            string usertype = Session["UserType"].ToString();

            if (usertype == "Hiring")
            {
                btnSave.Enabled = false;
                rc.Visible = true;
                RejectedRemark1.Enabled = true;
                RejectedRemark2.Enabled = true;
                RejectedRemark3.Enabled = true;
                RejectedRemark4.Enabled = true;
                RejectedRemark5.Enabled = true;

                comment1.ReadOnly = false;
                comment2.ReadOnly = false;
                comment3.ReadOnly = false;
                comment4.ReadOnly = false;
                comment5.ReadOnly = false;
                rc.Visible = false;
            }
            else
            {



                comment1.ReadOnly = true;
                comment2.ReadOnly = true;
                comment3.ReadOnly = true;
                comment4.ReadOnly = true;
                comment5.ReadOnly = true;
            }


            //if (Page.User.IsInRole("Hiring"))
            //{

            //    btnSave.Enabled = false;
            //    rc.Visible = false;




            //}
            if (usertype == "HiringR")
            {
                comment1.ReadOnly = false;
                comment2.ReadOnly = false;
                comment3.ReadOnly = false;
                comment4.ReadOnly = false;
                comment5.ReadOnly = false;





            }

            if (usertype == "ClientPlusReject")
            {
                comment1.ReadOnly = false;
                comment2.ReadOnly = false;
                comment3.ReadOnly = false;
                comment4.ReadOnly = false;
                comment5.ReadOnly = false;
                btnSave.Visible = true;
                btnSave.Enabled = true;


            }
            if (usertype == "Admin")
            {
                RejectedRemark1.ReadOnly = false;
                RejectedRemark2.ReadOnly = false;
                RejectedRemark3.ReadOnly = false;
                RejectedRemark4.ReadOnly = false;
                RejectedRemark5.ReadOnly = false;

                btnfileupload.Enabled = false;
                fileup.Enabled = false;
                ddlType.Enabled = false;
                btnSave.Visible = true;
                btnSave.Enabled = true;

            }
            if (usertype == "Client")
            {
                RejectedRemark1.ReadOnly = true;
                RejectedRemark2.ReadOnly = true;
                RejectedRemark3.ReadOnly = true;
                RejectedRemark4.ReadOnly = true;
                RejectedRemark5.ReadOnly = true;
                //comment1.ReadOnly = true;
                //comment2.ReadOnly = true;
                //comment3.ReadOnly = true;
                //comment4.ReadOnly = true;
                //comment5.ReadOnly = true;

                btnfileupload.Enabled = false;
                fileup.Enabled = false;
                ddlType.Enabled = false;
                btnSave.Enabled = false;

            }


            //else
            //{
            //    string user = Session["UserName"].ToString();
            //    string password = Session["Password"].ToString();

            //    ds = getDataset("select SNo,COE from CandidateBand4Info  where  CandidateName='" + user + "' and Password='" + password + "'");
            //    drpCOE.DataTextField = "COE";
            //    drpCOE.DataValueField = "SNo";
            //    drpCOE.DataSource = ds;
            //    drpCOE.DataBind();
            //    // drpCOE.Items.Insert(0, new ListItem("Select", "0"));
            //}

            FillState();
            FillCandidateData();
            ShowFile();

            if (grdFileUploadDownload.Rows.Count > 0)
            {
                btnSave.Enabled = true;
            }
            //if (txtFirstName.Text.ToString() != "")
            //{
            //    txtFirstName.Attributes.Add("readonly", "readonly");
            //    //txtMiddleName.Attributes.Add("readonly", "readonly");
            //    //txtLastName.Attributes.Add("readonly", "readonly");
            //    txtfathername.Attributes.Add("readonly", "readonly");
            //    txtcandidateDOB.Attributes.Add("readonly", "readonly");
            //    txtcandidatemobile.Attributes.Add("readonly", "readonly");
            //    //txtcandidatealternateno.Attributes.Add("readonly", "readonly");
            //    txtGender.Attributes.Add("readonly", "readonly");
            //    txtmaritalstatus.Attributes.Add("readonly", "readonly");
            //    candidatedob.Visible = false;
            //    txtcandidateDOB.Width = 150;

            //}
            //else
            //{
            //    candidatedob.Visible = true;
            //    txtcandidateDOB.Width = 130;

            //}
        }
        }
        catch (Exception ex)
        {
        }

       


        


        //RequiredFieldValidator1.EnableClientScript = false;


    }

    private DataSet getDataset(string query)
    {
        DataSet tempDataSet = new DataSet();
        SqlDataAdapter dap = new SqlDataAdapter(query, con);
        dap.Fill(tempDataSet);
        return tempDataSet;
    }


    protected void FillState()
    {
        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        txtAddressparmentstate.DataTextField = "StateName";
        txtAddressparmentstate.DataValueField = "StateId";
        txtAddressparmentstate.DataSource = ds;
        txtAddressparmentstate.DataBind();
        txtAddressparmentstate.Items.Insert(0, new ListItem("Select", "0"));


        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        txtaddlongstaystate.DataTextField = "StateName";
        txtaddlongstaystate.DataValueField = "StateId";
        txtaddlongstaystate.DataSource = ds;
        txtaddlongstaystate.DataBind();
        txtaddlongstaystate.Items.Insert(0, new ListItem("Select", "0"));


        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        txtaddcurrentstate.DataTextField = "StateName";
        txtaddcurrentstate.DataValueField = "StateId";
        txtaddcurrentstate.DataSource = ds;
        txtaddcurrentstate.DataBind();
        txtaddcurrentstate.Items.Insert(0, new ListItem("Select", "0"));


        //ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");



        //ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        //drpidentitystate.DataTextField = "StateName";
        //drpidentitystate.DataValueField = "StateId";
        //drpidentitystate.DataSource = ds;
        //drpidentitystate.DataBind();
        //drpidentitystate.Items.Insert(0, new ListItem("Select", "0"));




    }
    protected void btnSave_Click(object sender, EventArgs e)
    {

        //try
        //{
        //if ((drpeducation.SelectedItem.Text != "--Select--") !! (drpnoo))
        //{


            candidateobj.gender = txtGender.Text.ToString();
            candidateobj.maritalstatus = txtmaritalstatus.SelectedItem.Text.ToString();


            if (drpBand.SelectedItem.Text == "--Select--")
            {
                candidateobj.Band = "";

            }
            else
            {
                candidateobj.Band = drpBand.SelectedItem.Text.ToString();

            }
            if (drpCOE.SelectedItem.Text == "--Select--")
            {
                candidateobj.COE = "";
            }

            if (drpCOE.SelectedItem.Text == "OTHER")
            {
                candidateobj.COE = txtCOE.Text.ToString();
            }
            else
            {
                candidateobj.COE = drpCOE.SelectedItem.Text.ToString();
            }
            if (drpPOJ.SelectedItem.Text == "--Select--")
            {
                candidateobj.PlaceofJoing = "";
            }
            else
            {
                candidateobj.PlaceofJoing = drpPOJ.SelectedItem.Text.ToString();
            }
            candidateobj.DateofJoining = txtDateOfJoining.Text.ToString();
            candidateobj.FirstName = txtFirstName.Text.ToString();
            candidateobj.MiddleName = txtMiddleName.Text.ToString();
            candidateobj.Surname = txtLastName.Text.ToString();
            candidateobj.FatherName = txtfathername.Text.ToString();
            candidateobj.DOB = txtcandidateDOB.Text.ToString();
            candidateobj.Mobile = txtcandidatemobile.Text.ToString();
            if (drpeducation.SelectedItem.Text != "--Select--")
            {
                candidateobj.EducationList = drpeducation.SelectedItem.Text;

            }
            else
            {
                candidateobj.EducationList = "";
            }
            candidateobj.Edu1_CollegeName = txt_Edu1_CollageName.Text.ToString();
            candidateobj.Edu1_UniversityName = txt_Edu1_UniversityName0.Text.ToString();
            candidateobj.Edu1_Address = txtEdu1Address.Text.ToString();
            candidateobj.Edu1_RollNo = txtedu1Rollno.Text.ToString();
            candidateobj.Edu1_YearOfPassing = txt_Edu1_YearOfPassing0.Text.ToString();
            candidateobj.Edu1_EducationalQualification = txt_Edu1_EducationalQualification.Text.ToString();

            candidateobj.Edu2_CollegeName = txt_Edu2_CollageName.Text.ToString();
            candidateobj.Edu2_UniversityName = txt_Edu2_UniversityName0.Text.ToString();
            candidateobj.Edu2_Address = txtEdu2Address.Text.ToString();
            candidateobj.Edu2_RollNo = txtedu2Rollno.Text.ToString();
            candidateobj.Edu2_YearOfPassing = txt_Edu2_YearOfPassing0.Text.ToString();
            candidateobj.Edu2_EducationalQualification = txt_Edu2_EducationalQualification.Text.ToString();

            candidateobj.Edu3_CollegeName = txt_Edu3_CollageName.Text.ToString();
            candidateobj.Edu3_UniversityName = txt_Edu3_UniversityName0.Text.ToString();
            candidateobj.Edu3_Address = txtEdu3Address.Text.ToString();
            candidateobj.Edu3_RollNo = txtedu3Rollno.Text.ToString();
            candidateobj.YearOfPassing3 = txt_Edu3_YearOfPassing0.Text.ToString();
            candidateobj.Edu3_EducationalQualification = txt_Edu3_EducationalQualification.Text.ToString();

            candidateobj.Edu4_CollegeName = txt_Edu4_CollageName.Text.ToString();
            candidateobj.Edu4_UniversityName = txt_Edu4_UniversityName0.Text.ToString();
            candidateobj.Edu4_Address = txtEdu4Address.Text.ToString();
            candidateobj.Edu4_RollNo = txtedu4Rollno.Text.ToString();
            candidateobj.YearOfPassing4 = txt_Edu4_YearOfPassing0.Text.ToString();
            candidateobj.Edu4_EducationalQualification = txt_Edu4_EducationalQualification.Text.ToString();

            candidateobj.Edu5_CollegeName = txt_Edu5_CollageName.Text.ToString();
            candidateobj.Edu5_UniversityName = txt_Edu5_UniversityName0.Text.ToString();
            candidateobj.Edu5_Address = txtEdu5Address.Text.ToString();
            candidateobj.Edu5_RollNo = txtedu5Rollno.Text.ToString();
            candidateobj.YearOfPassing5 = txt_Edu5_YearOfPassing0.Text.ToString();
            candidateobj.Edu5_EducationalQualification = txt_Edu5_EducationalQualification.Text.ToString();

            candidateobj.Edu6_CollegeName = txt_Edu6_CollageName.Text.ToString();
            candidateobj.Edu6_UniversityName = txt_Edu6_UniversityName0.Text.ToString();
            candidateobj.Edu6_Address = txtEdu6Address.Text.ToString();
            candidateobj.Edu6_RollNo = txtedu6Rollno.Text.ToString();
            candidateobj.YearOfPassing6 = txt_Edu6_YearOfPassing0.Text.ToString();
            candidateobj.Edu6_EducationalQualification = txt_Edu6_EducationalQualification.Text.ToString();

            candidateobj.Edu7_CollegeName = txt_Edu7_CollageName.Text.ToString();
            candidateobj.Edu7_UniversityName = txt_Edu7_UniversityName0.Text.ToString();
            candidateobj.Edu7_Address = txtEdu7Address.Text.ToString();
            candidateobj.Edu7_RollNo = txtedu7Rollno.Text.ToString();
            candidateobj.YearOfPassing7 = txt_Edu7_YearOfPassing0.Text.ToString();
            candidateobj.Edu7_EducationalQualification = txt_Edu7_EducationalQualification.Text.ToString();

            candidateobj.Edu8_CollegeName = txt_Edu8_CollageName.Text.ToString();
            candidateobj.Edu8_UniversityName = txt_Edu8_UniversityName0.Text.ToString();
            candidateobj.Edu8_Address = txtEdu8Address.Text.ToString();
            candidateobj.Edu8_RollNo = txtedu8Rollno.Text.ToString();
            candidateobj.YearOfPassing8 = txt_Edu8_YearOfPassing0.Text.ToString();
            candidateobj.Edu8_EducationalQualification = txt_Edu8_EducationalQualification.Text.ToString();


            if (dropaddress.SelectedItem.Text == "Address Check")
            {
                candidateobj.AddressCheck = dropaddress.SelectedItem.Text;

            }
            else
            {
                candidateobj.AddressCheck = "";

            }
            candidateobj.PermanentAddress = txtaddress1parmanent.Text.ToString();

            if (txtAddressparmentstate.SelectedItem.Text != "--Select--")
            {
                candidateobj.Per_State = txtAddressparmentstate.SelectedItem.Text.ToString();
            }



            candidateobj.Per_City = txtadd1parmanentcity.Text.ToString();
            candidateobj.Per_AddressPhoneNo = txt_parmanetSTD.Text.ToString() + "-" + txt_parmanent_PhoneNo.Text.ToString();
            candidateobj.Per_Landmark = txtadd1parmanentlandmark.Text.ToString();
            if (txtadd1livingsince.SelectedItem.Text != "--Select--")
            {
                candidateobj.Per_LivingSince = txtadd1livingsince.SelectedItem.Text.ToString();
            }
            candidateobj.Per_LivingSince = "";
            candidateobj.Per_PoliceStation = txtadd1policestation.Text.ToString();
            candidateobj.Per_PostOffice = txtadd1pincode.Text.ToString();

            candidateobj.add1logeststay = txtadd1logeststay.Text.ToString();

            if (txtaddlongstaystate.SelectedItem.Text != "--Select--")
            {
                candidateobj.add1logeststarystate = txtaddlongstaystate.SelectedItem.Text.ToString();
            }

            candidateobj.add1logeststarycity = txtaddlongeststaycity.Text.ToString();
            candidateobj.add1logeststaryphonenumber = txtlogstaySTd.Text.ToString() + "-" + txtlongstayNumber.Text.ToString();
            candidateobj.add1logeststarylandmark = txtlongstaylandmark.Text.ToString();
            if (txtlongstaylivingsince.SelectedItem.Text != "--Select--")
            {
                candidateobj.add1logeststaryLeavingsince = txtlongstaylivingsince.SelectedItem.Text.ToString();
            }

            candidateobj.add1logeststaryLeavingsince = "";
            candidateobj.add1logeststarypolicestation = txtlongstaypolicestation.Text.ToString();
            candidateobj.add1logeststarypincode = txtlongstaypincode.Text.ToString();

            candidateobj.CurrentAddress = txtaddcurrentaddres.Text.ToString();

            if (txtaddcurrentstate.SelectedItem.Text != "--Select--")
            {
                candidateobj.Curr_State = txtaddcurrentstate.SelectedItem.Text.ToString();
            }



            candidateobj.Curr_City = txtaddcurentcity.Text.ToString();
            candidateobj.Curr_PhoneNo = txtaddcurentSTD.Text.ToString() + "-" + txtaddcurrentnumber.Text.ToString();
            //string chk1 = "";
            //string chk2 = "";
            //string chk3 = "";

            //if (chkcriminal1.Checked == true)
            //{
            //    chk1 = "1";
            //    candidateobj.criminalchk1 = chk1.ToString();

            //}
            //else
            //{
            //    candidateobj.criminalchk1 = "";
            //}

            //if (chkcriminal2.Checked == true)
            //{
            //    chk2 = "2";
            //    candidateobj.criminalchk2 = chk2.ToString();

            //}
            //else
            //{
            //    candidateobj.criminalchk2 = "";
            //}


            //if (chkcriminal3.Checked == true)
            //{
            //    chk3 = "3";
            //    candidateobj.criminalchk3 = chk3.ToString();

            //}
            //else
            //{
            //    candidateobj.criminalchk3 = "";
            //}
            if (dropFresherexp.SelectedItem.Text == "Fresher")
            {
                candidateobj.FresherOrExp = "";
            }
            else
            {
                candidateobj.FresherOrExp = dropFresherexp.SelectedItem.Text.ToString();
            }
            if (drpnoofcompany.SelectedItem.Text == "--Select--")
            {
                candidateobj.NoOfComp = "";
            }
            else
            {
                if (drpnoofcompany.SelectedItem.Text == "1")
                {
                    candidateobj.NoOfComp = "Company1";

                }
                if (drpnoofcompany.SelectedItem.Text == "2")
                {
                    candidateobj.NoOfComp = "Company2";

                }
                //if (drpnoofcompany.SelectedItem.Text == "3")
                //{
                //    candidateobj.NoOfComp = "Company3";

                //}
                //if (drpnoofcompany.SelectedItem.Text == "4")
                //{
                //    candidateobj.NoOfComp = "Company4";

                //}
                //if (drpnoofcompany.SelectedItem.Text == "5")
                //{
                //    candidateobj.NoOfComp = "Company5";

                //}

                candidateobj.NoOfComp = drpnoofcompany.SelectedItem.Text.ToString();
            }
            candidateobj.EmpHis1_CompnayNameandLocation = txtcmpy1nameloction.Text.ToString();
            candidateobj.EmpHis1_LastPositionHeldnDepartmentName = txtcmp1lastpostin.Text.ToString();
            candidateobj.cmp1department = txtcmp1department.Text.ToString();
            candidateobj.EmpHis1_TelephoneNo = txtcmp1Std.Text.ToString() + "-" + txtcmp1number.Text.ToString();
            candidateobj.EmpHis1_Address = txtemp1officeaddress.Text.ToString();
            candidateobj.EmpHis1_EmployeeCode = txtemp1employecode.Text.ToString();
            candidateobj.ExperienceInYears1 = txtcmpny1expinyear.Text.ToString();
            candidateobj.EmpHis1_PeriodofEmployment = periodofemployment1.Text.ToString();
            candidateobj.EmpHis1_PeriodofEmploymentRemark = periodofemptilldate1.Text.ToString();
            candidateobj.EmpHis1RLvl1_NameDesignatinOfSupervisor = txtemp1namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp1HRdesignation = txtcmp1hrdesignation.Text.ToString();
            candidateobj.EmpHis1RLvl1_TelepnoneNo = txtemp1supervisorlevel1STD.Text.ToString() + "-" + txtemp1supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis1RLvl1_MobileNo = txtemp1supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis1RLvl1_EmailId = txtemp1supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis1RLvl2_NameDesignatinOfSupervisor = txtemp1namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp1RMdesignation = txtcmp1supervisordesignation.Text.ToString();

            candidateobj.EmpHis1RLvl2_TelepnoneNo = txtemp1supervisorlevel2STD.Text.ToString() + "-" + txtemp1supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis1RLvl2_MobileNo = txtemp1supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis1RLvl2_EmailId = txtemp1supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis1_TempPerma = RadioButtoncmp1emptype.SelectedValue.ToString();
            candidateobj.EmpHis1_AgencyDetails = emp1agencydetail.Text.ToString();
            candidateobj.EmpHis1_RemunerationOrSalary = emp1remunerationsalary.Text.ToString();
            candidateobj.EmpHis1_ReasonOfLeaving = emp1reasonofleaving.Text.ToString();
            candidateobj.EmpHis1_referenceYN = emp1referenceYN.SelectedValue.ToString();
            //candidateobj.EmpHis1_IncaseOfGap = emp1incaseofgap.Text.ToString();
            candidateobj.EmpHis1_NoticePeriodorNot = RadioButtonemp1noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis2_CompnayNameandLocation = txtemp2compnyname.Text.ToString();
            candidateobj.EmpHis2_LastPositionHeldnDepartmentName = txtemp2lastposition.Text.ToString();
            candidateobj.cmp2department = txtcmp2department.Text.ToString();
            candidateobj.EmpHis2_TelephoneNo = emp2cmpSTD.Text.ToString() + "-" + emp2cmpnumber.Text.ToString();
            candidateobj.EmpHis2_Address = txtemp2officeaddress.Text.ToString();
            candidateobj.EmpHis2_EmployeeCode = txtemp2employeecode.Text.ToString();
            candidateobj.ExperienceInYears2 = txtemp2experience.Text.ToString();
            candidateobj.EmpHis2_PeriodofEmployment = periodofemployment2.Text.ToString();
            candidateobj.EmpHis2_PeriodofEmploymentRemark = periodofemptilldate2.Text.ToString();
            candidateobj.EmpHis2RLvl1_NameDesignatinOfSupervisor = txtemp2namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp2HRdesignation = txtcmp2hrdesignation.Text.ToString();

            candidateobj.EmpHis2RLvl1_TelepnoneNo = txtemp2supervisorlevel1STD.Text.ToString() + "-" + txtemp2supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis2RLvl1_MobileNo = txtemp2supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis2RLvl1_EmailId = txtemp2supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis2RLvl2_NameDesignatinOfSupervisor = txtemp2namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp2RMdesignation = txtcmp2supervisordesignation.Text.ToString();

            candidateobj.EmpHis2RLvl2_TelepnoneNo = txtemp2supervisorlevel2STD.Text.ToString() + "-" + txtemp2supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis2RLvl2_MobileNo = txtemp2supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis2RLvl2_EmailId = txtemp2supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis2_TempPerma = RadioButtoncmp2emptype.SelectedValue.ToString();
            candidateobj.EmpHis2_AgencyDetails = emp2agencydetail.Text.ToString();
            candidateobj.EmpHis2_RemunerationOrSalary = emp2remunerationsalary.Text.ToString();
            candidateobj.EmpHis2_ReasonOfLeaving = emp2reasonofleaving.Text.ToString();
            candidateobj.EmpHis2_referenceYN = emp2referenceYN.Text.ToString();
            // candidateobj.EmpHis2_IncaseOfGap = emp2incaseofgap.Text.ToString();
            candidateobj.EmpHis2_NoticePeriodorNot = RadioButtonemp2noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis3_CompnayNameandLocation = txtemp3companyname.Text.ToString();
            candidateobj.EmpHis3_LastPositionHeldnDepartmentName = txtemp3lastposition.Text.ToString();
            candidateobj.cmp3department = cmp3department.Text.ToString();

            candidateobj.EmpHis3_TelephoneNo = emp3cmpSTD.Text.ToString() + "-" + emp3cmpnumber.Text.ToString();
            candidateobj.EmpHis3_Address = txtemp3officeaddress.Text.ToString();
            candidateobj.EmpHis3_EmployeeCode = txtemp3employeecode.Text.ToString();
            candidateobj.ExperienceInYears3 = txtemp3experienceinyear.Text.ToString();
            candidateobj.EmpHis3_PeriodofEmployment = periodofemployment3.Text.ToString();
            candidateobj.EmpHis3_PeriodofEmploymentRemark = periodofemptilldate3.Text.ToString();
            candidateobj.EmpHis3RLvl1_NameDesignatinOfSupervisor = txtemp3namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp3HRdesignation = txtcmp3hrdesignation.Text.ToString();

            candidateobj.EmpHis3RLvl1_TelepnoneNo = txtemp3supervisorlevel1STD.Text.ToString() + "-" + txtemp3supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis3RLvl1_MobileNo = txtemp3supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis3RLvl1_EmailId = txtemp3supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis3RLvl2_NameDesignatinOfSupervisor = txtemp3namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp3RMdesignation = txtcmp3supervisordesignation.Text.ToString();

            candidateobj.EmpHis3RLvl2_TelepnoneNo = txtemp3supervisorlevel2STD.Text.ToString() + "-" + txtemp3supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis3RLvl2_MobileNo = txtemp3supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis3RLvl2_EmailId = txtemp3supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis3_TempPerma = RadioButtoncmp3emptype.SelectedValue.ToString();
            candidateobj.EmpHis3_AgencyDetails = emp3agencydetail.Text.ToString();
            candidateobj.EmpHis3_RemunerationOrSalary = emp3remunerationsalary.Text.ToString();
            candidateobj.EmpHis3_ReasonOfLeaving = emp3reasonofleaving.Text.ToString();
            candidateobj.EmpHis3_referenceYN = emp3referenceYN.Text.ToString();
            //candidateobj.EmpHis3_IncaseOfGap = emp3incaseofgap.Text.ToString();
            candidateobj.EmpHis3_NoticePeriodorNot = RadioButtonemp3noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis4_CompnayNameandLocation = txtemp4companyname.Text.ToString();
            candidateobj.EmpHis4_LastPositionHeldnDepartmentName = txtemp4lastpostion.Text.ToString();
            candidateobj.cmp4department = txtcmp4department.Text.ToString();

            candidateobj.EmpHis4_TelephoneNo = emp4cmpSTD.Text.ToString() + "-" + emp4cmpnumber.Text.ToString();
            candidateobj.EmpHis4_Address = txtemp4officeaddress.Text.ToString();
            candidateobj.EmpHis4_EmployeeCode = txtemp4employeecode.Text.ToString();
            candidateobj.ExperienceInYears4 = txtemp4experience.Text.ToString();
            candidateobj.EmpHis4_PeriodofEmployment = periodofemployment4.Text.ToString();
            candidateobj.EmpHis4_PeriodofEmploymentRemark = periodofemptilldate4.Text.ToString();
            candidateobj.EmpHis4RLvl1_NameDesignatinOfSupervisor = txtemp4namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp4HRdesignation = txtcmp4hrdesignation.Text.ToString();

            candidateobj.EmpHis4RLvl1_TelepnoneNo = txtemp4supervisorlevel1STD.Text.ToString() + "-" + txtemp3supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis4RLvl1_MobileNo = txtemp4supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis4RLvl1_EmailId = txtemp4supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis4RLvl2_NameDesignatinOfSupervisor = txtemp4namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp4RMdesignation = txtcmp4supervisordesignation.Text.ToString();

            candidateobj.EmpHis4RLvl2_TelepnoneNo = txtemp4supervisorlevel2STD.Text.ToString() + "-" + txtemp3supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis4RLvl2_MobileNo = txtemp4supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis4RLvl2_EmailId = txtemp4supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis4_TempPerma = RadioButtoncmp4emptype.SelectedValue.ToString();
            candidateobj.EmpHis4_AgencyDetails = emp4agencydetail.Text.ToString();
            candidateobj.EmpHis4_RemunerationOrSalary = emp4remunerationsalary.Text.ToString();
            candidateobj.EmpHis4_ReasonOfLeaving = emp4reasonofleaving.Text.ToString();
            candidateobj.EmpHis4_referenceYN = emp4referenceYN.Text.ToString();
            //candidateobj.EmpHis4_IncaseOfGap = emp4incaseofgap.Text.ToString();
            candidateobj.EmpHis4_NoticePeriodorNot = RadioButtonemp4noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis5_CompnayNameandLocation = txtemp5companyname.Text.ToString();
            candidateobj.EmpHis5_LastPositionHeldnDepartmentName = txtemp5lastposition.Text.ToString();
            candidateobj.cmp5department = txtcmp5department.Text.ToString();

            candidateobj.EmpHis5_TelephoneNo = emp5cmpSTD.Text.ToString() + "-" + emp5cmpnumber.Text.ToString();
            candidateobj.EmpHis5_Address = txtemp5officeaddress.Text.ToString();
            candidateobj.EmpHis5_EmployeeCode = txtemp5employeecode.Text.ToString();
            candidateobj.ExperienceInYears5 = txtemp5experience.Text.ToString();
            candidateobj.EmpHis5_PeriodofEmployment = periodofemployment5.Text.ToString();
            candidateobj.EmpHis5_PeriodofEmploymentRemark = periodofemptilldate5.Text.ToString();
            candidateobj.EmpHis5RLvl1_NameDesignatinOfSupervisor = txtemp5namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp5HRdesignation = txtcmp5hrdesignation.Text.ToString();

            candidateobj.EmpHis5RLvl1_TelepnoneNo = txtemp5supervisorlevel1STD.Text.ToString() + "-" + txtemp3supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis5RLvl1_MobileNo = txtemp5supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis5RLvl1_EmailId = txtemp5supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis5RLvl2_NameDesignatinOfSupervisor = txtemp5namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp5RMdesignation = txtcmp5supervisordesignation.Text.ToString();

            candidateobj.EmpHis5RLvl2_TelepnoneNo = txtemp5supervisorlevel2STD.Text.ToString() + "-" + txtemp5supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis5RLvl2_MobileNo = txtemp5supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis5RLvl2_EmailId = txtemp5supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis5_TempPerma = RadioButtoncmp5emptype.SelectedValue.ToString();
            candidateobj.EmpHis5_AgencyDetails = emp5agencydetail.Text.ToString();
            candidateobj.EmpHis5_RemunerationOrSalary = emp5remunerationsalary.Text.ToString();
            candidateobj.EmpHis5_ReasonOfLeaving = emp5reasonofleaving.Text.ToString();
            candidateobj.EmpHis5_referenceYN = emp5referenceYN.Text.ToString();
            //candidateobj.EmpHis5_IncaseOfGap = emp5incaseofgap.Text.ToString();
            candidateobj.EmpHis5_NoticePeriodorNot = RadioButtonemp5noticeperiodYN.SelectedValue.ToString();

            candidateobj.CurrentEmployment = radiobuttoncurrentemp.SelectedValue.ToString();




            candidateobj.RejectedRemarks1 = RejectedRemark1.Text.ToString();
            candidateobj.RejectedRemarks2 = RejectedRemark2.Text.ToString();
            candidateobj.RejectedRemarks3 = RejectedRemark3.Text.ToString();
            candidateobj.RejectedRemarks4 = RejectedRemark4.Text.ToString();
            candidateobj.RejectedRemarks5 = RejectedRemark5.Text.ToString();

            candidateobj.comment1 = comment1.Text.ToString();
            candidateobj.comment2 = comment2.Text.ToString();
            candidateobj.comment3 = comment3.Text.ToString();
            candidateobj.comment4 = comment4.Text.ToString();
            candidateobj.comment5 = comment5.Text.ToString();

            candidateobj.candidatealternateno = txtcandidatealternateno.Text.ToString();
            candidateobj.candidateremarks = txtcandidateremarks.Text.ToString();

            //candidateobj.CAmemeber = txtCAmember.Text.ToString();
            //---mohan
            if (ddlref.SelectedItem.Text != "--Select--")
            {
                candidateobj.RefList = ddlref.SelectedItem.Text;

            }
            else
            {
                candidateobj.RefList = "";
            }
           
            candidateobj.Ref1RefName = txtRef1RefName.Text;
            candidateobj.Ref1CompName = txtRef1CompanyName.Text;
            candidateobj.Ref1Designation = txtRef1Designation.Text;
            candidateobj.Ref1Email = txtRef1EmailId.Text;
            candidateobj.Ref1Contact = txtRef1Contact.Text;

            candidateobj.Ref2RefName = txtRef2RefName.Text;
            candidateobj.Ref2CompName = txtRef2CompanyName.Text;
            candidateobj.Ref2Designation = txtRef2Designation.Text;
            candidateobj.Ref2Email = txtRef2EmailId.Text;
            candidateobj.Ref2Contact = txtRef2Contact.Text;

            if (ddlcibil.SelectedItem.Text != "--Select--")
            {
                candidateobj.CIBILList = ddlcibil.SelectedItem.Text;

            }
            else
            {
                candidateobj.CIBILList = "";
            }
            candidateobj.CIBILContact = txtCIBILContact.Text;
            candidateobj.CIBILDOB = dtpCIBILDOB.Text;
            candidateobj.CIBILEmail = txtCIBILEmail.Text;
            candidateobj.CIBILFullName = txtCIBILFullName.Text;
            candidateobj.CIBILGender = ddlCIBILgender.Text;
            candidateobj.CIBILPanCard = txtCIBILPanCard.Text;
            candidateobj.CIBILpassportno = txtCIBILpasportno.Text;
            candidateobj.CIBILvoterID = txtCIBILvoterid.Text;
            candidateobj.CIBILDrivinglicense = txtCIBILlience.Text;

            


            string username = User.Identity.Name.ToString();
            candidateobj.user = username.ToString();
            if (cid == "0" || cid == "")
            {
                candidateobj.Mode = "0";
            }
            else
            {
                candidateobj.Mode = Request.QueryString["mode"];
            }

            string url;
            url = "saveinfo.aspx?type=" + candidateobj.Mode;

            candidateobj.CandidateID = Convert.ToInt32(cid);

            string usertype = "";
            if (string.IsNullOrEmpty(Convert.ToString(Session["UserType"])))
            {
                Response.Redirect("CandidateLogin.aspx");
            }
            else
            {
                usertype = Session["UserType"].ToString();
            }


            if (txtFirstName.Text != "" || drpCOE.SelectedItem.Text != "Select")
            {


                int dtInsert = candidateobj.saveband4CandidateDetails(candidateobj);

                if (dtInsert == 0)
                {

                    if (usertype != "ClientPlusReject" && usertype != "Admin")
                    {
                        Response.Redirect(url);
                    }
                    else
                    {
                        Response.Write("<Script Language='javascript'> alert('Data Updated !')</Script>");
                    }



                }
                else if (dtInsert == -2)
                {

                    Response.Write("<Script Language='javascript'> alert('Already Data Saved !')</Script>");
                }
                else if (dtInsert == -1)
                {

                    Response.Write("<Script Language='javascript'> alert('Error In Procedure...InsertEmployeeInfo!')</Script>");
                }



            }
        //}

        //else
        //{
        //    Response.Write("<Script Language='javascript'> alert('Please Fill Education Related Information')</Script>");

        //}

        //}


        //}

        //catch (Exception ex)
        //{

        //    Response.Write("<Script Language='javascript'> alert('EXCEPTION!!!!)</Script>");

        //}


    }
    protected void drpnoofcompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpnoofcompany.SelectedValue == "0")
        {
            Cmp1.Visible = false;
            Cmp2.Visible = false;
            Cmp3.Visible = false;
            Cmp4.Visible = false;
            Cmp5.Visible = false;

        }
        if (drpnoofcompany.SelectedValue == "1")
        {
            Cmp1.Visible = true;
            Cmp2.Visible = false;
            Cmp3.Visible = false;
            Cmp4.Visible = false;
            Cmp5.Visible = false;

            Page.Validate();
        }
        if (drpnoofcompany.SelectedValue == "2")
        {
            Cmp1.Visible = true;
            Cmp2.Visible = true;
            Cmp3.Visible = false;
            Cmp4.Visible = false;
            Cmp5.Visible = false;

            Page.Validate();
        }
        //if (drpnoofcompany.SelectedValue == "3")
        //{
        //    Cmp1.Visible = true;
        //    Cmp2.Visible = true;
        //    Cmp3.Visible = true;
        //    Cmp4.Visible = false;
        //    Cmp5.Visible = false;

        //    Page.Validate();
        //}
        //if (drpnoofcompany.SelectedValue == "4")
        //{
        //    Cmp1.Visible = true;
        //    Cmp2.Visible = true;
        //    Cmp3.Visible = true;
        //    Cmp4.Visible = true;
        //    Cmp5.Visible = false;

        //    Page.Validate();
        //}
        //if (drpnoofcompany.SelectedValue == "5")
        //{
        //    Cmp1.Visible = true;
        //    Cmp2.Visible = true;
        //    Cmp3.Visible = true;
        //    Cmp4.Visible = true;
        //    Cmp5.Visible = true;

        //    Page.Validate();

        //}

    }
    protected void dropaddress_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (dropaddress.SelectedValue == "0")
        {
            ad1.Visible = false;

        }
        if (dropaddress.SelectedValue == "Address Check")
        {
            ad1.Visible = true;
            Page.Validate();
        }
    }

    protected void dropFresherexp_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (dropFresherexp.SelectedValue == "0")
        {
            Cmp1.Visible = false;
            drpnoofcompany.Enabled = false;
            radiobuttoncurrentemp.Enabled = false;
        }
        if (dropFresherexp.SelectedValue == "Fresher")
        {
            Cmp1.Visible = false;
            drpnoofcompany.Enabled = false;
            radiobuttoncurrentemp.Enabled = false;
        }
        if (dropFresherexp.SelectedValue == "Experienced")
        {
            Cmp1.Visible = true;
            drpnoofcompany.Enabled = true;
            radiobuttoncurrentemp.Enabled = true;
        }
    }
    protected void FillCandidateData()
    {
        string usertype = Session["UserType"].ToString();

        if (usertype == "ClientPlusReject")
        {
            if (Request.QueryString["bgcview"] == "fresh")
            {
                rc.Visible = true;
            }
            else
            {
                rc.Visible = true;
            }
            btnSave.Visible = true;
            btnSave.Enabled = true;


            RejectedRemark1.ReadOnly = false;
            RejectedRemark2.ReadOnly = false;
            RejectedRemark3.ReadOnly = false;
            RejectedRemark4.ReadOnly = false;
            RejectedRemark5.ReadOnly = false;



            comment1.ReadOnly = true;
            comment2.ReadOnly = true;
            comment3.ReadOnly = true;
            comment4.ReadOnly = true;
            comment5.ReadOnly = true;

           

            RequiredFieldValidator4.EnableClientScript = false;
            CompareValidator1.EnableClientScript = false;
            //COEvalidation.EnableClientScript = false;
            //RequiredFieldValidator11.EnableClientScript = false;



        }

        if (usertype == "Admin")
        {
            rc.Visible = true;
            btnSave.Visible = true;
            btnSave.Enabled = true;
            COEvalidation.EnableClientScript = false;
            //RequiredFieldValidatorcomment1.EnableClientScript = false;


        }

        //if (txtFirstName.Text.Length != 0)
        //{
        //    txtFirstName.ReadOnly = true;
        //    txtMiddleName.ReadOnly = true;
        //    txtLastName.ReadOnly = true;
        //    txtfathername.ReadOnly = true;
        //    txtcandidateDOB.ReadOnly = true;
        //    txtcandidatemobile.ReadOnly = true;
        //}


        string ChkMode = Request.QueryString["mode"];
        int Id = 0;
        //string ses = Session["RefID"].ToString();


        //&& Request.QueryString["bgcview"] != "vv"
        if (Request.QueryString["mode"] == "Update")
        {


            string s = cid;
            if ((s == "undefined") || (s == "") || (s=="0"))
            {
               

            }
            else
            {

                Id = Convert.ToInt32(cid);
                txtFirstName.Enabled = false;
                txtMiddleName.Enabled = false;
                txtLastName.Enabled = false;
                txtfathername.Enabled = true;
                txtcandidateDOB.Enabled = false;
                txtcandidatemobile.Enabled = false;
                RequiredFieldValidator11.EnableClientScript = false;
                CompareValidator1.EnableClientScript = false;
                txtcandidatealternateno.Enabled = false;

                txtGender.Enabled = false;
                txtmaritalstatus.Enabled = false;
                btnSave.Enabled = true;
            }
        }
        if (Request.QueryString["mode"] == "View" )
        {
            comment1.ReadOnly = false;


            txtFirstName.Enabled = false;
            txtMiddleName.Enabled = false;
            txtLastName.Enabled = false;
            txtfathername.Enabled = true;
            txtcandidateDOB.Enabled = false;
            txtcandidatemobile.Enabled = false;        
            RequiredFieldValidator11.EnableClientScript = false;
            txtcandidatealternateno.Enabled = false;

            txtGender.Enabled = false;
            txtmaritalstatus.Enabled = false;

           
            btnSave.Enabled = false;
            btnfileupload.Enabled = false;

            
            string s = cid;
            if ((s == "undefined") || (s == ""))
            {
            }
            else
            {
                Id = Convert.ToInt32(cid);
            }

            if (usertype == "ClientPlusReject" && Request.QueryString["bgcview"] != "vv")
            {
                RList.Visible = false;
                btnfileupload.Visible = true;
                // rc.Visible = true;
                btnSave.Visible = true;
                //drpPOJ.Enabled = false;
                //txtDateOfJoining.Enabled = false;
                txtFirstName.ReadOnly = true;
                txtMiddleName.ReadOnly = true;
                txtLastName.ReadOnly = true;
                txtfathername.ReadOnly = false;
                //txtcandidateDOB.ReadOnly = true;
                txtcandidateDOB.Enabled = false;
                txtcandidatemobile.ReadOnly = true;


                if (drpCOE.Text != "--Select--")
                {
                    COEvalidation.EnableClientScript = false;
                }

            }
            else
                if (usertype == "Admin")
                {
                    RList.Visible = false;


                    rc.Visible = true;
                    btnSave.Visible = true;
                    btnSave.Enabled = true;
                    CheckBox1.Enabled = false;
                    //


                    drpeducation.Enabled = false;
                    drpBand.Enabled = false;
                    drpCOE.Enabled = false;
                    COEvalidation.EnableClientScript = false;
                    CompareValidator2.EnableClientScript = false;
                    drpPOJ.Enabled = false;
                    txtDateOfJoining.Enabled = false;
                    txtFirstName.ReadOnly = true;
                    txtMiddleName.ReadOnly = true;
                    txtLastName.ReadOnly = true;
                    txtfathername.ReadOnly = true;
                    txtcandidatealternateno.ReadOnly = true;
                    //txtcandidateDOB.ReadOnly = true;
                    txtcandidateDOB.Enabled = false;
                    txtcandidatemobile.ReadOnly = true;
                    txt_Edu1_CollageName.ReadOnly = true;
                    txt_Edu1_UniversityName0.ReadOnly = true;
                    //txtCAmember.ReadOnly = true;
                    txtEdu1Address.ReadOnly = true;
                    txtedu1Rollno.ReadOnly = true;
                    txt_Edu1_YearOfPassing0.ReadOnly = true;
                    txt_Edu1_EducationalQualification.ReadOnly = true;
                    txt_Edu2_CollageName.ReadOnly = true;
                    txt_Edu2_UniversityName0.ReadOnly = true;
                    //txtCAmember.ReadOnly = true;
                    txtEdu2Address.ReadOnly = true;
                    txtedu2Rollno.ReadOnly = true;
                    txt_Edu2_YearOfPassing0.ReadOnly = true;
                    txt_Edu2_EducationalQualification.ReadOnly = true;
                    txt_Edu3_CollageName.ReadOnly = true;
                    txt_Edu3_UniversityName0.ReadOnly = true;
                    //txtCAmember.ReadOnly = true;
                    txtEdu3Address.ReadOnly = true;
                    txtedu3Rollno.ReadOnly = true;
                    txt_Edu3_YearOfPassing0.ReadOnly = true;
                    txt_Edu3_EducationalQualification.ReadOnly = true;

                    dropFresherexp.Enabled = false;
                    drpnoofcompany.Enabled = false;
                    txtcmpy1nameloction.ReadOnly = true;
                    txtcmp1lastpostin.ReadOnly = true;
                    dropaddress.Enabled = false;
                    txtaddress1parmanent.ReadOnly = true;
                    txtAddressparmentstate.Enabled = false;
                    txtadd1parmanentcity.ReadOnly = true;
                    txt_parmanetSTD.ReadOnly = true;
                    //
                    txt_parmanent_PhoneNo.ReadOnly = true;
                    txtlongstayNumber.ReadOnly = true;

                    txtadd1parmanentlandmark.ReadOnly = true;
                    txtadd1livingsince.Enabled = false;
                    txtadd1policestation.ReadOnly = true;
                    txtadd1pincode.ReadOnly = true;
                    txtadd1logeststay.ReadOnly = true;
                    txtaddlongstaystate.Enabled = false;
                    txtaddlongeststaycity.ReadOnly = true;
                    txtlogstaySTd.ReadOnly = true;
                    txtlongstaylandmark.ReadOnly = true;
                    txtlongstaylivingsince.Enabled = false;
                    txtlongstaypolicestation.ReadOnly = true;
                    txtlongstaypincode.ReadOnly = true;
                    txtaddcurrentaddres.ReadOnly = true;
                    txtaddcurrentstate.Enabled = false;

                    txtaddcurentcity.ReadOnly = true;
                    txtaddcurentSTD.ReadOnly = true;
                    txtaddcurrentnumber.ReadOnly = true;
                    dropFresherexp.Enabled = false;
                    drpnoofcompany.Enabled = false;
                    txtcmpy1nameloction.ReadOnly = true;
                    txtcmp1lastpostin.ReadOnly = true;

                    txtaddcurentSTD.ReadOnly = true;
                    txtaddcurrentnumber.ReadOnly = true;

                    txtemp1officeaddress.ReadOnly = true;
                    txtemp1employecode.ReadOnly = true;
                    txtcmpny1expinyear.ReadOnly = true;
                    periodofemployment1.Enabled = false;
                    periodofemptilldate1.Enabled = false;
                    txtemp1namedesignationofsupervisorlevel1.ReadOnly = true;
                    txtemp1supervisorlevel1moblie.ReadOnly = true;
                    txtemp1supervisorlevel1email.ReadOnly = true;
                    txtemp1namedesignationofsupervisorlevel2.ReadOnly = true;
                    txtemp1supervisorlevel2mobile.ReadOnly = true;
                    txtemp1supervisorlevel2email.ReadOnly = true;
                    RadioButtoncmp1emptype.Enabled = false;
                    emp1agencydetail.ReadOnly = true;
                    emp1remunerationsalary.ReadOnly = true;
                    emp1reasonofleaving.ReadOnly = true;
                    emp1referenceYN.Enabled = false;
                    // emp1incaseofgap.ReadOnly = true;
                    RadioButtonemp1noticeperiodYN.Enabled = false;
                    //disable comp2

                    txtemp2compnyname.ReadOnly = true;
                    txtemp2lastposition.ReadOnly = true;

                    txtemp2officeaddress.ReadOnly = true;



                    txtemp2employeecode.ReadOnly = true;
                    txtemp2experience.ReadOnly = true;
                    periodofemployment2.Enabled = false;
                    periodofemptilldate2.Enabled = false;
                    txtemp2namedesignationofsupervisorlevel1.ReadOnly = true;



                    txtemp2supervisorlevel1moblie.ReadOnly = true;
                    txtemp2supervisorlevel1email.ReadOnly = true;
                    txtemp2namedesignationofsupervisorlevel2.ReadOnly = true;
                    txtemp2supervisorlevel2mobile.ReadOnly = true;
                    txtemp2supervisorlevel2email.ReadOnly = true;
                    RadioButtoncmp2emptype.Enabled = false;
                    emp2agencydetail.ReadOnly = true;
                    emp2remunerationsalary.ReadOnly = true;
                    emp2reasonofleaving.ReadOnly = true;
                    emp2referenceYN.ReadOnly = true;
                    // emp2incaseofgap.ReadOnly = true;
                    RadioButtonemp2noticeperiodYN.Enabled = false;

                    //comp3


                    txtemp3companyname.ReadOnly = true;
                    txtemp3lastposition.ReadOnly = true;

                    txtemp3officeaddress.ReadOnly = true;



                    txtemp3employeecode.ReadOnly = true;
                    txtemp3experienceinyear.ReadOnly = true;
                    periodofemployment3.Enabled = false;
                    periodofemptilldate3.Enabled = false;
                    txtemp3namedesignationofsupervisorlevel1.ReadOnly = true;



                    txtemp3supervisorlevel1moblie.ReadOnly = true;
                    txtemp3supervisorlevel1email.ReadOnly = true;
                    txtemp3namedesignationofsupervisorlevel2.ReadOnly = true;
                    txtemp3supervisorlevel2mobile.ReadOnly = true;
                    txtemp3supervisorlevel2email.ReadOnly = true;
                    RadioButtoncmp3emptype.Enabled = false;
                    emp3agencydetail.ReadOnly = true;
                    emp3remunerationsalary.ReadOnly = true;
                    emp3reasonofleaving.ReadOnly = true;
                    emp3referenceYN.ReadOnly = true;
                    // emp3incaseofgap.ReadOnly = true;
                    RadioButtonemp3noticeperiodYN.Enabled = false;
                    //cmp 4

                    txtemp4companyname.ReadOnly = true;
                    txtemp4lastpostion.ReadOnly = true;

                    txtemp4officeaddress.ReadOnly = true;



                    txtemp4employeecode.ReadOnly = true;
                    txtemp4experience.ReadOnly = true;

                    periodofemployment4.Enabled = false;
                    periodofemptilldate4.Enabled = false;
                    txtemp4namedesignationofsupervisorlevel1.ReadOnly = true;



                    txtemp4supervisorlevel1moblie.ReadOnly = true;
                    txtemp4supervisorlevel1email.ReadOnly = true;
                    txtemp4namedesignationofsupervisorlevel2.ReadOnly = true;
                    txtemp4supervisorlevel2mobile.ReadOnly = true;
                    txtemp4supervisorlevel2email.ReadOnly = true;
                    RadioButtoncmp4emptype.Enabled = false;

                    emp4remunerationsalary.ReadOnly = true;
                    emp4reasonofleaving.ReadOnly = true;
                    emp4referenceYN.ReadOnly = true;

                    RadioButtonemp4noticeperiodYN.Enabled = false;

                    //cmp5

                    txtemp5companyname.ReadOnly = true;
                    txtemp5lastposition.ReadOnly = true;

                    txtemp5officeaddress.ReadOnly = true;



                    txtemp5employeecode.ReadOnly = true;
                    txtemp5experience.ReadOnly = true;

                    periodofemployment5.Enabled = false;
                    periodofemptilldate5.Enabled = false;
                    txtemp5namedesignationofsupervisorlevel1.ReadOnly = true;



                    txtemp5supervisorlevel1moblie.ReadOnly = true;
                    txtemp5supervisorlevel1email.ReadOnly = true;
                    txtemp5namedesignationofsupervisorlevel2.ReadOnly = true;
                    txtemp5supervisorlevel2mobile.ReadOnly = true;
                    txtemp5supervisorlevel2email.ReadOnly = true;
                    RadioButtoncmp5emptype.Enabled = false;
                    emp5agencydetail.ReadOnly = true;
                    emp5remunerationsalary.ReadOnly = true;
                    emp5reasonofleaving.ReadOnly = true;
                    emp5referenceYN.ReadOnly = true;

                    RadioButtonemp5noticeperiodYN.Enabled = false;
                    radiobuttoncurrentemp.Enabled = false;



                    txtcmp1Std.ReadOnly = true;
                    txtcmp1number.ReadOnly = true;




                    txtemp1supervisorlevel1STD.Enabled = false;
                    txtemp1supervisorlevel1number.Enabled = false;

                    txtemp1supervisorlevel2STD.Enabled = false;
                    txtemp1supervisorlevel2number.Enabled = false;
                    txtcmp1department.ReadOnly = true;
                    txtcmp2department.ReadOnly = true;

                    cmp3department.ReadOnly = true;
                    txtcmp4department.ReadOnly = true;
                    txtcmp5department.ReadOnly = true;

                    txtcmp1hrdesignation.ReadOnly = true;
                    txtcmp2hrdesignation.ReadOnly = true;
                    txtcmp3hrdesignation.ReadOnly = true;
                    txtcmp4hrdesignation.ReadOnly = true;
                    txtcmp5hrdesignation.ReadOnly = true;

                    txtcmp1supervisordesignation.ReadOnly = true;
                    txtcmp2supervisordesignation.ReadOnly = true;
                    txtcmp3supervisordesignation.ReadOnly = true;
                    txtcmp4supervisordesignation.ReadOnly = true;
                    txtcmp5supervisordesignation.ReadOnly = true;


                    txtemp2supervisorlevel1STD.ReadOnly = true;
                    txtemp2supervisorlevel1number.ReadOnly = true;

                    txtemp3supervisorlevel1STD.ReadOnly = true;
                    txtemp3supervisorlevel1number.ReadOnly = true;


                    txtemp4supervisorlevel1STD.ReadOnly = true;
                    txtemp4supervisorlevel1number.ReadOnly = true;

                    txtemp5supervisorlevel1STD.ReadOnly = true;
                    txtemp5supervisorlevel1number.ReadOnly = true;

                    txtemp2supervisorlevel2STD.ReadOnly = true;
                    txtemp2supervisorlevel2number.ReadOnly = true;
                    ///
                    txtemp3supervisorlevel2STD.ReadOnly = true;
                    txtemp3supervisorlevel2number.ReadOnly = true;

                    txtemp4supervisorlevel2STD.ReadOnly = true;
                    txtemp4supervisorlevel2number.ReadOnly = true;

                    txtemp5supervisorlevel2STD.ReadOnly = true;
                    txtemp5supervisorlevel2number.ReadOnly = true;

                    emp2cmpSTD.ReadOnly = true;
                    emp2cmpnumber.ReadOnly = true;

                    emp3cmpSTD.ReadOnly = true;
                    emp3cmpnumber.ReadOnly = true;

                    emp4cmpSTD.ReadOnly = true;
                    emp4cmpnumber.ReadOnly = true;

                    emp5cmpSTD.ReadOnly = true;
                    emp5cmpnumber.ReadOnly = true;





                    txtGender.Enabled = false;
                    txtmaritalstatus.Enabled = false;
                    txtRef1RefName.ReadOnly = true;
                    txtRef1CompanyName.ReadOnly = true;
                    txtRef1Designation.ReadOnly = true;
                    txtRef1EmailId.ReadOnly = true;
                    txtRef1Contact.ReadOnly = true;
                    txtRef2RefName.ReadOnly = true;
                    txtRef2CompanyName.ReadOnly = true;
                    txtRef2Designation.ReadOnly = true;
                    txtRef2EmailId.ReadOnly = true;
                    txtRef2Contact.ReadOnly = true;
                    ddlref.Enabled = false;
                    ddlcibil.Enabled = false;
                    txtCIBILFullName.ReadOnly = true;
                    dtpCIBILDOB.ReadOnly = true;
                    ddlCIBILgender.Enabled = false;
                    txtCIBILEmail.ReadOnly = true;
                    txtCIBILContact.ReadOnly = true;
                    txtCIBILPanCard.ReadOnly = true;
                    txtCIBILpasportno.ReadOnly = true;
                    txtCIBILvoterid.ReadOnly = true;
                    txtCIBILlience.ReadOnly = true;


                    ////////



                }
                else
                {
                    btnSave.Visible = false;
                    //btnfileupload.Enabled = false;
                    RList.Visible = false;
                }


            if(Request.QueryString["bgcview"] == "vv")
            {


                txt_Edu1_CollageName.Enabled = false;
                txt_Edu1_UniversityName0.Enabled = false;
                //txtCAmember.ReadOnly = true;
                txtEdu1Address.Enabled = false;
                txtedu1Rollno.Enabled = false;
                txt_Edu1_YearOfPassing0.Enabled = false;
                txt_Edu1_EducationalQualification.Enabled = false;




                txtcandidatealternateno.Enabled = false;

                CheckBox1.Enabled = false;
                txtcmpy1nameloction.Enabled = false;
                txtcmp1lastpostin.Enabled = false;
                RadioButtonemp1noticeperiodYN.Enabled = false;
                txtcmp1Std.Enabled = false;
                txtcmp1hrdesignation.Enabled = false;
                txtemp1supervisorlevel1STD.Enabled = false;
                txtemp1supervisorlevel1number.Enabled = false;
                txtcmp1supervisordesignation.Enabled = false;
                txtemp1supervisorlevel2STD.Enabled=false;
                txtemp1supervisorlevel2number.Enabled = false;




                dropFresherexp.Enabled = false;

                txtcmp1number.Enabled = false;
                txtcmp1department.Enabled = false;
                txtemp1officeaddress.Enabled = false;
                txtemp1employecode.Enabled = false;
                txtcmpny1expinyear.Enabled = false;
                periodofemployment1.Enabled = false;
                periodofemptilldate1.Enabled = false;
                txtemp1namedesignationofsupervisorlevel1.Enabled = false;
                txtemp1supervisorlevel1moblie.Enabled = false;
                txtemp1supervisorlevel1email.Enabled = false;
                txtemp1namedesignationofsupervisorlevel2.Enabled = false;
                txtemp1supervisorlevel2mobile.Enabled = false;
                txtemp1supervisorlevel2email.Enabled = false;
                RadioButtoncmp1emptype.Enabled = false;
                emp1agencydetail.Enabled = false;
                emp1remunerationsalary.Enabled = false;
                emp1reasonofleaving.Enabled = false;
                emp1referenceYN.Enabled = false;


                txtGender.Enabled = false;
                txtmaritalstatus.Enabled = false;

                txtRef1RefName.Enabled = false;
                txtRef1CompanyName.Enabled = false;
                txtRef1Designation.Enabled = false;
                txtRef1EmailId.Enabled = false;
                txtRef1Contact.Enabled = false;
                txtRef2RefName.Enabled = false;
                txtRef2CompanyName.Enabled = false;
                txtRef2Designation.Enabled = false;
                txtRef2EmailId.Enabled = false;
                txtRef2Contact.Enabled = false;
                ddlref.Enabled = false;







                ddlcibil.Enabled = false;
                txtCIBILFullName.Enabled = false;
                dtpCIBILDOB.Enabled = false;
                ddlCIBILgender.Enabled = false;
                txtCIBILEmail.Enabled = false;
                txtCIBILContact.Enabled = false;
                txtCIBILPanCard.Enabled = false;
                txtCIBILpasportno.Enabled = false;
                txtCIBILvoterid.Enabled = false;
                txtCIBILlience.Enabled = false;







                comment1.Enabled = false;
                comment2.Enabled = false;
                comment3.Enabled = false;
                comment4.Enabled = false;
                comment5.Enabled = false;




            }

        }
        else
        {
           
            
            

        }
        

        DataSet dsEmployeeInfo = new DataSet();
        CandidateDetails objinfo = new CandidateDetails();
        dsEmployeeInfo = objinfo.SelectData(Id);
        if (dsEmployeeInfo.Tables[0].Rows.Count > 0)
        {
            //string ddd = dsEmployeeInfo.Tables[0].Rows[0]["HaveAccount"].ToString();


            //string pen = dsEmployeeInfo.Tables[0].Rows[0]["HavePAN"].ToString();



            if (grdFileUploadDownload.Rows.Count > 0)
            {
                btnSave.Enabled = true;
            }

            drpBand.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Band"].ToString();


            //if (dsEmployeeInfo.Tables[0].Rows[0]["COE"].ToString() != "--Select--")
            //{
            string coe = dsEmployeeInfo.Tables[0].Rows[0]["COE"].ToString();
            drpCOE.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["COE"].ToString();
            //}
            //else
            //{
            // drpCOE.SelectedItem.Text = "--Select--";


            //}


            drpPOJ.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["PlaceofJoing"].ToString();
            if (drpPOJ.SelectedItem.Text != "--Select--")
            {
                CompareValidator2.EnableClientScript = false;
            }


            txtcandidatealternateno.Text = dsEmployeeInfo.Tables[0].Rows[0]["CandidateAlternateNo"].ToString();
            txtcandidateremarks.Text = dsEmployeeInfo.Tables[0].Rows[0]["CandidateRemarks"].ToString();

            txtDateOfJoining.Text = dsEmployeeInfo.Tables[0].Rows[0]["DOJ"].ToString();

            txtFirstName.Text = dsEmployeeInfo.Tables[0].Rows[0]["FirstName"].ToString();

            txtMiddleName.Text = dsEmployeeInfo.Tables[0].Rows[0]["MiddleName"].ToString();

            txtLastName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Surname"].ToString();

            txtfathername.Text = dsEmployeeInfo.Tables[0].Rows[0]["FatherName"].ToString();

            txtcandidateDOB.Text = dsEmployeeInfo.Tables[0].Rows[0]["DOB"].ToString();

            txtcandidatemobile.Text = dsEmployeeInfo.Tables[0].Rows[0]["Mobile"].ToString();
            txtGender.Text = dsEmployeeInfo.Tables[0].Rows[0]["Gender"].ToString();
            txtmaritalstatus.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["MaritalStatus"].ToString();
            if (dsEmployeeInfo.Tables[0].Rows[0]["educationcheck"].ToString() != "")
            {
                drpeducation.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["educationcheck"].ToString();

            }
            else
            {
                drpeducation.SelectedItem.Text = "--Select--";
            }

            txt_Edu1_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu1_CollegeName"].ToString();
            txt_Edu1_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu1_UniversityName"].ToString();
            txtEdu1Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu1_Address"].ToString();
            txtedu1Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu1_RollNo"].ToString();
            txt_Edu1_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing"].ToString();
            txt_Edu1_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu1_EducationalQualification"].ToString();

            txt_Edu2_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu2_CollegeName"].ToString();
            txt_Edu2_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu2_UniversityName"].ToString();
            txtEdu2Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu2_Address"].ToString();
            txtedu2Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu2_RollNo"].ToString();
            txt_Edu2_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing2"].ToString();
            txt_Edu2_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu2_EducationalQualification"].ToString();

            txt_Edu3_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu3_CollegeName"].ToString();
            txt_Edu3_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu3_UniversityName"].ToString();
            txtEdu3Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu3_Address"].ToString();
            txtedu3Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu3_RollNo"].ToString();
            txt_Edu3_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing3"].ToString();
            txt_Edu3_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu3_EducationalQualification"].ToString();

            txt_Edu4_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu4_CollegeName"].ToString();
            txt_Edu4_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu4_UniversityName"].ToString();
            txtEdu4Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu4_Address"].ToString();
            txtedu4Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu4_RollNo"].ToString();
            txt_Edu4_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing4"].ToString();
            txt_Edu4_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu4_EducationalQualification"].ToString();

            txt_Edu5_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu5_CollegeName"].ToString();
            txt_Edu5_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu5_UniversityName"].ToString();
            txtEdu5Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu5_Address"].ToString();
            txtedu5Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu5_RollNo"].ToString();
            txt_Edu5_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing5"].ToString();
            txt_Edu5_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu5_EducationalQualification"].ToString();

            txt_Edu6_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu6_CollegeName"].ToString();
            txt_Edu6_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu6_UniversityName"].ToString();
            txtEdu6Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu6_Address"].ToString();
            txtedu6Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu6_RollNo"].ToString();
            txt_Edu6_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing6"].ToString();
            txt_Edu6_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu6_EducationalQualification"].ToString();

            txt_Edu7_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu7_CollegeName"].ToString();
            txt_Edu7_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu7_UniversityName"].ToString();
            txtEdu7Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu7_Address"].ToString();
            txtedu7Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu7_RollNo"].ToString();
            txt_Edu7_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing7"].ToString();
            txt_Edu7_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu7_EducationalQualification"].ToString();

            txt_Edu8_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu8_CollegeName"].ToString();
            txt_Edu8_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu8_UniversityName"].ToString();
            txtEdu8Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu8_Address"].ToString();
            txtedu8Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu8_RollNo"].ToString();
            txt_Edu8_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing8"].ToString();
            txt_Edu8_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu8_EducationalQualification"].ToString();








            if (dsEmployeeInfo.Tables[0].Rows[0]["AddressChecks"].ToString() != "")
            {
                dropaddress.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["AddressChecks"].ToString();
            }
            else
            {
                dropaddress.SelectedItem.Text = "--Select--";


            }

            txtaddress1parmanent.Text = dsEmployeeInfo.Tables[0].Rows[0]["PermanentAddress"].ToString();

            txtAddressparmentstate.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_State"].ToString();

            txtadd1parmanentcity.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_City"].ToString();

            //txt_parmanetSTD.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_AddressPhoneNo"].ToString();

            txtadd1parmanentlandmark.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_Landmark"].ToString();

            if (dsEmployeeInfo.Tables[0].Rows[0]["Per_LivingSince"].ToString() != "")
            {
                txtadd1livingsince.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_LivingSince"].ToString();
            }
            else
            {
                txtadd1livingsince.SelectedItem.Text = "--Select--";

            }
            //txtadd1livingsince.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_LivingSince"].ToString();

            txtadd1policestation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_PoliceStation"].ToString();

            txtadd1pincode.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_PostOffice"].ToString();

            txtadd1logeststay.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_address"].ToString();


            if (txtadd1logeststay.Text == "Same as Permanent")
            {

                RadioButtonList222.SelectedValue = "Same";
                txtadd1logeststay.Text = "Same as Permanent";
                txtadd1logeststay.ReadOnly = true;
                txtaddlongstaystate.Enabled = false;
                txtaddlongeststaycity.ReadOnly = true;
                txtlongstaylandmark.ReadOnly = true;
                txtlongstaylivingsince.Enabled = false;
                txtlongstaypolicestation.ReadOnly = true;
                txtlongstaypincode.ReadOnly = true;
                txtlogstaySTd.ReadOnly = true;
                txtlongstayNumber.ReadOnly = true;


                //RequiredFieldValidator28.EnableClientScript = false;
                //RequiredFieldValidator27.EnableClientScript = false;
                // RequiredFieldValidator29.EnableClientScript = false;
                //RequiredFieldValidator32.EnableClientScript = false;
                RequiredFieldValidator33.EnableClientScript = false;
                //RequiredFieldValidator38.EnableClientScript = false;
               // RegularExpressionValidator6.EnableClientScript = false;
                //RequiredFieldValidator39.EnableClientScript = false;



            }

            txtaddlongstaystate.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_State"].ToString();

            txtaddlongeststaycity.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_City"].ToString();

            //txtlogstaySTd.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_PhoneNo"].ToString();

            txtlongstaylandmark.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_Landmark"].ToString();

            if (dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_LivingSince"].ToString() != "")
            {
                txtlongstaylivingsince.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_LivingSince"].ToString();
            }
            else
            {
                txtlongstaylivingsince.SelectedItem.Text = "--Select--";

            }

            // txtlongstaylivingsince.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_LivingSince"].ToString();

            txtlongstaypolicestation.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_PoliceStation"].ToString();

            txtlongstaypincode.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_Pincode"].ToString();

            txtaddcurrentaddres.Text = dsEmployeeInfo.Tables[0].Rows[0]["CurrentAddress"].ToString();


            if (txtaddcurrentaddres.Text == "Same as Permanent")
            {

                // RadioButtonList222.SelectedValue = "Same";
                txtaddcurentSTD.Text = "";
                txtaddcurrentnumber.Text = "";
                txtaddcurrentaddres.Text = "Same as Permanent";
                txtaddcurrentstate.SelectedItem.Text = "";
                txtaddcurentcity.Text = "";

                txtaddcurentSTD.ReadOnly = true;
                txtaddcurrentnumber.ReadOnly = true;
                txtaddcurrentaddres.ReadOnly = true;
                txtaddcurrentstate.Enabled = false;
                txtaddcurentcity.ReadOnly = true;


                //RequiredFieldValidator43.EnableClientScript = false;
                //RequiredFieldValidator45.EnableClientScript = false;
                //RequiredFieldValidator44.EnableClientScript = false;
                //  RequiredFieldValidator46.EnableClientScript = false;

            }

            if (txtaddcurrentaddres.Text == "Same as Longest Stay")
            {

                // RadioButtonList222.SelectedValue = "Same";
                txtaddcurentSTD.Text = "";
                txtaddcurrentnumber.Text = "";
                txtaddcurrentaddres.Text = "Same as Longest Stay";
                txtaddcurrentstate.SelectedItem.Text = "";
                txtaddcurentcity.Text = "";

                txtaddcurentSTD.ReadOnly = true;
                txtaddcurrentnumber.ReadOnly = true;
                txtaddcurrentaddres.ReadOnly = true;
                txtaddcurrentstate.Enabled = false;
                txtaddcurentcity.ReadOnly = true;


                //RequiredFieldValidator43.EnableClientScript = false;
                //RequiredFieldValidator45.EnableClientScript = false;
               // RequiredFieldValidator44.EnableClientScript = false;
                //  RequiredFieldValidator46.EnableClientScript = false;

            }

            txtaddcurrentstate.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Curr_State"].ToString();

            txtaddcurentcity.Text = dsEmployeeInfo.Tables[0].Rows[0]["Curr_City"].ToString();

            string currphone = dsEmployeeInfo.Tables[0].Rows[0]["Curr_PhoneNo"].ToString();

            string parmanetSTD = dsEmployeeInfo.Tables[0].Rows[0]["Per_AddressPhoneNo"].ToString();

            string longstaySTD = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_PhoneNo"].ToString();

            if (longstaySTD.Contains("-"))
            {
                string[] currindex = longstaySTD.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtlogstaySTd.Text = c1;
                txtlongstayNumber.Text = c2;


            }

            if (parmanetSTD.Contains("-"))
            {
                string[] currindex = parmanetSTD.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txt_parmanetSTD.Text = c1;
                txt_parmanent_PhoneNo.Text = c2;


            }




            if (currphone.Contains("-"))
            {
                string[] currindex = currphone.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtaddcurentSTD.Text = c1;
                txtaddcurrentnumber.Text = c2;


            }

            dropFresherexp.SelectedIndex = 0;
            if (dsEmployeeInfo.Tables[0].Rows[0]["Fresher_experience"].ToString() == "Experienced")
            {
                dropFresherexp.SelectedIndex = 1;
                Cmp1.Visible = true;
                drpnoofcompany.Enabled = true;
                radiobuttoncurrentemp.Enabled = true;
            }
            else
            {
                Cmp1.Visible = false;
                drpnoofcompany.Enabled = false;
                radiobuttoncurrentemp.Enabled = false;
            }

            if (dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString() != "")
            {

                if (dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString() == "Company1")
                {
                    drpnoofcompany.SelectedItem.Text = "1";

                }
                if (dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString() == "Company2")
                {
                    drpnoofcompany.SelectedItem.Text = "2";
                }
                //if (dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString() == "Company3")
                //{
                //    drpnoofcompany.SelectedItem.Text = "3";
                //}
                //if (dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString() == "Company4")
                //{
                //    drpnoofcompany.SelectedItem.Text = "4";
                //}
                //if (dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString() == "Company5")
                //{
                //    drpnoofcompany.SelectedItem.Text = "5";
                //}


                //drpnoofcompany.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString();
            }
            else
            {
                drpnoofcompany.SelectedItem.Text = "--Select--";
            }


            txtcmpy1nameloction.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_CompnayNameandLocation"].ToString();

            txtcmp1lastpostin.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_LastPositionHeldnDepartmentName"].ToString();

            string EmpHis1_TelephoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_TelephoneNo"].ToString();

            if (EmpHis1_TelephoneNo.Contains("-"))
            {
                string[] currindex = EmpHis1_TelephoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtcmp1Std.Text = c1;
                txtcmp1number.Text = c2;

                //txtaddcurrentnumber.Text = c2;

            }

            txtemp1officeaddress.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_Address"].ToString();



            txtemp1employecode.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_EmployeeCode"].ToString();
            txtcmpny1expinyear.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_Experienceinyear"].ToString();
            periodofemployment1.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_PeriodofEmployment"].ToString();
            periodofemptilldate1.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_PeriodofEmploymentTillDate"].ToString();
            txtemp1namedesignationofsupervisorlevel1.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl1_NameDesignatinOfSupervisor"].ToString();

            string EmpHis1RLvl1_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl1_TelepnoneNo"].ToString();
            if (EmpHis1RLvl1_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis1RLvl1_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp1supervisorlevel1STD.Text = c1;
                txtemp1supervisorlevel1number.Text = c2;

            }


            txtemp1supervisorlevel1moblie.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl1_MobileNo"].ToString();
            txtemp1supervisorlevel1email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl1_EmailId"].ToString();
            txtemp1namedesignationofsupervisorlevel2.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl2_NameDesignatinOfSupervisor"].ToString();
            string EmpHis1RLvl2_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl2_TelepnoneNo"].ToString();
            if (EmpHis1RLvl2_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis1RLvl2_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp1supervisorlevel2STD.Text = c1;
                txtemp1supervisorlevel2number.Text = c2;

            }



            txtemp1supervisorlevel2mobile.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl2_MobileNo"].ToString();
            txtemp1supervisorlevel2email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl2_EmailId"].ToString();
            RadioButtoncmp1emptype.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_TempPerma"].ToString();
            emp1agencydetail.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_AgencyDetails"].ToString();
            emp1remunerationsalary.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_RemunerationOrSalary"].ToString();
            emp1reasonofleaving.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_ReasonOfLeaving"].ToString();
            emp1referenceYN.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_referenceYN"].ToString();
            //emp1incaseofgap.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_IncaseOfGap"].ToString();
            RadioButtonemp1noticeperiodYN.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_NoticePeriodorNot"].ToString();

            //company 2
            txtemp2compnyname.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_CompnayNameandLocation"].ToString();

            txtemp2lastposition.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_LastPositionHeldnDepartmentName"].ToString();

            string EmpHis2_TelephoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_TelephoneNo"].ToString();

            if (EmpHis2_TelephoneNo.Contains("-"))
            {
                string[] currindex = EmpHis2_TelephoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                emp2cmpSTD.Text = c1;
                emp2cmpnumber.Text = c2;
            }




            txtemp2officeaddress.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_Address"].ToString();
            txtemp2employeecode.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_EmployeeCode"].ToString();
            txtemp2experience.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_Experienceinyear"].ToString();
            periodofemployment2.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_PeriodofEmployment"].ToString();
            periodofemptilldate2.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_PeriodofEmploymentTillDate"].ToString();
            txtemp2namedesignationofsupervisorlevel1.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl1_NameDesignatinOfSupervisor"].ToString();

            string EmpHis2RLvl1_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl1_TelepnoneNo"].ToString();
            if (EmpHis2RLvl1_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis2RLvl1_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp2supervisorlevel1STD.Text = c1;
                txtemp2supervisorlevel1number.Text = c2;
            }



            txtemp2supervisorlevel1moblie.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl1_MobileNo"].ToString();
            txtemp2supervisorlevel1email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl1_EmailId"].ToString();
            txtemp2namedesignationofsupervisorlevel2.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl2_NameDesignatinOfSupervisor"].ToString();
            string EmpHis2RLvl2_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl2_TelepnoneNo"].ToString();
            if (EmpHis2RLvl2_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis2RLvl2_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp2supervisorlevel2STD.Text = c1;
                txtemp2supervisorlevel2number.Text = c2;
            }


            txtemp2supervisorlevel2mobile.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl2_MobileNo"].ToString();
            txtemp2supervisorlevel2email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl2_EmailId"].ToString();
            RadioButtoncmp2emptype.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_TempPerma"].ToString();
            emp2agencydetail.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_AgencyDetails"].ToString();
            emp2remunerationsalary.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_RemunerationOrSalary"].ToString();
            emp2reasonofleaving.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_ReasonOfLeaving"].ToString();
            emp2referenceYN.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_referenceYN"].ToString();
            //emp2incaseofgap.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_IncaseOfGap"].ToString();
            RadioButtonemp2noticeperiodYN.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_NoticePeriodorNot"].ToString();

            //company 3

            txtemp3companyname.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_CompnayNameandLocation"].ToString();
            txtemp3lastposition.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_LastPositionHeldnDepartmentName"].ToString();
            string EmpHis3_TelephoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_TelephoneNo"].ToString();
            if (EmpHis3_TelephoneNo.Contains("-"))
            {
                string[] currindex = EmpHis3_TelephoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                emp3cmpSTD.Text = c1;
                emp3cmpnumber.Text = c2;
            }




            txtemp3officeaddress.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_Address"].ToString();
            txtemp3employeecode.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_EmployeeCode"].ToString();
            txtemp3experienceinyear.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_Experienceinyear"].ToString();
            periodofemployment3.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_PeriodofEmployment"].ToString();
            periodofemptilldate3.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_PeriodofEmploymentTillDate"].ToString();
            txtemp3namedesignationofsupervisorlevel1.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl1_NameDesignatinOfSupervisor"].ToString();

            string EmpHis3RLvl1_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl1_TelepnoneNo"].ToString();
            if (EmpHis3RLvl1_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis3RLvl1_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp3supervisorlevel1STD.Text = c1;
                txtemp3supervisorlevel1number.Text = c2;
            }



            txtemp3supervisorlevel1moblie.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl1_MobileNo"].ToString();
            txtemp3supervisorlevel1email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl1_EmailId"].ToString();
            txtemp3namedesignationofsupervisorlevel2.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl2_NameDesignatinOfSupervisor"].ToString();
            string EmpHis3RLvl2_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl2_TelepnoneNo"].ToString();
            if (EmpHis3RLvl2_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis3RLvl2_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp3supervisorlevel2STD.Text = c1;
                txtemp3supervisorlevel2number.Text = c2;
            }


            txtemp3supervisorlevel2mobile.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl2_MobileNo"].ToString();
            txtemp3supervisorlevel2email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl2_EmailId"].ToString();
            RadioButtoncmp3emptype.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_TempPerma"].ToString();
            emp3agencydetail.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_AgencyDetails"].ToString();
            emp3remunerationsalary.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_RemunerationOrSalary"].ToString();
            emp3reasonofleaving.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_ReasonOfLeaving"].ToString();
            emp3referenceYN.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_referenceYN"].ToString();
            //emp3incaseofgap.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_IncaseOfGap"].ToString();
            RadioButtonemp3noticeperiodYN.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_NoticePeriodorNot"].ToString();

            //company 4


            txtemp4companyname.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_CompnayNameandLocation"].ToString();
            txtemp4lastpostion.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_LastPositionHeldnDepartmentName"].ToString();

            string EmpHis4_TelephoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_TelephoneNo"].ToString();
            if (EmpHis4_TelephoneNo.Contains("-"))
            {
                string[] currindex = EmpHis4_TelephoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                emp4cmpSTD.Text = c1;
                emp4cmpnumber.Text = c2;
            }


            txtemp4officeaddress.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_Address"].ToString();
            txtemp4employeecode.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_EmployeeCode"].ToString();
            txtemp4experience.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_Experienceinyear"].ToString();
            periodofemployment4.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_PeriodofEmployment"].ToString();
            periodofemptilldate4.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_PeriodofEmploymentTillDate"].ToString();
            txtemp4namedesignationofsupervisorlevel1.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl1_NameDesignatinOfSupervisor"].ToString();

            string EmpHis4RLvl1_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl1_TelepnoneNo"].ToString();
            if (EmpHis4RLvl1_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis4RLvl1_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp4supervisorlevel1STD.Text = c1;
                txtemp4supervisorlevel1number.Text = c2;
            }



            txtemp4supervisorlevel1moblie.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl1_MobileNo"].ToString();
            txtemp4supervisorlevel1email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl1_EmailId"].ToString();
            txtemp4namedesignationofsupervisorlevel2.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl2_NameDesignatinOfSupervisor"].ToString();
            string EmpHis4RLvl2_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl2_TelepnoneNo"].ToString();
            if (EmpHis4RLvl2_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis4RLvl2_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp4supervisorlevel2STD.Text = c1;
                txtemp4supervisorlevel2number.Text = c2;
            }


            txtemp4supervisorlevel2mobile.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl2_MobileNo"].ToString();
            txtemp4supervisorlevel2email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl2_EmailId"].ToString();
            RadioButtoncmp4emptype.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_TempPerma"].ToString();
            emp4agencydetail.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_AgencyDetails"].ToString();
            emp4remunerationsalary.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_RemunerationOrSalary"].ToString();
            emp4reasonofleaving.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_ReasonOfLeaving"].ToString();
            emp4referenceYN.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_referenceYN"].ToString();
            // emp4incaseofgap.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_IncaseOfGap"].ToString();
            RadioButtonemp4noticeperiodYN.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_NoticePeriodorNot"].ToString();


            //company 5

            txtemp5companyname.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_CompnayNameandLocation"].ToString();
            txtemp5lastposition.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_LastPositionHeldnDepartmentName"].ToString();

            string EmpHis5_TelephoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_TelephoneNo"].ToString();
            if (EmpHis5_TelephoneNo.Contains("-"))
            {
                string[] currindex = EmpHis5_TelephoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                emp5cmpSTD.Text = c1;
                emp5cmpnumber.Text = c2;
            }


            txtemp5officeaddress.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_Address"].ToString();
            txtemp5employeecode.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_EmployeeCode"].ToString();
            txtemp5experience.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_Experienceinyear"].ToString();
            periodofemployment5.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_PeriodofEmployment"].ToString();
            periodofemptilldate5.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_PeriodofEmploymentTillDate"].ToString();
            txtemp5namedesignationofsupervisorlevel1.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl1_NameDesignatinOfSupervisor"].ToString();

            string EmpHis5RLvl1_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl1_TelepnoneNo"].ToString();
            if (EmpHis5RLvl1_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis5RLvl1_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp5supervisorlevel1STD.Text = c1;
                txtemp5supervisorlevel1number.Text = c2;
            }



            txtemp5supervisorlevel1moblie.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl1_MobileNo"].ToString();
            txtemp5supervisorlevel1email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl1_EmailId"].ToString();
            txtemp5namedesignationofsupervisorlevel2.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl2_NameDesignatinOfSupervisor"].ToString();
            string EmpHis5RLvl2_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl2_TelepnoneNo"].ToString();
            if (EmpHis5RLvl2_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis5RLvl2_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp5supervisorlevel2STD.Text = c1;
                txtemp5supervisorlevel2number.Text = c2;
            }


            txtemp5supervisorlevel2mobile.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl2_MobileNo"].ToString();
            txtemp5supervisorlevel2email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl2_EmailId"].ToString();
            RadioButtoncmp5emptype.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_TempPerma"].ToString();
            emp5agencydetail.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_AgencyDetails"].ToString();
            emp5remunerationsalary.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_RemunerationOrSalary"].ToString();
            emp5reasonofleaving.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_ReasonOfLeaving"].ToString();
            emp5referenceYN.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_referenceYN"].ToString();
            // emp5incaseofgap.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_IncaseOfGap"].ToString();
            RadioButtonemp5noticeperiodYN.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_NoticePeriodorNot"].ToString();
            radiobuttoncurrentemp.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["CurrentEmploymentStatus"].ToString();



            if (dsEmployeeInfo.Tables[0].Rows[0]["RefCheck"].ToString() != "")
            {
                ddlref.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["RefCheck"].ToString();

            }
            else
            {
                ddlref.SelectedItem.Text = "--Select--";
            }
            //if (dsEmployeeInfo.Tables[0].Rows[0]["CibilCheck"].ToString() != "")
            //{
            //    ddlcibil.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["CibilCheck"].ToString();

            //}
            //else
            //{
            //    ddlcibil.SelectedItem.Text = "--Select--";
            //}
            txtRef1RefName.Text = dsEmployeeInfo.Tables[0].Rows[0]["RefCheck1AppName"].ToString();
            txtRef1CompanyName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref1Company"].ToString();
            txtRef1Designation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref1Desi"].ToString();
            txtRef1EmailId.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref1Email"].ToString();
            txtRef1Contact.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref1CN"].ToString();

            txtRef2RefName.Text = dsEmployeeInfo.Tables[0].Rows[0]["RefCheck2AppName"].ToString();
            txtRef2CompanyName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref2Company"].ToString();
            txtRef2Designation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref2Desi"].ToString();
            txtRef2EmailId.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref2Email"].ToString();
            txtRef2Contact.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref2CN"].ToString();

            txtCIBILContact.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cibilcontact"].ToString();
            dtpCIBILDOB.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cibildob"].ToString();
            txtCIBILEmail.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cibilmail"].ToString();
            txtCIBILFullName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cibilname"].ToString();
            ddlCIBILgender.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cibilgender"].ToString();
            txtCIBILPanCard.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cibilpanno"].ToString();
            txtCIBILpasportno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cibilpassportno"].ToString();


          //if (ddlCIBILgender.SelectedItem.Text == "Male")
          //  {
          //      txtGender.SelectedIndex = 0;
          //  }
          //  else
          //  {
          //      txtGender.SelectedIndex = 1;
          //  }




            txtCIBILvoterid.Text = dsEmployeeInfo.Tables[0].Rows[0]["CibilvoterID"].ToString();
            txtCIBILlience.Text = dsEmployeeInfo.Tables[0].Rows[0]["CibilDrivinglicense"].ToString();

            //rejected remarks and commnets....
            RejectedRemark1.Text = dsEmployeeInfo.Tables[0].Rows[0]["RejectedRemarks1"].ToString();
            RejectedRemark2.Text = dsEmployeeInfo.Tables[0].Rows[0]["RejectedRemarks2"].ToString();
            RejectedRemark3.Text = dsEmployeeInfo.Tables[0].Rows[0]["RejectedRemarks3"].ToString();
            RejectedRemark4.Text = dsEmployeeInfo.Tables[0].Rows[0]["RejectedRemarks4"].ToString();
            RejectedRemark5.Text = dsEmployeeInfo.Tables[0].Rows[0]["RejectedRemarks5"].ToString();

            comment1.Text = dsEmployeeInfo.Tables[0].Rows[0]["comment1"].ToString();
            comment2.Text = dsEmployeeInfo.Tables[0].Rows[0]["comment2"].ToString();
            comment3.Text = dsEmployeeInfo.Tables[0].Rows[0]["comment3"].ToString();
            comment4.Text = dsEmployeeInfo.Tables[0].Rows[0]["comment4"].ToString();
            comment5.Text = dsEmployeeInfo.Tables[0].Rows[0]["comment5"].ToString();


            txtcmp1department.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp1Department"].ToString();
            txtcmp2department.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp2Department"].ToString();
            cmp3department.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp3Department"].ToString();
            txtcmp4department.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp4Department"].ToString();
            txtcmp5department.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp5Department"].ToString();

            txtcmp1hrdesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp1HRdesignation"].ToString();
            txtcmp2hrdesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp2HRdesignation"].ToString();
            txtcmp3hrdesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp3HRdesignation"].ToString();
            txtcmp4hrdesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp4HRdesignation"].ToString();
            txtcmp5hrdesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp5HRdesignation"].ToString();

            txtcmp1supervisordesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp1RMdesignation"].ToString();
            txtcmp2supervisordesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp2RMdesignation"].ToString();
            txtcmp3supervisordesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp3RMdesignation"].ToString();
            txtcmp4supervisordesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp4RMdesignation"].ToString();
            txtcmp5supervisordesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp5RMdesignation"].ToString();


            //drpdruglist.SelectedIndex = drpdruglist.Items.IndexOf(drpdruglist.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["DrugList"].ToString()));
            //if (drpdruglist.SelectedItem.Text == "Drug")
            //{

            //    Drug.Visible = true;
            //}


            drpeducation.SelectedIndex = drpeducation.Items.IndexOf(drpeducation.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["educationcheck"].ToString()));
            if (drpeducation.SelectedItem.Text == "Education 1")
            {

                edu1.Visible = true;
                edu2.Visible = false;
                edu3.Visible = false;
                edu4.Visible = false;
                edu5.Visible = false;
                edu6.Visible = false;
                edu7.Visible = false;
                edu8.Visible = false;

            }
            if (drpeducation.SelectedItem.Text == "Education 2")
            {

                edu1.Visible = true;
                edu2.Visible = true;
                edu3.Visible = false;
                edu4.Visible = false;
                edu5.Visible = false;
                edu6.Visible = false;
                edu7.Visible = false;
                edu8.Visible = false;

            }
            if (drpeducation.SelectedItem.Text == "Education 3")
            {

                edu1.Visible = true;
                edu2.Visible = true;
                edu3.Visible = true;
                edu4.Visible = false;
                edu5.Visible = false;
                edu6.Visible = false;
                edu7.Visible = false;
                edu8.Visible = false;

            }
            if (drpeducation.SelectedItem.Text == "Education 4")
            {

                edu1.Visible = true;
                edu2.Visible = true;
                edu3.Visible = true;
                edu4.Visible = true;
                edu5.Visible = false;
                edu6.Visible = false;
                edu7.Visible = false;
                edu8.Visible = false;

            }
            if (drpeducation.SelectedItem.Text == "Education 5")
            {

                edu1.Visible = true;
                edu2.Visible = true;
                edu3.Visible = true;
                edu4.Visible = true;
                edu5.Visible = true;
                edu6.Visible = false;
                edu7.Visible = false;
                edu8.Visible = false;

            }
            if (drpeducation.SelectedItem.Text == "Education 6")
            {

                edu1.Visible = true;
                edu2.Visible = true;
                edu3.Visible = true;
                edu4.Visible = true;
                edu5.Visible = true;
                edu6.Visible = true;
                edu7.Visible = false;
                edu8.Visible = false;

            }
            if (drpeducation.SelectedItem.Text == "Education 7")
            {

                edu1.Visible = true;
                edu2.Visible = true;
                edu3.Visible = true;
                edu4.Visible = true;
                edu5.Visible = true;
                edu6.Visible = true;
                edu7.Visible = true;
                edu8.Visible = false;

            }
            if (drpeducation.SelectedItem.Text == "Education 8")
            {

                edu1.Visible = true;
                edu2.Visible = true;
                edu3.Visible = true;
                edu4.Visible = true;
                edu5.Visible = true;
                edu6.Visible = true;
                edu7.Visible = true;
                edu8.Visible = true;

            }
            dropaddress.SelectedIndex = dropaddress.Items.IndexOf(dropaddress.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["addresschecks"].ToString()));
            if (dropaddress.SelectedItem.Text == "Address Check")
            {
                ad1.Visible = true;
            }
            drpnoofcompany.SelectedIndex = drpnoofcompany.Items.IndexOf(drpnoofcompany.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString()));

            if (drpnoofcompany.SelectedItem.Text == "1")
            {
                Cmp1.Visible = true;
                Cmp2.Visible = false;
                Cmp3.Visible = false;
                Cmp4.Visible = false;
                Cmp5.Visible = false;

            }
            if (drpnoofcompany.SelectedItem.Text == "2")
            {
                Cmp1.Visible = true;
                Cmp2.Visible = true;
                Cmp3.Visible = false;
                Cmp4.Visible = false;
                Cmp5.Visible = false;

            }
            //if (drpnoofcompany.SelectedItem.Text == "3")
            //{
            //    Cmp1.Visible = true;
            //    Cmp2.Visible = true;
            //    Cmp3.Visible = true;
            //    Cmp4.Visible = false;
            //    Cmp5.Visible = false;

            //}
            //if (drpnoofcompany.SelectedItem.Text == "4")
            //{
            //    Cmp1.Visible = true;
            //    Cmp2.Visible = true;
            //    Cmp3.Visible = true;
            //    Cmp4.Visible = true;
            //    Cmp5.Visible = false;

            //}
            //if (drpnoofcompany.SelectedItem.Text == "5")
            //{
            //    Cmp1.Visible = true;
            //    Cmp2.Visible = true;
            //    Cmp3.Visible = true;
            //    Cmp4.Visible = true;
            //    Cmp5.Visible = true;

            //}
            ddlref.SelectedIndex = ddlref.Items.IndexOf(ddlref.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["RefCheck"].ToString()));
            if (ddlref.SelectedItem.Text == "Reference1")
            {

                ref1.Visible = true;
                ref2.Visible = false;
                

            }
            if (ddlref.SelectedItem.Text == "Reference2")
            {

                ref1.Visible = true;
                ref2.Visible = true;

            }
            //ddlcibil.SelectedIndex = ddlcibil.Items.IndexOf(ddlcibil.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["CibilCheck"].ToString()));
            //if (ddlcibil.SelectedItem.Text == "Cibil")
            //{
            //   cibil.Visible = true;
            //}
           
        }

    }


    protected void btnfileupload_Click(object sender, EventArgs e)
    {
        RequiredFieldValidator9.EnableClientScript = true;
        //CompareValidator3.EnableClientScript = true;
        uploadFile();
        ShowFile();
        if (fileup.HasFile == true && int.Parse(grdFileUploadDownload.Rows.Count.ToString()) != 0)
        {
            btnSave.Enabled = true;
            return;
        }



    }



    public void uploaddetail()
    {
        candidateobj.FirstName = txtFirstName.Text.ToString();
        candidateobj.MiddleName = txtMiddleName.Text.ToString();
        candidateobj.Surname = txtLastName.Text.ToString();
        candidateobj.FatherName = txtfathername.Text.ToString();
        candidateobj.Mobile = txtcandidatemobile.Text.ToString();

        candidateobj.saveband4CandidateDetails(candidateobj);

    }
    public void uploadFile()
    {
        uploadfiles.uploaddownloadfiles up = new uploadfiles.uploaddownloadfiles();


        if (fileup.HasFile == true)
        {
            string filename = fileup.PostedFile.FileName;
            int i = -1;
            string[] filepathSplit = filename.Split('\\');
            foreach (string arrStr in filepathSplit)
            {
                i++;
            }
            string file = filepathSplit[i].ToString();
            string Checkype = ddlType.SelectedItem.Value.ToString();
            //save the file to the server
            string fileRename = file + System.DateTime.Now.ToString("ddMMyyyyhhmmss");
            fileup.PostedFile.SaveAs(Server.MapPath("~\\Uploaded\\") + fileRename);
            //lblStatus.Text = "File Saved to: " + Server.MapPath("~\\Uploaded\\") +EmpID+Checkype+ file;
            string Filename = Server.MapPath("~\\Uploaded\\") + fileRename;
            up.ActiveStatus = "1";
            up.BackgroundType = Checkype;
            up.CandidateID = "0";
            up.FileName = fileRename;
            up.UploadStatus = "1";
            up.FileSize = "NA";
            up.FirstName = txtFirstName.Text.ToString();
            up.MiddleName = txtMiddleName.Text.ToString();
            up.Surname = txtLastName.Text.ToString();
            up.FatherName = txtfathername.Text.ToString();
            up.Mobile = txtcandidatemobile.Text.ToString();
            try
            {
                up.saveFile(up);
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('"+ex.Message+"');</script>");
            }

            lblStatus.Text = "File Uploaded Successfully";


        }
        else
        {
            //Response.Write("ss");
            Response.Write("<script>alert('Please Choose a File !');</script>");
        }

    }
    public void ShowFile()
    {
        CandidateInfonamespace.CandidateDetails candidateobj = new CandidateInfonamespace.CandidateDetails();
        DataSet ds = new DataSet();
        candidateobj.FirstName = txtFirstName.Text.ToString();
        candidateobj.MiddleName = txtMiddleName.Text.ToString();
        candidateobj.Surname = txtLastName.Text.ToString();
        candidateobj.FatherName = txtfathername.Text.ToString();
        candidateobj.Mobile = txtcandidatemobile.Text.ToString();
        ds = candidateobj.showfile(candidateobj);
        grdFileUploadDownload.DataSource = ds;
        grdFileUploadDownload.DataBind();



    }

    protected void grdFileUploadDownload_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string filename = Convert.ToString(e.CommandArgument);
        if (filename != "")
        {

            string FolderPath = Server.MapPath("~\\Uploaded\\");
            string path = FolderPath + filename;

            System.IO.FileInfo file = new System.IO.FileInfo(path);

            if (file.Exists)
            {

                Response.Clear();

                Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);

                Response.AddHeader("Content-Length", file.Length.ToString());

                Response.ContentType = "application/octet-stream";

                Response.WriteFile(file.FullName);

                Response.End();

            }

            else

                //aq
                Response.Write("");
            //Response.Redirect("FileM.aspx");



        }

    }
    protected void logoutbtn_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Redirect("../Login.aspx");
    }
    protected void grdFileUploadDownload_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        CandidateInfonamespace.CandidateDetails candidateobj = new CandidateInfonamespace.CandidateDetails();
        DataSet ds = new DataSet();
        candidateobj.FirstName = txtFirstName.Text.ToString();
        candidateobj.MiddleName = txtMiddleName.Text.ToString();
        candidateobj.Surname = txtLastName.Text.ToString();
        candidateobj.FatherName = txtfathername.Text.ToString();
        candidateobj.Mobile = txtcandidatemobile.Text.ToString();

        //int key = Convert.ToInt32(grdFileUploadDownload.DataKeys[e.RowIndex].Value);
        string key = grdFileUploadDownload.Rows[e.RowIndex].Cells[1].Text;
        candidateobj.key = key.ToString();

        candidateobj.deleteupload(candidateobj);
        ShowFile();
        if (int.Parse(grdFileUploadDownload.Rows.Count.ToString()) != 0)
        {
            btnSave.Enabled = true;
        }
        else
        {
            btnSave.Enabled = false;
        }

    }

    protected void grdFileUploadDownload_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (Request.QueryString["mode"] == "View")
        {
            e.Row.Cells[4].Visible = false;
        }
        else
        {
            e.Row.Cells[4].Visible = true;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Server.Transfer("BGCForm.aspx");
    }
    protected void RadioButtoncmp1emptype_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (RadioButtoncmp1emptype.SelectedValue == "Permanent")
        {
            emp1agencydetail.ReadOnly = true;
            emp1agencydetail.BackColor = System.Drawing.Color.LightCoral;
        }
        if (RadioButtoncmp1emptype.SelectedValue == "Temporary")
        {
            emp1agencydetail.ReadOnly = false;
            emp1agencydetail.BackColor = System.Drawing.Color.White;

        }

        if (RadioButtoncmp2emptype.SelectedValue == "Permanent")
        {
            emp2agencydetail.ReadOnly = true;
            emp2agencydetail.BackColor = System.Drawing.Color.LightCoral;

        }
        if (RadioButtoncmp2emptype.SelectedValue == "Temporary")
        {
            emp2agencydetail.ReadOnly = false;
            emp2agencydetail.BackColor = System.Drawing.Color.White;
        }

        if (RadioButtoncmp3emptype.SelectedValue == "Permanent")
        {
            emp3agencydetail.ReadOnly = true;
            emp3agencydetail.BackColor = System.Drawing.Color.LightCoral;
        }
        if (RadioButtoncmp3emptype.SelectedValue == "Temporary")
        {
            emp3agencydetail.ReadOnly = false;
            emp3agencydetail.BackColor = System.Drawing.Color.White;
        }

        if (RadioButtoncmp4emptype.SelectedValue == "Permanent")
        {
            emp4agencydetail.ReadOnly = true;
            emp4agencydetail.BackColor = System.Drawing.Color.LightCoral;
        }
        if (RadioButtoncmp4emptype.SelectedValue == "Temporary")
        {
            emp4agencydetail.ReadOnly = false;
            emp4agencydetail.BackColor = System.Drawing.Color.White;
        }

        if (RadioButtoncmp5emptype.SelectedValue == "Permanent")
        {
            emp5agencydetail.ReadOnly = true;
            emp5agencydetail.BackColor = System.Drawing.Color.LightCoral;
        }
        if (RadioButtoncmp5emptype.SelectedValue == "Temporary")
        {
            emp5agencydetail.ReadOnly = false;
            emp5agencydetail.BackColor = System.Drawing.Color.White;
        }
    }










    protected void drpCOE_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpCOE.SelectedItem.Text == "OTHER")
        {
            txtCOE.Visible = true;

        }
        else
        {
            txtCOE.Visible = false;
        }
    }
    protected void drpeducation_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (drpeducation.SelectedValue == "0")
        {
            edu1.Visible = false;
            edu2.Visible = false;
            edu3.Visible = false;
            edu4.Visible = false;
            edu5.Visible = false;
            edu6.Visible = false;
            edu7.Visible = false;
            edu8.Visible = false;

        }
        if (drpeducation.SelectedValue == "Education 1")
        {
            edu1.Visible = true;
            edu2.Visible = false;
            edu3.Visible = false;
            edu4.Visible = false;
            edu5.Visible = false;
            edu6.Visible = false;
            edu7.Visible = false;
            edu8.Visible = false;


            Page.Validate();
        }
        if (drpeducation.SelectedValue == "Education 2")
        {
            edu1.Visible = true;
            edu2.Visible = true;
            edu3.Visible = false;
            edu4.Visible = false;
            edu5.Visible = false;
            edu6.Visible = false;
            edu7.Visible = false;
            edu8.Visible = false;


            Page.Validate();
        }
        if (drpeducation.SelectedValue == "Education 3")
        {
            edu1.Visible = true;
            edu2.Visible = true;
            edu3.Visible = true;
            edu4.Visible = false;
            edu5.Visible = false;
            edu6.Visible = false;
            edu7.Visible = false;
            edu8.Visible = false;


            Page.Validate();
        }
        if (drpeducation.SelectedValue == "Education 4")
        {
            edu1.Visible = true;
            edu2.Visible = true;
            edu3.Visible = true;
            edu4.Visible = true;
            edu5.Visible = false;
            edu6.Visible = false;
            edu7.Visible = false;
            edu8.Visible = false;


            Page.Validate();
        }
        if (drpeducation.SelectedValue == "Education 5")
        {
            edu1.Visible = true;
            edu2.Visible = true;
            edu3.Visible = true;
            edu4.Visible = true;
            edu5.Visible = true;
            edu6.Visible = false;
            edu7.Visible = false;
            edu8.Visible = false;


            Page.Validate();
        }
        if (drpeducation.SelectedValue == "Education 6")
        {
            edu1.Visible = true;
            edu2.Visible = true;
            edu3.Visible = true;
            edu4.Visible = true;
            edu5.Visible = true;
            edu6.Visible = true;
            edu7.Visible = false;
            edu8.Visible = false;


            Page.Validate();
        }
        if (drpeducation.SelectedValue == "Education 7")
        {
            edu1.Visible = true;
            edu2.Visible = true;
            edu3.Visible = true;
            edu4.Visible = true;
            edu5.Visible = true;
            edu6.Visible = true;
            edu7.Visible = true;
            edu8.Visible = false;


            Page.Validate();
        }
        if (drpeducation.SelectedValue == "Education 8")
        {
            edu1.Visible = true;
            edu2.Visible = true;
            edu3.Visible = true;
            edu4.Visible = true;
            edu5.Visible = true;
            edu6.Visible = true;
            edu7.Visible = true;
            edu8.Visible = true;


            Page.Validate();
        }

    }

    protected void RadioButtonList222_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (RadioButtonList222.SelectedValue == "Same as Permanent")
        {

            txtadd1logeststay.Text = "Same as Permanent";

            txtadd1logeststay.ReadOnly = true;
            txtaddlongstaystate.Enabled = false;
            txtaddlongeststaycity.ReadOnly = true;
            txtlongstaylandmark.ReadOnly = true;
            txtlongstaylivingsince.Enabled = false;
            txtlongstaypolicestation.ReadOnly = true;
            txtlongstaypincode.ReadOnly = true;
            txtlogstaySTd.ReadOnly = true;
            txtlongstayNumber.ReadOnly = true;


            //RequiredFieldValidator28.EnableClientScript = false;
            //RequiredFieldValidator27.EnableClientScript = false;
            // RequiredFieldValidator29.EnableClientScript = false;
            //RequiredFieldValidator32.EnableClientScript = false;
            RequiredFieldValidator33.EnableClientScript = false;
            //RequiredFieldValidator38.EnableClientScript = false;
            //RegularExpressionValidator6.EnableClientScript = false;
            //RequiredFieldValidator39.EnableClientScript = false;



        }
        if (RadioButtonList222.SelectedValue == "New")
        {
            txtadd1logeststay.Text = "";
            txtaddlongstaystate.SelectedItem.Text = "";
            txtaddlongeststaycity.Text = "";
            txtlongstaylandmark.Text = "";
            txtlongstaylivingsince.SelectedItem.Text = "";
            txtlongstaypolicestation.Text = "";
            txtlongstaypincode.Text = "";
            txtlogstaySTd.Text = "";
            txtlongstayNumber.Text = "";


            txtadd1logeststay.ReadOnly = false;
            txtaddlongstaystate.Enabled = true;
            txtaddlongeststaycity.ReadOnly = false;
            txtlongstaylandmark.ReadOnly = false;
            txtlongstaylivingsince.Enabled = true;
            txtlongstaypolicestation.ReadOnly = false;
            txtlongstaypincode.ReadOnly = false;
            txtlogstaySTd.ReadOnly = false;
            txtlongstayNumber.ReadOnly = false;

            //RequiredFieldValidator28.EnableClientScript = true;
            //RequiredFieldValidator27.EnableClientScript = true;
            //RequiredFieldValidator29.EnableClientScript = true;
            //RequiredFieldValidator32.EnableClientScript = true;
            RequiredFieldValidator33.EnableClientScript = true;
            //RequiredFieldValidator38.EnableClientScript = true;
            //RegularExpressionValidator6.EnableClientScript = true;
            //RequiredFieldValidator39.EnableClientScript = true;

        }

    }



    protected void Radiocurrentaddress_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Radiocurrentaddress.SelectedValue == "Same as Permanent")
        {

            txtaddcurentSTD.Text = "";
            txtaddcurrentnumber.Text = "";
            txtaddcurrentaddres.Text = "Same as Permanent";
            txtaddcurrentstate.SelectedItem.Text = "";
            txtaddcurentcity.Text = "";

            txtaddcurentSTD.ReadOnly = true;
            txtaddcurrentnumber.ReadOnly = true;
            txtaddcurrentaddres.ReadOnly = true;
            txtaddcurrentstate.Enabled = false;
            txtaddcurentcity.ReadOnly = true;


           // RequiredFieldValidator43.EnableClientScript = false;
           // RequiredFieldValidator45.EnableClientScript = false;
           // RequiredFieldValidator44.EnableClientScript = false;
            //RequiredFieldValidator46.EnableClientScript = false;




        }
        if (Radiocurrentaddress.SelectedValue == "Same as Longest Stay")
        {

            txtaddcurentSTD.Text = "";
            txtaddcurrentnumber.Text = "";
            txtaddcurrentaddres.Text = "Same as Longest Stay";
            txtaddcurrentstate.SelectedItem.Text = "";
            txtaddcurentcity.Text = "";


            txtaddcurentSTD.ReadOnly = true;
            txtaddcurrentnumber.ReadOnly = true;
            txtaddcurrentaddres.ReadOnly = true;
            txtaddcurrentstate.Enabled = false;
            txtaddcurentcity.ReadOnly = true;

            //txtaddcurentSTD.Text = txtlogstaySTd.Text.ToString();
            //txtaddcurrentnumber.Text = txtlongstayNumber.Text.ToString();

            //txtaddcurrentaddres.Text = txtadd1logeststay.Text.ToString();
            //txtaddcurrentstate.Text = txtaddlongstaystate.Text.ToString();
            //txtaddcurentcity.Text = txtaddlongeststaycity.Text.ToString();

           // RequiredFieldValidator43.EnableClientScript = false;
           // RequiredFieldValidator45.EnableClientScript = false;
           // RequiredFieldValidator44.EnableClientScript = false;
            // RequiredFieldValidator46.EnableClientScript = false;
        }

        if (Radiocurrentaddress.SelectedValue == "New")
        {

            txtaddcurentSTD.ReadOnly = false;
            txtaddcurrentnumber.ReadOnly = false;
            txtaddcurrentaddres.ReadOnly = false;
            txtaddcurrentstate.Enabled = true;
            txtaddcurentcity.ReadOnly = false;


            txtaddcurentSTD.Text = "";
            txtaddcurrentnumber.Text = "";
            txtaddcurrentaddres.Text = "";
            txtaddcurrentstate.SelectedItem.Text = "";
            txtaddcurentcity.Text = "";

            //RequiredFieldValidator43.EnableClientScript = true;
            //RequiredFieldValidator45.EnableClientScript = true;
            //RequiredFieldValidator44.EnableClientScript = true;
            //  RequiredFieldValidator46.EnableClientScript = true;

        }
    }

    protected void periodofemptilldate1_TextChanged(object sender, EventArgs e)
    {

        if (periodofemployment1.Text == "")
        {

            Response.Write("<script>alert('Please choose From date first!!')</script>");
            periodofemptilldate1.Text = "";
        }
        else

            if (periodofemployment1.Text != "" && periodofemptilldate1.Text != "")
            {

                const string DateFormat = "dd/MM/yyyy";
                DateTime From = DateTime.ParseExact(periodofemployment1.Text, DateFormat, null);
                DateTime To = DateTime.ParseExact(periodofemptilldate1.Text, DateFormat, null);

                if (From > To)
                {
                    Response.Write("<script>alert('To date must be greater than the From date!!')</script>");
                    periodofemptilldate1.Text = "";

                }
                else
                {
                    TimeSpan Span = To - From;

                    DateTime Total = DateTime.MinValue + Span;

                    int Years = Total.Year - 1;
                    int Months = Total.Month - 1;
                    int Days = Total.Day - 1;
                    txtcmpny1expinyear.Text = Years + "year " + Months + "months " + Days + "days";
                }


            }
    }
    protected void periodofemptilldate2_TextChanged(object sender, EventArgs e)
    {
        if (periodofemployment2.Text == "")
        {

            Response.Write("<script>alert('Please choose From date first!!')</script>");
            periodofemptilldate2.Text = "";
        }
        else

            if (periodofemployment2.Text != "" && periodofemptilldate2.Text != "")
            {
                const string DateFormat = "dd/MM/yyyy";
                DateTime From = DateTime.ParseExact(periodofemployment2.Text, DateFormat, null);
                DateTime To = DateTime.ParseExact(periodofemptilldate2.Text, DateFormat, null);

                if (From > To)
                {
                    Response.Write("<script>alert('To date must be greater than the From date!!')</script>");
                    periodofemptilldate2.Text = "";

                }
                else
                {
                    TimeSpan Span = To - From;


                    DateTime Total = DateTime.MinValue + Span;



                    int Years = Total.Year - 1;
                    int Months = Total.Month - 1;
                    int Days = Total.Day - 1;
                    txtemp2experience.Text = Years + "year " + Months + "months " + Days + "days";
                }



            }
    }
    protected void periodofemptilldate3_TextChanged(object sender, EventArgs e)
    {
        if (periodofemployment3.Text == "")
        {

            Response.Write("<script>alert('Please choose From date first!!')</script>");
            periodofemptilldate3.Text = "";
        }
        else

            if (periodofemployment3.Text != "" && periodofemptilldate3.Text != "")
            {
                const string DateFormat = "dd/MM/yyyy";
                DateTime From = DateTime.ParseExact(periodofemployment3.Text, DateFormat, null);
                DateTime To = DateTime.ParseExact(periodofemptilldate3.Text, DateFormat, null);


                if (From > To)
                {
                    Response.Write("<script>alert('To date must be greater than the From date!!')</script>");
                    periodofemptilldate3.Text = "";

                }
                else
                {
                    TimeSpan Span = To - From;


                    DateTime Total = DateTime.MinValue + Span;



                    int Years = Total.Year - 1;
                    int Months = Total.Month - 1;
                    int Days = Total.Day - 1;
                    txtemp3experienceinyear.Text = Years + "year " + Months + "months " + Days + "days";
                }



            }

    }
    protected void periodofemptilldate4_TextChanged(object sender, EventArgs e)
    {
        if (periodofemployment4.Text == "")
        {

            Response.Write("<script>alert('Please choose From date first!!')</script>");
            periodofemptilldate4.Text = "";
        }
        else
            if (periodofemployment4.Text != "" && periodofemptilldate4.Text != "")
            {
                const string DateFormat = "dd/MM/yyyy";
                DateTime From = DateTime.ParseExact(periodofemployment4.Text, DateFormat, null);
                DateTime To = DateTime.ParseExact(periodofemptilldate4.Text, DateFormat, null);


                if (From > To)
                {
                    Response.Write("<script>alert('To date must be greater than the From date!!')</script>");
                    periodofemptilldate4.Text = "";

                }
                else
                {
                    TimeSpan Span = To - From;


                    DateTime Total = DateTime.MinValue + Span;



                    int Years = Total.Year - 1;
                    int Months = Total.Month - 1;
                    int Days = Total.Day - 1;
                    txtemp4experience.Text = Years + "year " + Months + "months " + Days + "days";
                }



            }
    }
    protected void periodofemptilldate5_TextChanged(object sender, EventArgs e)
    {

        if (periodofemployment5.Text == "")
        {

            Response.Write("<script>alert('Please choose period of employment from date first!!')</script>");
            periodofemptilldate5.Text = "";
        }
        else
            if (periodofemployment5.Text != "" && periodofemptilldate5.Text != "")
            {
                const string DateFormat = "dd/MM/yyyy";
                DateTime From = DateTime.ParseExact(periodofemployment5.Text, DateFormat, null);
                DateTime To = DateTime.ParseExact(periodofemptilldate5.Text, DateFormat, null);

                if (From > To)
                {
                    Response.Write("<script>alert('To date must be greater than the From date!!')</script>");
                    periodofemptilldate5.Text = "";

                }
                else
                {

                    TimeSpan Span = To - From;


                    DateTime Total = DateTime.MinValue + Span;



                    int Years = Total.Year - 1;
                    int Months = Total.Month - 1;
                    int Days = Total.Day - 1;
                    txtemp5experience.Text = Years + "year " + Months + "months " + Days + "days";
                }



            }
    }


    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBox1.Checked == true)
        {
            periodofemployment1.ReadOnly = true;
            periodofemployment1.Text = "";
            periodofemptilldate1.ReadOnly = true;
            periodofemptilldate1.Text = "";
            txtcmpny1expinyear.ReadOnly = true;
            txtcmpny1expinyear.Text = "Still Active";
            calender1emp1from.Visible = false;
            calender1emp1to.Visible = false;

        }
        else
        {
            periodofemployment1.ReadOnly = false;
            periodofemployment1.Text = "";
            periodofemptilldate1.ReadOnly = false;
            periodofemptilldate1.Text = "";
            txtcmpny1expinyear.ReadOnly = false;
            txtcmpny1expinyear.Text = "";
            calender1emp1from.Visible = true;
            calender1emp1to.Visible = true;
        }
    }



    //protected void imageadd_Load(object sender, EventArgs e)
    //{

    //    string ede = lblEdu.Text;
    //    lblEdu.Text = "Add";

    //    imageedu.Attributes.Add("onclick", "openPopUp('PopUp.aspx')");
    //    Session["ID"] = "Add".ToString();
    //}

    //protected void imageedu_Load(object sender, EventArgs e)
    //{
    //    string ee = lblEdu.Text;
    //    lblEdu.Text = "Edu";


    //    Session["ID"] = "Edu".ToString();
    //}
    protected void ddlref_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlref.SelectedValue == "0")
        {
            ref1.Visible = false;
            ref2.Visible = false;

        }
        if (ddlref.SelectedValue == "Reference1")
        {
            ref1.Visible = true;
            ref2.Visible = false;

        }
        if (ddlref.SelectedValue == "Reference2")
        {
            ref1.Visible = true;
            ref2.Visible = true;

        }
    }
    protected void ddlcibil_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlcibil.SelectedValue == "0")
        {
            cibil.Visible = false;

        }
        if (ddlcibil.SelectedValue == "Cibil")
        {
            cibil.Visible = true;

        }
    }
    protected void BtnAuthorizationLetter_Click(object sender, EventArgs e)
    {
       string FolderPath = Server.MapPath("~\\LOA\\Authorization form.pdf");
       System.IO.FileInfo file = new System.IO.FileInfo(FolderPath);
      if (file.Exists)
       {
           Response.Clear();
           Response.AddHeader("Content-Disposition", "attachment;filename=\"" + file.Name + "\"");            
           Response.AddHeader("Content-Length", file.Length.ToString());
           Response.ContentType = "application/octet-stream";
            Response.WriteFile(file.FullName);
            Response.End();
        }

    }
    protected void btnfileupedu_Click(object sender, EventArgs e)
    {
        uploadfiles.uploaddownloadfiles up = new uploadfiles.uploaddownloadfiles();
        if (fileeduupload.HasFile == true)
        {
            string filename = fileeduupload.PostedFile.FileName;
            int i = -1;
            string[] filepathSplit = filename.Split('\\');
            foreach (string arrStr in filepathSplit)
            {
                i++;
            }
            string file = filepathSplit[i].ToString();
            string Checkype = "Provisional Certificate";
            //save the file to the server
            string fileRename = file + System.DateTime.Now.ToString("ddMMyyyyhhmmss");
            fileeduupload.PostedFile.SaveAs(Server.MapPath("~\\Uploaded\\") + fileRename);
            //lblStatus.Text = "File Saved to: " + Server.MapPath("~\\Uploaded\\") +EmpID+Checkype+ file;
            string Filename = Server.MapPath("~\\Uploaded\\") + fileRename;
            up.ActiveStatus = "1";
            up.BackgroundType = Checkype;
            up.CandidateID = "0";
            up.FileName = fileRename;
            up.UploadStatus = "1";
            up.FileSize = "NA";
            up.FirstName = txtFirstName.Text.ToString();
            up.MiddleName = txtMiddleName.Text.ToString();
            up.Surname = txtLastName.Text.ToString();
            up.FatherName = txtfathername.Text.ToString();
            up.Mobile = txtcandidatemobile.Text.ToString();
            try
            {
                up.saveFile(up);
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            lblstatusedu.Text = "File Uploaded Successfully";


        }
        else
        {
            //Response.Write("ss");
            Response.Write("<script>alert('Please Choose a File !');</script>");
        }
        ShowFile();
        // tbladdd.Visible = true;
    }
    protected void Button1up_Click(object sender, EventArgs e)
    {
        uploadfiles.uploaddownloadfiles up = new uploadfiles.uploaddownloadfiles();
        if (fileupload2.HasFile == true)
        {
            string filename = fileeduupload.PostedFile.FileName;
            int i = -1;
            string[] filepathSplit = filename.Split('\\');
            foreach (string arrStr in filepathSplit)
            {
                i++;
            }
            string file = filepathSplit[i].ToString();
            string Checkype = "Relieving Letter";
            //save the file to the server
            string fileRename = file + System.DateTime.Now.ToString("ddMMyyyyhhmmss");
            fileeduupload.PostedFile.SaveAs(Server.MapPath("~\\Uploaded\\") + fileRename);
            //lblStatus.Text = "File Saved to: " + Server.MapPath("~\\Uploaded\\") +EmpID+Checkype+ file;
            string Filename = Server.MapPath("~\\Uploaded\\") + fileRename;
            up.ActiveStatus = "1";
            up.BackgroundType = Checkype;
            up.CandidateID = "0";
            up.FileName = fileRename;
            up.UploadStatus = "1";
            up.FileSize = "NA";
            up.FirstName = txtFirstName.Text.ToString();
            up.MiddleName = txtMiddleName.Text.ToString();
            up.Surname = txtLastName.Text.ToString();
            up.FatherName = txtfathername.Text.ToString();
            up.Mobile = txtcandidatemobile.Text.ToString();
            try
            {
                up.saveFile(up);
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            lblstatusedu.Text = "File Uploaded Successfully";


        }
        else
        {
            //Response.Write("ss");
            Response.Write("<script>alert('Please Choose a File !');</script>");
        }
        ShowFile();
        // tbladdd.Visible = true;
    }
    protected void btnaddupload_Click(object sender, EventArgs e)
    {
        uploadfiles.uploaddownloadfiles up = new uploadfiles.uploaddownloadfiles();
        if (fileuploadadd.HasFile == true)
        {
            string filename = fileeduupload.PostedFile.FileName;
            int i = -1;
            string[] filepathSplit = filename.Split('\\');
            foreach (string arrStr in filepathSplit)
            {
                i++;
            }
            string file = filepathSplit[i].ToString();
            string Checkype = "Address";
            //save the file to the server
            string fileRename = file + System.DateTime.Now.ToString("ddMMyyyyhhmmss");
            fileeduupload.PostedFile.SaveAs(Server.MapPath("~\\Uploaded\\") + fileRename);
            //lblStatus.Text = "File Saved to: " + Server.MapPath("~\\Uploaded\\") +EmpID+Checkype+ file;
            string Filename = Server.MapPath("~\\Uploaded\\") + fileRename;
            up.ActiveStatus = "1";
            up.BackgroundType = Checkype;
            up.CandidateID = "0";
            up.FileName = fileRename;
            up.UploadStatus = "1";
            up.FileSize = "NA";
            up.FirstName = txtFirstName.Text.ToString();
            up.MiddleName = txtMiddleName.Text.ToString();
            up.Surname = txtLastName.Text.ToString();
            up.FatherName = txtfathername.Text.ToString();
            up.Mobile = txtcandidatemobile.Text.ToString();
            try
            {
                up.saveFile(up);
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            lblstatusedu.Text = "File Uploaded Successfully";


        }
        else
        {
            //Response.Write("ss");
            Response.Write("<script>alert('Please Choose a File !');</script>");
        }
        ShowFile();
        // tbladdd.Visible = true;

    }
    protected void btnpartial_Click(object sender, EventArgs e)
    {
       
        //try
        //{
        //if ((drpeducation.SelectedItem.Text != "--Select--") !! (drpnoo))
        //{


            candidateobj.gender = txtGender.Text.ToString();
            candidateobj.maritalstatus = txtmaritalstatus.SelectedItem.Text.ToString();


            if (drpBand.SelectedItem.Text == "--Select--")
            {
                candidateobj.Band = "";

            }
            else
            {
                candidateobj.Band = drpBand.SelectedItem.Text.ToString();

            }
            if (drpCOE.SelectedItem.Text == "--Select--")
            {
                candidateobj.COE = "";
            }

            if (drpCOE.SelectedItem.Text == "OTHER")
            {
                candidateobj.COE = txtCOE.Text.ToString();
            }
            else
            {
                candidateobj.COE = drpCOE.SelectedItem.Text.ToString();
            }
            if (drpPOJ.SelectedItem.Text == "--Select--")
            {
                candidateobj.PlaceofJoing = "";
            }
            else
            {
                candidateobj.PlaceofJoing = drpPOJ.SelectedItem.Text.ToString();
            }
            candidateobj.DateofJoining = txtDateOfJoining.Text.ToString();
            candidateobj.FirstName = txtFirstName.Text.ToString();
            candidateobj.MiddleName = txtMiddleName.Text.ToString();
            candidateobj.Surname = txtLastName.Text.ToString();
            candidateobj.FatherName = txtfathername.Text.ToString();
            candidateobj.DOB = txtcandidateDOB.Text.ToString();
            candidateobj.Mobile = txtcandidatemobile.Text.ToString();
            if (drpeducation.SelectedItem.Text != "--Select--")
            {
                candidateobj.EducationList = drpeducation.SelectedItem.Text;

            }
            else
            {
                candidateobj.EducationList = "";
            }
            candidateobj.Edu1_CollegeName = txt_Edu1_CollageName.Text.ToString();
            candidateobj.Edu1_UniversityName = txt_Edu1_UniversityName0.Text.ToString();
            candidateobj.Edu1_Address = txtEdu1Address.Text.ToString();
            candidateobj.Edu1_RollNo = txtedu1Rollno.Text.ToString();
            candidateobj.Edu1_YearOfPassing = txt_Edu1_YearOfPassing0.Text.ToString();
            candidateobj.Edu1_EducationalQualification = txt_Edu1_EducationalQualification.Text.ToString();

            candidateobj.Edu2_CollegeName = txt_Edu2_CollageName.Text.ToString();
            candidateobj.Edu2_UniversityName = txt_Edu2_UniversityName0.Text.ToString();
            candidateobj.Edu2_Address = txtEdu2Address.Text.ToString();
            candidateobj.Edu2_RollNo = txtedu2Rollno.Text.ToString();
            candidateobj.Edu2_YearOfPassing = txt_Edu2_YearOfPassing0.Text.ToString();
            candidateobj.Edu2_EducationalQualification = txt_Edu2_EducationalQualification.Text.ToString();

            candidateobj.Edu3_CollegeName = txt_Edu3_CollageName.Text.ToString();
            candidateobj.Edu3_UniversityName = txt_Edu3_UniversityName0.Text.ToString();
            candidateobj.Edu3_Address = txtEdu3Address.Text.ToString();
            candidateobj.Edu3_RollNo = txtedu3Rollno.Text.ToString();
            candidateobj.YearOfPassing3 = txt_Edu3_YearOfPassing0.Text.ToString();
            candidateobj.Edu3_EducationalQualification = txt_Edu3_EducationalQualification.Text.ToString();

            candidateobj.Edu4_CollegeName = txt_Edu4_CollageName.Text.ToString();
            candidateobj.Edu4_UniversityName = txt_Edu4_UniversityName0.Text.ToString();
            candidateobj.Edu4_Address = txtEdu4Address.Text.ToString();
            candidateobj.Edu4_RollNo = txtedu4Rollno.Text.ToString();
            candidateobj.YearOfPassing4 = txt_Edu4_YearOfPassing0.Text.ToString();
            candidateobj.Edu4_EducationalQualification = txt_Edu4_EducationalQualification.Text.ToString();

            candidateobj.Edu5_CollegeName = txt_Edu5_CollageName.Text.ToString();
            candidateobj.Edu5_UniversityName = txt_Edu5_UniversityName0.Text.ToString();
            candidateobj.Edu5_Address = txtEdu5Address.Text.ToString();
            candidateobj.Edu5_RollNo = txtedu5Rollno.Text.ToString();
            candidateobj.YearOfPassing5 = txt_Edu5_YearOfPassing0.Text.ToString();
            candidateobj.Edu5_EducationalQualification = txt_Edu5_EducationalQualification.Text.ToString();

            candidateobj.Edu6_CollegeName = txt_Edu6_CollageName.Text.ToString();
            candidateobj.Edu6_UniversityName = txt_Edu6_UniversityName0.Text.ToString();
            candidateobj.Edu6_Address = txtEdu6Address.Text.ToString();
            candidateobj.Edu6_RollNo = txtedu6Rollno.Text.ToString();
            candidateobj.YearOfPassing6 = txt_Edu6_YearOfPassing0.Text.ToString();
            candidateobj.Edu6_EducationalQualification = txt_Edu6_EducationalQualification.Text.ToString();

            candidateobj.Edu7_CollegeName = txt_Edu7_CollageName.Text.ToString();
            candidateobj.Edu7_UniversityName = txt_Edu7_UniversityName0.Text.ToString();
            candidateobj.Edu7_Address = txtEdu7Address.Text.ToString();
            candidateobj.Edu7_RollNo = txtedu7Rollno.Text.ToString();
            candidateobj.YearOfPassing7 = txt_Edu7_YearOfPassing0.Text.ToString();
            candidateobj.Edu7_EducationalQualification = txt_Edu7_EducationalQualification.Text.ToString();

            candidateobj.Edu8_CollegeName = txt_Edu8_CollageName.Text.ToString();
            candidateobj.Edu8_UniversityName = txt_Edu8_UniversityName0.Text.ToString();
            candidateobj.Edu8_Address = txtEdu8Address.Text.ToString();
            candidateobj.Edu8_RollNo = txtedu8Rollno.Text.ToString();
            candidateobj.YearOfPassing8 = txt_Edu8_YearOfPassing0.Text.ToString();
            candidateobj.Edu8_EducationalQualification = txt_Edu8_EducationalQualification.Text.ToString();


            if (dropaddress.SelectedItem.Text == "Address Check")
            {
                candidateobj.AddressCheck = dropaddress.SelectedItem.Text;

            }
            else
            {
                candidateobj.AddressCheck = "";

            }
            candidateobj.PermanentAddress = txtaddress1parmanent.Text.ToString();

            if (txtAddressparmentstate.SelectedItem.Text != "--Select--")
            {
                candidateobj.Per_State = txtAddressparmentstate.SelectedItem.Text.ToString();
            }



            candidateobj.Per_City = txtadd1parmanentcity.Text.ToString();
            candidateobj.Per_AddressPhoneNo = txt_parmanetSTD.Text.ToString() + "-" + txt_parmanent_PhoneNo.Text.ToString();
            candidateobj.Per_Landmark = txtadd1parmanentlandmark.Text.ToString();
            if (txtadd1livingsince.SelectedItem.Text != "--Select--")
            {
                candidateobj.Per_LivingSince = txtadd1livingsince.SelectedItem.Text.ToString();
            }
            candidateobj.Per_LivingSince = "";
            candidateobj.Per_PoliceStation = txtadd1policestation.Text.ToString();
            candidateobj.Per_PostOffice = txtadd1pincode.Text.ToString();

            candidateobj.add1logeststay = txtadd1logeststay.Text.ToString();

            if (txtaddlongstaystate.SelectedItem.Text != "--Select--")
            {
                candidateobj.add1logeststarystate = txtaddlongstaystate.SelectedItem.Text.ToString();
            }

            candidateobj.add1logeststarycity = txtaddlongeststaycity.Text.ToString();
            candidateobj.add1logeststaryphonenumber = txtlogstaySTd.Text.ToString() + "-" + txtlongstayNumber.Text.ToString();
            candidateobj.add1logeststarylandmark = txtlongstaylandmark.Text.ToString();
            if (txtlongstaylivingsince.SelectedItem.Text != "--Select--")
            {
                candidateobj.add1logeststaryLeavingsince = txtlongstaylivingsince.SelectedItem.Text.ToString();
            }

            candidateobj.add1logeststaryLeavingsince = "";
            candidateobj.add1logeststarypolicestation = txtlongstaypolicestation.Text.ToString();
            candidateobj.add1logeststarypincode = txtlongstaypincode.Text.ToString();

            candidateobj.CurrentAddress = txtaddcurrentaddres.Text.ToString();

            if (txtaddcurrentstate.SelectedItem.Text != "--Select--")
            {
                candidateobj.Curr_State = txtaddcurrentstate.SelectedItem.Text.ToString();
            }



            candidateobj.Curr_City = txtaddcurentcity.Text.ToString();
            candidateobj.Curr_PhoneNo = txtaddcurentSTD.Text.ToString() + "-" + txtaddcurrentnumber.Text.ToString();
            //string chk1 = "";
            //string chk2 = "";
            //string chk3 = "";

            //if (chkcriminal1.Checked == true)
            //{
            //    chk1 = "1";
            //    candidateobj.criminalchk1 = chk1.ToString();

            //}
            //else
            //{
            //    candidateobj.criminalchk1 = "";
            //}

            //if (chkcriminal2.Checked == true)
            //{
            //    chk2 = "2";
            //    candidateobj.criminalchk2 = chk2.ToString();

            //}
            //else
            //{
            //    candidateobj.criminalchk2 = "";
            //}


            //if (chkcriminal3.Checked == true)
            //{
            //    chk3 = "3";
            //    candidateobj.criminalchk3 = chk3.ToString();

            //}
            //else
            //{
            //    candidateobj.criminalchk3 = "";
            //}
            if (dropFresherexp.SelectedItem.Text == "Fresher")
            {
                candidateobj.FresherOrExp = "";
            }
            else
            {
                candidateobj.FresherOrExp = dropFresherexp.SelectedItem.Text.ToString();
            }
            if (drpnoofcompany.SelectedItem.Text == "--Select--")
            {
                candidateobj.NoOfComp = "";
            }
            else
            {
                if (drpnoofcompany.SelectedItem.Text == "1")
                {
                    candidateobj.NoOfComp = "Company1";

                }
                if (drpnoofcompany.SelectedItem.Text == "2")
                {
                    candidateobj.NoOfComp = "Company2";

                }
                //if (drpnoofcompany.SelectedItem.Text == "3")
                //{
                //    candidateobj.NoOfComp = "Company3";

                //}
                //if (drpnoofcompany.SelectedItem.Text == "4")
                //{
                //    candidateobj.NoOfComp = "Company4";

                //}
                //if (drpnoofcompany.SelectedItem.Text == "5")
                //{
                //    candidateobj.NoOfComp = "Company5";

                //}

                candidateobj.NoOfComp = drpnoofcompany.SelectedItem.Text.ToString();
            }
            candidateobj.EmpHis1_CompnayNameandLocation = txtcmpy1nameloction.Text.ToString();
            candidateobj.EmpHis1_LastPositionHeldnDepartmentName = txtcmp1lastpostin.Text.ToString();
            candidateobj.cmp1department = txtcmp1department.Text.ToString();
            candidateobj.EmpHis1_TelephoneNo = txtcmp1Std.Text.ToString() + "-" + txtcmp1number.Text.ToString();
            candidateobj.EmpHis1_Address = txtemp1officeaddress.Text.ToString();
            candidateobj.EmpHis1_EmployeeCode = txtemp1employecode.Text.ToString();
            candidateobj.ExperienceInYears1 = txtcmpny1expinyear.Text.ToString();
            candidateobj.EmpHis1_PeriodofEmployment = periodofemployment1.Text.ToString();
            candidateobj.EmpHis1_PeriodofEmploymentRemark = periodofemptilldate1.Text.ToString();
            candidateobj.EmpHis1RLvl1_NameDesignatinOfSupervisor = txtemp1namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp1HRdesignation = txtcmp1hrdesignation.Text.ToString();
            candidateobj.EmpHis1RLvl1_TelepnoneNo = txtemp1supervisorlevel1STD.Text.ToString() + "-" + txtemp1supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis1RLvl1_MobileNo = txtemp1supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis1RLvl1_EmailId = txtemp1supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis1RLvl2_NameDesignatinOfSupervisor = txtemp1namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp1RMdesignation = txtcmp1supervisordesignation.Text.ToString();

            candidateobj.EmpHis1RLvl2_TelepnoneNo = txtemp1supervisorlevel2STD.Text.ToString() + "-" + txtemp1supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis1RLvl2_MobileNo = txtemp1supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis1RLvl2_EmailId = txtemp1supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis1_TempPerma = RadioButtoncmp1emptype.SelectedValue.ToString();
            candidateobj.EmpHis1_AgencyDetails = emp1agencydetail.Text.ToString();
            candidateobj.EmpHis1_RemunerationOrSalary = emp1remunerationsalary.Text.ToString();
            candidateobj.EmpHis1_ReasonOfLeaving = emp1reasonofleaving.Text.ToString();
            candidateobj.EmpHis1_referenceYN = emp1referenceYN.SelectedValue.ToString();
            //candidateobj.EmpHis1_IncaseOfGap = emp1incaseofgap.Text.ToString();
            candidateobj.EmpHis1_NoticePeriodorNot = RadioButtonemp1noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis2_CompnayNameandLocation = txtemp2compnyname.Text.ToString();
            candidateobj.EmpHis2_LastPositionHeldnDepartmentName = txtemp2lastposition.Text.ToString();
            candidateobj.cmp2department = txtcmp2department.Text.ToString();
            candidateobj.EmpHis2_TelephoneNo = emp2cmpSTD.Text.ToString() + "-" + emp2cmpnumber.Text.ToString();
            candidateobj.EmpHis2_Address = txtemp2officeaddress.Text.ToString();
            candidateobj.EmpHis2_EmployeeCode = txtemp2employeecode.Text.ToString();
            candidateobj.ExperienceInYears2 = txtemp2experience.Text.ToString();
            candidateobj.EmpHis2_PeriodofEmployment = periodofemployment2.Text.ToString();
            candidateobj.EmpHis2_PeriodofEmploymentRemark = periodofemptilldate2.Text.ToString();
            candidateobj.EmpHis2RLvl1_NameDesignatinOfSupervisor = txtemp2namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp2HRdesignation = txtcmp2hrdesignation.Text.ToString();

            candidateobj.EmpHis2RLvl1_TelepnoneNo = txtemp2supervisorlevel1STD.Text.ToString() + "-" + txtemp2supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis2RLvl1_MobileNo = txtemp2supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis2RLvl1_EmailId = txtemp2supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis2RLvl2_NameDesignatinOfSupervisor = txtemp2namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp2RMdesignation = txtcmp2supervisordesignation.Text.ToString();

            candidateobj.EmpHis2RLvl2_TelepnoneNo = txtemp2supervisorlevel2STD.Text.ToString() + "-" + txtemp2supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis2RLvl2_MobileNo = txtemp2supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis2RLvl2_EmailId = txtemp2supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis2_TempPerma = RadioButtoncmp2emptype.SelectedValue.ToString();
            candidateobj.EmpHis2_AgencyDetails = emp2agencydetail.Text.ToString();
            candidateobj.EmpHis2_RemunerationOrSalary = emp2remunerationsalary.Text.ToString();
            candidateobj.EmpHis2_ReasonOfLeaving = emp2reasonofleaving.Text.ToString();
            candidateobj.EmpHis2_referenceYN = emp2referenceYN.Text.ToString();
            // candidateobj.EmpHis2_IncaseOfGap = emp2incaseofgap.Text.ToString();
            candidateobj.EmpHis2_NoticePeriodorNot = RadioButtonemp2noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis3_CompnayNameandLocation = txtemp3companyname.Text.ToString();
            candidateobj.EmpHis3_LastPositionHeldnDepartmentName = txtemp3lastposition.Text.ToString();
            candidateobj.cmp3department = cmp3department.Text.ToString();

            candidateobj.EmpHis3_TelephoneNo = emp3cmpSTD.Text.ToString() + "-" + emp3cmpnumber.Text.ToString();
            candidateobj.EmpHis3_Address = txtemp3officeaddress.Text.ToString();
            candidateobj.EmpHis3_EmployeeCode = txtemp3employeecode.Text.ToString();
            candidateobj.ExperienceInYears3 = txtemp3experienceinyear.Text.ToString();
            candidateobj.EmpHis3_PeriodofEmployment = periodofemployment3.Text.ToString();
            candidateobj.EmpHis3_PeriodofEmploymentRemark = periodofemptilldate3.Text.ToString();
            candidateobj.EmpHis3RLvl1_NameDesignatinOfSupervisor = txtemp3namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp3HRdesignation = txtcmp3hrdesignation.Text.ToString();

            candidateobj.EmpHis3RLvl1_TelepnoneNo = txtemp3supervisorlevel1STD.Text.ToString() + "-" + txtemp3supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis3RLvl1_MobileNo = txtemp3supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis3RLvl1_EmailId = txtemp3supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis3RLvl2_NameDesignatinOfSupervisor = txtemp3namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp3RMdesignation = txtcmp3supervisordesignation.Text.ToString();

            candidateobj.EmpHis3RLvl2_TelepnoneNo = txtemp3supervisorlevel2STD.Text.ToString() + "-" + txtemp3supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis3RLvl2_MobileNo = txtemp3supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis3RLvl2_EmailId = txtemp3supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis3_TempPerma = RadioButtoncmp3emptype.SelectedValue.ToString();
            candidateobj.EmpHis3_AgencyDetails = emp3agencydetail.Text.ToString();
            candidateobj.EmpHis3_RemunerationOrSalary = emp3remunerationsalary.Text.ToString();
            candidateobj.EmpHis3_ReasonOfLeaving = emp3reasonofleaving.Text.ToString();
            candidateobj.EmpHis3_referenceYN = emp3referenceYN.Text.ToString();
            //candidateobj.EmpHis3_IncaseOfGap = emp3incaseofgap.Text.ToString();
            candidateobj.EmpHis3_NoticePeriodorNot = RadioButtonemp3noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis4_CompnayNameandLocation = txtemp4companyname.Text.ToString();
            candidateobj.EmpHis4_LastPositionHeldnDepartmentName = txtemp4lastpostion.Text.ToString();
            candidateobj.cmp4department = txtcmp4department.Text.ToString();

            candidateobj.EmpHis4_TelephoneNo = emp4cmpSTD.Text.ToString() + "-" + emp4cmpnumber.Text.ToString();
            candidateobj.EmpHis4_Address = txtemp4officeaddress.Text.ToString();
            candidateobj.EmpHis4_EmployeeCode = txtemp4employeecode.Text.ToString();
            candidateobj.ExperienceInYears4 = txtemp4experience.Text.ToString();
            candidateobj.EmpHis4_PeriodofEmployment = periodofemployment4.Text.ToString();
            candidateobj.EmpHis4_PeriodofEmploymentRemark = periodofemptilldate4.Text.ToString();
            candidateobj.EmpHis4RLvl1_NameDesignatinOfSupervisor = txtemp4namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp4HRdesignation = txtcmp4hrdesignation.Text.ToString();

            candidateobj.EmpHis4RLvl1_TelepnoneNo = txtemp4supervisorlevel1STD.Text.ToString() + "-" + txtemp3supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis4RLvl1_MobileNo = txtemp4supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis4RLvl1_EmailId = txtemp4supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis4RLvl2_NameDesignatinOfSupervisor = txtemp4namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp4RMdesignation = txtcmp4supervisordesignation.Text.ToString();

            candidateobj.EmpHis4RLvl2_TelepnoneNo = txtemp4supervisorlevel2STD.Text.ToString() + "-" + txtemp3supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis4RLvl2_MobileNo = txtemp4supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis4RLvl2_EmailId = txtemp4supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis4_TempPerma = RadioButtoncmp4emptype.SelectedValue.ToString();
            candidateobj.EmpHis4_AgencyDetails = emp4agencydetail.Text.ToString();
            candidateobj.EmpHis4_RemunerationOrSalary = emp4remunerationsalary.Text.ToString();
            candidateobj.EmpHis4_ReasonOfLeaving = emp4reasonofleaving.Text.ToString();
            candidateobj.EmpHis4_referenceYN = emp4referenceYN.Text.ToString();
            //candidateobj.EmpHis4_IncaseOfGap = emp4incaseofgap.Text.ToString();
            candidateobj.EmpHis4_NoticePeriodorNot = RadioButtonemp4noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis5_CompnayNameandLocation = txtemp5companyname.Text.ToString();
            candidateobj.EmpHis5_LastPositionHeldnDepartmentName = txtemp5lastposition.Text.ToString();
            candidateobj.cmp5department = txtcmp5department.Text.ToString();

            candidateobj.EmpHis5_TelephoneNo = emp5cmpSTD.Text.ToString() + "-" + emp5cmpnumber.Text.ToString();
            candidateobj.EmpHis5_Address = txtemp5officeaddress.Text.ToString();
            candidateobj.EmpHis5_EmployeeCode = txtemp5employeecode.Text.ToString();
            candidateobj.ExperienceInYears5 = txtemp5experience.Text.ToString();
            candidateobj.EmpHis5_PeriodofEmployment = periodofemployment5.Text.ToString();
            candidateobj.EmpHis5_PeriodofEmploymentRemark = periodofemptilldate5.Text.ToString();
            candidateobj.EmpHis5RLvl1_NameDesignatinOfSupervisor = txtemp5namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp5HRdesignation = txtcmp5hrdesignation.Text.ToString();

            candidateobj.EmpHis5RLvl1_TelepnoneNo = txtemp5supervisorlevel1STD.Text.ToString() + "-" + txtemp3supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis5RLvl1_MobileNo = txtemp5supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis5RLvl1_EmailId = txtemp5supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis5RLvl2_NameDesignatinOfSupervisor = txtemp5namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp5RMdesignation = txtcmp5supervisordesignation.Text.ToString();

            candidateobj.EmpHis5RLvl2_TelepnoneNo = txtemp5supervisorlevel2STD.Text.ToString() + "-" + txtemp5supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis5RLvl2_MobileNo = txtemp5supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis5RLvl2_EmailId = txtemp5supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis5_TempPerma = RadioButtoncmp5emptype.SelectedValue.ToString();
            candidateobj.EmpHis5_AgencyDetails = emp5agencydetail.Text.ToString();
            candidateobj.EmpHis5_RemunerationOrSalary = emp5remunerationsalary.Text.ToString();
            candidateobj.EmpHis5_ReasonOfLeaving = emp5reasonofleaving.Text.ToString();
            candidateobj.EmpHis5_referenceYN = emp5referenceYN.Text.ToString();
            //candidateobj.EmpHis5_IncaseOfGap = emp5incaseofgap.Text.ToString();
            candidateobj.EmpHis5_NoticePeriodorNot = RadioButtonemp5noticeperiodYN.SelectedValue.ToString();

            candidateobj.CurrentEmployment = radiobuttoncurrentemp.SelectedValue.ToString();




            candidateobj.RejectedRemarks1 = RejectedRemark1.Text.ToString();
            candidateobj.RejectedRemarks2 = RejectedRemark2.Text.ToString();
            candidateobj.RejectedRemarks3 = RejectedRemark3.Text.ToString();
            candidateobj.RejectedRemarks4 = RejectedRemark4.Text.ToString();
            candidateobj.RejectedRemarks5 = RejectedRemark5.Text.ToString();

            candidateobj.comment1 = comment1.Text.ToString();
            candidateobj.comment2 = comment2.Text.ToString();
            candidateobj.comment3 = comment3.Text.ToString();
            candidateobj.comment4 = comment4.Text.ToString();
            candidateobj.comment5 = comment5.Text.ToString();

            candidateobj.candidatealternateno = txtcandidatealternateno.Text.ToString();
            candidateobj.candidateremarks = txtcandidateremarks.Text.ToString();

            //candidateobj.CAmemeber = txtCAmember.Text.ToString();
            //---mohan
            if (ddlref.SelectedItem.Text != "--Select--")
            {
                candidateobj.RefList = ddlref.SelectedItem.Text;

            }
            else
            {
                candidateobj.RefList = "";
            }
           
            candidateobj.Ref1RefName = txtRef1RefName.Text;
            candidateobj.Ref1CompName = txtRef1CompanyName.Text;
            candidateobj.Ref1Designation = txtRef1Designation.Text;
            candidateobj.Ref1Email = txtRef1EmailId.Text;
            candidateobj.Ref1Contact = txtRef1Contact.Text;

            candidateobj.Ref2RefName = txtRef2RefName.Text;
            candidateobj.Ref2CompName = txtRef2CompanyName.Text;
            candidateobj.Ref2Designation = txtRef2Designation.Text;
            candidateobj.Ref2Email = txtRef2EmailId.Text;
            candidateobj.Ref2Contact = txtRef2Contact.Text;

            if (ddlcibil.SelectedItem.Text != "--Select--")
            {
                candidateobj.CIBILList = ddlcibil.SelectedItem.Text;

            }
            else
            {
                candidateobj.CIBILList = "";
            }
            candidateobj.CIBILContact = txtCIBILContact.Text;
            candidateobj.CIBILDOB = dtpCIBILDOB.Text;
            candidateobj.CIBILEmail = txtCIBILEmail.Text;
            candidateobj.CIBILFullName = txtCIBILFullName.Text;
            candidateobj.CIBILGender = ddlCIBILgender.Text;
            candidateobj.CIBILPanCard = txtCIBILPanCard.Text;
            candidateobj.CIBILpassportno = txtCIBILpasportno.Text;
            candidateobj.CIBILvoterID = txtCIBILvoterid.Text;
            candidateobj.CIBILDrivinglicense = txtCIBILlience.Text;

            


            string username = User.Identity.Name.ToString();
            candidateobj.user = username.ToString();
            if (cid == "0" || cid == "")
            {
                candidateobj.Mode = "0";
            }
            else
            {
                candidateobj.Mode = Request.QueryString["mode"];
            }

            string url;
            url = "saveinfo.aspx?type="+ candidateobj.Mode+"&savetyep=partial";

            candidateobj.CandidateID = Convert.ToInt32(cid);
            string usertype = "";
            if (string.IsNullOrEmpty(Convert.ToString(Session["UserType"])))
            {
                Response.Redirect("CandidateLogin.aspx");
            }
            else
            {
                usertype = Session["UserType"].ToString();
            }


            if (txtFirstName.Text != "" || drpCOE.SelectedItem.Text != "Select")
            {


                int dtInsert = candidateobj.Savepartial(candidateobj);

                if (dtInsert == 0)
                {

                    if (usertype != "ClientPlusReject" && usertype != "Admin")
                    {
                        Response.Redirect(url);
                    }
                    else
                    {
                        Response.Write("<Script Language='javascript'> alert('Data Updated !')</Script>");
                    }



                }
                //else if (dtInsert == -2)
                //{

                //    Response.Write("<Script Language='javascript'> alert('Already Data Saved !')</Script>");
                //}
                //else if (dtInsert == -1)
                //{

                //    Response.Write("<Script Language='javascript'> alert('Error In Procedure...InsertEmployeeInfo!')</Script>");
                //}



            }
        }

        //else
        //{
        //    Response.Write("<Script Language='javascript'> alert('Please Fill Education Related Information')</Script>");

        //}

        //}



        //}

        //catch (Exception ex)
        //{

        //    Response.Write("<Script Language='javascript'> alert('EXCEPTION!!!!)</Script>");

        //}

    protected void btnpartialadd_Click(object sender, EventArgs e)
    {
        //try
        //{
        //if ((drpeducation.SelectedItem.Text != "--Select--") !! (drpnoo))
        //{


            candidateobj.gender = txtGender.Text.ToString();
            candidateobj.maritalstatus = txtmaritalstatus.SelectedItem.Text.ToString();


            if (drpBand.SelectedItem.Text == "--Select--")
            {
                candidateobj.Band = "";

            }
            else
            {
                candidateobj.Band = drpBand.SelectedItem.Text.ToString();

            }
            if (drpCOE.SelectedItem.Text == "--Select--")
            {
                candidateobj.COE = "";
            }

            if (drpCOE.SelectedItem.Text == "OTHER")
            {
                candidateobj.COE = txtCOE.Text.ToString();
            }
            else
            {
                candidateobj.COE = drpCOE.SelectedItem.Text.ToString();
            }
            if (drpPOJ.SelectedItem.Text == "--Select--")
            {
                candidateobj.PlaceofJoing = "";
            }
            else
            {
                candidateobj.PlaceofJoing = drpPOJ.SelectedItem.Text.ToString();
            }
            candidateobj.DateofJoining = txtDateOfJoining.Text.ToString();
            candidateobj.FirstName = txtFirstName.Text.ToString();
            candidateobj.MiddleName = txtMiddleName.Text.ToString();
            candidateobj.Surname = txtLastName.Text.ToString();
            candidateobj.FatherName = txtfathername.Text.ToString();
            candidateobj.DOB = txtcandidateDOB.Text.ToString();
            candidateobj.Mobile = txtcandidatemobile.Text.ToString();
            if (drpeducation.SelectedItem.Text != "--Select--")
            {
                candidateobj.EducationList = drpeducation.SelectedItem.Text;

            }
            else
            {
                candidateobj.EducationList = "";
            }
            candidateobj.Edu1_CollegeName = txt_Edu1_CollageName.Text.ToString();
            candidateobj.Edu1_UniversityName = txt_Edu1_UniversityName0.Text.ToString();
            candidateobj.Edu1_Address = txtEdu1Address.Text.ToString();
            candidateobj.Edu1_RollNo = txtedu1Rollno.Text.ToString();
            candidateobj.Edu1_YearOfPassing = txt_Edu1_YearOfPassing0.Text.ToString();
            candidateobj.Edu1_EducationalQualification = txt_Edu1_EducationalQualification.Text.ToString();

            candidateobj.Edu2_CollegeName = txt_Edu2_CollageName.Text.ToString();
            candidateobj.Edu2_UniversityName = txt_Edu2_UniversityName0.Text.ToString();
            candidateobj.Edu2_Address = txtEdu2Address.Text.ToString();
            candidateobj.Edu2_RollNo = txtedu2Rollno.Text.ToString();
            candidateobj.Edu2_YearOfPassing = txt_Edu2_YearOfPassing0.Text.ToString();
            candidateobj.Edu2_EducationalQualification = txt_Edu2_EducationalQualification.Text.ToString();

            candidateobj.Edu3_CollegeName = txt_Edu3_CollageName.Text.ToString();
            candidateobj.Edu3_UniversityName = txt_Edu3_UniversityName0.Text.ToString();
            candidateobj.Edu3_Address = txtEdu3Address.Text.ToString();
            candidateobj.Edu3_RollNo = txtedu3Rollno.Text.ToString();
            candidateobj.YearOfPassing3 = txt_Edu3_YearOfPassing0.Text.ToString();
            candidateobj.Edu3_EducationalQualification = txt_Edu3_EducationalQualification.Text.ToString();

            candidateobj.Edu4_CollegeName = txt_Edu4_CollageName.Text.ToString();
            candidateobj.Edu4_UniversityName = txt_Edu4_UniversityName0.Text.ToString();
            candidateobj.Edu4_Address = txtEdu4Address.Text.ToString();
            candidateobj.Edu4_RollNo = txtedu4Rollno.Text.ToString();
            candidateobj.YearOfPassing4 = txt_Edu4_YearOfPassing0.Text.ToString();
            candidateobj.Edu4_EducationalQualification = txt_Edu4_EducationalQualification.Text.ToString();

            candidateobj.Edu5_CollegeName = txt_Edu5_CollageName.Text.ToString();
            candidateobj.Edu5_UniversityName = txt_Edu5_UniversityName0.Text.ToString();
            candidateobj.Edu5_Address = txtEdu5Address.Text.ToString();
            candidateobj.Edu5_RollNo = txtedu5Rollno.Text.ToString();
            candidateobj.YearOfPassing5 = txt_Edu5_YearOfPassing0.Text.ToString();
            candidateobj.Edu5_EducationalQualification = txt_Edu5_EducationalQualification.Text.ToString();

            candidateobj.Edu6_CollegeName = txt_Edu6_CollageName.Text.ToString();
            candidateobj.Edu6_UniversityName = txt_Edu6_UniversityName0.Text.ToString();
            candidateobj.Edu6_Address = txtEdu6Address.Text.ToString();
            candidateobj.Edu6_RollNo = txtedu6Rollno.Text.ToString();
            candidateobj.YearOfPassing6 = txt_Edu6_YearOfPassing0.Text.ToString();
            candidateobj.Edu6_EducationalQualification = txt_Edu6_EducationalQualification.Text.ToString();

            candidateobj.Edu7_CollegeName = txt_Edu7_CollageName.Text.ToString();
            candidateobj.Edu7_UniversityName = txt_Edu7_UniversityName0.Text.ToString();
            candidateobj.Edu7_Address = txtEdu7Address.Text.ToString();
            candidateobj.Edu7_RollNo = txtedu7Rollno.Text.ToString();
            candidateobj.YearOfPassing7 = txt_Edu7_YearOfPassing0.Text.ToString();
            candidateobj.Edu7_EducationalQualification = txt_Edu7_EducationalQualification.Text.ToString();

            candidateobj.Edu8_CollegeName = txt_Edu8_CollageName.Text.ToString();
            candidateobj.Edu8_UniversityName = txt_Edu8_UniversityName0.Text.ToString();
            candidateobj.Edu8_Address = txtEdu8Address.Text.ToString();
            candidateobj.Edu8_RollNo = txtedu8Rollno.Text.ToString();
            candidateobj.YearOfPassing8 = txt_Edu8_YearOfPassing0.Text.ToString();
            candidateobj.Edu8_EducationalQualification = txt_Edu8_EducationalQualification.Text.ToString();


            if (dropaddress.SelectedItem.Text == "Address Check")
            {
                candidateobj.AddressCheck = dropaddress.SelectedItem.Text;

            }
            else
            {
                candidateobj.AddressCheck = "";

            }
            candidateobj.PermanentAddress = txtaddress1parmanent.Text.ToString();

            if (txtAddressparmentstate.SelectedItem.Text != "--Select--")
            {
                candidateobj.Per_State = txtAddressparmentstate.SelectedItem.Text.ToString();
            }



            candidateobj.Per_City = txtadd1parmanentcity.Text.ToString();
            candidateobj.Per_AddressPhoneNo = txt_parmanetSTD.Text.ToString() + "-" + txt_parmanent_PhoneNo.Text.ToString();
            candidateobj.Per_Landmark = txtadd1parmanentlandmark.Text.ToString();
            if (txtadd1livingsince.SelectedItem.Text != "--Select--")
            {
                candidateobj.Per_LivingSince = txtadd1livingsince.SelectedItem.Text.ToString();
            }
            candidateobj.Per_LivingSince = "";
            candidateobj.Per_PoliceStation = txtadd1policestation.Text.ToString();
            candidateobj.Per_PostOffice = txtadd1pincode.Text.ToString();

            candidateobj.add1logeststay = txtadd1logeststay.Text.ToString();

            if (txtaddlongstaystate.SelectedItem.Text != "--Select--")
            {
                candidateobj.add1logeststarystate = txtaddlongstaystate.SelectedItem.Text.ToString();
            }

            candidateobj.add1logeststarycity = txtaddlongeststaycity.Text.ToString();
            candidateobj.add1logeststaryphonenumber = txtlogstaySTd.Text.ToString() + "-" + txtlongstayNumber.Text.ToString();
            candidateobj.add1logeststarylandmark = txtlongstaylandmark.Text.ToString();
            if (txtlongstaylivingsince.SelectedItem.Text != "--Select--")
            {
                candidateobj.add1logeststaryLeavingsince = txtlongstaylivingsince.SelectedItem.Text.ToString();
            }

            candidateobj.add1logeststaryLeavingsince = "";
            candidateobj.add1logeststarypolicestation = txtlongstaypolicestation.Text.ToString();
            candidateobj.add1logeststarypincode = txtlongstaypincode.Text.ToString();

            candidateobj.CurrentAddress = txtaddcurrentaddres.Text.ToString();

            if (txtaddcurrentstate.SelectedItem.Text != "--Select--")
            {
                candidateobj.Curr_State = txtaddcurrentstate.SelectedItem.Text.ToString();
            }



            candidateobj.Curr_City = txtaddcurentcity.Text.ToString();
            candidateobj.Curr_PhoneNo = txtaddcurentSTD.Text.ToString() + "-" + txtaddcurrentnumber.Text.ToString();
            //string chk1 = "";
            //string chk2 = "";
            //string chk3 = "";

            //if (chkcriminal1.Checked == true)
            //{
            //    chk1 = "1";
            //    candidateobj.criminalchk1 = chk1.ToString();

            //}
            //else
            //{
            //    candidateobj.criminalchk1 = "";
            //}

            //if (chkcriminal2.Checked == true)
            //{
            //    chk2 = "2";
            //    candidateobj.criminalchk2 = chk2.ToString();

            //}
            //else
            //{
            //    candidateobj.criminalchk2 = "";
            //}


            //if (chkcriminal3.Checked == true)
            //{
            //    chk3 = "3";
            //    candidateobj.criminalchk3 = chk3.ToString();

            //}
            //else
            //{
            //    candidateobj.criminalchk3 = "";
            //}
            if (dropFresherexp.SelectedItem.Text == "Fresher")
            {
                candidateobj.FresherOrExp = "";
            }
            else
            {
                candidateobj.FresherOrExp = dropFresherexp.SelectedItem.Text.ToString();
            }
            if (drpnoofcompany.SelectedItem.Text == "--Select--")
            {
                candidateobj.NoOfComp = "";
            }
            else
            {
                if (drpnoofcompany.SelectedItem.Text == "1")
                {
                    candidateobj.NoOfComp = "Company1";

                }
                if (drpnoofcompany.SelectedItem.Text == "2")
                {
                    candidateobj.NoOfComp = "Company2";

                }
                //if (drpnoofcompany.SelectedItem.Text == "3")
                //{
                //    candidateobj.NoOfComp = "Company3";

                //}
                //if (drpnoofcompany.SelectedItem.Text == "4")
                //{
                //    candidateobj.NoOfComp = "Company4";

                //}
                //if (drpnoofcompany.SelectedItem.Text == "5")
                //{
                //    candidateobj.NoOfComp = "Company5";

                //}

                candidateobj.NoOfComp = drpnoofcompany.SelectedItem.Text.ToString();
            }
            candidateobj.EmpHis1_CompnayNameandLocation = txtcmpy1nameloction.Text.ToString();
            candidateobj.EmpHis1_LastPositionHeldnDepartmentName = txtcmp1lastpostin.Text.ToString();
            candidateobj.cmp1department = txtcmp1department.Text.ToString();
            candidateobj.EmpHis1_TelephoneNo = txtcmp1Std.Text.ToString() + "-" + txtcmp1number.Text.ToString();
            candidateobj.EmpHis1_Address = txtemp1officeaddress.Text.ToString();
            candidateobj.EmpHis1_EmployeeCode = txtemp1employecode.Text.ToString();
            candidateobj.ExperienceInYears1 = txtcmpny1expinyear.Text.ToString();
            candidateobj.EmpHis1_PeriodofEmployment = periodofemployment1.Text.ToString();
            candidateobj.EmpHis1_PeriodofEmploymentRemark = periodofemptilldate1.Text.ToString();
            candidateobj.EmpHis1RLvl1_NameDesignatinOfSupervisor = txtemp1namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp1HRdesignation = txtcmp1hrdesignation.Text.ToString();
            candidateobj.EmpHis1RLvl1_TelepnoneNo = txtemp1supervisorlevel1STD.Text.ToString() + "-" + txtemp1supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis1RLvl1_MobileNo = txtemp1supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis1RLvl1_EmailId = txtemp1supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis1RLvl2_NameDesignatinOfSupervisor = txtemp1namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp1RMdesignation = txtcmp1supervisordesignation.Text.ToString();

            candidateobj.EmpHis1RLvl2_TelepnoneNo = txtemp1supervisorlevel2STD.Text.ToString() + "-" + txtemp1supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis1RLvl2_MobileNo = txtemp1supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis1RLvl2_EmailId = txtemp1supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis1_TempPerma = RadioButtoncmp1emptype.SelectedValue.ToString();
            candidateobj.EmpHis1_AgencyDetails = emp1agencydetail.Text.ToString();
            candidateobj.EmpHis1_RemunerationOrSalary = emp1remunerationsalary.Text.ToString();
            candidateobj.EmpHis1_ReasonOfLeaving = emp1reasonofleaving.Text.ToString();
            candidateobj.EmpHis1_referenceYN = emp1referenceYN.SelectedValue.ToString();
            //candidateobj.EmpHis1_IncaseOfGap = emp1incaseofgap.Text.ToString();
            candidateobj.EmpHis1_NoticePeriodorNot = RadioButtonemp1noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis2_CompnayNameandLocation = txtemp2compnyname.Text.ToString();
            candidateobj.EmpHis2_LastPositionHeldnDepartmentName = txtemp2lastposition.Text.ToString();
            candidateobj.cmp2department = txtcmp2department.Text.ToString();
            candidateobj.EmpHis2_TelephoneNo = emp2cmpSTD.Text.ToString() + "-" + emp2cmpnumber.Text.ToString();
            candidateobj.EmpHis2_Address = txtemp2officeaddress.Text.ToString();
            candidateobj.EmpHis2_EmployeeCode = txtemp2employeecode.Text.ToString();
            candidateobj.ExperienceInYears2 = txtemp2experience.Text.ToString();
            candidateobj.EmpHis2_PeriodofEmployment = periodofemployment2.Text.ToString();
            candidateobj.EmpHis2_PeriodofEmploymentRemark = periodofemptilldate2.Text.ToString();
            candidateobj.EmpHis2RLvl1_NameDesignatinOfSupervisor = txtemp2namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp2HRdesignation = txtcmp2hrdesignation.Text.ToString();

            candidateobj.EmpHis2RLvl1_TelepnoneNo = txtemp2supervisorlevel1STD.Text.ToString() + "-" + txtemp2supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis2RLvl1_MobileNo = txtemp2supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis2RLvl1_EmailId = txtemp2supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis2RLvl2_NameDesignatinOfSupervisor = txtemp2namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp2RMdesignation = txtcmp2supervisordesignation.Text.ToString();

            candidateobj.EmpHis2RLvl2_TelepnoneNo = txtemp2supervisorlevel2STD.Text.ToString() + "-" + txtemp2supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis2RLvl2_MobileNo = txtemp2supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis2RLvl2_EmailId = txtemp2supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis2_TempPerma = RadioButtoncmp2emptype.SelectedValue.ToString();
            candidateobj.EmpHis2_AgencyDetails = emp2agencydetail.Text.ToString();
            candidateobj.EmpHis2_RemunerationOrSalary = emp2remunerationsalary.Text.ToString();
            candidateobj.EmpHis2_ReasonOfLeaving = emp2reasonofleaving.Text.ToString();
            candidateobj.EmpHis2_referenceYN = emp2referenceYN.Text.ToString();
            // candidateobj.EmpHis2_IncaseOfGap = emp2incaseofgap.Text.ToString();
            candidateobj.EmpHis2_NoticePeriodorNot = RadioButtonemp2noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis3_CompnayNameandLocation = txtemp3companyname.Text.ToString();
            candidateobj.EmpHis3_LastPositionHeldnDepartmentName = txtemp3lastposition.Text.ToString();
            candidateobj.cmp3department = cmp3department.Text.ToString();

            candidateobj.EmpHis3_TelephoneNo = emp3cmpSTD.Text.ToString() + "-" + emp3cmpnumber.Text.ToString();
            candidateobj.EmpHis3_Address = txtemp3officeaddress.Text.ToString();
            candidateobj.EmpHis3_EmployeeCode = txtemp3employeecode.Text.ToString();
            candidateobj.ExperienceInYears3 = txtemp3experienceinyear.Text.ToString();
            candidateobj.EmpHis3_PeriodofEmployment = periodofemployment3.Text.ToString();
            candidateobj.EmpHis3_PeriodofEmploymentRemark = periodofemptilldate3.Text.ToString();
            candidateobj.EmpHis3RLvl1_NameDesignatinOfSupervisor = txtemp3namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp3HRdesignation = txtcmp3hrdesignation.Text.ToString();

            candidateobj.EmpHis3RLvl1_TelepnoneNo = txtemp3supervisorlevel1STD.Text.ToString() + "-" + txtemp3supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis3RLvl1_MobileNo = txtemp3supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis3RLvl1_EmailId = txtemp3supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis3RLvl2_NameDesignatinOfSupervisor = txtemp3namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp3RMdesignation = txtcmp3supervisordesignation.Text.ToString();

            candidateobj.EmpHis3RLvl2_TelepnoneNo = txtemp3supervisorlevel2STD.Text.ToString() + "-" + txtemp3supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis3RLvl2_MobileNo = txtemp3supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis3RLvl2_EmailId = txtemp3supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis3_TempPerma = RadioButtoncmp3emptype.SelectedValue.ToString();
            candidateobj.EmpHis3_AgencyDetails = emp3agencydetail.Text.ToString();
            candidateobj.EmpHis3_RemunerationOrSalary = emp3remunerationsalary.Text.ToString();
            candidateobj.EmpHis3_ReasonOfLeaving = emp3reasonofleaving.Text.ToString();
            candidateobj.EmpHis3_referenceYN = emp3referenceYN.Text.ToString();
            //candidateobj.EmpHis3_IncaseOfGap = emp3incaseofgap.Text.ToString();
            candidateobj.EmpHis3_NoticePeriodorNot = RadioButtonemp3noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis4_CompnayNameandLocation = txtemp4companyname.Text.ToString();
            candidateobj.EmpHis4_LastPositionHeldnDepartmentName = txtemp4lastpostion.Text.ToString();
            candidateobj.cmp4department = txtcmp4department.Text.ToString();

            candidateobj.EmpHis4_TelephoneNo = emp4cmpSTD.Text.ToString() + "-" + emp4cmpnumber.Text.ToString();
            candidateobj.EmpHis4_Address = txtemp4officeaddress.Text.ToString();
            candidateobj.EmpHis4_EmployeeCode = txtemp4employeecode.Text.ToString();
            candidateobj.ExperienceInYears4 = txtemp4experience.Text.ToString();
            candidateobj.EmpHis4_PeriodofEmployment = periodofemployment4.Text.ToString();
            candidateobj.EmpHis4_PeriodofEmploymentRemark = periodofemptilldate4.Text.ToString();
            candidateobj.EmpHis4RLvl1_NameDesignatinOfSupervisor = txtemp4namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp4HRdesignation = txtcmp4hrdesignation.Text.ToString();

            candidateobj.EmpHis4RLvl1_TelepnoneNo = txtemp4supervisorlevel1STD.Text.ToString() + "-" + txtemp3supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis4RLvl1_MobileNo = txtemp4supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis4RLvl1_EmailId = txtemp4supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis4RLvl2_NameDesignatinOfSupervisor = txtemp4namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp4RMdesignation = txtcmp4supervisordesignation.Text.ToString();

            candidateobj.EmpHis4RLvl2_TelepnoneNo = txtemp4supervisorlevel2STD.Text.ToString() + "-" + txtemp3supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis4RLvl2_MobileNo = txtemp4supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis4RLvl2_EmailId = txtemp4supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis4_TempPerma = RadioButtoncmp4emptype.SelectedValue.ToString();
            candidateobj.EmpHis4_AgencyDetails = emp4agencydetail.Text.ToString();
            candidateobj.EmpHis4_RemunerationOrSalary = emp4remunerationsalary.Text.ToString();
            candidateobj.EmpHis4_ReasonOfLeaving = emp4reasonofleaving.Text.ToString();
            candidateobj.EmpHis4_referenceYN = emp4referenceYN.Text.ToString();
            //candidateobj.EmpHis4_IncaseOfGap = emp4incaseofgap.Text.ToString();
            candidateobj.EmpHis4_NoticePeriodorNot = RadioButtonemp4noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis5_CompnayNameandLocation = txtemp5companyname.Text.ToString();
            candidateobj.EmpHis5_LastPositionHeldnDepartmentName = txtemp5lastposition.Text.ToString();
            candidateobj.cmp5department = txtcmp5department.Text.ToString();

            candidateobj.EmpHis5_TelephoneNo = emp5cmpSTD.Text.ToString() + "-" + emp5cmpnumber.Text.ToString();
            candidateobj.EmpHis5_Address = txtemp5officeaddress.Text.ToString();
            candidateobj.EmpHis5_EmployeeCode = txtemp5employeecode.Text.ToString();
            candidateobj.ExperienceInYears5 = txtemp5experience.Text.ToString();
            candidateobj.EmpHis5_PeriodofEmployment = periodofemployment5.Text.ToString();
            candidateobj.EmpHis5_PeriodofEmploymentRemark = periodofemptilldate5.Text.ToString();
            candidateobj.EmpHis5RLvl1_NameDesignatinOfSupervisor = txtemp5namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp5HRdesignation = txtcmp5hrdesignation.Text.ToString();

            candidateobj.EmpHis5RLvl1_TelepnoneNo = txtemp5supervisorlevel1STD.Text.ToString() + "-" + txtemp3supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis5RLvl1_MobileNo = txtemp5supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis5RLvl1_EmailId = txtemp5supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis5RLvl2_NameDesignatinOfSupervisor = txtemp5namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp5RMdesignation = txtcmp5supervisordesignation.Text.ToString();

            candidateobj.EmpHis5RLvl2_TelepnoneNo = txtemp5supervisorlevel2STD.Text.ToString() + "-" + txtemp5supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis5RLvl2_MobileNo = txtemp5supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis5RLvl2_EmailId = txtemp5supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis5_TempPerma = RadioButtoncmp5emptype.SelectedValue.ToString();
            candidateobj.EmpHis5_AgencyDetails = emp5agencydetail.Text.ToString();
            candidateobj.EmpHis5_RemunerationOrSalary = emp5remunerationsalary.Text.ToString();
            candidateobj.EmpHis5_ReasonOfLeaving = emp5reasonofleaving.Text.ToString();
            candidateobj.EmpHis5_referenceYN = emp5referenceYN.Text.ToString();
            //candidateobj.EmpHis5_IncaseOfGap = emp5incaseofgap.Text.ToString();
            candidateobj.EmpHis5_NoticePeriodorNot = RadioButtonemp5noticeperiodYN.SelectedValue.ToString();

            candidateobj.CurrentEmployment = radiobuttoncurrentemp.SelectedValue.ToString();




            candidateobj.RejectedRemarks1 = RejectedRemark1.Text.ToString();
            candidateobj.RejectedRemarks2 = RejectedRemark2.Text.ToString();
            candidateobj.RejectedRemarks3 = RejectedRemark3.Text.ToString();
            candidateobj.RejectedRemarks4 = RejectedRemark4.Text.ToString();
            candidateobj.RejectedRemarks5 = RejectedRemark5.Text.ToString();

            candidateobj.comment1 = comment1.Text.ToString();
            candidateobj.comment2 = comment2.Text.ToString();
            candidateobj.comment3 = comment3.Text.ToString();
            candidateobj.comment4 = comment4.Text.ToString();
            candidateobj.comment5 = comment5.Text.ToString();

            candidateobj.candidatealternateno = txtcandidatealternateno.Text.ToString();
            candidateobj.candidateremarks = txtcandidateremarks.Text.ToString();

            //candidateobj.CAmemeber = txtCAmember.Text.ToString();
            //---mohan
            if (ddlref.SelectedItem.Text != "--Select--")
            {
                candidateobj.RefList = ddlref.SelectedItem.Text;

            }
            else
            {
                candidateobj.RefList = "";
            }
           
            candidateobj.Ref1RefName = txtRef1RefName.Text;
            candidateobj.Ref1CompName = txtRef1CompanyName.Text;
            candidateobj.Ref1Designation = txtRef1Designation.Text;
            candidateobj.Ref1Email = txtRef1EmailId.Text;
            candidateobj.Ref1Contact = txtRef1Contact.Text;

            candidateobj.Ref2RefName = txtRef2RefName.Text;
            candidateobj.Ref2CompName = txtRef2CompanyName.Text;
            candidateobj.Ref2Designation = txtRef2Designation.Text;
            candidateobj.Ref2Email = txtRef2EmailId.Text;
            candidateobj.Ref2Contact = txtRef2Contact.Text;

            if (ddlcibil.SelectedItem.Text != "--Select--")
            {
                candidateobj.CIBILList = ddlcibil.SelectedItem.Text;

            }
            else
            {
                candidateobj.CIBILList = "";
            }
            candidateobj.CIBILContact = txtCIBILContact.Text;
            candidateobj.CIBILDOB = dtpCIBILDOB.Text;
            candidateobj.CIBILEmail = txtCIBILEmail.Text;
            candidateobj.CIBILFullName = txtCIBILFullName.Text;
            candidateobj.CIBILGender = ddlCIBILgender.Text;
            candidateobj.CIBILPanCard = txtCIBILPanCard.Text;
            candidateobj.CIBILpassportno = txtCIBILpasportno.Text;
            candidateobj.CIBILvoterID = txtCIBILvoterid.Text;
            candidateobj.CIBILDrivinglicense = txtCIBILlience.Text;

            


            string username = User.Identity.Name.ToString();
            candidateobj.user = username.ToString();
            if (cid == "0" ||cid == "")
            {
                candidateobj.Mode = "0";
            }
            else
            {
                candidateobj.Mode = Request.QueryString["mode"];
            }

            string url;
            url = "saveinfo.aspx?type="+ candidateobj.Mode+"savetyep=partial";

            candidateobj.CandidateID = Convert.ToInt32(cid);
            string usertype = "";
            if (string.IsNullOrEmpty(Convert.ToString(Session["UserType"])))
            {
                Response.Redirect("CandidateLogin.aspx");
            }
            else
            {
                usertype = Session["UserType"].ToString();
            }


            if (txtFirstName.Text != "" || drpCOE.SelectedItem.Text != "Select")
            {


                int dtInsert = candidateobj.Savepartial(candidateobj);

                if (dtInsert == 0)
                {

                    if (usertype != "ClientPlusReject" && usertype != "Admin")
                    {
                        Response.Redirect(url);
                    }
                    else
                    {
                        Response.Write("<Script Language='javascript'> alert('Data Updated !')</Script>");
                    }



                }
                //else if (dtInsert == -2)
                //{

                //    Response.Write("<Script Language='javascript'> alert('Already Data Saved !')</Script>");
                //}
                //else if (dtInsert == -1)
                //{

                //    Response.Write("<Script Language='javascript'> alert('Error In Procedure...InsertEmployeeInfo!')</Script>");
                //}



            }
        }

        //else
        //{
        //    Response.Write("<Script Language='javascript'> alert('Please Fill Education Related Information')</Script>");

        //}

        //}



        //}

        //catch (Exception ex)
        //{

        //    Response.Write("<Script Language='javascript'> alert('EXCEPTION!!!!)</Script>");

        //}
    protected void btnpartialemp_Click(object sender, EventArgs e)
{
        //try
        //{
        //if ((drpeducation.SelectedItem.Text != "--Select--") !! (drpnoo))
        //{


            candidateobj.gender = txtGender.Text.ToString();
            candidateobj.maritalstatus = txtmaritalstatus.SelectedItem.Text.ToString();


            if (drpBand.SelectedItem.Text == "--Select--")
            {
                candidateobj.Band = "";

            }
            else
            {
                candidateobj.Band = drpBand.SelectedItem.Text.ToString();

            }
            if (drpCOE.SelectedItem.Text == "--Select--")
            {
                candidateobj.COE = "";
            }

            if (drpCOE.SelectedItem.Text == "OTHER")
            {
                candidateobj.COE = txtCOE.Text.ToString();
            }
            else
            {
                candidateobj.COE = drpCOE.SelectedItem.Text.ToString();
            }
            if (drpPOJ.SelectedItem.Text == "--Select--")
            {
                candidateobj.PlaceofJoing = "";
            }
            else
            {
                candidateobj.PlaceofJoing = drpPOJ.SelectedItem.Text.ToString();
            }
            candidateobj.DateofJoining = txtDateOfJoining.Text.ToString();
            candidateobj.FirstName = txtFirstName.Text.ToString();
            candidateobj.MiddleName = txtMiddleName.Text.ToString();
            candidateobj.Surname = txtLastName.Text.ToString();
            candidateobj.FatherName = txtfathername.Text.ToString();
            candidateobj.DOB = txtcandidateDOB.Text.ToString();
            candidateobj.Mobile = txtcandidatemobile.Text.ToString();
            if (drpeducation.SelectedItem.Text != "--Select--")
            {
                candidateobj.EducationList = drpeducation.SelectedItem.Text;

            }
            else
            {
                candidateobj.EducationList = "";
            }
            candidateobj.Edu1_CollegeName = txt_Edu1_CollageName.Text.ToString();
            candidateobj.Edu1_UniversityName = txt_Edu1_UniversityName0.Text.ToString();
            candidateobj.Edu1_Address = txtEdu1Address.Text.ToString();
            candidateobj.Edu1_RollNo = txtedu1Rollno.Text.ToString();
            candidateobj.Edu1_YearOfPassing = txt_Edu1_YearOfPassing0.Text.ToString();
            candidateobj.Edu1_EducationalQualification = txt_Edu1_EducationalQualification.Text.ToString();

            candidateobj.Edu2_CollegeName = txt_Edu2_CollageName.Text.ToString();
            candidateobj.Edu2_UniversityName = txt_Edu2_UniversityName0.Text.ToString();
            candidateobj.Edu2_Address = txtEdu2Address.Text.ToString();
            candidateobj.Edu2_RollNo = txtedu2Rollno.Text.ToString();
            candidateobj.Edu2_YearOfPassing = txt_Edu2_YearOfPassing0.Text.ToString();
            candidateobj.Edu2_EducationalQualification = txt_Edu2_EducationalQualification.Text.ToString();

            candidateobj.Edu3_CollegeName = txt_Edu3_CollageName.Text.ToString();
            candidateobj.Edu3_UniversityName = txt_Edu3_UniversityName0.Text.ToString();
            candidateobj.Edu3_Address = txtEdu3Address.Text.ToString();
            candidateobj.Edu3_RollNo = txtedu3Rollno.Text.ToString();
            candidateobj.YearOfPassing3 = txt_Edu3_YearOfPassing0.Text.ToString();
            candidateobj.Edu3_EducationalQualification = txt_Edu3_EducationalQualification.Text.ToString();

            candidateobj.Edu4_CollegeName = txt_Edu4_CollageName.Text.ToString();
            candidateobj.Edu4_UniversityName = txt_Edu4_UniversityName0.Text.ToString();
            candidateobj.Edu4_Address = txtEdu4Address.Text.ToString();
            candidateobj.Edu4_RollNo = txtedu4Rollno.Text.ToString();
            candidateobj.YearOfPassing4 = txt_Edu4_YearOfPassing0.Text.ToString();
            candidateobj.Edu4_EducationalQualification = txt_Edu4_EducationalQualification.Text.ToString();

            candidateobj.Edu5_CollegeName = txt_Edu5_CollageName.Text.ToString();
            candidateobj.Edu5_UniversityName = txt_Edu5_UniversityName0.Text.ToString();
            candidateobj.Edu5_Address = txtEdu5Address.Text.ToString();
            candidateobj.Edu5_RollNo = txtedu5Rollno.Text.ToString();
            candidateobj.YearOfPassing5 = txt_Edu5_YearOfPassing0.Text.ToString();
            candidateobj.Edu5_EducationalQualification = txt_Edu5_EducationalQualification.Text.ToString();

            candidateobj.Edu6_CollegeName = txt_Edu6_CollageName.Text.ToString();
            candidateobj.Edu6_UniversityName = txt_Edu6_UniversityName0.Text.ToString();
            candidateobj.Edu6_Address = txtEdu6Address.Text.ToString();
            candidateobj.Edu6_RollNo = txtedu6Rollno.Text.ToString();
            candidateobj.YearOfPassing6 = txt_Edu6_YearOfPassing0.Text.ToString();
            candidateobj.Edu6_EducationalQualification = txt_Edu6_EducationalQualification.Text.ToString();

            candidateobj.Edu7_CollegeName = txt_Edu7_CollageName.Text.ToString();
            candidateobj.Edu7_UniversityName = txt_Edu7_UniversityName0.Text.ToString();
            candidateobj.Edu7_Address = txtEdu7Address.Text.ToString();
            candidateobj.Edu7_RollNo = txtedu7Rollno.Text.ToString();
            candidateobj.YearOfPassing7 = txt_Edu7_YearOfPassing0.Text.ToString();
            candidateobj.Edu7_EducationalQualification = txt_Edu7_EducationalQualification.Text.ToString();

            candidateobj.Edu8_CollegeName = txt_Edu8_CollageName.Text.ToString();
            candidateobj.Edu8_UniversityName = txt_Edu8_UniversityName0.Text.ToString();
            candidateobj.Edu8_Address = txtEdu8Address.Text.ToString();
            candidateobj.Edu8_RollNo = txtedu8Rollno.Text.ToString();
            candidateobj.YearOfPassing8 = txt_Edu8_YearOfPassing0.Text.ToString();
            candidateobj.Edu8_EducationalQualification = txt_Edu8_EducationalQualification.Text.ToString();


            if (dropaddress.SelectedItem.Text == "Address Check")
            {
                candidateobj.AddressCheck = dropaddress.SelectedItem.Text;

            }
            else
            {
                candidateobj.AddressCheck = "";

            }
            candidateobj.PermanentAddress = txtaddress1parmanent.Text.ToString();

            if (txtAddressparmentstate.SelectedItem.Text != "--Select--")
            {
                candidateobj.Per_State = txtAddressparmentstate.SelectedItem.Text.ToString();
            }



            candidateobj.Per_City = txtadd1parmanentcity.Text.ToString();
            candidateobj.Per_AddressPhoneNo = txt_parmanetSTD.Text.ToString() + "-" + txt_parmanent_PhoneNo.Text.ToString();
            candidateobj.Per_Landmark = txtadd1parmanentlandmark.Text.ToString();
            if (txtadd1livingsince.SelectedItem.Text != "--Select--")
            {
                candidateobj.Per_LivingSince = txtadd1livingsince.SelectedItem.Text.ToString();
            }
            candidateobj.Per_LivingSince = "";
            candidateobj.Per_PoliceStation = txtadd1policestation.Text.ToString();
            candidateobj.Per_PostOffice = txtadd1pincode.Text.ToString();

            candidateobj.add1logeststay = txtadd1logeststay.Text.ToString();

            if (txtaddlongstaystate.SelectedItem.Text != "--Select--")
            {
                candidateobj.add1logeststarystate = txtaddlongstaystate.SelectedItem.Text.ToString();
            }

            candidateobj.add1logeststarycity = txtaddlongeststaycity.Text.ToString();
            candidateobj.add1logeststaryphonenumber = txtlogstaySTd.Text.ToString() + "-" + txtlongstayNumber.Text.ToString();
            candidateobj.add1logeststarylandmark = txtlongstaylandmark.Text.ToString();
            if (txtlongstaylivingsince.SelectedItem.Text != "--Select--")
            {
                candidateobj.add1logeststaryLeavingsince = txtlongstaylivingsince.SelectedItem.Text.ToString();
            }

            candidateobj.add1logeststaryLeavingsince = "";
            candidateobj.add1logeststarypolicestation = txtlongstaypolicestation.Text.ToString();
            candidateobj.add1logeststarypincode = txtlongstaypincode.Text.ToString();

            candidateobj.CurrentAddress = txtaddcurrentaddres.Text.ToString();

            if (txtaddcurrentstate.SelectedItem.Text != "--Select--")
            {
                candidateobj.Curr_State = txtaddcurrentstate.SelectedItem.Text.ToString();
            }



            candidateobj.Curr_City = txtaddcurentcity.Text.ToString();
            candidateobj.Curr_PhoneNo = txtaddcurentSTD.Text.ToString() + "-" + txtaddcurrentnumber.Text.ToString();
            //string chk1 = "";
            //string chk2 = "";
            //string chk3 = "";

            //if (chkcriminal1.Checked == true)
            //{
            //    chk1 = "1";
            //    candidateobj.criminalchk1 = chk1.ToString();

            //}
            //else
            //{
            //    candidateobj.criminalchk1 = "";
            //}

            //if (chkcriminal2.Checked == true)
            //{
            //    chk2 = "2";
            //    candidateobj.criminalchk2 = chk2.ToString();

            //}
            //else
            //{
            //    candidateobj.criminalchk2 = "";
            //}


            //if (chkcriminal3.Checked == true)
            //{
            //    chk3 = "3";
            //    candidateobj.criminalchk3 = chk3.ToString();

            //}
            //else
            //{
            //    candidateobj.criminalchk3 = "";
            //}

           
            if (dropFresherexp.SelectedItem.Text == "Fresher")
            {
                candidateobj.FresherOrExp = "";
            }
            else
            {
                candidateobj.FresherOrExp = dropFresherexp.SelectedItem.Text.ToString();
            }
            if (drpnoofcompany.SelectedItem.Text == "--Select--")
            {
                candidateobj.NoOfComp = "";
            }
            else
            {
                if (drpnoofcompany.SelectedItem.Text == "1")
                {
                    candidateobj.NoOfComp = "Company1";

                }
                if (drpnoofcompany.SelectedItem.Text == "2")
                {
                    candidateobj.NoOfComp = "Company2";

                }
                //if (drpnoofcompany.SelectedItem.Text == "3")
                //{
                //    candidateobj.NoOfComp = "Company3";

                //}
                //if (drpnoofcompany.SelectedItem.Text == "4")
                //{
                //    candidateobj.NoOfComp = "Company4";

                //}
                //if (drpnoofcompany.SelectedItem.Text == "5")
                //{
                //    candidateobj.NoOfComp = "Company5";

                //}

                candidateobj.NoOfComp = drpnoofcompany.SelectedItem.Text.ToString();
            }
            candidateobj.EmpHis1_CompnayNameandLocation = txtcmpy1nameloction.Text.ToString();
            candidateobj.EmpHis1_LastPositionHeldnDepartmentName = txtcmp1lastpostin.Text.ToString();
            candidateobj.cmp1department = txtcmp1department.Text.ToString();
            candidateobj.EmpHis1_TelephoneNo = txtcmp1Std.Text.ToString() + "-" + txtcmp1number.Text.ToString();
            candidateobj.EmpHis1_Address = txtemp1officeaddress.Text.ToString();
            candidateobj.EmpHis1_EmployeeCode = txtemp1employecode.Text.ToString();
            candidateobj.ExperienceInYears1 = txtcmpny1expinyear.Text.ToString();
            candidateobj.EmpHis1_PeriodofEmployment = periodofemployment1.Text.ToString();
            candidateobj.EmpHis1_PeriodofEmploymentRemark = periodofemptilldate1.Text.ToString();
            candidateobj.EmpHis1RLvl1_NameDesignatinOfSupervisor = txtemp1namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp1HRdesignation = txtcmp1hrdesignation.Text.ToString();
            candidateobj.EmpHis1RLvl1_TelepnoneNo = txtemp1supervisorlevel1STD.Text.ToString() + "-" + txtemp1supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis1RLvl1_MobileNo = txtemp1supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis1RLvl1_EmailId = txtemp1supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis1RLvl2_NameDesignatinOfSupervisor = txtemp1namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp1RMdesignation = txtcmp1supervisordesignation.Text.ToString();

            candidateobj.EmpHis1RLvl2_TelepnoneNo = txtemp1supervisorlevel2STD.Text.ToString() + "-" + txtemp1supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis1RLvl2_MobileNo = txtemp1supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis1RLvl2_EmailId = txtemp1supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis1_TempPerma = RadioButtoncmp1emptype.SelectedValue.ToString();
            candidateobj.EmpHis1_AgencyDetails = emp1agencydetail.Text.ToString();
            candidateobj.EmpHis1_RemunerationOrSalary = emp1remunerationsalary.Text.ToString();
            candidateobj.EmpHis1_ReasonOfLeaving = emp1reasonofleaving.Text.ToString();
            candidateobj.EmpHis1_referenceYN = emp1referenceYN.SelectedValue.ToString();
            //candidateobj.EmpHis1_IncaseOfGap = emp1incaseofgap.Text.ToString();
            candidateobj.EmpHis1_NoticePeriodorNot = RadioButtonemp1noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis2_CompnayNameandLocation = txtemp2compnyname.Text.ToString();
            candidateobj.EmpHis2_LastPositionHeldnDepartmentName = txtemp2lastposition.Text.ToString();
            candidateobj.cmp2department = txtcmp2department.Text.ToString();
            candidateobj.EmpHis2_TelephoneNo = emp2cmpSTD.Text.ToString() + "-" + emp2cmpnumber.Text.ToString();
            candidateobj.EmpHis2_Address = txtemp2officeaddress.Text.ToString();
            candidateobj.EmpHis2_EmployeeCode = txtemp2employeecode.Text.ToString();
            candidateobj.ExperienceInYears2 = txtemp2experience.Text.ToString();
            candidateobj.EmpHis2_PeriodofEmployment = periodofemployment2.Text.ToString();
            candidateobj.EmpHis2_PeriodofEmploymentRemark = periodofemptilldate2.Text.ToString();
            candidateobj.EmpHis2RLvl1_NameDesignatinOfSupervisor = txtemp2namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp2HRdesignation = txtcmp2hrdesignation.Text.ToString();

            candidateobj.EmpHis2RLvl1_TelepnoneNo = txtemp2supervisorlevel1STD.Text.ToString() + "-" + txtemp2supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis2RLvl1_MobileNo = txtemp2supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis2RLvl1_EmailId = txtemp2supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis2RLvl2_NameDesignatinOfSupervisor = txtemp2namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp2RMdesignation = txtcmp2supervisordesignation.Text.ToString();

            candidateobj.EmpHis2RLvl2_TelepnoneNo = txtemp2supervisorlevel2STD.Text.ToString() + "-" + txtemp2supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis2RLvl2_MobileNo = txtemp2supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis2RLvl2_EmailId = txtemp2supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis2_TempPerma = RadioButtoncmp2emptype.SelectedValue.ToString();
            candidateobj.EmpHis2_AgencyDetails = emp2agencydetail.Text.ToString();
            candidateobj.EmpHis2_RemunerationOrSalary = emp2remunerationsalary.Text.ToString();
            candidateobj.EmpHis2_ReasonOfLeaving = emp2reasonofleaving.Text.ToString();
            candidateobj.EmpHis2_referenceYN = emp2referenceYN.Text.ToString();
            // candidateobj.EmpHis2_IncaseOfGap = emp2incaseofgap.Text.ToString();
            candidateobj.EmpHis2_NoticePeriodorNot = RadioButtonemp2noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis3_CompnayNameandLocation = txtemp3companyname.Text.ToString();
            candidateobj.EmpHis3_LastPositionHeldnDepartmentName = txtemp3lastposition.Text.ToString();
            candidateobj.cmp3department = cmp3department.Text.ToString();

            candidateobj.EmpHis3_TelephoneNo = emp3cmpSTD.Text.ToString() + "-" + emp3cmpnumber.Text.ToString();
            candidateobj.EmpHis3_Address = txtemp3officeaddress.Text.ToString();
            candidateobj.EmpHis3_EmployeeCode = txtemp3employeecode.Text.ToString();
            candidateobj.ExperienceInYears3 = txtemp3experienceinyear.Text.ToString();
            candidateobj.EmpHis3_PeriodofEmployment = periodofemployment3.Text.ToString();
            candidateobj.EmpHis3_PeriodofEmploymentRemark = periodofemptilldate3.Text.ToString();
            candidateobj.EmpHis3RLvl1_NameDesignatinOfSupervisor = txtemp3namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp3HRdesignation = txtcmp3hrdesignation.Text.ToString();

            candidateobj.EmpHis3RLvl1_TelepnoneNo = txtemp3supervisorlevel1STD.Text.ToString() + "-" + txtemp3supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis3RLvl1_MobileNo = txtemp3supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis3RLvl1_EmailId = txtemp3supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis3RLvl2_NameDesignatinOfSupervisor = txtemp3namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp3RMdesignation = txtcmp3supervisordesignation.Text.ToString();

            candidateobj.EmpHis3RLvl2_TelepnoneNo = txtemp3supervisorlevel2STD.Text.ToString() + "-" + txtemp3supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis3RLvl2_MobileNo = txtemp3supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis3RLvl2_EmailId = txtemp3supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis3_TempPerma = RadioButtoncmp3emptype.SelectedValue.ToString();
            candidateobj.EmpHis3_AgencyDetails = emp3agencydetail.Text.ToString();
            candidateobj.EmpHis3_RemunerationOrSalary = emp3remunerationsalary.Text.ToString();
            candidateobj.EmpHis3_ReasonOfLeaving = emp3reasonofleaving.Text.ToString();
            candidateobj.EmpHis3_referenceYN = emp3referenceYN.Text.ToString();
            //candidateobj.EmpHis3_IncaseOfGap = emp3incaseofgap.Text.ToString();
            candidateobj.EmpHis3_NoticePeriodorNot = RadioButtonemp3noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis4_CompnayNameandLocation = txtemp4companyname.Text.ToString();
            candidateobj.EmpHis4_LastPositionHeldnDepartmentName = txtemp4lastpostion.Text.ToString();
            candidateobj.cmp4department = txtcmp4department.Text.ToString();

            candidateobj.EmpHis4_TelephoneNo = emp4cmpSTD.Text.ToString() + "-" + emp4cmpnumber.Text.ToString();
            candidateobj.EmpHis4_Address = txtemp4officeaddress.Text.ToString();
            candidateobj.EmpHis4_EmployeeCode = txtemp4employeecode.Text.ToString();
            candidateobj.ExperienceInYears4 = txtemp4experience.Text.ToString();
            candidateobj.EmpHis4_PeriodofEmployment = periodofemployment4.Text.ToString();
            candidateobj.EmpHis4_PeriodofEmploymentRemark = periodofemptilldate4.Text.ToString();
            candidateobj.EmpHis4RLvl1_NameDesignatinOfSupervisor = txtemp4namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp4HRdesignation = txtcmp4hrdesignation.Text.ToString();

            candidateobj.EmpHis4RLvl1_TelepnoneNo = txtemp4supervisorlevel1STD.Text.ToString() + "-" + txtemp3supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis4RLvl1_MobileNo = txtemp4supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis4RLvl1_EmailId = txtemp4supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis4RLvl2_NameDesignatinOfSupervisor = txtemp4namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp4RMdesignation = txtcmp4supervisordesignation.Text.ToString();

            candidateobj.EmpHis4RLvl2_TelepnoneNo = txtemp4supervisorlevel2STD.Text.ToString() + "-" + txtemp3supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis4RLvl2_MobileNo = txtemp4supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis4RLvl2_EmailId = txtemp4supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis4_TempPerma = RadioButtoncmp4emptype.SelectedValue.ToString();
            candidateobj.EmpHis4_AgencyDetails = emp4agencydetail.Text.ToString();
            candidateobj.EmpHis4_RemunerationOrSalary = emp4remunerationsalary.Text.ToString();
            candidateobj.EmpHis4_ReasonOfLeaving = emp4reasonofleaving.Text.ToString();
            candidateobj.EmpHis4_referenceYN = emp4referenceYN.Text.ToString();
            //candidateobj.EmpHis4_IncaseOfGap = emp4incaseofgap.Text.ToString();
            candidateobj.EmpHis4_NoticePeriodorNot = RadioButtonemp4noticeperiodYN.SelectedValue.ToString();


            candidateobj.EmpHis5_CompnayNameandLocation = txtemp5companyname.Text.ToString();
            candidateobj.EmpHis5_LastPositionHeldnDepartmentName = txtemp5lastposition.Text.ToString();
            candidateobj.cmp5department = txtcmp5department.Text.ToString();

            candidateobj.EmpHis5_TelephoneNo = emp5cmpSTD.Text.ToString() + "-" + emp5cmpnumber.Text.ToString();
            candidateobj.EmpHis5_Address = txtemp5officeaddress.Text.ToString();
            candidateobj.EmpHis5_EmployeeCode = txtemp5employeecode.Text.ToString();
            candidateobj.ExperienceInYears5 = txtemp5experience.Text.ToString();
            candidateobj.EmpHis5_PeriodofEmployment = periodofemployment5.Text.ToString();
            candidateobj.EmpHis5_PeriodofEmploymentRemark = periodofemptilldate5.Text.ToString();
            candidateobj.EmpHis5RLvl1_NameDesignatinOfSupervisor = txtemp5namedesignationofsupervisorlevel1.Text.ToString();
            candidateobj.cmp5HRdesignation = txtcmp5hrdesignation.Text.ToString();

            candidateobj.EmpHis5RLvl1_TelepnoneNo = txtemp5supervisorlevel1STD.Text.ToString() + "-" + txtemp3supervisorlevel1number.Text.ToString();
            candidateobj.EmpHis5RLvl1_MobileNo = txtemp5supervisorlevel1moblie.Text.ToString();
            candidateobj.EmpHis5RLvl1_EmailId = txtemp5supervisorlevel1email.Text.ToString();
            candidateobj.EmpHis5RLvl2_NameDesignatinOfSupervisor = txtemp5namedesignationofsupervisorlevel2.Text.ToString();
            candidateobj.cmp5RMdesignation = txtcmp5supervisordesignation.Text.ToString();

            candidateobj.EmpHis5RLvl2_TelepnoneNo = txtemp5supervisorlevel2STD.Text.ToString() + "-" + txtemp5supervisorlevel2number.Text.ToString();
            candidateobj.EmpHis5RLvl2_MobileNo = txtemp5supervisorlevel2mobile.Text.ToString();
            candidateobj.EmpHis5RLvl2_EmailId = txtemp5supervisorlevel2email.Text.ToString();
            candidateobj.EmpHis5_TempPerma = RadioButtoncmp5emptype.SelectedValue.ToString();
            candidateobj.EmpHis5_AgencyDetails = emp5agencydetail.Text.ToString();
            candidateobj.EmpHis5_RemunerationOrSalary = emp5remunerationsalary.Text.ToString();
            candidateobj.EmpHis5_ReasonOfLeaving = emp5reasonofleaving.Text.ToString();
            candidateobj.EmpHis5_referenceYN = emp5referenceYN.Text.ToString();
            //candidateobj.EmpHis5_IncaseOfGap = emp5incaseofgap.Text.ToString();
            candidateobj.EmpHis5_NoticePeriodorNot = RadioButtonemp5noticeperiodYN.SelectedValue.ToString();

            candidateobj.CurrentEmployment = radiobuttoncurrentemp.SelectedValue.ToString();




            candidateobj.RejectedRemarks1 = RejectedRemark1.Text.ToString();
            candidateobj.RejectedRemarks2 = RejectedRemark2.Text.ToString();
            candidateobj.RejectedRemarks3 = RejectedRemark3.Text.ToString();
            candidateobj.RejectedRemarks4 = RejectedRemark4.Text.ToString();
            candidateobj.RejectedRemarks5 = RejectedRemark5.Text.ToString();

            candidateobj.comment1 = comment1.Text.ToString();
            candidateobj.comment2 = comment2.Text.ToString();
            candidateobj.comment3 = comment3.Text.ToString();
            candidateobj.comment4 = comment4.Text.ToString();
            candidateobj.comment5 = comment5.Text.ToString();

            candidateobj.candidatealternateno = txtcandidatealternateno.Text.ToString();
            candidateobj.candidateremarks = txtcandidateremarks.Text.ToString();

            //candidateobj.CAmemeber = txtCAmember.Text.ToString();
            //---mohan
            if (ddlref.SelectedItem.Text != "--Select--")
            {
                candidateobj.RefList = ddlref.SelectedItem.Text;

            }
            else
            {
                candidateobj.RefList = "";
            }
           
            candidateobj.Ref1RefName = txtRef1RefName.Text;
            candidateobj.Ref1CompName = txtRef1CompanyName.Text;
            candidateobj.Ref1Designation = txtRef1Designation.Text;
            candidateobj.Ref1Email = txtRef1EmailId.Text;
            candidateobj.Ref1Contact = txtRef1Contact.Text;

            candidateobj.Ref2RefName = txtRef2RefName.Text;
            candidateobj.Ref2CompName = txtRef2CompanyName.Text;
            candidateobj.Ref2Designation = txtRef2Designation.Text;
            candidateobj.Ref2Email = txtRef2EmailId.Text;
            candidateobj.Ref2Contact = txtRef2Contact.Text;

            if (ddlcibil.SelectedItem.Text != "--Select--")
            {
                candidateobj.CIBILList = ddlcibil.SelectedItem.Text;

            }
            else
            {
                candidateobj.CIBILList = "";
            }
            candidateobj.CIBILContact = txtCIBILContact.Text;
            candidateobj.CIBILDOB = dtpCIBILDOB.Text;
            candidateobj.CIBILEmail = txtCIBILEmail.Text;
            candidateobj.CIBILFullName = txtCIBILFullName.Text;
            candidateobj.CIBILGender = ddlCIBILgender.Text;
            candidateobj.CIBILPanCard = txtCIBILPanCard.Text;
            candidateobj.CIBILpassportno = txtCIBILpasportno.Text;
            candidateobj.CIBILvoterID = txtCIBILvoterid.Text;
            candidateobj.CIBILDrivinglicense = txtCIBILlience.Text;

            


            string username = User.Identity.Name.ToString();
            candidateobj.user = username.ToString();
            if (cid == "0" || cid == "")
            {
                candidateobj.Mode = "0";
            }
            else
            {
                candidateobj.Mode = Request.QueryString["mode"];
            }

            string url;
            url = "saveinfo.aspx?type="+ candidateobj.Mode+"savetyep=partial";

            candidateobj.CandidateID = Convert.ToInt32(cid);
            string usertype = "";
            if (string.IsNullOrEmpty(Convert.ToString(Session["UserType"])))
            {
                Response.Redirect("CandidateLogin.aspx");
            }
            else
            {
                usertype = Session["UserType"].ToString();
            }


            if (txtFirstName.Text != "" || drpCOE.SelectedItem.Text != "Select")
            {


                int dtInsert = candidateobj.Savepartial(candidateobj);

                if (dtInsert == 0)
                {

                    if (usertype != "ClientPlusReject" && usertype != "Admin")
                    {
                        Response.Redirect(url);
                    }
                    else
                    {
                        Response.Write("<Script Language='javascript'> alert('Data Updated !')</Script>");
                    }



                }
                //else if (dtInsert == -2)
                //{

                //    Response.Write("<Script Language='javascript'> alert('Already Data Saved !')</Script>");
                //}
                //else if (dtInsert == -1)
                //{

                //    Response.Write("<Script Language='javascript'> alert('Error In Procedure...InsertEmployeeInfo!')</Script>");
                //}



            }
        }

        //else
        //{
        //    Response.Write("<Script Language='javascript'> alert('Please Fill Education Related Information')</Script>");

        //}

        //}



        //}

        //catch (Exception ex)
        //{

        //    Response.Write("<Script Language='javascript'> alert('EXCEPTION!!!!)</Script>");

        //}
  protected void btnfiledegree_Click(object sender, EventArgs e)
    {
        uploadfiles.uploaddownloadfiles up = new uploadfiles.uploaddownloadfiles();
        if (FileUploaddegree.HasFile == true)
        {
            string filename = FileUploaddegree.PostedFile.FileName;
            int i = -1;
            string[] filepathSplit = filename.Split('\\');
            foreach (string arrStr in filepathSplit)
            {
                i++;
            }
            string file = filepathSplit[i].ToString();
            string Checkype = "Degree";
            //save the file to the server
            string fileRename = file + System.DateTime.Now.ToString("ddMMyyyyhhmmss");
            FileUploaddegree.PostedFile.SaveAs(Server.MapPath("~\\Uploaded\\") + fileRename);
            //lblStatus.Text = "File Saved to: " + Server.MapPath("~\\Uploaded\\") +EmpID+Checkype+ file;
            string Filename = Server.MapPath("~\\Uploaded\\") + fileRename;
            up.ActiveStatus = "1";
            up.BackgroundType = Checkype;
            up.CandidateID = "0";
            up.FileName = fileRename;
            up.UploadStatus = "1";
            up.FileSize = "NA";
            up.FirstName = txtFirstName.Text.ToString();
            up.MiddleName = txtMiddleName.Text.ToString();
            up.Surname = txtLastName.Text.ToString();
            up.FatherName = txtfathername.Text.ToString();
            up.Mobile = txtcandidatemobile.Text.ToString();
            try
            {
                up.saveFile(up);
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            lblstatusedu.Text = "File Uploaded Successfully";


        }
        else
        {
            //Response.Write("ss");
            Response.Write("<script>alert('Please Choose a File !');</script>");
        }
        ShowFile();
        // tbladdd.Visible = true;
    }
    protected void btnuploadmarksheet_Click(object sender, EventArgs e)
    {
        uploadfiles.uploaddownloadfiles up = new uploadfiles.uploaddownloadfiles();
        if (FileUploadmarksheet.HasFile == true)
        {
            string filename = FileUploadmarksheet.PostedFile.FileName;
            int i = -1;
            string[] filepathSplit = filename.Split('\\');
            foreach (string arrStr in filepathSplit)
            {
                i++;
            }
            string file = filepathSplit[i].ToString();
            string Checkype = "All Year Marksheet";
            //save the file to the server
            string fileRename = file + System.DateTime.Now.ToString("ddMMyyyyhhmmss");
            FileUploadmarksheet.PostedFile.SaveAs(Server.MapPath("~\\Uploaded\\") + fileRename);
            //lblStatus.Text = "File Saved to: " + Server.MapPath("~\\Uploaded\\") +EmpID+Checkype+ file;
            string Filename = Server.MapPath("~\\Uploaded\\") + fileRename;
            up.ActiveStatus = "1";
            up.BackgroundType = Checkype;
            up.CandidateID = "0";
            up.FileName = fileRename;
            up.UploadStatus = "1";
            up.FileSize = "NA";
            up.FirstName = txtFirstName.Text.ToString();
            up.MiddleName = txtMiddleName.Text.ToString();
            up.Surname = txtLastName.Text.ToString();
            up.FatherName = txtfathername.Text.ToString();
            up.Mobile = txtcandidatemobile.Text.ToString();
            try
            {
                up.saveFile(up);
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            lblstatusedu.Text = "File Uploaded Successfully";


        }
        else
        {
            //Response.Write("ss");
            Response.Write("<script>alert('Please Choose a File !');</script>");
        }
        ShowFile();
    }
    protected void btnuploadapp_Click(object sender, EventArgs e)
    {
        uploadfiles.uploaddownloadfiles up = new uploadfiles.uploaddownloadfiles();
        if (fileuploadapp.HasFile == true)
        {
            string filename = fileuploadapp.PostedFile.FileName;
            int i = -1;
            string[] filepathSplit = filename.Split('\\');
            foreach (string arrStr in filepathSplit)
            {
                i++;
            }
            string file = filepathSplit[i].ToString();
            string Checkype = "Appoint Letter";
            //save the file to the server
            string fileRename = file + System.DateTime.Now.ToString("ddMMyyyyhhmmss");
            fileuploadapp.PostedFile.SaveAs(Server.MapPath("~\\Uploaded\\") + fileRename);
            //lblStatus.Text = "File Saved to: " + Server.MapPath("~\\Uploaded\\") +EmpID+Checkype+ file;
            string Filename = Server.MapPath("~\\Uploaded\\") + fileRename;
            up.ActiveStatus = "1";
            up.BackgroundType = Checkype;
            up.CandidateID = "0";
            up.FileName = fileRename;
            up.UploadStatus = "1";
            up.FileSize = "NA";
            up.FirstName = txtFirstName.Text.ToString();
            up.MiddleName = txtMiddleName.Text.ToString();
            up.Surname = txtLastName.Text.ToString();
            up.FatherName = txtfathername.Text.ToString();
            up.Mobile = txtcandidatemobile.Text.ToString();
            try
            {
                up.saveFile(up);
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            lblstatusedu.Text = "File Uploaded Successfully";


        }
        else
        {
            //Response.Write("ss");
            Response.Write("<script>alert('Please Choose a File !');</script>");
        }
        ShowFile();
        // tbladdd.Visible = true;
    }
    protected void uploadrelieving_Click(object sender, EventArgs e)
    {
        uploadfiles.uploaddownloadfiles up = new uploadfiles.uploaddownloadfiles();
        if (fileuploadrelieving.HasFile == true)
        {
            string filename = fileuploadrelieving.PostedFile.FileName;
            int i = -1;
            string[] filepathSplit = filename.Split('\\');
            foreach (string arrStr in filepathSplit)
            {
                i++;
            }
            string file = filepathSplit[i].ToString();
            string Checkype = "Salary Slip";
            //save the file to the server
            string fileRename = file + System.DateTime.Now.ToString("ddMMyyyyhhmmss");
            fileuploadrelieving.PostedFile.SaveAs(Server.MapPath("~\\Uploaded\\") + fileRename);
            //lblStatus.Text = "File Saved to: " + Server.MapPath("~\\Uploaded\\") +EmpID+Checkype+ file;
            string Filename = Server.MapPath("~\\Uploaded\\") + fileRename;
            up.ActiveStatus = "1";
            up.BackgroundType = Checkype;
            up.CandidateID = "0";
            up.FileName = fileRename;
            up.UploadStatus = "1";
            up.FileSize = "NA";
            up.FirstName = txtFirstName.Text.ToString();
            up.MiddleName = txtMiddleName.Text.ToString();
            up.Surname = txtLastName.Text.ToString();
            up.FatherName = txtfathername.Text.ToString();
            up.Mobile = txtcandidatemobile.Text.ToString();
            try
            {
                up.saveFile(up);
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            lblstatusedu.Text = "File Uploaded Successfully";


        }
        else
        {
            //Response.Write("ss");
            Response.Write("<script>alert('Please Choose a File !');</script>");
        }
        ShowFile();
        // tbladdd.Visible = true;
    }
}

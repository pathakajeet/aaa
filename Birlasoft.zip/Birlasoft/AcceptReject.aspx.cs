﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DataAccess;
using procall1;
using Casestatus;
using System.Drawing;
using IISERVZCLASS;
using System.Text;
using System.Net;


public partial class AcceptReject : System.Web.UI.Page
{
    CandidateInfonamespace.CandidateDetails candidateobj = new CandidateInfonamespace.CandidateDetails();

    procall pc = new procall();
    DataSet ds = new DataSet();

   
    protected void Page_Load(object sender, EventArgs e)
    {
        string str = Session["UserType"].ToString();
        if (str == "Admin")
        {
            td1.Visible = false;
            td2.Visible = true;
            rj.Visible = false;
            fc.Visible = false;
            rj.Visible = false;

        }
        if (str == "Hiring")
        {
            td1.Visible = false;
            td2.Visible = false;
            rj.Visible = false;
            fc.Visible = false;
            rj.Visible = false;

        }
        if (str == "ClientPlusReject")
        {
            td1.Visible = false;
            td2.Visible = false;
            rj.Visible = true;
            fc.Visible = true;

        }
   
       
        if (!IsPostBack)
        {
            ds = pc.showalllist();
            GridView1.DataSource = ds;
            GridView1.DataBind();

        }
    }
  
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
       
        
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string strScript = "uncheckOthers(" + ((CheckBox)e.Row.Cells[0].FindControl("caseinitialize")).ClientID + ");";
            ((CheckBox)e.Row.Cells[0].FindControl("caseinitialize")).Attributes.Add("onclick", "javascript:return Selectone(this,'" + GridView1.ClientID + "');");
           
            ((CheckBox)e.Row.FindControl("caseinitialize")).Attributes.Add("onclick", "javascript:return HideandShowTextBox('" + ((CheckBox)e.Row.FindControl("caseinitialize")).ClientID + "*" + ((Button)e.Row.FindControl("btn1")).ClientID + "')");
            ((Button)e.Row.FindControl("btn1")).Style.Add("display", "none");



            ((CheckBox)e.Row.FindControl("rejectcase")).Attributes.Add("onclick", "javascript:return HideandShowTextBox('" + ((CheckBox)e.Row.FindControl("rejectcase")).ClientID + "*" + ((Button)e.Row.FindControl("btn2")).ClientID + "')");
            ((Button)e.Row.FindControl("btn2")).Style.Add("display", "none");


        }
   
    }



    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "btn1")// for accept
        {
      

            procall pc = new procall();
            DataSet ds = new DataSet();
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                GridViewRow row = GridView1.Rows[i];
                bool isrevert = ((CheckBox)row.FindControl("caseinitialize")).Checked;
                if (isrevert)
                {

                    string candidateid = GridView1.Rows[i].Cells[5].Text;
                    string name = GridView1.Rows[i].Cells[6].Text;
                    string location = GridView1.Rows[i].Cells[13].Text;
                    candidateobj.accept(candidateid, name, location);



                    //ds = candidateobj.SmsMobileNumber(candidateid);

                    //string mobile = ds.Tables[0].Rows[0]["Mobile"].ToString();
                    //string username = ds.Tables[0].Rows[0]["UserName"].ToString();
                    //string candidatename = candidateid + "-" + name;

                    //string URL = "";

                    //URL = "http://203.122.58.168/prepaidgetbroadcast/PrepaidGetBroadcast?userid=iiservz&pwd=7s7P7511&msgtype=s&ctype=1&sender=IISERV&pno=" + mobile + "&msgtxt=Dear+" + username + "%2C%0A%0AThe+candidate+" + candidatename + "+has+been+Accepted+for+verification+done+by+IISERVZ.&alert=1";

                    //HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(URL);
                    //request.Method = "POST";
                    //HttpWebResponse response = (HttpWebResponse)request.GetResponse();


                }
            }
            //string strplace;
            //if (dropPOJ.SelectedItem.Text.Trim() != "Select")
            //{
            //    strplace = dropPOJ.SelectedItem.Text.ToString();
            //}
            //else
            //{
            //    strplace = "";
            //}

            //ds = pc.acceptreject(strplace);
            //GridView1.DataSource = ds;
            //GridView1.DataBind();
            //if (dropPOJ.SelectedItem.Text.Trim() == "All")
            //{
                ds = pc.showalllist();
                GridView1.DataSource = ds;
                GridView1.DataBind();
           // }

        }
        if (e.CommandName == "btn2") // for reject
        {
            
            procall pc = new procall();
            DataSet ds = new DataSet();
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                GridViewRow row = GridView1.Rows[i];
                bool isrevert = ((CheckBox)row.FindControl("rejectcase")).Checked;
                if (isrevert)
                {


                    Status st = new Status();
                    string candidateid = GridView1.Rows[i].Cells[5].Text;
                    string name = GridView1.Rows[i].Cells[6].Text;
                    string location = GridView1.Rows[i].Cells[13].Text;
                    string ii = st.reject(candidateid, name, location);


                    //ds = candidateobj.SmsMobileNumber(candidateid);

                    //string mobile = ds.Tables[0].Rows[0]["Mobile"].ToString();
                    //string username = ds.Tables[0].Rows[0]["UserName"].ToString();
                    //string candidatename = candidateid + "-" + name;


                    //string URL = "";

                    //URL = "http://203.122.58.168/prepaidgetbroadcast/PrepaidGetBroadcast?userid=iiservz&pwd=7s7P7511&msgtype=s&ctype=1&sender=IISERV&pno=" + mobile + "&msgtxt=Dear+" + username + "%2C%0A%0AThe+candidate+" + candidatename + "+has+been+Rejected+for+verification+done+by+IISERVZ.&alert=1";

                    //HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(URL);
                    //request.Method = "POST";
                    //HttpWebResponse response = (HttpWebResponse)request.GetResponse();


                }
            }
            //string strplace;
            //if (dropPOJ.SelectedItem.Text.Trim() != "Select")
            //{
            //    strplace = dropPOJ.SelectedItem.Text.ToString();
            //}
            //else
            //{
            //    strplace = "";
            //}

            //ds = pc.acceptreject(strplace);
            //GridView1.DataSource = ds;
            //GridView1.DataBind();
            //if (dropPOJ.SelectedItem.Text.Trim() == "All")
            //{
                ds = pc.showalllist();
                GridView1.DataSource = ds;
                GridView1.DataBind();
            //}
        }

    }
    protected void btnlogout_Click(object sender, EventArgs e)
    {
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Redirect("../Login.aspx");
    }
    
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //procall pc = new procall();
        //DataSet ds = new DataSet();
        //string strplace;
        //if (dropPOJ.SelectedItem.Text.Trim() != "Select")
        //{
        //    strplace = dropPOJ.SelectedItem.Text.ToString();
        //    ds = pc.acceptreject(strplace);
        //    GridView1.DataSource = ds;
        //    GridView1.DataBind();
        //}
        //else
        //{
        //    strplace = "";
        //}


        //ds = pc.showalllist();
        //GridView1.DataSource = ds;
        //GridView1.DataBind();
        //if (dropPOJ.SelectedItem.Text.Trim() == "All")
        //{
            ds = pc.showalllist();
            GridView1.DataSource = ds;
            GridView1.DataBind();
        //}
    }
}

﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace IISERVZCLASS
{
    public class InsertDefaultData
    {
        /// <summary>
        /// Current
        /// </summary>
        #region Global Connection String
        private SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
        #endregion

        public InsertDefaultData()
        {
        }

        #region Check Root Menu Table For Data
        public bool chkMenuData()
        {
            SqlDataAdapter adap = new SqlDataAdapter("select * from menu_root", con);
            DataSet dS = new DataSet();
            adap.Fill(dS);
            if (dS.Tables[0].Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region Insert Root Menu
        public void insRootMenu()
        {
            con.Open();
            string insString = "insert into menu_root (rootname,position,rooturl,activestatus) " +
                   " values (@rName,@pos,@rUrl,@aStatus)";
            SqlCommand cmd = new SqlCommand(insString, con);
            cmd.Parameters.Add(new SqlParameter("@rName", "Home"));
            cmd.Parameters.Add(new SqlParameter("@pos", 1));
            cmd.Parameters.Add(new SqlParameter("@rUrl", "~/FormHome.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rName", "Masters"));
            cmd.Parameters.Add(new SqlParameter("@pos", 2));
            cmd.Parameters.Add(new SqlParameter("@rUrl", "#"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rName", "Transactions"));
            cmd.Parameters.Add(new SqlParameter("@pos", 3));
            cmd.Parameters.Add(new SqlParameter("@rUrl", "#"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();

            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rName", "Reports"));
            cmd.Parameters.Add(new SqlParameter("@pos", 4));
            cmd.Parameters.Add(new SqlParameter("@rUrl", "#"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();

            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rName", "Profile"));
            cmd.Parameters.Add(new SqlParameter("@pos", 5));
            cmd.Parameters.Add(new SqlParameter("@rUrl", "#"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rName", "Logout"));
            cmd.Parameters.Add(new SqlParameter("@pos", 6));
            cmd.Parameters.Add(new SqlParameter("@rUrl", "~/FormLogout.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            con.Close();
        }
        #endregion

        #region Check Sub Menu For Data
        public bool chkSubMenu()
        {
            SqlDataAdapter adapSub = new SqlDataAdapter("select * from sub_menu", con);
            DataSet dSSub = new DataSet();
            adapSub.Fill(dSSub);
            if (dSSub.Tables[0].Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region Insert Sub Menu Data
        public void insSubMenu()
        {
            con.Open();
            string sqlQuery = "insert into sub_menu (rootid,menutitle,modulename,position,submenuurl,activestatus) values " +
                    " (@rID,@meName,@mName,@pos,@smUrl,@aStatus)";
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.Parameters.Add(new SqlParameter("@rID", 2));
            cmd.Parameters.Add(new SqlParameter("@meName", "Zone Master"));
            cmd.Parameters.Add(new SqlParameter("@mName", "Zone_Master"));
            cmd.Parameters.Add(new SqlParameter("@pos", 1));
            cmd.Parameters.Add(new SqlParameter("@smUrl", "~/ZoneList.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rID", 2));
            cmd.Parameters.Add(new SqlParameter("@meName", "State Master"));
            cmd.Parameters.Add(new SqlParameter("@mName", "State_Master"));
            cmd.Parameters.Add(new SqlParameter("@pos", 2));
            cmd.Parameters.Add(new SqlParameter("@smUrl", "~/StateList.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rID", 2));
            cmd.Parameters.Add(new SqlParameter("@meName", "Branch Master"));
            cmd.Parameters.Add(new SqlParameter("@mName", "Branch_Master"));
            cmd.Parameters.Add(new SqlParameter("@pos", 3));
            cmd.Parameters.Add(new SqlParameter("@smUrl", "~/BranchList.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rID", 2));
            cmd.Parameters.Add(new SqlParameter("@meName", "User Master"));
            cmd.Parameters.Add(new SqlParameter("@mName", "User_Master"));
            cmd.Parameters.Add(new SqlParameter("@pos", 4));
            cmd.Parameters.Add(new SqlParameter("@smUrl", "~/UserList.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rID", 2));
            cmd.Parameters.Add(new SqlParameter("@meName", "Client Master"));
            cmd.Parameters.Add(new SqlParameter("@mName", "Client_Master"));
            cmd.Parameters.Add(new SqlParameter("@pos", 5));
            cmd.Parameters.Add(new SqlParameter("@smUrl", "~/ClientList.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rID", 2));
            cmd.Parameters.Add(new SqlParameter("@meName", "Questions"));
            cmd.Parameters.Add(new SqlParameter("@mName", "QuestionMaster"));
            cmd.Parameters.Add(new SqlParameter("@pos", 6));
            cmd.Parameters.Add(new SqlParameter("@smUrl", "~/formquestionlist.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();

            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rID", 2));
            cmd.Parameters.Add(new SqlParameter("@meName", "Question Template"));
            cmd.Parameters.Add(new SqlParameter("@mName", "ClientQuestionMaster"));
            cmd.Parameters.Add(new SqlParameter("@pos", 7));
            cmd.Parameters.Add(new SqlParameter("@smUrl", "~/formclientquestionmaster.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();

            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rID", 2));
            cmd.Parameters.Add(new SqlParameter("@meName", "Services"));
            cmd.Parameters.Add(new SqlParameter("@mName", "Services"));
            cmd.Parameters.Add(new SqlParameter("@pos", 8));
            cmd.Parameters.Add(new SqlParameter("@smUrl", "~/ServiceList.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();

            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rID", 3));
            cmd.Parameters.Add(new SqlParameter("@meName", "Case Receiving"));
            cmd.Parameters.Add(new SqlParameter("@mName", "CaseReceiving"));
            cmd.Parameters.Add(new SqlParameter("@pos", 1));
            //cmd.Parameters.Add(new SqlParameter("@smUrl", "~/FormCaseList.aspx"));
            cmd.Parameters.Add(new SqlParameter("@smUrl", "~/FormCaseReceiving.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rID", 3));
            cmd.Parameters.Add(new SqlParameter("@meName", "Case Allocation"));
            cmd.Parameters.Add(new SqlParameter("@mName", "CaseAllocation"));
            cmd.Parameters.Add(new SqlParameter("@pos", 2));
            cmd.Parameters.Add(new SqlParameter("@smUrl", "~/FormAllocation.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();

            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rID", 4));
            cmd.Parameters.Add(new SqlParameter("@meName", "Allotted/Pending Cases Reports"));
            cmd.Parameters.Add(new SqlParameter("@mName", "Allocated/PendingCases"));
            cmd.Parameters.Add(new SqlParameter("@pos", 1));
            cmd.Parameters.Add(new SqlParameter("@smUrl", "~/FormAllocatedandPendingReport.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();

            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rID", 4));
            cmd.Parameters.Add(new SqlParameter("@meName", "MIS Reports"));
            cmd.Parameters.Add(new SqlParameter("@mName", "MISReport"));
            cmd.Parameters.Add(new SqlParameter("@pos", 2));
            cmd.Parameters.Add(new SqlParameter("@smUrl", "~/FormMisReport.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();


            //cmd.Parameters.Clear();
            //cmd.Parameters.Add(new SqlParameter("@rID", 4));
            //cmd.Parameters.Add(new SqlParameter("@meName", "Report Format"));
            //cmd.Parameters.Add(new SqlParameter("@mName", "ReportFormat"));
            //cmd.Parameters.Add(new SqlParameter("@pos", 3));
            //cmd.Parameters.Add(new SqlParameter("@smUrl", "~/FormReportFormat.aspx"));
            //cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            //cmd.ExecuteNonQuery();
            ////Audit Checks

            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rID", 4));
            cmd.Parameters.Add(new SqlParameter("@meName", "Audit Checks"));
            cmd.Parameters.Add(new SqlParameter("@mName", "AuditChecks"));
            cmd.Parameters.Add(new SqlParameter("@pos", 3));
            cmd.Parameters.Add(new SqlParameter("@smUrl", "~/FormAuditCheck.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();

            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@rID", 5));
            cmd.Parameters.Add(new SqlParameter("@meName", "Roles"));
            cmd.Parameters.Add(new SqlParameter("@mName", "Role"));
            cmd.Parameters.Add(new SqlParameter("@pos", 1));
            cmd.Parameters.Add(new SqlParameter("@smUrl", "~/accesslevel.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            //Change Password Menu
            cmd.Parameters.Add(new SqlParameter("@rID", 5));
            cmd.Parameters.Add(new SqlParameter("@meName", "Change Password"));
            cmd.Parameters.Add(new SqlParameter("@mName", "ChangePassword"));
            cmd.Parameters.Add(new SqlParameter("@pos", 2));
            cmd.Parameters.Add(new SqlParameter("@smUrl", "~/ChangePassword.aspx"));
            cmd.Parameters.Add(new SqlParameter("@aStatus", 1));
            //Change Password Menu
            cmd.ExecuteNonQuery();
            con.Close();
        }
        #endregion

        #region Check Service Type Data
        public bool chkService()
        {
            SqlDataAdapter adap = new SqlDataAdapter("select * from Tbl_Service_Type", con);
            DataSet dSService = new DataSet();
            adap.Fill(dSService);
            if (dSService.Tables[0].Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region Insert Data Into Service Type Table
        public void insService()
        {
            con.Open();
            string sqlQuery = "insert into Tbl_Service_Type (Service) values(@service)";
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.Parameters.Add(new SqlParameter("@service", "Business Verification"));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@service", "Field Verification"));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@service", "Tele Verification"));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            con.Close();
        }
        #endregion

        #region Check For Modules
        public bool chkModule()
        {
            SqlDataAdapter adap = new SqlDataAdapter("select * from tbl_module_master", con);
            DataSet dSmodule = new DataSet();
            adap.Fill(dSmodule);
            if (dSmodule.Tables[0].Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region Insert Values Into Modules Table
        public void insModule()
        {
            string chkQuery = "select modulename from sub_menu where modulename not in(select Modulename from tbl_module_master)";
            SqlDataAdapter adap = new SqlDataAdapter(chkQuery, con);
            DataSet dSModule = new DataSet();
            adap.Fill(dSModule);
            SqlDataAdapter adapMaxID = new SqlDataAdapter("select isnull(max(moduleID),0) from tbl_module_master", con);
            DataSet dSMaxId = new DataSet();
            adapMaxID.Fill(dSMaxId);
            int MMaxID = int.Parse(dSMaxId.Tables[0].Rows[0][0].ToString()) + 1;
            con.Open();
            string sqlQuery = "insert into Tbl_Module_Master(moduleid,ModuleName) values (@mID,@mName)";
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            for (int i = 0; i < dSModule.Tables[0].Rows.Count; i++)
            {
                cmd.Parameters.Add(new SqlParameter("@mID", MMaxID));
                cmd.Parameters.Add(new SqlParameter("@mName", dSModule.Tables[0].Rows[i]["modulename"].ToString()));
                cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
                MMaxID += 1;
            }
            con.Close();
        }
        #endregion

        #region Check Service Type Data
        public bool chkArea()
        {
            SqlDataAdapter adap = new SqlDataAdapter("select * from Tbl_Area", con);
            DataSet dSArea = new DataSet();
            adap.Fill(dSArea);
            if (dSArea.Tables[0].Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region Insert Data Into Area Table
        public void insArea()
        {
            con.Open();
            string sqlQuery = "Insert into Tbl_Area(Area) values(@area)";
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.Parameters.Add(new SqlParameter("@area", "Area1"));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@area", "Area2"));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@area", "Area3"));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            cmd.Parameters.Add(new SqlParameter("@area", "Area4"));
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            con.Close();
        }
        #endregion
    }
}

﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using DataAccess;
using UploadDownloadManager;

/// <summary>
/// Summary description for FileUploadDownloadManager
/// </summary>


namespace UploadDownloadManager
{

    public class FileUploadDownloadManager
    {
        private string strFileName;
        private string strUploadStatus;
        private string strEmployeeID;
        private string strBackgroundType;
        private string strActiveStatus;
        private string strFileSize;

        public string FileName
        {
            get
            {
                return strFileName;
            }
            set
            {
                strFileName = value;
            }
        }
        public string UploadStatus
        {
            get
            {
                return strUploadStatus;
            }
            set
            {
                strUploadStatus = value;
            }
        }
        public string EmployeeID
        {
            get
            {
                return strEmployeeID;
            }
            set
            {
                strEmployeeID = value;
            }
        }
        public string ActiveStatus
        {
            get
            {
                return strActiveStatus;
            }
            set
            {
                strActiveStatus = value;
            }
        }

        public string FileSize
        {
            get
            {
                return strFileSize;
            }
            set
            {
                strFileSize = value;
            }
        }
        public string BackgroundType
        {
            get
            {
                return strBackgroundType;
            }
            set
            {
                strBackgroundType = value;
            }
        }
        public string saveFile(FileUploadDownloadManager objFileUD)
        {

            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[6];

            paramsToStore[0] = new SqlParameter("@FileName", SqlDbType.VarChar);
            paramsToStore[0].Value = objFileUD.FileName;
            paramsToStore[1] = new SqlParameter("@EmployeeID", SqlDbType.VarChar);
            paramsToStore[1].Value = objFileUD.EmployeeID;
            paramsToStore[2] = new SqlParameter("@UploadStatus", SqlDbType.VarChar);
            paramsToStore[2].Value = objFileUD.UploadStatus;
            paramsToStore[3] = new SqlParameter("@ActiveStatus", SqlDbType.VarChar);
            paramsToStore[3].Value = objFileUD.ActiveStatus;
            paramsToStore[4] = new SqlParameter("@FileSize", SqlDbType.VarChar);
            paramsToStore[4].Value = objFileUD.FileSize;
            paramsToStore[5] = new SqlParameter("@BackgroundType", SqlDbType.VarChar);
            paramsToStore[5].Value = objFileUD.BackgroundType;
            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsertFileUploadDownloadManager", paramsToStore));
        }

        public DataSet fillKPMG()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "KPMG");
            return dr;

        }
        public DataSet fillWIPRO()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "WIPROEdu");
            return dr;

        }

        public DataSet fillWIPROCity()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "WIPROCity");
            return dr;

        }

    }

}

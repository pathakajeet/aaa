﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DataAccess;
/// <summary>
/// Summary description for procall
/// </summary>
 namespace procall1
 {
public class procall
{
	public procall()
	{
		
	}
    public DataSet acceptreject(string POJ)
    {
        DataSet dr;
        dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "acceptreject",
             SQLDataAccess.CreateParameter("@POJ", SqlDbType.VarChar, POJ, ParameterDirection.Input, 50, false));



        return dr;

    }

    public DataSet showalllist()
    {
        DataSet dr;
        dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "showalllist");

        return dr;

    }

    public DataSet showMIS()
    {
        DataSet dr;
        dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "showMIS");

        return dr;

    }
   public DataSet SearchbyClientt(string username, string usertype, string fromdate, string todate,string type)
    {
        DataSet dr;
        dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchbyClientt",
             SQLDataAccess.CreateParameter("@user", SqlDbType.VarChar, username, ParameterDirection.Input, 50, false),
             SQLDataAccess.CreateParameter("@usertype", SqlDbType.VarChar, usertype, ParameterDirection.Input, 50, false),
             SQLDataAccess.CreateParameter("@fromdate", SqlDbType.VarChar, fromdate, ParameterDirection.Input, 50, false),
             SQLDataAccess.CreateParameter("@todate", SqlDbType.VarChar, todate, ParameterDirection.Input, 50, false),
             SQLDataAccess.CreateParameter("@type", SqlDbType.VarChar, type, ParameterDirection.Input, 50, false));

        return dr;

    }

   public DataSet insuffdocupload(int insID, string FileName, string checks, string refid, string remarks)
   {
       DataSet dr;
       dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "insuffdocupload",
           SQLDataAccess.CreateParameter("@insID", SqlDbType.Int, insID, ParameterDirection.Input, 10, false),
               SQLDataAccess.CreateParameter("@FileName", SqlDbType.VarChar, FileName, ParameterDirection.Input, 250, false),
               SQLDataAccess.CreateParameter("@checks", SqlDbType.VarChar, checks, ParameterDirection.Input, 250, false),
               SQLDataAccess.CreateParameter("@refid", SqlDbType.VarChar, refid, ParameterDirection.Input, 250, false),
                SQLDataAccess.CreateParameter("@remarks", SqlDbType.VarChar, remarks, ParameterDirection.Input, 250, false)
               )
           ;




       return dr;

   }

    public DataSet SearchbyClient(string username, string usertype)
         {
             DataSet dr;
             dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchbyClient",
                  SQLDataAccess.CreateParameter("@user", SqlDbType.VarChar, username, ParameterDirection.Input, 50, false),
                  SQLDataAccess.CreateParameter("@usertype", SqlDbType.VarChar, usertype, ParameterDirection.Input, 50, false));

             return dr;

         }

    public DataSet SearchMIS(string text)
    {
        DataSet dr;
        dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchMIS",
             SQLDataAccess.CreateParameter("@text", SqlDbType.VarChar, text, ParameterDirection.Input, 50, false));



        return dr;

    }

    public DataSet casestatus(string username, string usertype)
    {
        DataSet dr;
        dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "casestatus",
             SQLDataAccess.CreateParameter("@user", SqlDbType.VarChar, username, ParameterDirection.Input, 50, false),
             SQLDataAccess.CreateParameter("@usertype", SqlDbType.VarChar, usertype, ParameterDirection.Input, 50, false));



        return dr;

    }


   

    public DataSet test(string POJ)
    {
        DataSet dr;
        dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "test",
             SQLDataAccess.CreateParameter("@POJ", SqlDbType.VarChar, POJ, ParameterDirection.Input, 50, false));



        return dr;

    }

    //public DataSet OfferDropList(string POJ)
    //{
    //    DataSet dr;
    //    dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OfferDropList",
    //         SQLDataAccess.CreateParameter("@POJ", SqlDbType.VarChar, POJ, ParameterDirection.Input, 50, false));



    //    return dr;

    //}



    public DataSet showRejectedList()
    {
        DataSet dr;
        dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "showRejectedList");
        return dr;

    }

     public DataSet OfferDropList(string username, string usertype, string fromdate, string todate)
         {
             DataSet dr;
             dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OfferDropList",
                  SQLDataAccess.CreateParameter("@user", SqlDbType.VarChar, username, ParameterDirection.Input, 50, false),
                  SQLDataAccess.CreateParameter("@usertype", SqlDbType.VarChar, usertype, ParameterDirection.Input, 50, false),
                  SQLDataAccess.CreateParameter("@fromdate", SqlDbType.VarChar, fromdate, ParameterDirection.Input, 50, false),
                  SQLDataAccess.CreateParameter("@todate", SqlDbType.VarChar, todate, ParameterDirection.Input, 50, false));

             return dr;

         }

     public DataSet rejectedlist(string search_criteria, string search_keyword, string username,string datefrom, string dateto)
    {
        DataSet dr;
        dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "rejectedlist",
                  SQLDataAccess.CreateParameter("@searchcriteria", SqlDbType.VarChar, search_criteria, ParameterDirection.Input, 50, false),
                  SQLDataAccess.CreateParameter("@searchkeyword", SqlDbType.VarChar, search_keyword, ParameterDirection.Input, 50, false),
                  SQLDataAccess.CreateParameter("@fromdate", SqlDbType.VarChar, datefrom, ParameterDirection.Input, 50, false),
                  SQLDataAccess.CreateParameter("@todate", SqlDbType.VarChar, dateto, ParameterDirection.Input, 50, false),
                  SQLDataAccess.CreateParameter("@username", SqlDbType.VarChar, username, ParameterDirection.Input, 50, false)
                  );
           
             
        


        return dr;

    }

    public DataSet reportaeging()
    {
        DataSet dr;
        dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "reportaeging");




        return dr;

    }
    public DataSet showallreqruiterdata()
    {
        DataSet dr;
        dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "showallreqruiterdata");

        return dr;

    }


    public DataSet accept(string POJ)
    {
        DataSet dr;
        dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "accept",
             SQLDataAccess.CreateParameter("@POJ", SqlDbType.VarChar, POJ, ParameterDirection.Input, 50, false));



        return dr;

    }
   
}
 }

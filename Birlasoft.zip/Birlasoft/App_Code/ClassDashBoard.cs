﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using System.Globalization;
/// <summary>
/// Summary description for DashBoard
/// </summary>
/// 
namespace IISERVZ
{

public class ClassDashBoard
{
    public string cnn;
    public ClassDashBoard()
	{
        cnn = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
	}


    public DataTable ShowTat(String TatStatus,String ClinetName)
    {
        SqlConnection sqlcon = new SqlConnection(cnn);
        SqlDataAdapter sda = new SqlDataAdapter();
        DataTable dt = new DataTable();
        try
        {
            sqlcon.Open();
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = sqlcon;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ShowTat";
                cmd.Parameters.AddWithValue("@TatStatus", TatStatus);
                cmd.Parameters.AddWithValue("@ClientName", ClinetName);
                sda.SelectCommand = cmd;
                sda.Fill(dt);
                sqlcon.Close();
            }



        }
        catch (SqlException se)
        {
            //DBErLog.DbServLog(se, se.ToString());
        }
        finally
        {
            sqlcon.Close();
        }
        return dt;

    }
    ///ShowTatColor
    ///
    
    //MonthValue, Green, Red, Amber
    public DataTable ShowTatColor(String ClinetName)
    {
        SqlConnection sqlcon = new SqlConnection(cnn);
        SqlDataAdapter sda = new SqlDataAdapter();
        DataTable dt = new DataTable();
        try
        {
            sqlcon.Open();
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = sqlcon;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ShowTatColor";
                cmd.Parameters.AddWithValue("@ClientName", ClinetName);
                sda.SelectCommand = cmd;
                sda.Fill(dt);
                sqlcon.Close();
            }



        }
        catch (SqlException se)
        {
            //DBErLog.DbServLog(se, se.ToString());
        }
        finally
        {
            sqlcon.Close();
        }
        return dt;

    }


    /// <summary>
    /// /
    /// </summary>
    /// <param name="?"></param>
    /// <returns>
    /// TotalCases,MonthVal,sClosed,Insuff,WIP
    /// </returns>
    public DataTable ShowBGCStatus(String ClinetName)
    {
         SqlConnection sqlcon = new SqlConnection(cnn);
        SqlDataAdapter sda = new SqlDataAdapter();
        DataTable dt = new DataTable();
        try
        {
            sqlcon.Open();
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = sqlcon;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ShowBGCStatus";
                cmd.Parameters.AddWithValue("@ClientName", ClinetName);
                sda.SelectCommand = cmd;
                sda.Fill(dt);
                sqlcon.Close();
            }



        }
        catch (SqlException se)
        {
            //DBErLog.DbServLog(se, se.ToString());
        }
        finally
        {
            sqlcon.Close();
        }
        return dt;
    }







}
}
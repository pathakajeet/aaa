﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data.SqlClient;

namespace IISERVZCLASS.App_Code
{
    
    public class GlobalConnection
    {
      
    }
}

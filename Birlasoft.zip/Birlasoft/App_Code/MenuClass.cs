﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.WebControls;

namespace IISERVZCLASS
{
    /// <summary>
    /// Summary description for MenuClass
    /// </summary>

    public class MenuClass
    {
        public MenuClass()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        public static Menu buildMenu(Menu menu, SqlConnection con, string userID)
        {
            con.Open();
            string selQuery = string.Empty;
            if (userID == "0")
            {
                selQuery = "select * from sub_menu";
            }
            else
            {
                selQuery = "select sm.rootID,sm.MenuTitle,sm.submenuurl,userid,trm.roleid,trm.rolename,trd.access,tmm.modulename from tbl_user_master tum inner join tbl_role_master trm on tum.roleid=trm.roleid " +
                            "inner join tbl_role_details trd on trm.roleid=trd.roleid inner join tbl_module_master tmm on trd.moduleid=tmm.moduleid " +
                            "inner join sub_menu sm on tmm.modulename=sm.modulename " +
                            "where tum.userid=" + userID + " and trd.access=1 order by sm.position";
            }
            SqlDataAdapter adaptum = new SqlDataAdapter("select * from menu_root order by position", con);
            SqlDataAdapter adaptrm = new SqlDataAdapter(selQuery, con);
            DataSet ds = new DataSet();
            adaptum.Fill(ds, "Menu_Root");
            adaptrm.Fill(ds, "Sub_Menu");
            con.Close();
            ds.Relations.Add("Children", ds.Tables["Menu_Root"].Columns["RootID"],
                ds.Tables["Sub_Menu"].Columns["RootID"]);
            foreach (DataRow parentItem in ds.Tables["Menu_Root"].Rows)
            {
                MenuItem categoryItem = new MenuItem((string)parentItem["RootName"]);
                categoryItem.NavigateUrl = parentItem["RootUrl"].ToString();
                menu.Items.Add(categoryItem);
                foreach (DataRow childItem in parentItem.GetChildRows("Children"))
                {
                    MenuItem childrenItem = new MenuItem((string)childItem["MenuTitle"]);
                    childrenItem.NavigateUrl = childItem["submenuurl"].ToString();
                    //if (userID != "0")
                    //{
                    //    if (childItem["access"].ToString() == "False")
                    //    {
                    //        childrenItem.Enabled = false;
                    //    }
                    //}

                    if ((string)childItem["MenuTitle"] != "Questions")
                    {
                        categoryItem.ChildItems.Add(childrenItem);
                    }
                    else
                    {
                        if (ds.Tables["Sub_Menu"].Rows[0][5].ToString().ToUpper() != "FOS")
                            categoryItem.ChildItems.Add(childrenItem);
                    }


                }
            }
            return menu;
        }
    }
}

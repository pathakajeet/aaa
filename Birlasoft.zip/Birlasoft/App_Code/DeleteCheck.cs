﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for DeleteCheck
/// </summary>
namespace IISERVZCLASS
{
    public static class DeleteCheck
    {
        #region Global Connection String
        private static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OnicraCreditVerification"].ToString());
        #endregion


        public static bool checkDelete(string tabName, string ID, string colName)
        {
            con.Open();
            string chkQuery = "select * from " + tabName + " where " + colName + "=" + ID;
            SqlDataAdapter adap = new SqlDataAdapter(chkQuery, con);
            DataSet dS = new DataSet();
            adap.Fill(dS);
            con.Close();
            if (dS.Tables[0].Rows.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static string errMsg(string PName, string CName)
        {
            string message = "This " + PName + " Is Associated With Some " + CName + ".Kindly Delete The " + CName + " To Delete This " + PName;
            return message;
        }
    }
}

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DataAccess;
using Casestatus;
using System.Collections;



/// <summary>
/// Summary description for Status
/// </summary>
/// 
namespace Casestatus
{
    public class Status
    {

        private string strCaseStatus;
        //Commented on 23rd april //usp_UpdateCloseStatus_ColorFinal
        //private string strAllocatedStatus;
        private string strEmployeeID;



        public string CaseStatus
        {
            get
            {
                return strCaseStatus;
            }
            set
            {
                strCaseStatus = value;
            }
        }
        //Commented on 23rd april
        //public string AllocatedStatus
        //{
        //    get
        //    {
        //        return strAllocatedStatus;
        //    }
        //    set
        //    {
        //        strAllocatedStatus = value;
        //    }
        //}
        public string EmployeeID
        {
            get
            {
                return strEmployeeID;
            }
            set
            {
                strEmployeeID = value;
            }

        }

        public string Updatestatus(string empId)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[1];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_Updatestatus", paramsToStore));

        }
        public string UpdateAllocation(string empId)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[1];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_UpdateAllocation", paramsToStore));


        }

        public string insufffollwupmail(string refid, string candidate, string component, string remarks, string insdate, string inslevel)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[6];


            paramsToStore[0] = new SqlParameter("@refid", SqlDbType.VarChar);
            paramsToStore[0].Value = refid;

            paramsToStore[1] = new SqlParameter("@candidate", SqlDbType.VarChar);
            paramsToStore[1].Value = candidate;

            paramsToStore[2] = new SqlParameter("@component", SqlDbType.VarChar);
            paramsToStore[2].Value = component;

            paramsToStore[3] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[3].Value = remarks;

            paramsToStore[4] = new SqlParameter("@insdate", SqlDbType.VarChar);
            paramsToStore[4].Value = insdate;

            paramsToStore[5] = new SqlParameter("@inslevel", SqlDbType.VarChar);
            paramsToStore[5].Value = inslevel;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "insfollowmail", paramsToStore));

        }


        public string FNSstop(string mobileno)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[1];


            paramsToStore[0] = new SqlParameter("@mobileno", SqlDbType.VarChar);
            paramsToStore[0].Value = mobileno;




            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "FNSstop", paramsToStore));

        }

        public string Fnsmail(string mobileno)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[1];


            paramsToStore[0] = new SqlParameter("@mobileno", SqlDbType.VarChar);
            paramsToStore[0].Value = mobileno;




            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Fnssendmail", paramsToStore));

        }

    
        public string dashboard(string RefID, string ClientName, string CandidateName, string Edu1, string Edu2, string Edu3, string Edu4, string Edu5, string Edu6, string Edu7, string Edu8, string Emp1, string Emp2, string Emp3, string Emp4, string Emp5, string Emp6, string Emp7, string Emp8, string Ref1, string Ref2, string Ref3, string Add1, string Add2, string Add3, string Add4, string Add5, string Add6, string Add7, string Add8, string Cri1, string Cri2, string Cri3, string Cri4, string Cri5, string Cri6, string Cri7, string Cri8, string DB, string Drug, string Id1, string Id2, string Id3, string Id4, string Priority, string TAT)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[46];
            paramsToStore[0] = new SqlParameter("@RefID", SqlDbType.VarChar);
            paramsToStore[0].Value = RefID;

            paramsToStore[1] = new SqlParameter("@ClientName", SqlDbType.VarChar);
            paramsToStore[1].Value = ClientName;

            paramsToStore[2] = new SqlParameter("@CandidateName", SqlDbType.VarChar);
            paramsToStore[2].Value = CandidateName;

            paramsToStore[3] = new SqlParameter("@Edu1", SqlDbType.VarChar);
            paramsToStore[3].Value = Edu1;

            paramsToStore[4] = new SqlParameter("@Edu2", SqlDbType.VarChar);
            paramsToStore[4].Value = Edu2;

            paramsToStore[5] = new SqlParameter("@Edu3", SqlDbType.VarChar);
            paramsToStore[5].Value = Edu3;

            paramsToStore[6] = new SqlParameter("@Edu4", SqlDbType.VarChar);
            paramsToStore[6].Value = Edu4;

            paramsToStore[7] = new SqlParameter("@Edu5", SqlDbType.VarChar);
            paramsToStore[7].Value = Edu5;

            paramsToStore[8] = new SqlParameter("@Edu6", SqlDbType.VarChar);
            paramsToStore[8].Value = Edu6;

            paramsToStore[9] = new SqlParameter("@Edu7", SqlDbType.VarChar);
            paramsToStore[9].Value = Edu7;


            paramsToStore[10] = new SqlParameter("@Edu8", SqlDbType.VarChar);
            paramsToStore[10].Value = Edu8;


            paramsToStore[11] = new SqlParameter("@Emp1", SqlDbType.VarChar);
            paramsToStore[11].Value = Emp1;

            paramsToStore[12] = new SqlParameter("@Emp2", SqlDbType.VarChar);
            paramsToStore[12].Value = Emp2;

            paramsToStore[13] = new SqlParameter("@Emp3", SqlDbType.VarChar);
            paramsToStore[13].Value = Emp3;

            paramsToStore[14] = new SqlParameter("@Emp4", SqlDbType.VarChar);
            paramsToStore[14].Value = Emp4;

            paramsToStore[15] = new SqlParameter("@Emp5", SqlDbType.VarChar);
            paramsToStore[15].Value = Emp5;

            paramsToStore[16] = new SqlParameter("@Emp6", SqlDbType.VarChar);
            paramsToStore[16].Value = Emp6;

            paramsToStore[17] = new SqlParameter("@Emp7", SqlDbType.VarChar);
            paramsToStore[17].Value = Emp7;

            paramsToStore[18] = new SqlParameter("@Emp8", SqlDbType.VarChar);
            paramsToStore[18].Value = Emp8;

            paramsToStore[19] = new SqlParameter("@Ref1", SqlDbType.VarChar);
            paramsToStore[19].Value = Ref1;

            paramsToStore[20] = new SqlParameter("@Ref2", SqlDbType.VarChar);
            paramsToStore[20].Value = Ref2;

            paramsToStore[21] = new SqlParameter("@Ref3", SqlDbType.VarChar);
            paramsToStore[21].Value = Ref3;

            paramsToStore[22] = new SqlParameter("@Add1", SqlDbType.VarChar);
            paramsToStore[22].Value = Add1;

            paramsToStore[23] = new SqlParameter("@Add2", SqlDbType.VarChar);
            paramsToStore[23].Value = Add2;

            paramsToStore[24] = new SqlParameter("@Add3", SqlDbType.VarChar);
            paramsToStore[24].Value = Add3;

            paramsToStore[25] = new SqlParameter("@Add4", SqlDbType.VarChar);
            paramsToStore[25].Value = Add4;

            paramsToStore[26] = new SqlParameter("@Add5", SqlDbType.VarChar);
            paramsToStore[26].Value = Add5;

            paramsToStore[27] = new SqlParameter("@Add6", SqlDbType.VarChar);
            paramsToStore[27].Value = Add6;

            paramsToStore[28] = new SqlParameter("@Add7", SqlDbType.VarChar);
            paramsToStore[28].Value = Add7;

            paramsToStore[29] = new SqlParameter("@Add8", SqlDbType.VarChar);
            paramsToStore[29].Value = Add8;

            paramsToStore[30] = new SqlParameter("@Cri1", SqlDbType.VarChar);
            paramsToStore[30].Value = Cri1;

            paramsToStore[31] = new SqlParameter("@Cri2", SqlDbType.VarChar);
            paramsToStore[31].Value = Cri2;

            paramsToStore[32] = new SqlParameter("@Cri3", SqlDbType.VarChar);
            paramsToStore[32].Value = Cri3;

            paramsToStore[33] = new SqlParameter("@Cri4", SqlDbType.VarChar);
            paramsToStore[33].Value = Cri4;

            paramsToStore[34] = new SqlParameter("@Cri5", SqlDbType.VarChar);
            paramsToStore[34].Value = Cri5;

            paramsToStore[35] = new SqlParameter("@Cri6", SqlDbType.VarChar);
            paramsToStore[35].Value = Cri6;

            paramsToStore[36] = new SqlParameter("@Cri7", SqlDbType.VarChar);
            paramsToStore[36].Value = Cri7;

            paramsToStore[37] = new SqlParameter("@Cri8", SqlDbType.VarChar);
            paramsToStore[37].Value = Cri8;

            paramsToStore[38] = new SqlParameter("@DB", SqlDbType.VarChar);
            paramsToStore[38].Value = DB;

            paramsToStore[39] = new SqlParameter("@Drug", SqlDbType.VarChar);
            paramsToStore[39].Value = Drug;

            paramsToStore[40] = new SqlParameter("@Id1", SqlDbType.VarChar);
            paramsToStore[40].Value = Id1;

            paramsToStore[41] = new SqlParameter("@Id2", SqlDbType.VarChar);
            paramsToStore[41].Value = Id2;

            paramsToStore[42] = new SqlParameter("@Id3", SqlDbType.VarChar);
            paramsToStore[42].Value = Id3;

            paramsToStore[43] = new SqlParameter("@Id4", SqlDbType.VarChar);
            paramsToStore[43].Value = Id4;

            paramsToStore[44] = new SqlParameter("@Priority", SqlDbType.VarChar);
            paramsToStore[44].Value = Priority;

            paramsToStore[45] = new SqlParameter("@TAT", SqlDbType.VarChar);
            paramsToStore[45].Value = TAT;





            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "CounterDashboard", paramsToStore));

        }


        //allocation
        public string allocUpdateAllocation(string empId)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[1];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocusp_UpdateAllocation", paramsToStore));

        }

        public string ReallocateCase(string candidateid)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[1];
            paramsToStore[0] = new SqlParameter("@candidateid", SqlDbType.VarChar);
            paramsToStore[0].Value = candidateid;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ReallocateCase", paramsToStore));

        }

        public string reject(string candidateid, string name, string rejectuser, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[4];
            paramsToStore[0] = new SqlParameter("@candidateid", SqlDbType.VarChar);
            paramsToStore[0].Value = candidateid;

            paramsToStore[1] = new SqlParameter("@name", SqlDbType.VarChar);
            paramsToStore[1].Value = name;


            paramsToStore[2] = new SqlParameter("@rejectuser", SqlDbType.VarChar);
            paramsToStore[2].Value = rejectuser;

            paramsToStore[3] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[3].Value = remarks;



            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "reject", paramsToStore));


        }

        public string updateemail(string candidateid, string name, string rejectuser, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[4];
            paramsToStore[0] = new SqlParameter("@candidateid", SqlDbType.VarChar);
            paramsToStore[0].Value = candidateid;

            paramsToStore[1] = new SqlParameter("@name", SqlDbType.VarChar);
            paramsToStore[1].Value = name;


            paramsToStore[2] = new SqlParameter("@rejectuser", SqlDbType.VarChar);
            paramsToStore[2].Value = rejectuser;

            paramsToStore[3] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[3].Value = remarks;



            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "updateemail", paramsToStore));


        }





        public string ReportsendtoQuality(String RptRemark, string ReportColor, string ReportID, string username, string RptType)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[5];
            paramsToStore[0] = new SqlParameter("@ReportColor", SqlDbType.VarChar);
            paramsToStore[0].Value = ReportColor;

            paramsToStore[1] = new SqlParameter("@ReportID", SqlDbType.VarChar);
            paramsToStore[1].Value = ReportID;

            paramsToStore[2] = new SqlParameter("@username", SqlDbType.VarChar);
            paramsToStore[2].Value = username;

            paramsToStore[3] = new SqlParameter("@RptRemark", SqlDbType.VarChar);
            paramsToStore[3].Value = RptRemark;

            paramsToStore[4] = new SqlParameter("@RptType", SqlDbType.VarChar);
            paramsToStore[4].Value = RptType;


            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ReportsendtoQuality", paramsToStore));

        }

        public string PartialReportsend(String RptRemark, string ReportColor, string ReportID, string username, string RptType)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[5];
            paramsToStore[0] = new SqlParameter("@ReportColor", SqlDbType.VarChar);
            paramsToStore[0].Value = ReportColor;

            paramsToStore[1] = new SqlParameter("@ReportID", SqlDbType.VarChar);
            paramsToStore[1].Value = ReportID;

            paramsToStore[2] = new SqlParameter("@username", SqlDbType.VarChar);
            paramsToStore[2].Value = username;

            paramsToStore[3] = new SqlParameter("@RptRemark", SqlDbType.VarChar);
            paramsToStore[3].Value = RptRemark;

            paramsToStore[4] = new SqlParameter("@RptType", SqlDbType.VarChar);
            paramsToStore[4].Value = RptType;


            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "PartialReportsend", paramsToStore));

        }


        public string ExporttoClient(string empId, string username, string candidatename)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[3];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@username", SqlDbType.VarChar);
            paramsToStore[1].Value = username;

            paramsToStore[2] = new SqlParameter("@candidatename", SqlDbType.VarChar);
            paramsToStore[2].Value = candidatename;
            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ExporttoClient", paramsToStore));

        }

        public string InsuffAllocation(string empId)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[1];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "insuff_Allocation", paramsToStore));

        }

        public string InsuffEducationAllocation(string empId, string remark)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@remark", SqlDbType.VarChar);
            paramsToStore[1].Value = remark;
            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "insuff_edu_Allocation", paramsToStore));

        }


        public string InsuffEduUpdate(string eduId, string refid, string Remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[3];
            paramsToStore[0] = new SqlParameter("@EduID", SqlDbType.VarChar);
            paramsToStore[0].Value = eduId;


            paramsToStore[1] = new SqlParameter("@refid", SqlDbType.VarChar);
            paramsToStore[1].Value = refid;

            paramsToStore[2] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[2].Value = Remarks;




            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsuffEduUpdate", paramsToStore));

        }

        public string InsuffEmpUpdate(string empId, string refid, string checks, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[4];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@refid", SqlDbType.VarChar);
            paramsToStore[1].Value = refid;

            paramsToStore[2] = new SqlParameter("@checks", SqlDbType.VarChar);
            paramsToStore[2].Value = checks;

            paramsToStore[3] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[3].Value = remarks;

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsuffEmpUpdate", paramsToStore));

        }


        public string InsuffClearToEmp(string empId, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            paramsToStore[1] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsuffClearToEmp", paramsToStore));

        }

        public string InsuffEmploymentAllocation(string empId, string remark)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@remark", SqlDbType.VarChar);
            paramsToStore[1].Value = remark;
            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "insuff_emp_Allocation", paramsToStore));

        }
        public string ADDheadUpdate(string empId, string Checks, string Address, string AllocatedStaff, string state, string location)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[6];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@Checks", SqlDbType.VarChar);
            paramsToStore[1].Value = Checks;

            paramsToStore[2] = new SqlParameter("@AllocatedStaff", SqlDbType.VarChar);
            paramsToStore[2].Value = AllocatedStaff;

            paramsToStore[3] = new SqlParameter("@Address", SqlDbType.NVarChar);
            paramsToStore[3].Value = Address;

            paramsToStore[4] = new SqlParameter("@State", SqlDbType.VarChar);
            paramsToStore[4].Value = state;

            paramsToStore[5] = new SqlParameter("@Location", SqlDbType.VarChar);
            paramsToStore[5].Value = location;




            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ADDhead_UpdateAllocation", paramsToStore));

        }

        public string ADDheadUpdateNew(string empId, string Checks, string Address, string AllocatedStaff)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[4];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@Checks", SqlDbType.VarChar);
            paramsToStore[1].Value = Checks;

            paramsToStore[2] = new SqlParameter("@AllocatedStaff", SqlDbType.VarChar);
            paramsToStore[2].Value = AllocatedStaff;

            paramsToStore[3] = new SqlParameter("@Address", SqlDbType.NVarChar);
            paramsToStore[3].Value = Address;


            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ADDhead_UpdateAllocationNew", paramsToStore));

        }


        public string EmpSTOP(string cmpId, string empId, string user, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[4];
            paramsToStore[0] = new SqlParameter("@CmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = cmpId;

            paramsToStore[1] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[1].Value = empId;

            paramsToStore[2] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[2].Value = remarks;

            paramsToStore[3] = new SqlParameter("@user", SqlDbType.VarChar);
            paramsToStore[3].Value = user;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "EmpSTOPCase", paramsToStore));

        }
        //allocation
        //verihead
        public string veriheadUpdate(string empId, string Checks, string AllocatedStaff, string UniversityName, string CollegeName, string YearOfPassing, string AllocatedDate, string EduAddCriDetails, string RollNo, string Location, string State, int AllocatedStatus, string requirement)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[13];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@Checks", SqlDbType.VarChar);
            paramsToStore[1].Value = Checks;

            paramsToStore[2] = new SqlParameter("@AllocatedStaff", SqlDbType.VarChar);
            paramsToStore[2].Value = AllocatedStaff;

            paramsToStore[3] = new SqlParameter("@UniversityName", SqlDbType.VarChar);
            paramsToStore[3].Value = UniversityName;

            paramsToStore[4] = new SqlParameter("@CollegeName", SqlDbType.VarChar);
            paramsToStore[4].Value = CollegeName;

            paramsToStore[5] = new SqlParameter("@YearOfPassing", SqlDbType.VarChar);
            paramsToStore[5].Value = YearOfPassing;

            paramsToStore[6] = new SqlParameter("@AllocatedDate", SqlDbType.VarChar);
            paramsToStore[6].Value = AllocatedDate;


            //string RollNo,string YearOfPassing,string Location, string State
            // @EmpId ,            //@Checks ,            //@AllocatedStaff,            //@EduAddCriDetails ,            //@CollegeName,
            //@UniversityName ,            //@RollNo ,            //@YearOfPassing ,            //@Location ,            //@State,            //@AllocationDate,


            paramsToStore[7] = new SqlParameter("@EduAddCriDetails", SqlDbType.NVarChar);
            paramsToStore[7].Value = EduAddCriDetails;

            paramsToStore[8] = new SqlParameter("@RollNo", SqlDbType.VarChar);
            paramsToStore[8].Value = RollNo;

            paramsToStore[9] = new SqlParameter("@Location", SqlDbType.VarChar);
            paramsToStore[9].Value = Location;


            paramsToStore[10] = new SqlParameter("@State", SqlDbType.VarChar);
            paramsToStore[10].Value = State;


            paramsToStore[11] = new SqlParameter("@AllocatedStatus", SqlDbType.Int);
            paramsToStore[11].Value = AllocatedStatus;

            paramsToStore[12] = new SqlParameter("@requirement", SqlDbType.VarChar);
            paramsToStore[12].Value = requirement;

            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_UpdateAllocation", paramsToStore));

        }
        public string veriheadUpdateNew(string empId, string Checks, string AllocatedStaff, string UniversityName, string CollegeName, string YearOfPassing, string AllocatedDate, string EduAddCriDetails, string RollNo, string Location, string State, int AllocatedStatus, string requirement)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[13];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@Checks", SqlDbType.VarChar);
            paramsToStore[1].Value = Checks;

            paramsToStore[2] = new SqlParameter("@AllocatedStaff", SqlDbType.VarChar);
            paramsToStore[2].Value = AllocatedStaff;

            paramsToStore[3] = new SqlParameter("@UniversityName", SqlDbType.VarChar);
            paramsToStore[3].Value = UniversityName;

            paramsToStore[4] = new SqlParameter("@CollegeName", SqlDbType.VarChar);
            paramsToStore[4].Value = CollegeName;

            paramsToStore[5] = new SqlParameter("@YearOfPassing", SqlDbType.VarChar);
            paramsToStore[5].Value = YearOfPassing;

            paramsToStore[6] = new SqlParameter("@AllocatedDate", SqlDbType.VarChar);
            paramsToStore[6].Value = AllocatedDate;


            //string RollNo,string YearOfPassing,string Location, string State
            // @EmpId ,            //@Checks ,            //@AllocatedStaff,            //@EduAddCriDetails ,            //@CollegeName,
            //@UniversityName ,            //@RollNo ,            //@YearOfPassing ,            //@Location ,            //@State,            //@AllocationDate,


            paramsToStore[7] = new SqlParameter("@EduAddCriDetails", SqlDbType.NVarChar);
            paramsToStore[7].Value = EduAddCriDetails;

            paramsToStore[8] = new SqlParameter("@RollNo", SqlDbType.VarChar);
            paramsToStore[8].Value = RollNo;

            paramsToStore[9] = new SqlParameter("@Location", SqlDbType.VarChar);
            paramsToStore[9].Value = Location;


            paramsToStore[10] = new SqlParameter("@State", SqlDbType.VarChar);
            paramsToStore[10].Value = State;


            paramsToStore[11] = new SqlParameter("@AllocatedStatus", SqlDbType.Int);
            paramsToStore[11].Value = AllocatedStatus;

            paramsToStore[12] = new SqlParameter("@requirement", SqlDbType.VarChar);
            paramsToStore[12].Value = requirement;

            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_UpdateAllocationNew", paramsToStore));

        }
        //verihead



        public string NotUpdateAddRevert(string addId, string username, string refid)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[3];
            paramsToStore[0] = new SqlParameter("@AddID", SqlDbType.VarChar);
            paramsToStore[0].Value = addId;

            paramsToStore[1] = new SqlParameter("@username", SqlDbType.VarChar);
            paramsToStore[1].Value = username;

            paramsToStore[2] = new SqlParameter("@refid", SqlDbType.VarChar);
            paramsToStore[2].Value = refid;


            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "NotUpdateAddRevert", paramsToStore));

        }

        public string RejectAddRevert(string addId, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@AddID", SqlDbType.VarChar);
            paramsToStore[0].Value = addId;

            paramsToStore[1] = new SqlParameter("@remark", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "RejectAddRevert", paramsToStore));

        }

        public string AddSTOP(string cmpId, string empId, string user, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[4];
            paramsToStore[0] = new SqlParameter("@CmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = cmpId;

            paramsToStore[1] = new SqlParameter("@AddID", SqlDbType.VarChar);
            paramsToStore[1].Value = empId;

            paramsToStore[2] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[2].Value = remarks;

            paramsToStore[3] = new SqlParameter("@user", SqlDbType.VarChar);
            paramsToStore[3].Value = user;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AddSTOPCase", paramsToStore));

        }

        //Employment

        public string EMPheadUpdate(string empId, string Checks, string Employer, string AllocatedStaff)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[4];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@Checks", SqlDbType.VarChar);
            paramsToStore[1].Value = Checks;

            paramsToStore[2] = new SqlParameter("@AllocatedStaff", SqlDbType.VarChar);
            paramsToStore[2].Value = AllocatedStaff;

            paramsToStore[3] = new SqlParameter("@Employer", SqlDbType.NVarChar);
            paramsToStore[3].Value = Employer;


            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "EMPhead_UpdateAllocation", paramsToStore));

        }

        public string EMPheadUpdateNew(string empId, string Checks, string Employer, string AllocatedStaff)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[4];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@Checks", SqlDbType.VarChar);
            paramsToStore[1].Value = Checks;

            paramsToStore[2] = new SqlParameter("@AllocatedStaff", SqlDbType.VarChar);
            paramsToStore[2].Value = AllocatedStaff;

            paramsToStore[3] = new SqlParameter("@Employer", SqlDbType.NVarChar);
            paramsToStore[3].Value = Employer;


            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "EMPhead_UpdateAllocationNew", paramsToStore));

        }


        public string DDGridUpdate(string empId, string ClientName, string AppName, string university, string college, string education, string rollNo)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[7];

            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@Client", SqlDbType.VarChar);
            paramsToStore[1].Value = ClientName;

            paramsToStore[2] = new SqlParameter("@applicant", SqlDbType.VarChar);
            paramsToStore[2].Value = AppName;

            paramsToStore[3] = new SqlParameter("@University", SqlDbType.VarChar);
            paramsToStore[3].Value = university;

            paramsToStore[4] = new SqlParameter("@College", SqlDbType.VarChar);
            paramsToStore[4].Value = college;

            paramsToStore[5] = new SqlParameter("@education", SqlDbType.VarChar);
            paramsToStore[5].Value = education;

            paramsToStore[6] = new SqlParameter("@rollNo", SqlDbType.VarChar);
            paramsToStore[6].Value = rollNo;


            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DDGridUpdate", paramsToStore));

        }
        // DD/Courrier Module

        public string UpdateCloseStatusKPMG(string empId, string CloseDate)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@CloseDate", SqlDbType.VarChar);
            paramsToStore[1].Value = CloseDate;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_UpdateCloseStatus_ColorFinal_KPMG", paramsToStore));

        }

        public string UpdateCloseStatus(string empId, string CloseDate)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@CloseDate", SqlDbType.VarChar);
            paramsToStore[1].Value = CloseDate;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_UpdateCloseStatus_ColorFinal", paramsToStore));

        }
        public string UpdateRevert(string empId)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[1];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_UpdateRevert", paramsToStore));

        }

        public void RejectSendMail()
        {
            SqlParameter[] paramsToStore = new SqlParameter[0];
            SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_Reject_Case_SendMail", paramsToStore);
        }

        public string UpdateRevertInitiator(string empId)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[1];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_UpdateRevertInitiator", paramsToStore));

        }
        public string UpdateRevertToManager(string empId, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            paramsToStore[1] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_UpdateRevertToManager", paramsToStore));

        }
        //Commented on 23rd april
        //public string savestatus(Status objcs)
        //{

        //    string i = "";

        //    SqlParameter[] paramsToStore = new SqlParameter[3];



        //    paramsToStore[0] = new SqlParameter("@CaseStatus", SqlDbType.VarChar);
        //    paramsToStore[0].Value = objcs.CaseStatus;

        //    paramsToStore[1] = new SqlParameter("@AllocatedStatus", SqlDbType.VarChar);
        //    paramsToStore[1].Value = objcs.AllocatedStatus;


        //    paramsToStore[2] = new SqlParameter("@EmployeeID", SqlDbType.VarChar);
        //    paramsToStore[2].Value = objcs.EmployeeID;



        //    return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "savestatus", paramsToStore));

        //}

        public string Selectdeo(Status objcs)
        {

            string i = "";

            SqlParameter[] paramsToStore = new SqlParameter[1];






            paramsToStore[0] = new SqlParameter("@EmployeeID", SqlDbType.VarChar);
            paramsToStore[0].Value = objcs.EmployeeID;



            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_selectdeo", paramsToStore));

        }

        public DataSet getcasestatus(int empid)
        {
            DataSet casestatus;
            casestatus = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "bindcasestaus",
                          SQLDataAccess.CreateParameter("@empid", SqlDbType.Int, empid, ParameterDirection.Input, 20, false)

                     );
            return casestatus;
        }


        public DataSet GetCheck(int Empid)
        {
            DataSet casestatus;
            casestatus = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "LoadCheck",
                          SQLDataAccess.CreateParameter("@Empid", SqlDbType.Int, Empid, ParameterDirection.Input, 20, false)

                     );
            return casestatus;
        }

        public int Update_Status_Remarks(
              string empId, string StatusAddress, string AddRDate,
              string AddCDate, string AddressRemarks, string StatusEducation,
              string EduRDate, string EduCDate, string EducationRemarks,
              string Education2Status

                 // txtEdu2RDate.Value,
            // txtEdu2CDate.Value, 
              , string Education2Remarks,
            // string Edu2RDate, string Edu2CDate, 
              string Education3Status,
              string Education3Remarks, string Education4Status, string Education4Remarks,
              string StatusEmploymenthr1, string EmpHRRDate, string EmpHRCDate,
              string EmploymentRemarkshr1, string EmpSUPRDate, string EmpSUPCDate,//--21
              string StatusEmploymenthr2, string EmploymentRemarkshr2,
              string StatusEmploymenthr3, string EmploymentRemarkshr3, string StatusEmploymenthr4,
              string EmploymentRemarkshr4, string StatusEmploymenthr5, string EmploymentRemarkshr5,
              string StatusEmploymenthr6, string EmploymentRemarkshr6, string StatusEmploymenthr7,
              string EmploymentRemarkshr7, string StatusEmploymenthr8, string EmploymentRemarkshr8,
              string StatusCriminal, string CriminalRDate, string CriminalCDate, string CriminalRemarks,
              string StatusDrug, string DrugRDate, string DrugCDate, string DrugRemarks,
              string DataBaseStatus, string DBRDate, string DBCDate, string DataBaseRemarks,
              string FinalColor,
              string Address2Status, string Address2Remarks,
              string Address2RDate, string Address2CDate,
              string Address3Status, string Address3Remarks,
              string Address4Status, string Address4Remarks,
              string Address5Status, string Address5Remarks,
              string Address6Status, string Address6Remarks,
              string Address7Status, string Address7Remarks,
              string Address8Status, string Address8Remarks,
              string Education5Status, string Education5Remarks,
              string Education6Status, string Education6Remarks,
              string Education7Status, string Education7Remarks,
              string Education8Status, string Education8Remarks,
              string Criminal2Status, string Criminal2Remarks,
              string Criminal2RDate, string Criminal2CDate,
              string Criminal3Status, string Criminal3Remarks,
              string Criminal4Status, string Criminal4Remarks,
              string Criminal5Status, string Criminal5Remarks,
              string Criminal6Status, string Criminal6Remarks,
              string Criminal7Status, string Criminal7Remarks,
              string Criminal8Status, string Criminal8Remarks,
              string IdentityStatus, string IdentityRemarks,
              string IdentityRDate, string IdentityCDate,
              string Edu2RDate, string Edu2CDate,
              string ddlRef1, string RemRef1,
              string ddlRef2, string RemRef2,
              string ddlRef3, string RemRef3,
              string Ref1RDate, string Ref1CDate


              //ddlRef1.SelectedValue,
            // txtRemRef1.Text,
            // ddlRef2.SelectedValue,
            // txtRemRef2.Text,
            // ddlRef3.SelectedValue,
            // txtRemRef3.Text,
            // txtRef1RDate.Value,
            // txtRef2CDate.Value  
              )
        {
            int i;
            SqlParameter[] paramsToStore = new SqlParameter[102];
            ArrayList numbers = new ArrayList();

            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;


            paramsToStore[1] = new SqlParameter("@StatusAddress", SqlDbType.VarChar);
            paramsToStore[1].Value = StatusAddress;

            paramsToStore[2] = new SqlParameter("@AddRDate", SqlDbType.VarChar);
            paramsToStore[2].Value = (AddRDate == "" ? null : AddRDate);
            paramsToStore[3] = new SqlParameter("@AddCDate", SqlDbType.VarChar);
            paramsToStore[3].Value = (AddCDate == "" ? null : AddCDate);

            paramsToStore[4] = new SqlParameter("@AddressRemarks", SqlDbType.VarChar);
            paramsToStore[4].Value = AddressRemarks;

            paramsToStore[5] = new SqlParameter("@StatusEducation", SqlDbType.VarChar);
            paramsToStore[5].Value = StatusEducation;
            paramsToStore[6] = new SqlParameter("@EduRDate", SqlDbType.VarChar);
            paramsToStore[6].Value = (EduRDate == "" ? null : EduRDate);
            paramsToStore[7] = new SqlParameter("@EduCDate", SqlDbType.VarChar);
            paramsToStore[7].Value = (EduCDate == "" ? null : EduCDate);
            paramsToStore[8] = new SqlParameter("@EducationRemarks", SqlDbType.VarChar);
            paramsToStore[8].Value = EducationRemarks;

            paramsToStore[9] = new SqlParameter("@Education2Status", SqlDbType.VarChar);
            paramsToStore[9].Value = Education2Status;

            paramsToStore[10] = new SqlParameter("@Education2Remarks", SqlDbType.VarChar);
            paramsToStore[10].Value = Education2Remarks;

            paramsToStore[11] = new SqlParameter("@Education3Status", SqlDbType.VarChar);
            paramsToStore[11].Value = Education3Status;

            paramsToStore[12] = new SqlParameter("@Education3Remarks", SqlDbType.VarChar);
            paramsToStore[12].Value = Education3Remarks;

            paramsToStore[13] = new SqlParameter("@Education4Status", SqlDbType.VarChar);
            paramsToStore[13].Value = Education4Status;

            paramsToStore[14] = new SqlParameter("@Education4Remarks", SqlDbType.VarChar);
            paramsToStore[14].Value = Education4Remarks;





            paramsToStore[15] = new SqlParameter("@StatusEmploymenthr1", SqlDbType.VarChar);
            paramsToStore[15].Value = StatusEmploymenthr1;
            paramsToStore[16] = new SqlParameter("@EmpHRRDate", SqlDbType.VarChar);
            paramsToStore[16].Value = (EmpHRRDate == "" ? null : EmpHRRDate);
            paramsToStore[17] = new SqlParameter("@EmpHRCDate", SqlDbType.VarChar);
            paramsToStore[17].Value = (EmpHRCDate == "" ? null : EmpHRCDate);

            paramsToStore[18] = new SqlParameter("@EmploymentRemarkshr1", SqlDbType.VarChar);
            paramsToStore[18].Value = EmploymentRemarkshr1;




            //paramsToStore[19] = new SqlParameter("@StatusEmploymentSup1", SqlDbType.VarChar);
            //paramsToStore[19].Value = StatusEmploymentSup1;

            paramsToStore[19] = new SqlParameter("@EmpSUPRDate", SqlDbType.VarChar);
            paramsToStore[19].Value = (EmpSUPRDate == "" ? null : EmpSUPRDate);
            paramsToStore[20] = new SqlParameter("@EmpSUPCDate", SqlDbType.VarChar);
            paramsToStore[20].Value = (EmpSUPCDate == "" ? null : EmpSUPCDate);

            //paramsToStore[22] = new SqlParameter("@EmploymentRemarksSup1", SqlDbType.VarChar);
            //paramsToStore[22].Value = EmploymentRemarksSup1;

            paramsToStore[21] = new SqlParameter("@StatusEmploymenthr2", SqlDbType.VarChar);
            paramsToStore[21].Value = StatusEmploymenthr2;

            paramsToStore[22] = new SqlParameter("@EmploymentRemarkshr2", SqlDbType.VarChar);
            paramsToStore[22].Value = EmploymentRemarkshr2;

            //paramsToStore[25] = new SqlParameter("@StatusEmploymentSup2", SqlDbType.VarChar);
            //paramsToStore[25].Value = StatusEmploymentSup2;

            //paramsToStore[26] = new SqlParameter("@EmploymentRemarksSup2", SqlDbType.VarChar);
            //paramsToStore[26].Value = EmploymentRemarksSup2;



            paramsToStore[23] = new SqlParameter("@StatusEmploymenthr3", SqlDbType.VarChar);
            paramsToStore[23].Value = StatusEmploymenthr3;

            //paramsToStore[28] = new SqlParameter("@StatusEmploymentSup3", SqlDbType.VarChar);
            //paramsToStore[28].Value = StatusEmploymentSup3;

            paramsToStore[24] = new SqlParameter("@EmploymentRemarkshr3", SqlDbType.VarChar);
            paramsToStore[24].Value = EmploymentRemarkshr3;

            //paramsToStore[30] = new SqlParameter("@EmploymentRemarksSup3", SqlDbType.VarChar);
            //paramsToStore[30].Value = EmploymentRemarksSup3;



            paramsToStore[25] = new SqlParameter("@StatusEmploymenthr4", SqlDbType.VarChar);
            paramsToStore[25].Value = StatusEmploymenthr4;

            //paramsToStore[32] = new SqlParameter("@StatusEmploymentSup4", SqlDbType.VarChar);
            //paramsToStore[32].Value = StatusEmploymentSup4;

            paramsToStore[26] = new SqlParameter("@EmploymentRemarkshr4", SqlDbType.VarChar);
            paramsToStore[26].Value = EmploymentRemarkshr4;

            //paramsToStore[34] = new SqlParameter("@EmploymentRemarksSup4", SqlDbType.VarChar);
            //paramsToStore[34].Value = EmploymentRemarksSup4;




            paramsToStore[27] = new SqlParameter("@StatusEmploymenthr5", SqlDbType.VarChar);
            paramsToStore[27].Value = StatusEmploymenthr5;

            //paramsToStore[36] = new SqlParameter("@StatusEmploymentSup5", SqlDbType.VarChar);
            //paramsToStore[36].Value = StatusEmploymentSup5;

            paramsToStore[28] = new SqlParameter("@EmploymentRemarkshr5", SqlDbType.VarChar);
            paramsToStore[28].Value = EmploymentRemarkshr5;

            //paramsToStore[38] = new SqlParameter("@EmploymentRemarksSup5", SqlDbType.VarChar);
            //paramsToStore[38].Value = EmploymentRemarksSup5;

            paramsToStore[29] = new SqlParameter("@StatusCriminal", SqlDbType.VarChar);
            paramsToStore[29].Value = StatusCriminal;
            paramsToStore[30] = new SqlParameter("@CriminalRDate", SqlDbType.VarChar);
            paramsToStore[30].Value = (CriminalRDate == "" ? null : CriminalRDate);
            paramsToStore[31] = new SqlParameter("@CriminalCDate", SqlDbType.VarChar);
            paramsToStore[31].Value = (CriminalCDate == "" ? null : CriminalCDate);

            paramsToStore[32] = new SqlParameter("@CriminalRemarks", SqlDbType.VarChar);
            paramsToStore[32].Value = CriminalRemarks;

            paramsToStore[33] = new SqlParameter("@StatusDrug", SqlDbType.VarChar);
            paramsToStore[33].Value = StatusDrug;
            paramsToStore[34] = new SqlParameter("@DrugRDate", SqlDbType.VarChar);
            paramsToStore[34].Value = (DrugRDate == "" ? null : DrugRDate);

            paramsToStore[35] = new SqlParameter("@DrugCDate", SqlDbType.VarChar);
            paramsToStore[35].Value = (DrugCDate == "" ? null : DrugCDate);

            paramsToStore[36] = new SqlParameter("@DrugRemarks", SqlDbType.VarChar);
            paramsToStore[36].Value = DrugRemarks;

            paramsToStore[37] = new SqlParameter("@DataBaseStatus", SqlDbType.VarChar);
            paramsToStore[37].Value = DataBaseStatus;
            paramsToStore[38] = new SqlParameter("@DBRDate", SqlDbType.VarChar);
            paramsToStore[38].Value = (DBRDate == "" ? null : DBRDate);
            paramsToStore[39] = new SqlParameter("@DBCDate", SqlDbType.VarChar);
            paramsToStore[39].Value = (DBCDate == "" ? null : DBCDate);

            paramsToStore[40] = new SqlParameter("@DataBaseRemarks", SqlDbType.VarChar);
            paramsToStore[40].Value = DataBaseRemarks;



            paramsToStore[41] = new SqlParameter("@FinalColor", SqlDbType.VarChar);
            paramsToStore[41].Value = FinalColor;

            paramsToStore[42] = new SqlParameter("@StatusEmploymenthr6", SqlDbType.VarChar);
            paramsToStore[42].Value = StatusEmploymenthr6;


            paramsToStore[43] = new SqlParameter("@EmploymentRemarkshr6", SqlDbType.VarChar);
            paramsToStore[43].Value = EmploymentRemarkshr6;


            paramsToStore[44] = new SqlParameter("@StatusEmploymenthr7", SqlDbType.VarChar);
            paramsToStore[44].Value = StatusEmploymenthr7;


            paramsToStore[45] = new SqlParameter("@EmploymentRemarkshr7", SqlDbType.VarChar);
            paramsToStore[45].Value = EmploymentRemarkshr7;

            paramsToStore[46] = new SqlParameter("@StatusEmploymenthr8", SqlDbType.VarChar);
            paramsToStore[46].Value = StatusEmploymenthr8;


            paramsToStore[47] = new SqlParameter("@EmploymentRemarkshr8", SqlDbType.VarChar);
            paramsToStore[47].Value = EmploymentRemarkshr8;

            //---------------------------------------------------------------Add Others


            //Address2Status,Address2Remarks,
            //Address2RDate,Address2CDate
            //Address3Status,Address3Remarks
            //Address4Status,Address4Remarks
            //Address5Status,Address5Remarks
            //Address6Status,Address6Remarks
            //Address7Status,Address7Remarks
            //Address8Status,Address8Remarks


            //IdentityStatus,IdentityRemarks,
            //IdentityRDate,IdentityCDate


            paramsToStore[48] = new SqlParameter("@Address2Status", SqlDbType.VarChar);
            paramsToStore[48].Value = Address2Status;



            paramsToStore[49] = new SqlParameter("@Address2Remarks", SqlDbType.VarChar);
            paramsToStore[49].Value = Address2Remarks;


            paramsToStore[50] = new SqlParameter("@Address3Status", SqlDbType.VarChar);
            paramsToStore[50].Value = Address3Status;


            paramsToStore[51] = new SqlParameter("@Address3Remarks", SqlDbType.VarChar);
            paramsToStore[51].Value = Address3Remarks;


            paramsToStore[52] = new SqlParameter("@Address4Status", SqlDbType.VarChar);
            paramsToStore[52].Value = Address4Status;


            paramsToStore[53] = new SqlParameter("@Address4Remarks", SqlDbType.VarChar);
            paramsToStore[53].Value = Address4Remarks;


            paramsToStore[54] = new SqlParameter("@Address5Status", SqlDbType.VarChar);
            paramsToStore[54].Value = Address5Status;


            paramsToStore[55] = new SqlParameter("@Address5Remarks", SqlDbType.VarChar);
            paramsToStore[55].Value = Address5Remarks;


            paramsToStore[56] = new SqlParameter("@Address6Status", SqlDbType.VarChar);
            paramsToStore[56].Value = Address6Status;


            paramsToStore[57] = new SqlParameter("@Address6Remarks", SqlDbType.VarChar);
            paramsToStore[57].Value = Address6Remarks;


            paramsToStore[58] = new SqlParameter("@Address7Status", SqlDbType.VarChar);
            paramsToStore[58].Value = Address7Status;


            paramsToStore[59] = new SqlParameter("@Address7Remarks", SqlDbType.VarChar);
            paramsToStore[59].Value = Address7Remarks;


            paramsToStore[60] = new SqlParameter("@Address8Status", SqlDbType.VarChar);
            paramsToStore[60].Value = Address8Status;


            paramsToStore[61] = new SqlParameter("@Address8Remarks", SqlDbType.VarChar);
            paramsToStore[61].Value = Address8Remarks;
            //////////Address end


            //Education5Status,Education5Remarks,

            //Education6Status,Education6Remarks,

            //Education7Status,Education7Remarks,
            //Education8Status,Education8Remarks

            paramsToStore[62] = new SqlParameter("@Education5Status", SqlDbType.VarChar);
            paramsToStore[62].Value = Education5Status;


            paramsToStore[63] = new SqlParameter("@Education5Remarks", SqlDbType.VarChar);
            paramsToStore[63].Value = Education5Remarks;


            paramsToStore[64] = new SqlParameter("@Education6Status", SqlDbType.VarChar);
            paramsToStore[64].Value = Education6Status;


            paramsToStore[65] = new SqlParameter("@Education6Remarks", SqlDbType.VarChar);
            paramsToStore[65].Value = Education6Remarks;


            paramsToStore[66] = new SqlParameter("@Education7Status", SqlDbType.VarChar);
            paramsToStore[66].Value = Education7Status;

            paramsToStore[67] = new SqlParameter("@Education7Remarks", SqlDbType.VarChar);
            paramsToStore[67].Value = Education7Remarks;


            paramsToStore[68] = new SqlParameter("@Education8Status", SqlDbType.VarChar);
            paramsToStore[68].Value = Education8Status;

            paramsToStore[69] = new SqlParameter("@Education8Remarks", SqlDbType.VarChar);
            paramsToStore[69].Value = Education8Remarks;

            // Educationend

            //Criminal Check/////////////

            paramsToStore[70] = new SqlParameter("@Criminal2Status", SqlDbType.VarChar);
            paramsToStore[70].Value = Criminal2Status;



            paramsToStore[71] = new SqlParameter("@Criminal2Remarks", SqlDbType.VarChar);
            paramsToStore[71].Value = Criminal2Remarks;


            paramsToStore[72] = new SqlParameter("@Criminal3Status", SqlDbType.VarChar);
            paramsToStore[72].Value = Criminal3Status;


            paramsToStore[73] = new SqlParameter("@Criminal3Remarks", SqlDbType.VarChar);
            paramsToStore[73].Value = Criminal3Remarks;


            paramsToStore[74] = new SqlParameter("@Criminal4Status", SqlDbType.VarChar);
            paramsToStore[74].Value = Criminal4Status;


            paramsToStore[75] = new SqlParameter("@Criminal4Remarks", SqlDbType.VarChar);
            paramsToStore[75].Value = Criminal4Remarks;


            paramsToStore[76] = new SqlParameter("@Criminal5Status", SqlDbType.VarChar);
            paramsToStore[76].Value = Criminal5Status;


            paramsToStore[77] = new SqlParameter("@Criminal5Remarks", SqlDbType.VarChar);
            paramsToStore[77].Value = Criminal5Remarks;


            paramsToStore[78] = new SqlParameter("@Criminal6Status", SqlDbType.VarChar);
            paramsToStore[78].Value = Criminal6Status;


            paramsToStore[79] = new SqlParameter("@Criminal6Remarks", SqlDbType.VarChar);
            paramsToStore[79].Value = Criminal6Remarks;


            paramsToStore[80] = new SqlParameter("@Criminal7Status", SqlDbType.VarChar);
            paramsToStore[80].Value = Criminal7Status;


            paramsToStore[81] = new SqlParameter("@Criminal7Remarks", SqlDbType.VarChar);
            paramsToStore[81].Value = Criminal7Remarks;


            paramsToStore[82] = new SqlParameter("@Criminal8Status", SqlDbType.VarChar);
            paramsToStore[82].Value = Criminal8Status;


            paramsToStore[83] = new SqlParameter("@Criminal8Remarks", SqlDbType.VarChar);
            paramsToStore[83].Value = Criminal8Remarks;

            //Criminal2RDate,Criminal2CDate


            paramsToStore[84] = new SqlParameter("@Criminal2RDate", SqlDbType.VarChar);
            paramsToStore[84].Value = Criminal2RDate;


            paramsToStore[85] = new SqlParameter("@Criminal2CDate", SqlDbType.VarChar);
            paramsToStore[85].Value = Criminal2CDate;



            //IdentityStatus,IdentityRemarks,
            //IdentityRDate,IdentityCDate

            paramsToStore[86] = new SqlParameter("@IdentityStatus", SqlDbType.VarChar);
            paramsToStore[86].Value = IdentityStatus;

            paramsToStore[87] = new SqlParameter("@IdentityRemarks", SqlDbType.VarChar);
            paramsToStore[87].Value = IdentityRemarks;


            paramsToStore[88] = new SqlParameter("@IdentityRDate", SqlDbType.VarChar);
            paramsToStore[88].Value = IdentityRDate;

            paramsToStore[89] = new SqlParameter("@IdentityCDate", SqlDbType.VarChar);
            paramsToStore[89].Value = IdentityCDate;



            paramsToStore[90] = new SqlParameter("@Address2RDate", SqlDbType.VarChar);
            paramsToStore[90].Value = Address2RDate;


            paramsToStore[91] = new SqlParameter("@Address2CDate", SqlDbType.VarChar);
            paramsToStore[91].Value = Address2CDate;

            paramsToStore[92] = new SqlParameter("@Edu2RDate", SqlDbType.VarChar);
            paramsToStore[92].Value = Edu2RDate;

            paramsToStore[93] = new SqlParameter("@Edu2CDate", SqlDbType.VarChar);
            paramsToStore[93].Value = Edu2CDate;
            //Reference Check
            paramsToStore[94] = new SqlParameter("@ddlRef1", SqlDbType.VarChar);
            paramsToStore[94].Value = ddlRef1;

            paramsToStore[95] = new SqlParameter("@RemRef1", SqlDbType.VarChar);
            paramsToStore[95].Value = RemRef1;

            paramsToStore[96] = new SqlParameter("@ddlRef2", SqlDbType.VarChar);
            paramsToStore[96].Value = ddlRef2;

            paramsToStore[97] = new SqlParameter("@RemRef2", SqlDbType.VarChar);
            paramsToStore[97].Value = RemRef2;

            paramsToStore[98] = new SqlParameter("@ddlRef3", SqlDbType.VarChar);
            paramsToStore[98].Value = ddlRef3;

            paramsToStore[99] = new SqlParameter("@RemRef3", SqlDbType.VarChar);
            paramsToStore[99].Value = RemRef3;

            paramsToStore[100] = new SqlParameter("@Ref1RDate", SqlDbType.VarChar);
            paramsToStore[100].Value = Ref1RDate;

            paramsToStore[101] = new SqlParameter("@Ref1CDate", SqlDbType.VarChar);
            paramsToStore[101].Value = Ref1CDate;



            // string ddlRef1, string RemRef1,
            //string ddlRef2, string RemRef2,
            //string ddlRef3, string RemRef3,
            //string Ref1RDate, string Ref1CDate






            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_Update_Status_Remarks", paramsToStore));
        }

        public int usp_Update_COE_Applicable(string empId, string StatusAddress, string StatusEducation, string Education2Status, string Education3Status, string Education4Status, string StatusEmploymenthr1, string StatusEmploymentSup1, string StatusEmploymenthr2, string StatusEmploymentSup2, string StatusEmploymenthr3, string StatusEmploymentSup3, string StatusEmploymenthr4, string StatusEmploymentSup4, string StatusEmploymenthr5, string StatusEmploymentSup5, string StatusCriminal, string StatusDrug, string DataBaseStatus, string FinalColor, string Insufficiency, string InsufficiencyRaiseDate, string InsufficiencyCloseDate)
        {
            int i;
            SqlParameter[] paramsToStore = new SqlParameter[23];

            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@StatusAddress", SqlDbType.VarChar);
            paramsToStore[1].Value = StatusAddress;

            paramsToStore[2] = new SqlParameter("@StatusEducation", SqlDbType.VarChar);
            paramsToStore[2].Value = StatusEducation;

            paramsToStore[3] = new SqlParameter("@Education2Status", SqlDbType.VarChar);
            paramsToStore[3].Value = Education2Status;


            paramsToStore[4] = new SqlParameter("@Education3Status", SqlDbType.VarChar);
            paramsToStore[4].Value = Education3Status;

            paramsToStore[5] = new SqlParameter("@Education4Status", SqlDbType.VarChar);
            paramsToStore[5].Value = Education4Status;

            paramsToStore[6] = new SqlParameter("@StatusEmploymenthr1", SqlDbType.VarChar);
            paramsToStore[6].Value = StatusEmploymenthr1;

            paramsToStore[7] = new SqlParameter("@StatusEmploymentSup1", SqlDbType.VarChar);
            paramsToStore[7].Value = StatusEmploymentSup1;



            paramsToStore[8] = new SqlParameter("@StatusEmploymenthr2", SqlDbType.VarChar);
            paramsToStore[8].Value = StatusEmploymenthr2;


            paramsToStore[9] = new SqlParameter("@StatusEmploymentSup2", SqlDbType.VarChar);
            paramsToStore[9].Value = StatusEmploymentSup2;




            paramsToStore[10] = new SqlParameter("@StatusEmploymenthr3", SqlDbType.VarChar);
            paramsToStore[10].Value = StatusEmploymenthr3;

            paramsToStore[11] = new SqlParameter("@StatusEmploymentSup3", SqlDbType.VarChar);
            paramsToStore[11].Value = StatusEmploymentSup3;

            paramsToStore[12] = new SqlParameter("@StatusEmploymenthr4", SqlDbType.VarChar);
            paramsToStore[12].Value = StatusEmploymenthr4;

            paramsToStore[13] = new SqlParameter("@StatusEmploymentSup4", SqlDbType.VarChar);
            paramsToStore[13].Value = StatusEmploymentSup4;

            paramsToStore[14] = new SqlParameter("@StatusEmploymenthr5", SqlDbType.VarChar);
            paramsToStore[14].Value = StatusEmploymenthr5;

            paramsToStore[15] = new SqlParameter("@StatusEmploymentSup5", SqlDbType.VarChar);
            paramsToStore[15].Value = StatusEmploymentSup5;


            paramsToStore[16] = new SqlParameter("@StatusCriminal", SqlDbType.VarChar);
            paramsToStore[16].Value = StatusCriminal;

            paramsToStore[17] = new SqlParameter("@StatusDrug", SqlDbType.VarChar);
            paramsToStore[17].Value = StatusDrug;

            paramsToStore[18] = new SqlParameter("@DataBaseStatus", SqlDbType.VarChar);
            paramsToStore[18].Value = DataBaseStatus;

            paramsToStore[19] = new SqlParameter("@FinalColor", SqlDbType.VarChar);
            paramsToStore[19].Value = FinalColor;
            paramsToStore[20] = new SqlParameter("@Insufficiency", SqlDbType.VarChar);
            paramsToStore[20].Value = Insufficiency;
            paramsToStore[21] = new SqlParameter("@InsufficiencyRaiseDate", SqlDbType.VarChar);
            paramsToStore[21].Value = InsufficiencyRaiseDate;
            paramsToStore[22] = new SqlParameter("@InsufficiencyCloseDate", SqlDbType.VarChar);
            paramsToStore[22].Value = InsufficiencyCloseDate;




            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_Update_COE_Applicable", paramsToStore));
        }
        public string finalRevertManager(string empId, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            paramsToStore[1] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalVeriHeadRevertToManager", paramsToStore));

        }

        public string finalPendingRevertManager(string empId, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            paramsToStore[1] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalPendingRevertToManager", paramsToStore));

        }

        public string RejectRevertCaller(string empId, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            paramsToStore[1] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "RejectVeriHeadRevertToCaller", paramsToStore));

        }

        public string RejectInsuffToCaller(string eduId, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EduID", SqlDbType.VarChar);
            paramsToStore[0].Value = eduId;
            paramsToStore[1] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "RejectInsuffToCaller", paramsToStore));

        }

        public string InsuffClearToEdu(string empId, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            paramsToStore[1] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsuffClearToEdu", paramsToStore));

        }

        public string InsufficientStatus(string empId, string remarks, string client, string appName, string caller, string veriDate, string staffDate, string revertDate, string revertRemarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[9];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;

            paramsToStore[2] = new SqlParameter("@appName", SqlDbType.VarChar);
            paramsToStore[2].Value = appName;

            paramsToStore[3] = new SqlParameter("@caller", SqlDbType.VarChar);
            paramsToStore[3].Value = caller;

            paramsToStore[4] = new SqlParameter("@veriDate", SqlDbType.VarChar);
            paramsToStore[4].Value = veriDate;

            paramsToStore[5] = new SqlParameter("@staffDate", SqlDbType.VarChar);
            paramsToStore[5].Value = staffDate;

            paramsToStore[6] = new SqlParameter("@revertDate", SqlDbType.VarChar);
            paramsToStore[6].Value = revertDate;

            paramsToStore[7] = new SqlParameter("@revertRemarks", SqlDbType.VarChar);
            paramsToStore[7].Value = revertRemarks;

            paramsToStore[8] = new SqlParameter("@client", SqlDbType.VarChar);
            paramsToStore[8].Value = client;

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsufficientStatus", paramsToStore));

        }

        public string EmpRevert(string empId, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            paramsToStore[1] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empRevertToManager", paramsToStore));

        }

        public string NotUpdateEmpRevert(string empId, string username, string refid)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[3];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@username", SqlDbType.VarChar);
            paramsToStore[1].Value = username;

            paramsToStore[2] = new SqlParameter("@refid", SqlDbType.VarChar);
            paramsToStore[2].Value = refid;

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "NotUpdateEmpRevert", paramsToStore));

        }

        public string NotUpdateEduRevert(string eduId, string username, string refid)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[3];
            paramsToStore[0] = new SqlParameter("@EduID", SqlDbType.VarChar);
            paramsToStore[0].Value = eduId;

            paramsToStore[1] = new SqlParameter("@username", SqlDbType.VarChar);
            paramsToStore[1].Value = username;

            paramsToStore[2] = new SqlParameter("@refid", SqlDbType.VarChar);
            paramsToStore[2].Value = refid;

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "NotUpdateEduRevert", paramsToStore));

        }

        public string RejectEduRevert(string eduId, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EduID", SqlDbType.VarChar);
            paramsToStore[0].Value = eduId;

            paramsToStore[1] = new SqlParameter("@remark", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "RejectEduRevert", paramsToStore));

        }

        public string RejectEmpRevert(string empId, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@remark", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "RejectEmpRevert", paramsToStore));

        }


        public string EmpInsuffSend(string empId, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            paramsToStore[1] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empInsuffToManager", paramsToStore));

        }

        public string EmpReject(string empId, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            paramsToStore[1] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empRejectToCaller", paramsToStore));

        }

        public string EduSTOP(string eduId, string empId, string user, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[4];
            paramsToStore[0] = new SqlParameter("@EduID", SqlDbType.VarChar);
            paramsToStore[0].Value = eduId;

            paramsToStore[1] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[1].Value = empId;

            paramsToStore[2] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[2].Value = remarks;

            paramsToStore[3] = new SqlParameter("@user", SqlDbType.VarChar);
            paramsToStore[3].Value = user;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "EduSTOPCase", paramsToStore));

        }

        public string ReInitiateCheck(string vId, string EmpId, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[3];
            paramsToStore[0] = new SqlParameter("@VerID", SqlDbType.VarChar);
            paramsToStore[0].Value = vId;
            paramsToStore[1] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;
            paramsToStore[2] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[2].Value = EmpId;

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ReInitiateCheck", paramsToStore));

        }

        public string InsuffAddressAllocation(string addId)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[1];
            paramsToStore[0] = new SqlParameter("@AddID", SqlDbType.VarChar);
            paramsToStore[0].Value = addId;


            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "insuff_add_Allocation", paramsToStore));
        }
        public string InsuffClearToAdd(string addId, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@AddID", SqlDbType.VarChar);
            paramsToStore[0].Value = addId;
            paramsToStore[1] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsuffClearToAdd", paramsToStore));

        }

        public string InsuffAddUpdate(string addId, string refid, string check, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[4];
            paramsToStore[0] = new SqlParameter("@AddID", SqlDbType.VarChar);
            paramsToStore[0].Value = addId;
            paramsToStore[1] = new SqlParameter("@refid", SqlDbType.VarChar);
            paramsToStore[1].Value = refid;
            paramsToStore[2] = new SqlParameter("@checks", SqlDbType.VarChar);
            paramsToStore[2].Value = check;
            paramsToStore[3] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[3].Value = remarks;

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsuffAddUpdate", paramsToStore));

        }




        public string ReportsendtoExport(string RefID, string client, string candidate, string chkError, string MajorError, string RptStatus, string color, string remarks, string user)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[9];
            paramsToStore[0] = new SqlParameter("@RefID", SqlDbType.VarChar);
            paramsToStore[0].Value = RefID;

            paramsToStore[1] = new SqlParameter("@client", SqlDbType.VarChar);
            paramsToStore[1].Value = client;

            paramsToStore[2] = new SqlParameter("@candidate", SqlDbType.VarChar);
            paramsToStore[2].Value = candidate;

            paramsToStore[3] = new SqlParameter("@chkError", SqlDbType.VarChar);
            paramsToStore[3].Value = chkError;

            paramsToStore[4] = new SqlParameter("@majorError", SqlDbType.VarChar);
            paramsToStore[4].Value = MajorError;

            paramsToStore[5] = new SqlParameter("@RptStatus", SqlDbType.VarChar);
            paramsToStore[5].Value = RptStatus;

            paramsToStore[6] = new SqlParameter("@color", SqlDbType.VarChar);
            paramsToStore[6].Value = color;

            paramsToStore[7] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[7].Value = remarks;

            paramsToStore[8] = new SqlParameter("@user", SqlDbType.VarChar);
            paramsToStore[8].Value = user;

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ReportsendtoExport", paramsToStore));

        }

        public string RejectByQuality(string empId, string user, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[3];

            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[1].Value = remarks;

            paramsToStore[2] = new SqlParameter("@user", SqlDbType.VarChar);
            paramsToStore[2].Value = user;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "RejectByQuality", paramsToStore));

        }



        public string InsuffClearCheckByOp(string empId, string verid, string level, string check, string username)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[5];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@VerID", SqlDbType.VarChar);
            paramsToStore[1].Value = verid;

            paramsToStore[2] = new SqlParameter("@level", SqlDbType.VarChar);
            paramsToStore[2].Value = level;

            paramsToStore[3] = new SqlParameter("@checks", SqlDbType.VarChar);
            paramsToStore[3].Value = check;

            paramsToStore[4] = new SqlParameter("@username", SqlDbType.VarChar);
            paramsToStore[4].Value = username;

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Insuff_Clear_Check_By_Op", paramsToStore));

        }
        // Drug DB Allocation

        public string DrugDBUpdate(string empId, string Check, string Detail, string Staff)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[4];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@Check", SqlDbType.VarChar);
            paramsToStore[1].Value = Check;

            paramsToStore[2] = new SqlParameter("@Staff", SqlDbType.VarChar);
            paramsToStore[2].Value = Staff;

            paramsToStore[3] = new SqlParameter("@Detail", SqlDbType.VarChar);
            paramsToStore[3].Value = Detail;




            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DrugDB_Alloc", paramsToStore));

        }

        public string DrugDBUpdateNew(string empId, string Check, string Detail, string Staff)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[4];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@Check", SqlDbType.VarChar);
            paramsToStore[1].Value = Check;

            paramsToStore[2] = new SqlParameter("@Staff", SqlDbType.VarChar);
            paramsToStore[2].Value = Staff;

            paramsToStore[3] = new SqlParameter("@Detail", SqlDbType.VarChar);
            paramsToStore[3].Value = Detail;


            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DrugDB_ReAlloc", paramsToStore));

        }
        public string NotUpdateDrugRevert(string VerId, string username, string refid)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[3];
            paramsToStore[0] = new SqlParameter("@VerId", SqlDbType.VarChar);
            paramsToStore[0].Value = VerId;

            paramsToStore[1] = new SqlParameter("@username", SqlDbType.VarChar);
            paramsToStore[1].Value = username;

            paramsToStore[2] = new SqlParameter("@refid", SqlDbType.VarChar);
            paramsToStore[2].Value = refid;

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "NotUpdateDrugRevert", paramsToStore));

        }
        public string OfferDrop(string candidateid, string username, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[3];
            paramsToStore[0] = new SqlParameter("@candidateid", SqlDbType.VarChar);
            paramsToStore[0].Value = candidateid;

            paramsToStore[1] = new SqlParameter("@username", SqlDbType.VarChar);
            paramsToStore[1].Value = username;

            paramsToStore[2] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[2].Value = remarks;

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OfferDrop", paramsToStore));

        }


        public string DrugSTOP(string verId, string empId, string user, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[4];
            paramsToStore[0] = new SqlParameter("@VerID", SqlDbType.VarChar);
            paramsToStore[0].Value = verId;

            paramsToStore[1] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[1].Value = empId;

            paramsToStore[2] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[2].Value = remarks;

            paramsToStore[3] = new SqlParameter("@user", SqlDbType.VarChar);
            paramsToStore[3].Value = user;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DrugSTOPCase", paramsToStore));

        }

        public string setPrice(string empId)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[1];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = empId;
            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "setPrice", paramsToStore));

        }




        public string RPTAlloc(string empId, string candidate, string allocStaff)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[3];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.Int);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@candidate", SqlDbType.VarChar);
            paramsToStore[1].Value = candidate;

            paramsToStore[2] = new SqlParameter("@allocStaff", SqlDbType.Int);
            paramsToStore[2].Value = allocStaff;


            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "RPTAlloc", paramsToStore));

        }

        public string RPT_Re_Alloc(string empId, string allocStaff)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];
            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.Int);
            paramsToStore[0].Value = empId;

            paramsToStore[1] = new SqlParameter("@allocStaff", SqlDbType.Int);
            paramsToStore[1].Value = allocStaff;


            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "RPT_Re_Alloc", paramsToStore));

        }

        public string HOLDReport(String RptRemark, string EmpID)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];

            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = EmpID;

            paramsToStore[1] = new SqlParameter("@HOLDRemark", SqlDbType.VarChar);
            paramsToStore[1].Value = RptRemark;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "HOLDReport", paramsToStore));

        }
        public string ReportRelease(string RefId, string ReleaseBy)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];

            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = RefId;

            paramsToStore[1] = new SqlParameter("@releaseby", SqlDbType.VarChar);
            paramsToStore[1].Value = ReleaseBy;

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ReportRelease", paramsToStore));

        }
        public string ChangeBillingMonth(string RefId)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[1];

            paramsToStore[0] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[0].Value = RefId;

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ChangeBillingMonth", paramsToStore));

        }

        public string BillUpdate(string refid, string payment, string remark)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[3];
            paramsToStore[0] = new SqlParameter("@refid", SqlDbType.VarChar);
            paramsToStore[0].Value = refid;

            paramsToStore[1] = new SqlParameter("@payment", SqlDbType.VarChar);
            paramsToStore[1].Value = remark;

            paramsToStore[2] = new SqlParameter("@billingremark", SqlDbType.VarChar);
            paramsToStore[2].Value = payment;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "updatebill", paramsToStore));

        }


        public string InsuffSTOP(string verId, string empId, string user, string lvl, string checks, string remarks)
        {
            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[6];
            paramsToStore[0] = new SqlParameter("@VerID", SqlDbType.VarChar);
            paramsToStore[0].Value = verId;

            paramsToStore[1] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[1].Value = empId;

            paramsToStore[2] = new SqlParameter("@remarks", SqlDbType.VarChar);
            paramsToStore[2].Value = remarks;

            paramsToStore[3] = new SqlParameter("@user", SqlDbType.VarChar);
            paramsToStore[3].Value = user;

            paramsToStore[4] = new SqlParameter("@lvl", SqlDbType.VarChar);
            paramsToStore[4].Value = lvl;

            paramsToStore[5] = new SqlParameter("@checks", SqlDbType.VarChar);
            paramsToStore[5].Value = checks;
            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsuffSTOP", paramsToStore));

        }

    }
}
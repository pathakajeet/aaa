using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DataAccess;


namespace classgen1
{
    /// <summary>
    /// Summary description for classgen
    /// </summary>
    public class classgen
    {
        public classgen()
        {

        }

        public DataSet fillReportData(string str, string Session)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "fillReport",
                SQLDataAccess.CreateParameter("@Str", SqlDbType.VarChar, str, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Session", SqlDbType.VarChar, Session, ParameterDirection.Input, 20, false)

                );
            return dr;

        }

        public DataSet fillAddressTrackData(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AddressTracker",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }
        public DataSet AddressHeadDEO()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AddressHeadDEO");
            return dr;

        }

        public DataSet AddressHeadAllocDEO()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AddressHeadAllocDEO");
            return dr;

        }

        public DataSet Addclosebystaff(int addid1, string revertdate, string written, string complete, string remark, string Respondent, string Relation, string ContactNo, string Duration, string ResidenceType, string verifier, string vericontact, string veridesignation, string reverttype, string amount)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsertAddStaffClose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@addid1", SqlDbType.Int, addid1, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@written", SqlDbType.VarChar, written, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@complete", SqlDbType.VarChar, complete, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@remark", SqlDbType.VarChar, remark, ParameterDirection.Input, 500, false),
                SQLDataAccess.CreateParameter("@Respondent", SqlDbType.VarChar, Respondent, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Relation", SqlDbType.VarChar, Relation, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ContactNo", SqlDbType.VarChar, ContactNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Duration", SqlDbType.VarChar, Duration, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ResidenceType", SqlDbType.VarChar, ResidenceType, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verifier", SqlDbType.VarChar, verifier, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@vericontact", SqlDbType.VarChar, vericontact, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@veridesignation", SqlDbType.VarChar, veridesignation, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@reverttype", SqlDbType.VarChar, reverttype, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@amount", SqlDbType.VarChar, amount, ParameterDirection.Input, 50, false)
                 );
            return dr;

        }
        public DataSet pendingADDbystaff(int addid, string revertdate, string written, string pending, string remark)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "pendingADDstaffdata",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@addid", SqlDbType.Int, addid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@written", SqlDbType.VarChar, written, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@pending", SqlDbType.VarChar, pending, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@remark", SqlDbType.VarChar, remark, ParameterDirection.Input, 450, false)



              );
            return dr;

        }

        public DataSet insertADDremark(int RefID, string revertdate, string remark, string username)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsertADDRemark",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                //SQLDataAccess.CreateParameter("@eduid", SqlDbType.Int, eduid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@RefID", SqlDbType.Int, RefID, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@remark", SqlDbType.VarChar, remark, ParameterDirection.Input, 450, false),
                SQLDataAccess.CreateParameter("@username", SqlDbType.VarChar, username, ParameterDirection.Input, 450, false)
              );
            return dr;

        }

        public DataSet InsufficientADDbystaff(int addid, string revertdate, string written, string Insufficient, string remark)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsufficientAddStaff",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@addid", SqlDbType.Int, addid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@written", SqlDbType.VarChar, written, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Insufficient", SqlDbType.VarChar, Insufficient, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@remark", SqlDbType.VarChar, remark, ParameterDirection.Input, 450, false)



              );
            return dr;

        }

        public DataSet fillAddressStaff(string Staffname)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AddressStaffView",
                SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, Staffname, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet finaladdNew()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finaladdNew");
            return dr;

        }

       
        public DataSet UpdateAddClosure()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UpdateAddClosure");
            return dr;

        }
        public DataSet ExportCase()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ExportCase");
            return dr;

        }

        public DataSet finaladdInsuff()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finaladdInsuff");
            return dr;

        }

        public DataSet AddCriClosure()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AddCriClosure");
            return dr;

        }

        public DataSet AddCriClosed()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AddCriClosed");
            return dr;

        }

        public DataSet pendingaddremarkview(string addid)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "pendingaddremarkview",
                SQLDataAccess.CreateParameter("@addid", SqlDbType.VarChar, addid, ParameterDirection.Input, 50, false)

                );
            return dr;

        }

        public DataSet DashBoardSearchByCounter(string strCounter, string strClientName, string strdrpcheck, string strdrpsingle, string str)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DashBoardSearchByCounter",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

               //SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, StaffName, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@strCounter", SqlDbType.VarChar, strCounter, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@strClientName", SqlDbType.VarChar, strClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@strdrpcheck", SqlDbType.VarChar, strdrpcheck, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@strdrpsingle", SqlDbType.VarChar, strdrpsingle, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@str", SqlDbType.VarChar, str, ParameterDirection.Input, 50, false)




              );
            return dr;

        }


        public DataSet PrioritySet(string RefID, string Remark)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "PrioritySet",
                SQLDataAccess.CreateParameter("@RefID", SqlDbType.VarChar, RefID, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Remark", SqlDbType.VarChar, Remark, ParameterDirection.Input, 50, false)

                );
            return dr;

        }
        //case closed
        public DataSet fillcloseTrackData(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_selectManager_Status_onselect",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }
        //case closed on screen
        public DataSet fillcloseTrackData_cc(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_selectManager_Status_onselect_cc",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        public DataSet CounterDashBoardCall(string str)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "CounterDashboardCall",
                SQLDataAccess.CreateParameter("@str", SqlDbType.VarChar, str, ParameterDirection.Input, 50, false)

                );
            return dr;
        }

      

        public DataSet CounterDashboardDelete()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "CounterDashboardDelete");
            return dr;

        }
        public DataSet CaseDashBoard()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "CaseDashBoardnew");
            return dr;

        }

        public DataSet pendingremarkview(string eduid)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "pendingremarkview",
                SQLDataAccess.CreateParameter("@eduid", SqlDbType.VarChar, eduid, ParameterDirection.Input, 50, false)

                );
            return dr;

        }
        public DataSet completeremarkview(string eduid)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "completeremarkview",
                SQLDataAccess.CreateParameter("@eduid", SqlDbType.VarChar, eduid, ParameterDirection.Input, 50, false)

                );
            return dr;

        }

        public DataSet EDCview(string eduid)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "EDCview",
                SQLDataAccess.CreateParameter("@eduid", SqlDbType.VarChar, eduid, ParameterDirection.Input, 50, false)

                );
            return dr;

        }

        public DataSet empEDCview(string cmpid)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empEDCview",
                SQLDataAccess.CreateParameter("@empid", SqlDbType.VarChar, cmpid, ParameterDirection.Input, 50, false)

                );
            return dr;

        }


        public DataSet fillsearchAddressTrackData(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AddressTrackerSearch",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false)


              );
            return dr;

        }
        //allocated dig
        public DataSet DigData(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DigSearch",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false)


              );
            return dr;

        }







        //case closed
        public DataSet fillsearchTrackData(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_selectManager_Status_search",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        // for case closed screen
        public DataSet fillsearchTrackData_cc(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_selectManager_Status_search_cc",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false)


              );
            return dr;

        }
        public DataSet eduSearchID(string StaffName, string ClientRefNo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "eduSearchID",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

               SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, StaffName, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet eduSearchClient(string StaffName, string ClientName)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "eduSearchClient",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

               SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, StaffName, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet eduSearchApplicant(string StaffName, string AppName)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "eduSearchAppName",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

               SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, StaffName, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet eduSearchTAT(string StaffName, string TAT)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "eduSearchTAT",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

               SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, StaffName, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@TAT", SqlDbType.VarChar, TAT, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet eduSearchDate(string StaffName, string AllocDate)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "eduSearchDate",
                SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, StaffName, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AllocDate", SqlDbType.VarChar, AllocDate, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet eduSearchClientDate(string StaffName, string ClientName, string AllocDate)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "eduSearchClientDate",
                SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, StaffName, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@AllocDate", SqlDbType.VarChar, AllocDate, ParameterDirection.Input, 50, false)
                );
            return dr;

        }


        public DataSet SearchAppData(string AppName)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DDSearchAppData",

                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false)



              );
            return dr;

        }





        //SearchCriminalTracki


        public DataSet fillsearchAgencyTrack(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchAgencyTracker",
                // SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet SearchAgencyonCaseRec(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchAgencyTrackerCaseRec",
                // SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet fillMISonCaseRec(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchMISTrackerCaseRec",
                // SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet SearchEducationTrackeronCaseRec(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchEducationTrackerCaseRec",
                //SQLDataAccess.CreateParameter("@Education", SqlDbType.VarChar, Education, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet SearchEducationTrackeronTAT(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchEducationTrackerCaseTaT",
                // SQLDataAccess.CreateParameter("@Education", SqlDbType.VarChar, Education, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet SearchCriminalTrackerRec(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchCriminalTrackerRec",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet SearchCriminalTrackerTAT(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchCriminalTrackertat",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }


        public DataSet AddressTrackerSearchRec(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AddressTrackerSearchRec",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        //allocaed dig
        public DataSet DigSearchRec(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DigSearchRec",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet DigData(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Dig",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        // case closed
        public DataSet ccTrackerSearchRec(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_selectManager_Status_searchRec",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        //for close screen
        public DataSet ccTrackerSearchRec_cc(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_selectManager_Status_searchRec_cc",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }




        public DataSet AddressTrackerSearchTAT(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AddressTrackerSearchtat",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        //allocated dig
        public DataSet DigSearchTAT(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DigSearchtat",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }






        //case closed
        public DataSet ccTrackerSearchTAT(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_selectManager_Status_searchtat",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        // for case closed screen
        public DataSet ccTrackerSearchTAT_cc(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_selectManager_Status_searchtat_cc",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }






        public DataSet fillMISonCaseTAT(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchMISTrackerCaseTaT",
                // SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }



        public DataSet SearchAgencyonCaseTAT(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchAgencyTrackerCaseTAT",
                // SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false)


              );
            return dr;

        }



        public DataSet fillsearchMasterMIS(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchMISTracker",
                // SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet SearchCriminalTracker(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchCriminalTracker",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false)


              );
            return dr;

        }




        public DataSet fillCriminalTrackData(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "CriminalTracker",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        public DataSet SearchEducationTracker(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchEducationTracker",
                //SQLDataAccess.CreateParameter("@Education", SqlDbType.VarChar, Education, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false)


              );
            return dr;

        }




        public DataSet fillEducationTrackData(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "EducationTracker",
                //SQLDataAccess.CreateParameter("@EduList", SqlDbType.VarChar, EduList, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        public DataSet fillCaseNTATData(string ClientId, string DateFrom, string DateTo, string UserName)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "fillCASENTATReport",
                SQLDataAccess.CreateParameter("@ClientId", SqlDbType.VarChar, ClientId, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 20, false),
                 SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, UserName, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        public DataSet fillCaseNTATDataTAT(string ClientId, string TATFrom, string TATTo, string UserName)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "fillCASENTATReport_TAT",
                SQLDataAccess.CreateParameter("@ClientId", SqlDbType.VarChar, ClientId, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@TATFrom", SqlDbType.VarChar, TATFrom, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@TATTo", SqlDbType.VarChar, TATTo, ParameterDirection.Input, 20, false),
                 SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, UserName, ParameterDirection.Input, 20, false)

                );
            return dr;

        }

        public DataSet fillMasterMISData(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "MasterMISVPRoc",

                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }






        public DataSet fillReportALLData(string ClientId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "FillAllClientFormat",
                // SQLDataAccess.CreateParameter("@Str", SqlDbType.VarChar, str, ParameterDirection.Input, 20, false),
                //SQLDataAccess.CreateParameter("@Session", SqlDbType.VarChar, Session, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientId", SqlDbType.VarChar, ClientId, ParameterDirection.Input, 100, false)

                );
            return dr;

        }


        public DataSet fillAgencyTrackData(string ClientId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "FillAllClientFormat",
                // SQLDataAccess.CreateParameter("@Str", SqlDbType.VarChar, str, ParameterDirection.Input, 20, false),
                //SQLDataAccess.CreateParameter("@Session", SqlDbType.VarChar, Session, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientId", SqlDbType.VarChar, ClientId, ParameterDirection.Input, 100, false)

                );
            return dr;

        }







        public DataSet fillReport(string str)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "fillReport",
                SQLDataAccess.CreateParameter("@Str", SqlDbType.VarChar, str, ParameterDirection.Input, 20, false)

                );
            return dr;

        }

        public DataSet ShowCheckDetails(string str, string EmpId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "fillcheckdetails",
                SQLDataAccess.CreateParameter("@Check", SqlDbType.VarChar, str, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@EmpID", SqlDbType.VarChar, EmpId, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        public DataSet fillReportDEO()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_selectdeo");
            return dr;

        }
        public DataSet InsuffToNew()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsuffToNew");
            return dr;

        }
        public DataSet fillReportManager()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_selectManager_Status");
            return dr;

        }
        public DataSet fillManageronclient(string ClientName)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Status_closed_Client",
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet fillEducationStaff(string Staffname)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "EduStaffView",
                SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, Staffname, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet InsuffEducationStaff(string Staffname)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsuffEduStaffView",
                SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, Staffname, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet fillEmploymentStaff(string Staffname)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "EmpStaffView",
                SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, Staffname, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet fillDD()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "fillDD");
            return dr;

        }

        public DataSet DDView(string eid)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DDView",
                SQLDataAccess.CreateParameter("@refid", SqlDbType.VarChar, eid, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet fillReportManagerClosed()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_selectManager_Status_Closed");
            return dr;

        }
        public DataSet fillReportClient()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "usp_selectClient");
            return dr;

        }
        public DataSet fillReportHiring()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "USP_FillRevertData");
            return dr;

        }
        //Allocation
        public DataSet allocfillReportManager()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocusp_selectManager_Status");
            return dr;

        }

        public DataSet allocfillManageronclient(string ClientName)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocStatus_closed_Client",
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 50, false)
                );
            return dr;

        }
        public DataSet allocfillReportClient()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocusp_selectClient");
            return dr;

        }
        public DataSet allocfillReportDEO()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocusp_selectdeo");
            return dr;

        }

        public DataSet insuffReportDEO()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "insuff_selectdeo");
            return dr;

        }
        public DataSet allocfillReport(string str)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocfillReport",
                SQLDataAccess.CreateParameter("@Str", SqlDbType.VarChar, str, ParameterDirection.Input, 20, false)

                );
            return dr;

        }
        public DataSet allocfillReportManagerClosed()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocusp_selectManager_Status_Closed");
            return dr;

        }

        public DataSet InsuffallocfillReportManager()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Insuff_alloc_selectManager");
            return dr;

        }
        public DataSet allocccTrackerSearchRec(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocusp_selectManager_Status_searchRec",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet allocccTrackerSearchTAT(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocusp_selectManager_Status_searchtat",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet allocfillsearchTrackData(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocusp_selectManager_Status_search",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false)


              );
            return dr;

        }
        public DataSet allocfillcloseTrackData(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocusp_selectManager_Status_onselect",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }
        public DataSet allocfillcloseTrackData_cc(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocusp_selectManager_Status_onselect_cc",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }
        public DataSet allocccTrackerSearchRec_cc(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocusp_selectManager_Status_searchRec_cc",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet allocccTrackerSearchTAT_cc(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocusp_selectManager_Status_searchtat_cc",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet allocfillsearchTrackData_cc(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocusp_selectManager_Status_search_cc",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false)


              );
            return dr;

        }
        public DataSet mailedititem(int empid)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "editdata",
              SQLDataAccess.CreateParameter("@empid", SqlDbType.VarChar, empid, ParameterDirection.Input, 20, false)

                );
            return dr;
        }

        //for verihead
        public DataSet veriheadReport(string str)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "veriheadfillReport",
                SQLDataAccess.CreateParameter("@Str", SqlDbType.VarChar, str, ParameterDirection.Input, 20, false)

                );
            return dr;

        }
        public DataSet veriheadRec(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo, string uni, string clg, string year)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_searchRec",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@uni", SqlDbType.VarChar, uni, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@clg", SqlDbType.VarChar, clg, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@year", SqlDbType.VarChar, year, ParameterDirection.Input, 50, false)


              );
            return dr;

        }
        public DataSet veriheadRecall(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_all_rec",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }


        public DataSet veriheadalloc(string Manager, string anila, string strClientId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_alloc",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                  SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, strClientId, ParameterDirection.Input, 20, false)
                );
            return dr;

        }

        public DataSet EMPheadalloc(string Manager, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "EMPhead_alloc",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)

                );
            return dr;

        }


        public DataSet veriheadall(string Manager, string anila, string Client)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_all",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                 SQLDataAccess.CreateParameter("@Client", SqlDbType.VarChar, Client, ParameterDirection.Input, 20, false)
              );
            return dr;

        }
        public DataSet veriheadunalloc(string Manager, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_unalloc",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)
              );
            return dr;

        }
        public DataSet veriheadTAT(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo, string uni, string clg, string year)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_searchtat",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@uni", SqlDbType.VarChar, uni, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@clg", SqlDbType.VarChar, clg, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@year", SqlDbType.VarChar, year, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet veriheadAVDATE(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string Avdate, string uni, string clg, string year)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_searchAV",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@Avdate", SqlDbType.VarChar, Avdate, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@uni", SqlDbType.VarChar, uni, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@clg", SqlDbType.VarChar, clg, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@year", SqlDbType.VarChar, year, ParameterDirection.Input, 50, false)




              );
            return dr;

        }
        public DataSet veriheadAVDATEall(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string Avdate)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_all_AV",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@Avdate", SqlDbType.VarChar, Avdate, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet veriheadTATall(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_all_tat",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet veriheadData(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string uni, string clg, string year)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_search",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@uni", SqlDbType.VarChar, uni, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@clg", SqlDbType.VarChar, clg, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@year", SqlDbType.VarChar, year, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet veriheadDataall(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_all_search",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false)


              );
            return dr;

        }
        public DataSet veriheadData_cc(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }
        public DataSet veriheadData_cc_alloc(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_alloc_Client",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }


        public DataSet DDClient(string ClientName)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DDClient",

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false)

                );
            return dr;

        }


        public DataSet DDCaller(string Caller)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DDCaller",

                SQLDataAccess.CreateParameter("@CallerName", SqlDbType.VarChar, Caller, ParameterDirection.Input, 100, false)

                );
            return dr;

        }

        public DataSet DDSearchName(string Name)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DDSearchName",

                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, Name, ParameterDirection.Input, 100, false)

                );
            return dr;

        }



        public DataSet veriheadDEO()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_selectdeo");
            return dr;

        }

        public DataSet empHeadDEO()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "emphead_selectdeo");
            return dr;

        }

        //from education staff
        public DataSet closebystaff(int eduid, string revertdate, string written, string complete, string verFrom, string colgName, string verName, string verDesig, string contact, string posRemark, string staffRemarks, string roll)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsertEduStaffClose",

                SQLDataAccess.CreateParameter("@eduid", SqlDbType.Int, eduid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@written", SqlDbType.VarChar, written, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@complete", SqlDbType.VarChar, complete, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verFrom", SqlDbType.VarChar, verFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@colgName", SqlDbType.VarChar, colgName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verName", SqlDbType.VarChar, verName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verDesig", SqlDbType.VarChar, verDesig, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@contact", SqlDbType.VarChar, contact, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@posRemark", SqlDbType.VarChar, posRemark, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staffRemarks", SqlDbType.VarChar, staffRemarks, ParameterDirection.Input, 500, false),
                SQLDataAccess.CreateParameter("@veriRoll", SqlDbType.VarChar, roll, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet closebystaffVTW(int eduid, string revertdate, string written, string complete, string verFrom, string colgName, string verName, string verDesig, string contact, string posRemark, string staffRemarks, string roll, string caller)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsertEduStaffCloseVTW",

                SQLDataAccess.CreateParameter("@eduid", SqlDbType.Int, eduid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@written", SqlDbType.VarChar, written, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@complete", SqlDbType.VarChar, complete, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verFrom", SqlDbType.VarChar, verFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@colgName", SqlDbType.VarChar, colgName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verName", SqlDbType.VarChar, verName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verDesig", SqlDbType.VarChar, verDesig, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@contact", SqlDbType.VarChar, contact, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@posRemark", SqlDbType.VarChar, posRemark, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staffRemarks", SqlDbType.VarChar, staffRemarks, ParameterDirection.Input, 500, false),
                SQLDataAccess.CreateParameter("@veriRoll", SqlDbType.VarChar, roll, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@caller", SqlDbType.VarChar, caller, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet verbalclosewrittenpending(int eduid, string revertdate, string written, string complete, string verFrom, string colgName, string verName, string verDesig, string contact, string posRemark)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verbalclosewrittenpending",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@eduid", SqlDbType.Int, eduid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@written", SqlDbType.VarChar, written, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@complete", SqlDbType.VarChar, complete, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verFrom", SqlDbType.VarChar, verFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@colgName", SqlDbType.VarChar, colgName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verName", SqlDbType.VarChar, verName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verDesig", SqlDbType.VarChar, verDesig, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@contact", SqlDbType.VarChar, contact, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@posRemark", SqlDbType.VarChar, posRemark, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet pendingbystaff(int eduid, string revertdate, string written, string pending, string remark)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "pendingstaffdata",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@eduid", SqlDbType.Int, eduid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@written", SqlDbType.VarChar, written, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@pending", SqlDbType.VarChar, pending, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@remark", SqlDbType.VarChar, remark, ParameterDirection.Input, 450, false)



              );
            return dr;

        }

        public DataSet Insufficientbystaff(int eduid, string revertdate, string written, string Insufficient, string remark)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsufficientEduStaff",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@eduid", SqlDbType.Int, eduid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@written", SqlDbType.VarChar, written, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Insufficient", SqlDbType.VarChar, Insufficient, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@remark", SqlDbType.VarChar, remark, ParameterDirection.Input, 450, false)



              );
            return dr;

        }

        public DataSet finalTATpending(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalTATpending",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalTATNew(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalTATNew",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalTATInsufficient(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalTATInsufficient",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalTATInsuffClose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalTATInsuffClose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalalloctostaffpending(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctostaffpending",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalalloctostaffNew(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctostaffNew",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalalloctostaffInsufficient(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctostaffInsufficient",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalalloctostaffInsuffClose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctostaffInsuffClose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalTATStaffNew(string Manager, string ClientName, string TAT)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalTATStaffNew",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@TAT", SqlDbType.VarChar, TAT, ParameterDirection.Input, 50, false)



              );
            return dr;

        }



        public DataSet finalclosebystaffpending(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalclosebystaffpending",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet finalclosebystaffInsufficient(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalclosebystaffInsufficient",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet finalclosebystaffInsuffClose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalclosebystaffInsuffClose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet finalDatapending(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finaldatapending",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalDataNew(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finaldataNew",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalDataInsufficient(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finaldataInsufficient",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalDataInsuffClose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff, string closedate)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finaldataInsuffClose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@closedate", SqlDbType.VarChar, closedate, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalclientpending(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalclientpending",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }
        public DataSet finalclientInsufficient(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalclientInfficient",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        public DataSet finalclientInsuffClose(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalclientInsuffClose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        public DataSet finalclientNew(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalclientNew",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }


        public DataSet finalstaffpending(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalstaffpending",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }
        public DataSet finalstaffNew(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalstaffNew",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }
        public DataSet finalstaffInsufficient(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalstaffInsufficient",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        public DataSet finalstaffInsuffClose(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalstaffInsuffClose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        public DataSet writtenpendingfNew(string Manager, string spclRemark, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "writtenpendingfNew",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@spclRemark", SqlDbType.VarChar, spclRemark, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }


        public DataSet finalclosepending()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalcasepending");
            return dr;

        }
        public DataSet finalcloseNew()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalcaseNew");
            return dr;

        }

        public DataSet PriceDashBoard()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "PriceDashBoard");
            return dr;

        }

        public DataSet PriceDashBoardUpdate(string refid, string Edu1, string Edu2, string Edu3, string Edu4, string Edu5, string Edu6, string Edu7, string Edu8,
            string Emp1, string Emp2, string Emp3, string Emp4, string Emp5, string Emp6, string Emp7, string Emp8,
            string Add1, string Add2, string Add3, string Add4, string Add5, string Add6, string Add7, string Add8,
            string Cri1, string Cri2, string Cri3, string Cri4, string Cri5, string Cri6, string Cri7, string Cri8,
            string Ref1, string Ref2, string Ref3,
            string Databasechk, string Drug5, string Drug9, string Drug10, string Drug5withAlcohol,
            string Identity1, string Identity2, string Identity3, string Identity4,
            string Cat1, string Cat2, string Cat3, string Cat4, string Reason, string user
            )
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "PriceDashBoardUpdate",
                SQLDataAccess.CreateParameter("@refid", SqlDbType.VarChar, refid, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Edu1", SqlDbType.VarChar, Edu1, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Edu2", SqlDbType.VarChar, Edu2, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Edu3", SqlDbType.VarChar, Edu3, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Edu4", SqlDbType.VarChar, Edu4, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Edu5", SqlDbType.VarChar, Edu5, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Edu6", SqlDbType.VarChar, Edu6, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Edu7", SqlDbType.VarChar, Edu7, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Edu8", SqlDbType.VarChar, Edu8, ParameterDirection.Input, 50, false),

                SQLDataAccess.CreateParameter("@Emp1", SqlDbType.VarChar, Emp1, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Emp2", SqlDbType.VarChar, Emp2, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Emp3", SqlDbType.VarChar, Emp3, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Emp4", SqlDbType.VarChar, Emp4, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Emp5", SqlDbType.VarChar, Emp5, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Emp6", SqlDbType.VarChar, Emp6, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Emp7", SqlDbType.VarChar, Emp7, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Emp8", SqlDbType.VarChar, Emp8, ParameterDirection.Input, 50, false),

                SQLDataAccess.CreateParameter("@Add1", SqlDbType.VarChar, Add1, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Add2", SqlDbType.VarChar, Add2, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Add3", SqlDbType.VarChar, Add3, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Add4", SqlDbType.VarChar, Add4, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Add5", SqlDbType.VarChar, Add5, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Add6", SqlDbType.VarChar, Add6, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Add7", SqlDbType.VarChar, Add7, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Add8", SqlDbType.VarChar, Add8, ParameterDirection.Input, 50, false),

                SQLDataAccess.CreateParameter("@Cri1", SqlDbType.VarChar, Cri1, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Cri2", SqlDbType.VarChar, Cri2, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Cri3", SqlDbType.VarChar, Cri3, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Cri4", SqlDbType.VarChar, Cri4, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Cri5", SqlDbType.VarChar, Cri5, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Cri6", SqlDbType.VarChar, Cri6, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Cri7", SqlDbType.VarChar, Cri7, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Cri8", SqlDbType.VarChar, Cri8, ParameterDirection.Input, 50, false),

                SQLDataAccess.CreateParameter("@Ref1", SqlDbType.VarChar, Ref1, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Ref2", SqlDbType.VarChar, Ref2, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Ref3", SqlDbType.VarChar, Ref3, ParameterDirection.Input, 50, false),

                  SQLDataAccess.CreateParameter("@Databasechk", SqlDbType.VarChar, Databasechk, ParameterDirection.Input, 50, false),
                   SQLDataAccess.CreateParameter("@Drug5", SqlDbType.VarChar, Drug5, ParameterDirection.Input, 50, false),
                    SQLDataAccess.CreateParameter("@Drug9", SqlDbType.VarChar, Drug9, ParameterDirection.Input, 50, false),
                     SQLDataAccess.CreateParameter("@Drug10", SqlDbType.VarChar, Drug10, ParameterDirection.Input, 50, false),

                      SQLDataAccess.CreateParameter("@Drug5withAlcohol", SqlDbType.VarChar, Drug5withAlcohol, ParameterDirection.Input, 50, false),
                  SQLDataAccess.CreateParameter("@Identity1", SqlDbType.VarChar, Identity1, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Identity2", SqlDbType.VarChar, Identity2, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Identity3", SqlDbType.VarChar, Identity3, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Identity4", SqlDbType.VarChar, Identity4, ParameterDirection.Input, 50, false),

                SQLDataAccess.CreateParameter("@Cat1", SqlDbType.VarChar, Cat1, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Cat2", SqlDbType.VarChar, Cat2, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@Cat3", SqlDbType.VarChar, Cat3, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Cat4", SqlDbType.VarChar, Cat4, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Reason", SqlDbType.VarChar, Reason, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@username", SqlDbType.VarChar, user, ParameterDirection.Input, 50, false)




                );
            return dr;

        }
        public DataSet finalcloseInsufficient()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalcaseInsufficient");
            return dr;

        }

        public DataSet finalManagerInsufficient()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalManagerInsufficient");
            return dr;

        }

        public DataSet TATNew(string Manager, string TAT, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "TATNew",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@TAT", SqlDbType.VarChar, TAT, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }




        public DataSet finalalloctoveripending(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctoveripending",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalalloctoveriNew(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctoveriNew",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalalloctoverinsuffclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctoverinsuffclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalalloctoveriInsufficient(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctoveriInsufficient",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalRemarkNew(string Manager, string spclRemark, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalRemarkNew",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@spclRemark", SqlDbType.VarChar, spclRemark, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        public DataSet insertremark(int RefID, string revertdate, string remark, string username)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsertRemark",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                //SQLDataAccess.CreateParameter("@eduid", SqlDbType.Int, eduid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@RefID", SqlDbType.Int, RefID, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@remark", SqlDbType.VarChar, remark, ParameterDirection.Input, 450, false),
                SQLDataAccess.CreateParameter("@username", SqlDbType.VarChar, username, ParameterDirection.Input, 450, false)
              );
            return dr;

        }

        public DataSet insertCloseRemark(int RefID, string verFrom, string colgName, string verName, string verDesig, string contact, string posRemark)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsertCloseRemark",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                //SQLDataAccess.CreateParameter("@eduid", SqlDbType.Int, eduid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@RefID", SqlDbType.Int, RefID, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@verFrom", SqlDbType.VarChar, verFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@colgName", SqlDbType.VarChar, colgName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verName", SqlDbType.VarChar, verName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verDesig", SqlDbType.VarChar, verDesig, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@contact", SqlDbType.VarChar, contact, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@posRemark", SqlDbType.VarChar, posRemark, ParameterDirection.Input, 50, false)

            );
            return dr;

        }


        public DataSet pending(int eduid, string revertdate, string written, string complete, string remark)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsertEduStaffClose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@eduid", SqlDbType.Int, eduid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@written", SqlDbType.VarChar, written, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@complete", SqlDbType.VarChar, complete, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@remark", SqlDbType.VarChar, remark, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        //final veri head
        public DataSet finalveriheadfill()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalVeriHead");
            return dr;

        }
        public DataSet finalveriheadfillReportClient()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalVeriHeadClient");
            return dr;

        }
        public DataSet finalVeriHeadInsufficient()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalVeriHeadInsufficient");
            return dr;

        }
        public DataSet finalmailedititem(int empid)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finaleditdata",
              SQLDataAccess.CreateParameter("@empid", SqlDbType.VarChar, empid, ParameterDirection.Input, 20, false)

                );
            return dr;
        }
        public DataSet finalalloctoveri(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctoveri",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalTAT(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalTAT",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalalloctostaff(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctostaff",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalclosebystaff(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalclosebystaff",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }
        public DataSet finalData(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finaldata",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalclient(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalclient",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }
        public DataSet finalclientclose(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalclientclose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        public DataSet OPclientclose(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OPclientclose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        public DataSet finalstaff(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalstaff",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        public DataSet finalstaffclose(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalstaffclose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }
        public DataSet verificationClosure()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verificationClosure");
            return dr;

        }

        public DataSet UpdateEducation()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UpdateEducation");
            return dr;

        }
        public DataSet OPstaffclose(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OPstaffclose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }
        public DataSet Opalloctovericlose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Opalloctovericlose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet OPTATclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OPTATclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet OPalloctostaffclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OPalloctostaffclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet OPclosebystaffclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OPclosebystaffclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet OPDataclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OPDataclose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalclosecases()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalcasecloses");
            return dr;

        }

        public DataSet finalalloctovericlose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctovericlose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalTATclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalTATclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalalloctostaffclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctostaffclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalclosebystaffclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalclosebystaffclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet UPOPstaffclose(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UPOPstaffclose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }
        public DataSet UPOPalloctovericlose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UPOPalloctovericlose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet UPOPTATclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UPOPTATclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet UPOPalloctostaffclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UPOPalloctostaffclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet UPOPclosebystaffclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UPOPclosebystaffclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet UPOPDataclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UPOPDataclose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet UPOPclientclose(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UPOPclientclose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }
        public DataSet EmploymentClosure()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "EmploymentClosure");
            return dr;

        }

        public DataSet UpdateEmpClosure()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UpdateEmpClosure");
            return dr;

        }
        public DataSet finalDataclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finaldataclose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }






        //on anil close by verification scren
        public DataSet VAfinalclosecases()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "VAfinalcasecloses");
            return dr;

        }
        public DataSet VAfinalclientclose(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "VAfinalclientclose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }
        public DataSet VAfinalalloctovericlose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "VAfinalalloctovericlose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet VAfinalTATclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "VAfinalTATclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet VAfinalalloctostaffclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "VAfinalalloctostaffclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet VAfinalstaffclose(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "VAfinalstaffclose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }
        public DataSet VAfinalDataclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "VAfinaldataclose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        //veriheadall
        public DataSet veriheadallocav(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff, string CaseID, string uni, string clg, string year)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_alloc_AV",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseID, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@uni", SqlDbType.VarChar, uni, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@clg", SqlDbType.VarChar, clg, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@year", SqlDbType.VarChar, year, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet veriheadallocrec(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo, string staff, string uni, string clg, string year)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_alloc_rec",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@uni", SqlDbType.VarChar, uni, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@clg", SqlDbType.VarChar, clg, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@year", SqlDbType.VarChar, year, ParameterDirection.Input, 50, false)





              );
            return dr;

        }
        public DataSet veriheadalloctat(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo, string staff, string uni, string clg, string year)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_alloc_tat",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@uni", SqlDbType.VarChar, uni, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@clg", SqlDbType.VarChar, clg, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@year", SqlDbType.VarChar, year, ParameterDirection.Input, 50, false)




              );
            return dr;

        }
        public DataSet veriheadallocsearch(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff, string caseid, string uni, string clg, string year)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "verihead_alloc_search",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, caseid, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@uni", SqlDbType.VarChar, uni, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@clg", SqlDbType.VarChar, clg, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@year", SqlDbType.VarChar, year, ParameterDirection.Input, 50, false)




              );
            return dr;

        }
        //employment tracker
        public DataSet emptrackerRec(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "emptrackerRec",
                //SQLDataAccess.CreateParameter("@Education", SqlDbType.VarChar, Education, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet emptrackerTAT(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "emptrackerTaT",
                // SQLDataAccess.CreateParameter("@Education", SqlDbType.VarChar, Education, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet empTracker(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empTracker",
                //SQLDataAccess.CreateParameter("@Education", SqlDbType.VarChar, Education, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false)


              );
            return dr;

        }
        public DataSet empData(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string uni, string clg, string year)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "emp_search",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@uni", SqlDbType.VarChar, uni, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@clg", SqlDbType.VarChar, clg, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@year", SqlDbType.VarChar, year, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        //Report operation mis

        public DataSet operationsetzero()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "reportsetzero"



              );
            return dr;

        }

        public DataSet operationmisupdate()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "reportupdate"



              );
            return dr;

        }

        public DataSet operationupdatetotal()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "reportupdatetotal"



              );
            return dr;

        }

        public DataSet operationmisdisplay()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "reportdisplay"



              );
            return dr;

        }

        //client report
        public DataSet clientdisplay(string ClientName)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Clientdisplay",
                //SQLDataAccess.CreateParameter("@EduList", SqlDbType.VarChar, EduList, ParameterDirection.Input, 20, false),
               SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false)


               );
            return dr;

        }


        //client report



        //Report operation mis


        //////// Employment

        public DataSet empclosebystaff(int empid, string revertdate, string color, string written, string complete, string verName, string verDesig, string contact, string revert, string remarks)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "EmpStaffClose",

                SQLDataAccess.CreateParameter("@empid", SqlDbType.Int, empid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@color", SqlDbType.VarChar, color, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@written", SqlDbType.VarChar, written, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@complete", SqlDbType.VarChar, complete, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verName", SqlDbType.VarChar, verName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verDesig", SqlDbType.VarChar, verDesig, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@contact", SqlDbType.VarChar, contact, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@revert", SqlDbType.VarChar, revert, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@remarks", SqlDbType.VarChar, remarks, ParameterDirection.Input, 500, false)



              );
            return dr;

        }

        public DataSet empverbalclosewrittenpending(int empid, string revertdate, string color, string written, string complete, string verName, string verDesig, string contact, string revert, string remarks)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empverbalclosewrittenpending",

                SQLDataAccess.CreateParameter("@empid", SqlDbType.Int, empid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@color", SqlDbType.VarChar, color, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@written", SqlDbType.VarChar, written, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@complete", SqlDbType.VarChar, complete, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verName", SqlDbType.VarChar, verName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@verDesig", SqlDbType.VarChar, verDesig, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@contact", SqlDbType.VarChar, contact, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@revert", SqlDbType.VarChar, revert, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@remarks", SqlDbType.VarChar, remarks, ParameterDirection.Input, 500, false)



              );
            return dr;

        }

        public DataSet emppendingbystaff(int empid, string revertdate, string written, string pending, string remark)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "emppendingstaffdata",

                SQLDataAccess.CreateParameter("@empid", SqlDbType.Int, empid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@written", SqlDbType.VarChar, written, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@pending", SqlDbType.VarChar, pending, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@remark", SqlDbType.VarChar, remark, ParameterDirection.Input, 450, false)



              );
            return dr;

        }

        public DataSet empinsertremark(int RefID, string revertdate, string remark, string username)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empInsertRemark",

                SQLDataAccess.CreateParameter("@RefID", SqlDbType.Int, RefID, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@remark", SqlDbType.VarChar, remark, ParameterDirection.Input, 450, false),
                SQLDataAccess.CreateParameter("@username", SqlDbType.VarChar, username, ParameterDirection.Input, 450, false)
              );
            return dr;

        }


        public DataSet finalalloctoEmpclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctoEmpclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalTATEmpclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalTATEmpclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalalloctoEmpstaffclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctoEmpstaffclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }


        public DataSet finalclosebyEmpstaffclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalclosebyEmpstaffclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }



        public DataSet finalEmpdataclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalEmpdataclose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }


        public DataSet EmpPendingGridView(string empid)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "EmpPendingGridView",
                SQLDataAccess.CreateParameter("@empid", SqlDbType.VarChar, empid, ParameterDirection.Input, 50, false)

                );
            return dr;

        }

        public DataSet EmpInsufficientbystaff(int eduid, string revertdate, string written, string Insufficient, string remark)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "EmpInsufficientEduStaff",

                SQLDataAccess.CreateParameter("@empid", SqlDbType.Int, eduid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@revertdate", SqlDbType.VarChar, revertdate, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@written", SqlDbType.VarChar, written, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Insufficient", SqlDbType.VarChar, Insufficient, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@remark", SqlDbType.VarChar, remark, ParameterDirection.Input, 450, false)



              );
            return dr;

        }

        public DataSet finalEmpHead()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Empfinal");
            return dr;

        }

        public DataSet finalempNew()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalempNew");
            return dr;

        }
        public DataSet finalempInsuff()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalempInsuff");
            return dr;

        }
        public DataSet finalempclose()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalempclose");
            return dr;

        }

        public DataSet empSearchApplicant(string StaffName, string AppName)
        {

            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empSearchAppName",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

               SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, StaffName, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet empSearchEmployer(string StaffName, string Employer)
        {

            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empSearchEmployer",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

               SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, StaffName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Employer", SqlDbType.VarChar, Employer, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet empSearchDate(string StaffName, string Alloc, string TAT)
        {

            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empSearchDate",

               SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, StaffName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, Alloc, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@tat", SqlDbType.VarChar, TAT, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet empSearchApp(string strAppName)
        {

            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empSearchApp",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

               SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, strAppName, ParameterDirection.Input, 50, false)




              );
            return dr;

        }

        public DataSet empSearchAllocApp(string strAppName)
        {

            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empSearchAllocApp",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

               SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, strAppName, ParameterDirection.Input, 50, false)




              );
            return dr;

        }

        public DataSet empalloctoveri(string Manager, string ClientName, string anila, string AppName, string Employer, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empalloctoveri",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, Employer, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet empTAT(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo, string uni, string clg, string year)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "emp_searchtat",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@uni", SqlDbType.VarChar, uni, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@clg", SqlDbType.VarChar, clg, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@year", SqlDbType.VarChar, year, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet empalloctostaff(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empalloctostaff",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet empclosebystaff(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empclosebystaff",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet empData(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empdata",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet empfinalCloseApplicant(string AppName)
        {

            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empfinalCloseApplicant",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),


                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet empfinalCloseDate(string closeDate)
        {

            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "empfinalCloseDate",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),


                SQLDataAccess.CreateParameter("@closeMGR", SqlDbType.VarChar, closeDate, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet empallocav(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff, string CaseID, string uni, string clg, string year)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "emp_alloc_AV",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseID, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@uni", SqlDbType.VarChar, uni, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@clg", SqlDbType.VarChar, clg, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@year", SqlDbType.VarChar, year, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet empallocrec(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo, string staff, string uni, string clg, string year)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "emp_alloc_rec",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@uni", SqlDbType.VarChar, uni, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@clg", SqlDbType.VarChar, clg, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@year", SqlDbType.VarChar, year, ParameterDirection.Input, 50, false)





              );
            return dr;

        }
        public DataSet empallocsearch(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff, string caseid, string uni, string clg, string year)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "emp_alloc_search",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, caseid, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@uni", SqlDbType.VarChar, uni, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@clg", SqlDbType.VarChar, clg, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@year", SqlDbType.VarChar, year, ParameterDirection.Input, 50, false)




              );
            return dr;

        }
        public DataSet OpEmpalloctovericlose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OpEmpalloctovericlose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet OPEmpTATclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OPEmpTATclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet OPEmpalloctostaffclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OPEmpalloctostaffclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet OPEmpclosebystaffclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OPEmpclosebystaffclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet OPEmpDataclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OPEmpDataclose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet OpUPEmpalloctovericlose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OpUPEmpalloctovericlose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet OPUPEmpTATclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OPUPEmpTATclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet OPUPEmpalloctostaffclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OPUPEmpalloctostaffclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet OPUPEmpclosebystaffclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OPUPEmpclosebystaffclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet OPUPEmpDataclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "OPUPEmpDataclose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet empRec(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo, string uni, string clg, string year)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "emp_searchRec",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@uni", SqlDbType.VarChar, uni, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@clg", SqlDbType.VarChar, clg, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@year", SqlDbType.VarChar, year, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet empAVDATE(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string Avdate, string uni, string clg, string year)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "emp_searchAV",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
              SQLDataAccess.CreateParameter("@Avdate", SqlDbType.VarChar, Avdate, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@uni", SqlDbType.VarChar, uni, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@clg", SqlDbType.VarChar, clg, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@year", SqlDbType.VarChar, year, ParameterDirection.Input, 50, false)




              );
            return dr;

        }

        public DataSet finalEmpalloctoverinsuffclose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalEmpalloctoverinsuffclose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalEmpTATInsuffClose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalEmpTATInsuffClose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalEmpalloctostaffInsuffClose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalEmpalloctostaffInsuffClose",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalEmpDataInsuffClose(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff, string closedate)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalEmpdataInsuffClose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@closedate", SqlDbType.VarChar, closedate, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalEmpalloctoverNew(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalEmpalloctoverNew",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalEmpTATNew(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalEmpTATNew",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalEmpalloctostaffNew(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalEmpalloctostaffNew",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalEmpDataNew(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff, string closedate)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalEmpDataNew",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@closedate", SqlDbType.VarChar, closedate, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet Empinsuffbystaff(string ClientName, string AppName, string ClientRefNo, string revertDate, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Emp_insuff_staff",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@revert", SqlDbType.VarChar, revertDate, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet EmpinsuffData(string ClientName, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Emp_insuff_Data",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet ReinitiateCase(string EmpID)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ReinitiateCase",

                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, EmpID, ParameterDirection.Input, 50, false)

              );
            return dr;

        }
        public DataSet saveEDC(string eduid, string edc, string edcRemarks, string user)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "saveEDC",

                SQLDataAccess.CreateParameter("@eduid", SqlDbType.Int, eduid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@edc", SqlDbType.VarChar, edc, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@remarks", SqlDbType.VarChar, edcRemarks, ParameterDirection.Input, 500, false),
                SQLDataAccess.CreateParameter("@user", SqlDbType.VarChar, user, ParameterDirection.Input, 50, false)




              );
            return dr;

        }

        public DataSet saveEmpEDC(string empid, string edc, string edcRemarks, string user)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "saveEmpEDC",

                SQLDataAccess.CreateParameter("@empid", SqlDbType.Int, empid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@edc", SqlDbType.VarChar, edc, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@remarks", SqlDbType.VarChar, edcRemarks, ParameterDirection.Input, 500, false),
                SQLDataAccess.CreateParameter("@user", SqlDbType.VarChar, user, ParameterDirection.Input, 50, false)

              );
            return dr;

        }

        public DataSet finalEduAll()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalEduAll"
                );
            return dr;

        }
        public DataSet finalalloctoverAll(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctoverAll",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalTATAll(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalTATAll",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalalloctostaffAll(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalalloctostaffAll",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }
        public DataSet finalclosebystaffAll(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalclosebystaffAll",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }
        public DataSet finalDataAll(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalDataAll",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalstaffAll(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalstaffAll",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        public DataSet finalclientAll(string Manager, string ClientName, string anila)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalclientAll",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false)


                );
            return dr;

        }

        public DataSet finalEmpAll()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalEmpAll"
                );
            return dr;

        }

        public DataSet finalEmpalloctoveriAll(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalEmpalloctoveriAll",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalEmpTATAll(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalEmpTATAll",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalEmpalloctostaffAll(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalEmpalloctostaffAll",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finalEmpDataAll(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string staff, string closedate)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalEmpDataAll",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@closedate", SqlDbType.VarChar, closedate, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet ReportReady(string user)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ReportReady",
                 SQLDataAccess.CreateParameter("@RptExecutive", SqlDbType.VarChar, user, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet FirstLevelInsuff()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Opn_Insuff");
            return dr;

        }

        public DataSet searchClientAck(string ClientName, string RecvDate)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "searchClientAck",

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@RecvDate", SqlDbType.VarChar, RecvDate, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet searchClientAllocAck(string ClientName, string AllocDate)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "searchClientAllocAck",

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@AllocDate", SqlDbType.VarChar, AllocDate, ParameterDirection.Input, 50, false)
                );
            return dr;

        }


        public DataSet AllInsuffChecks(string ClientName, string DateFrm, string DateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AllInsuffChecks",

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrm", SqlDbType.VarChar, DateFrm, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false)
                );
            return dr;

        }
        public DataSet QualityCases()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Quality");
            return dr;

        }

        public DataSet AllCaseStatusView()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AllCaseStatusView");
            return dr;

        }


        public DataSet SearchStatus(string strStatus, string Datefrm, string Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SearchStatus",

                SQLDataAccess.CreateParameter("@Status", SqlDbType.VarChar, strStatus, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Datefrm", SqlDbType.VarChar, Datefrm, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet QualityCasesfetch()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Quality_Report");
            return dr;

        }
        public DataSet AplicantDatafetch(string ClientName, string AppName)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AplicantDatafetch",
                 SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false));
            return dr;
        }
        public DataSet AplicantDatafetch_Quality_Date(string QualityDate)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AplicantDatafetch_Quality_Date",
                 SQLDataAccess.CreateParameter("@QualityDate", SqlDbType.VarChar, QualityDate, ParameterDirection.Input, 10, false));
            return dr;
        }


        public DataSet AplicantDatafetch_Quality_Date_ClientName(string QualityDate, string ClientName)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AplicantDatafetch_Quality_Date_ClientName",
                 SQLDataAccess.CreateParameter("@QualityDate", SqlDbType.VarChar, QualityDate, ParameterDirection.Input, 10, false),
                 SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false));
            return dr;
        }

        //Address Criminal Identity Search

        //Address Criminal Identity Search

        public DataSet ACIallocAV(string ClientName, string AppName, string ClientRefNo, string DateFrom, string DateTo, string staff, string state, string loc)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_Alloc_AV",

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@state", SqlDbType.VarChar, state, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@loc", SqlDbType.VarChar, loc, ParameterDirection.Input, 50, false)

              );
            return dr;

        }

        public DataSet ACIalloctat(string ClientName, string AppName, string ClientRefNo, string TATDateFrom, string TATDateTo, string staff, string state, string loc)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_Alloc_TAT",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@state", SqlDbType.VarChar, state, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@loc", SqlDbType.VarChar, loc, ParameterDirection.Input, 50, false)




              );
            return dr;

        }

        public DataSet ACIallocsearch(string ClientName, string AppName, string ClientRefNo, string staff, string state, string loc)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_Alloc_Search",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@state", SqlDbType.VarChar, state, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@loc", SqlDbType.VarChar, loc, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet ACIclosebystaff(string ClientName, string AppName, string ClientRefNo, string revertDate, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_close_staff",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@revert", SqlDbType.VarChar, revertDate, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet ACIdataClose(string ClientName, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACIdataClose",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet ACIinsuffbystaff(string ClientName, string AppName, string ClientRefNo, string revertDate, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_insuff_staff",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@revert", SqlDbType.VarChar, revertDate, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet ACIinsuffData(string ClientName, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_insuff_Data",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet ACIalloctoveriNew(string ClientName, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_alloc_to_veri_New",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),

                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet ACI_TAT_New(string ClientName, string AppName, string ClientRefNo, string TAT, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_TAT_New",
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TAT", SqlDbType.VarChar, TAT, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet ACIalloctostaffNew(string ClientName, string AppName, string ClientRefNo, string StaffAlloc, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_alloc_to_staff_New",
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@StaffAlloc", SqlDbType.VarChar, StaffAlloc, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet ACIDataNew(string ClientName, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_Data_New",
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet finaladdAll()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalAddAll");
            return dr;

        }

        public DataSet ACIalloctoveriAll(string ClientName, string AppName, string ClientRefNo, string DateFrom, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_alloc_to_veri_All",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),

                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet ACI_TAT_All(string ClientName, string AppName, string ClientRefNo, string TAT, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_TAT_All",
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TAT", SqlDbType.VarChar, TAT, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet ACIDataAll(string ClientName, string AppName, string ClientRefNo, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_Data_All",
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet ACI_Search_AV(string ClientName, string AppName, string alloc, string user, string vendor)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_Search_AV",
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@alloc", SqlDbType.VarChar, alloc, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, user, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@vendor", SqlDbType.VarChar, vendor, ParameterDirection.Input, 100, false)




              );
            return dr;

        }

        public DataSet ACI_Search_TAT(string ClientName, string AppName, string TAT, string user, string vendor)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_Search_TAT",
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TAT", SqlDbType.VarChar, TAT, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, user, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@vendor", SqlDbType.VarChar, vendor, ParameterDirection.Input, 100, false)





              );
            return dr;

        }

        public DataSet PriceDetailByDateClient(string Datefrom, string Dateto, string clientname)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "pricedetailDate",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),

                SQLDataAccess.CreateParameter("@Datefrom", SqlDbType.VarChar, Datefrom, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@Dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@clientname", SqlDbType.VarChar, clientname, ParameterDirection.Input, 150, false)



                );
            return dr;

        }

        public DataSet PriceDetail(string datefrom, string dateto, string clientname)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "pricedetailnew",
                //SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),

                SQLDataAccess.CreateParameter("@datefrom", SqlDbType.VarChar, datefrom, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@dateto", SqlDbType.VarChar, dateto, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@clientname", SqlDbType.VarChar, clientname, ParameterDirection.Input, 100, false)




                );
            return dr;

        }

        public DataSet PriceMIS(string Datefrom, string Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "PriceMIS",
            SQLDataAccess.CreateParameter("@Datefrom", SqlDbType.VarChar, Datefrom, ParameterDirection.Input, 100, false),
            SQLDataAccess.CreateParameter("@Dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 100, false)

        );
            return dr;

        }

        public DataSet PriceMIS1(string Datefrom, string Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "PriceMIS1",
            SQLDataAccess.CreateParameter("@Datefrom", SqlDbType.VarChar, Datefrom, ParameterDirection.Input, 100, false),
            SQLDataAccess.CreateParameter("@Dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 100, false)

            );
            return dr;

        }

        public DataSet ACI_Search_Data(string ClientName, string AppName, string user, string vendor)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ACI_Search_Data",
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, user, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@vendor", SqlDbType.VarChar, vendor, ParameterDirection.Input, 100, false)

              );
            return dr;

        }

        public DataSet InsuffChecks()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AllInsuff");
            return dr;

        }
        public DataSet showCategory(string Client)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "showCategory",
                SQLDataAccess.CreateParameter("@Client", SqlDbType.VarChar, Client, ParameterDirection.Input, 100, false)

              );
            return dr;

        }

        // Drug DB 

        public DataSet DrugDBDEO()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DrugDBHeadDEO");
            return dr;

        }

        public DataSet DrugDBAllocDEO()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DrugDBHeadAllocDEO");
            return dr;

        }

        public DataSet fillDrugDBStaff(string Staffname)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DrugDBStaffView",
                SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, Staffname, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet DashboareDetailCheck(string RefID, string Check)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DashboareDetailCheck",
                SQLDataAccess.CreateParameter("@RefID", SqlDbType.VarChar, RefID, ParameterDirection.Input, 50, false),

                SQLDataAccess.CreateParameter("@Check", SqlDbType.VarChar, Check, ParameterDirection.Input, 100, false)

                );
            return dr;

        }

        public DataSet DashboareDetailCase(string RefID)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DashboareDetailCase",
                SQLDataAccess.CreateParameter("@RefID", SqlDbType.VarChar, RefID, ParameterDirection.Input, 50, false)

                );
            return dr;

        }

        public DataSet DrugDBclosebystaff(int verid, string complete, string remark, string reverttype)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsertDrugDBStaffClose",

                SQLDataAccess.CreateParameter("@verid", SqlDbType.Int, verid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@complete", SqlDbType.VarChar, complete, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@remark", SqlDbType.VarChar, remark, ParameterDirection.Input, 500, false),
                SQLDataAccess.CreateParameter("@reverttype", SqlDbType.VarChar, reverttype, ParameterDirection.Input, 50, false)
                 );
            return dr;

        }

        public DataSet DrugDBClosed()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DrugDBClosed");
            return dr;

        }

        public DataSet finaldrugAll()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalDrugAll");
            return dr;

        }

        public DataSet finalDrugNew()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "finalDrugNew");
            return dr;

        }

        public DataSet DrugDBClosure()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DrugDBClosure");
            return dr;

        }

        public DataSet UpdateDrugDBClosure()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UpdateDrugDBClosure");
            return dr;

        }

        public DataSet TotalCasesDetails(string client, string datefrom, string dateto, string type)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "TotalCasesDetails",

            SQLDataAccess.CreateParameter("@client", SqlDbType.VarChar, client, ParameterDirection.Input, 50, false),
            SQLDataAccess.CreateParameter("@datefrom", SqlDbType.VarChar, datefrom, ParameterDirection.Input, 50, false),
            SQLDataAccess.CreateParameter("@dateto", SqlDbType.VarChar, dateto, ParameterDirection.Input, 50, false),
            SQLDataAccess.CreateParameter("@type", SqlDbType.VarChar, type, ParameterDirection.Input, 50, false)
                );
            return dr;
        }

        public DataSet ActiveCases()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ActiveCases"

                );
            return dr;

        }

        public DataSet RptReadyCases()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "RptReadyCases"

                );
            return dr;

        }

        public DataSet RptReadyAllocCases()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "RptReadyAllocCases"
               );
            return dr;

        }

        public DataSet RptUnallocSearch(string ClientName, string AppName, string ClientRefNo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "RptUnallocSearch",

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false)




              );
            return dr;

        }

        public DataSet RptAllocDateSearch(string ClientName, string AppName, string ClientRefNo, string allocDate, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "RptAllocDateSearch",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@allocdate", SqlDbType.VarChar, allocDate, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet AllocationReport(string date)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AllocationReport",
                SQLDataAccess.CreateParameter("@Date1", SqlDbType.VarChar, date, ParameterDirection.Input, 50, false));
            return dr;
        }
        public DataSet AllocationReportDetail(string name, string date)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocationreportdetail",
                SQLDataAccess.CreateParameter("@allocationdate", SqlDbType.VarChar, date, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@clientname", SqlDbType.VarChar, name, ParameterDirection.Input, 100, false));
            return dr;
        }
        public DataSet AllocationReportDetail3(string name, string date)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocationreportdetail3",
                SQLDataAccess.CreateParameter("@allocationdate", SqlDbType.VarChar, date, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@clientname", SqlDbType.VarChar, name, ParameterDirection.Input, 100, false));
            return dr;
        }
        public DataSet AllocationReportDetail2(string name, string date)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocationreportdetail2",
                SQLDataAccess.CreateParameter("@allocationdate", SqlDbType.VarChar, date, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@clientname", SqlDbType.VarChar, name, ParameterDirection.Input, 100, false));
            return dr;
        }
        public DataSet AllocationReportDetail1(string name, string date)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocationreportdetail1",
                SQLDataAccess.CreateParameter("@allocationdate", SqlDbType.VarChar, date, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@clientname", SqlDbType.VarChar, name, ParameterDirection.Input, 100, false));
            return dr;
        }


        public DataSet AllocationReport1(string date)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AllocationReport1",
                SQLDataAccess.CreateParameter("@Date1", SqlDbType.VarChar, date, ParameterDirection.Input, 50, false));
            return dr;
        }
        public DataSet AllocationReport2(string date)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AllocationReport2",
                SQLDataAccess.CreateParameter("@Date1", SqlDbType.VarChar, date, ParameterDirection.Input, 50, false));
            return dr;
        }
        public DataSet AllocationReport3(string date)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "AllocationReport3",
                SQLDataAccess.CreateParameter("@Date1", SqlDbType.VarChar, date, ParameterDirection.Input, 50, false));
            return dr;
        }

        public DataSet AllocationReportDetail4(string name, string date)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocationreportdetail4",
                SQLDataAccess.CreateParameter("@allocationdate", SqlDbType.VarChar, date, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@clientname", SqlDbType.VarChar, name, ParameterDirection.Input, 100, false));
            return dr;
        }
        public DataSet AllocationReportDetail5(string name, string date)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocationreportdetail5",
                SQLDataAccess.CreateParameter("@allocationdate", SqlDbType.VarChar, date, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@clientname", SqlDbType.VarChar, name, ParameterDirection.Input, 100, false));
            return dr;
        }

        public DataSet AllocationReportDetail6(string name, string date)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocationreportdetail6",
                SQLDataAccess.CreateParameter("@allocationdate", SqlDbType.VarChar, date, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@clientname", SqlDbType.VarChar, name, ParameterDirection.Input, 100, false));
            return dr;
        }

        public DataSet AllocationReportDetail7(string name, string date)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocationreportdetail7",
                SQLDataAccess.CreateParameter("@allocationdate", SqlDbType.VarChar, date, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@clientname", SqlDbType.VarChar, name, ParameterDirection.Input, 100, false));
            return dr;
        }

        public DataSet dailyEduReport(string Datefrm, string Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dailyEduReport",

                SQLDataAccess.CreateParameter("@Datefrm", SqlDbType.VarChar, Datefrm, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 50, false)
                );
            return dr;

        }
        public DataSet dailyEmpReport(string Datefrm, string Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dailyEmpReport",

                SQLDataAccess.CreateParameter("@Datefrm", SqlDbType.VarChar, Datefrm, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet dailyRPTReport(string Datefrm, string Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dailyRPTReport",

                SQLDataAccess.CreateParameter("@Datefrm", SqlDbType.VarChar, Datefrm, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet dailyRPTReportbyName(string Datefrm, string Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dailyRPTReportbyName",

                SQLDataAccess.CreateParameter("@Datefrm", SqlDbType.VarChar, Datefrm, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet dailyRPTReportbyClient(string Datefrm, string Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dailyRPTReportbyClient",

                SQLDataAccess.CreateParameter("@Datefrm", SqlDbType.VarChar, Datefrm, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet TATReport(string today, string tmrw, string dyaftrtmrw)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "TATReport",

                SQLDataAccess.CreateParameter("@today", SqlDbType.VarChar, today, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@tmrw", SqlDbType.VarChar, tmrw, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@dyaftr2mrw", SqlDbType.VarChar, dyaftrtmrw, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet user(string user)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "searchUser",

                SQLDataAccess.CreateParameter("@user", SqlDbType.VarChar, user, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet rptqualityexport(string Date, string Date1)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "rpt_quality_export",

                SQLDataAccess.CreateParameter("@date", SqlDbType.VarChar, Date, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@date1", SqlDbType.VarChar, Date1, ParameterDirection.Input, 50, false)
                );
            return dr;
        }
        public DataSet Qualitycomplete(string Date, string Date1)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "qualityrpt",

                SQLDataAccess.CreateParameter("@date", SqlDbType.VarChar, Date, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@date1", SqlDbType.VarChar, Date1, ParameterDirection.Input, 50, false)
                );
            return dr;
        }
        public DataSet ReportExport(string Date, string Date1)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "reportexported",

                SQLDataAccess.CreateParameter("@date", SqlDbType.VarChar, Date, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@date1", SqlDbType.VarChar, Date1, ParameterDirection.Input, 50, false)
                );
            return dr;
        }

        public DataSet DashBoardSearchMISTracker(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DashBoardSearchMISTracker",
                // SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false)


              );
            return dr;

        }

        public DataSet RptDetail(String client, string Date, string Date1)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "rptdetail",
                SQLDataAccess.CreateParameter("@clientname", SqlDbType.VarChar, client, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@date1", SqlDbType.VarChar, Date, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@date2", SqlDbType.VarChar, Date1, ParameterDirection.Input, 50, false)
                );
            return dr;
        }
        public DataSet Qualitycomp(String client, string Date, string Date1)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "qualitycomp",
                SQLDataAccess.CreateParameter("@clientname", SqlDbType.VarChar, client, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@date1", SqlDbType.VarChar, Date, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@date2", SqlDbType.VarChar, Date1, ParameterDirection.Input, 50, false)
                );
            return dr;
        }
        public DataSet Reportexp(String client, string Date, string Date1)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "reportexp",
                SQLDataAccess.CreateParameter("@clientname", SqlDbType.VarChar, client, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@date1", SqlDbType.VarChar, Date, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@date2", SqlDbType.VarChar, Date1, ParameterDirection.Input, 50, false)
                );
            return dr;
        }





        public DataSet DailyProd(String client, string user, string Date, string Date1)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dailyprod",
                SQLDataAccess.CreateParameter("@clientname", SqlDbType.VarChar, client, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@date", SqlDbType.VarChar, Date, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@date1", SqlDbType.VarChar, Date1, ParameterDirection.Input, 50, false),
               SQLDataAccess.CreateParameter("@username", SqlDbType.VarChar, user, ParameterDirection.Input, 50, false)

                );
            return dr;
        }


        public DataSet pricedashboardsearch(string refid)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "pricedashboardsearch",
                SQLDataAccess.CreateParameter("@refid", SqlDbType.VarChar, refid, ParameterDirection.Input, 50, false)

                );
            return dr;

        }
        public DataSet DailyProd1(string user, string Date, string Date1)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dailyprod1",
                SQLDataAccess.CreateParameter("@date", SqlDbType.VarChar, Date, ParameterDirection.Input, 50, false),
                    SQLDataAccess.CreateParameter("@date1", SqlDbType.VarChar, Date1, ParameterDirection.Input, 50, false),
               SQLDataAccess.CreateParameter("@username", SqlDbType.VarChar, user, ParameterDirection.Input, 50, false)

                );
            return dr;
        }

        public DataSet ActiveCasesToAlloc()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ActiveCasesToAllocReportTeam"
            );
            return dr;

        }


        public DataSet TATDetails(string client, string date, string type)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "TATDetails",

            SQLDataAccess.CreateParameter("@client", SqlDbType.VarChar, client, ParameterDirection.Input, 50, false),
            SQLDataAccess.CreateParameter("@date", SqlDbType.VarChar, date, ParameterDirection.Input, 50, false),
            SQLDataAccess.CreateParameter("@type", SqlDbType.VarChar, type, ParameterDirection.Input, 50, false)
                );
            return dr;
        }
        public DataSet Export_Case_Month(string month)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Export_Case_Month",

            SQLDataAccess.CreateParameter("@month", SqlDbType.VarChar, month, ParameterDirection.Input, 50, false)

                );
            return dr;
        }

        public DataSet SingalCheckDetail(string clientname, string type)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SingalCheckDetail",
                SQLDataAccess.CreateParameter("@clientname", SqlDbType.VarChar, clientname, ParameterDirection.Input, 50, false)
                ,

                SQLDataAccess.CreateParameter("@type", SqlDbType.VarChar, type, ParameterDirection.Input, 100, false)
                );
            return dr;

        }


        public DataSet SingalCheckList()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SingalCheckList");
            return dr;

        }


        public DataSet dailyAddReport(string Datefrm, string Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dailyAddReport",

                SQLDataAccess.CreateParameter("@Datefrm", SqlDbType.VarChar, Datefrm, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 50, false)
                );
            return dr;

        }
        public DataSet dailyReportDetail(string caller, string type, string datefrm, string dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dailyreportdetail",

                SQLDataAccess.CreateParameter("@caller", SqlDbType.VarChar, caller, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@type", SqlDbType.VarChar, type, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@datefrm", SqlDbType.VarChar, datefrm, ParameterDirection.Input, 50, false),
                  SQLDataAccess.CreateParameter("@dateto", SqlDbType.VarChar, dateto, ParameterDirection.Input, 50, false)
                );
            return dr;

        }
        public DataSet Allocationrepdetail(string client, string date, string type)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "allocationrepdetail",

            SQLDataAccess.CreateParameter("@client", SqlDbType.VarChar, client, ParameterDirection.Input, 100, false),
            SQLDataAccess.CreateParameter("@date", SqlDbType.VarChar, date, ParameterDirection.Input, 50, false),
            SQLDataAccess.CreateParameter("@type", SqlDbType.VarChar, type, ParameterDirection.Input, 50, false)
                );
            return dr;
        }

        public DataSet dailyEduClientReport(string Datefrm, string Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dailyEduClientReport",

                SQLDataAccess.CreateParameter("@Datefrm", SqlDbType.VarChar, Datefrm, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 50, false)
                );
            return dr;

        }
        public DataSet dailyEmpClientReport(string Datefrm, string Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dailyEmpClientReport",

                SQLDataAccess.CreateParameter("@Datefrm", SqlDbType.VarChar, Datefrm, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet dailyAddClientReport(string Datefrm, string Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dailyAddClientReport",

                SQLDataAccess.CreateParameter("@Datefrm", SqlDbType.VarChar, Datefrm, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet DashboardClientID(string str)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DashboardClientID",
                SQLDataAccess.CreateParameter("@str", SqlDbType.VarChar, str, ParameterDirection.Input, 50, false)

                );
            return dr;

        }


        public DataSet SingalCheckRevenue()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "singlecheckrevenue");
            return dr;

        }

        public DataSet ExportedMISTrackerCaseRec(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string DateFrom, string DateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ExportedMISTrackerCaseRec",
                // SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateFrom", SqlDbType.VarChar, DateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@DateTo", SqlDbType.VarChar, DateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }


        public DataSet ExportedMISTrackerCaseTaT(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId, string TATDateFrom, string TATDateTo)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ExportedMISTrackerCaseTaT",
                // SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateFrom", SqlDbType.VarChar, TATDateFrom, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@TATDateTo", SqlDbType.VarChar, TATDateTo, ParameterDirection.Input, 50, false)



              );
            return dr;

        }

        public DataSet fillsearchExportedMIS(string Manager, string ClientName, string anila, string AppName, string ClientRefNo, string CaseId)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ExportedMISTracker",
                // SQLDataAccess.CreateParameter("@Address", SqlDbType.VarChar, Address, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@Manager", SqlDbType.VarChar, Manager, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@anila", SqlDbType.VarChar, anila, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@CaseID", SqlDbType.VarChar, CaseId, ParameterDirection.Input, 50, false)


              );
            return dr;

        }



        public DataSet DailyProdReport(string Datefrm, string Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dpr",

                SQLDataAccess.CreateParameter("@datefrm", SqlDbType.VarChar, Datefrm, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 50, false)
               );
            return dr;
        }
        public DataSet DailyProdReport1(string Datefrm, string Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dprbyname",

                SQLDataAccess.CreateParameter("@datefrm", SqlDbType.VarChar, Datefrm, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 50, false)
               );
            return dr;
        }

        public DataSet VeriDetails(string client, string datefrom, string dateto, string type, string veri)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "VeriDetails",

            SQLDataAccess.CreateParameter("@client", SqlDbType.VarChar, client, ParameterDirection.Input, 50, false),
            SQLDataAccess.CreateParameter("@datefrom", SqlDbType.VarChar, datefrom, ParameterDirection.Input, 50, false),
            SQLDataAccess.CreateParameter("@dateto", SqlDbType.VarChar, dateto, ParameterDirection.Input, 50, false),
            SQLDataAccess.CreateParameter("@type", SqlDbType.VarChar, type, ParameterDirection.Input, 50, false),
            SQLDataAccess.CreateParameter("@veri", SqlDbType.VarChar, veri, ParameterDirection.Input, 50, false)
                );
            return dr;
        }

        public DataSet dailyGenpactReport()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dailyGenpactReport"
                );
            return dr;

        }
        public DataSet TruncateGenpactTracker()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "TruncateGenpactTracker");
            return dr;

        }

        public DataSet DailyProdReport2(string Datefrm, String Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dprholdpending",
                SQLDataAccess.CreateParameter("@datefrm", SqlDbType.VarChar, Datefrm, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 50, false)

               );
            return dr;
        }

        public DataSet DPRDetail(string name, string Datefrm, string Dateto, string type, string client)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dprdetail",
                SQLDataAccess.CreateParameter("@executive", SqlDbType.VarChar, name, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@datefrm", SqlDbType.VarChar, Datefrm, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@type", SqlDbType.VarChar, type, ParameterDirection.Input, 50, false),
                  SQLDataAccess.CreateParameter("@client", SqlDbType.VarChar, client, ParameterDirection.Input, 50, false)
               );
            return dr;
        }

        public DataSet InsertGenpactData(string Datefrm, string Dateto)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "InsertGenpactData",

                SQLDataAccess.CreateParameter("@Datefrm", SqlDbType.VarChar, Datefrm, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@Dateto", SqlDbType.VarChar, Dateto, ParameterDirection.Input, 50, false)
                );
            return dr;

        }


        public DataSet InsuffReport(string date)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "insuffreport",
                 SQLDataAccess.CreateParameter("@Date", SqlDbType.VarChar, date, ParameterDirection.Input, 50, false)
                );
            return dr;

        }

        public DataSet InsuffReportDetail(string client, string Date, string type)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "insuffreportdetail",
            SQLDataAccess.CreateParameter("@client", SqlDbType.VarChar, client, ParameterDirection.Input, 100, false),
            SQLDataAccess.CreateParameter("@date", SqlDbType.VarChar, Date, ParameterDirection.Input, 50, false),
            SQLDataAccess.CreateParameter("@type", SqlDbType.VarChar, type, ParameterDirection.Input, 50, false)
                    );
            return dr;

        }

        public DataSet showTAT(string client)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "showTAT",

            SQLDataAccess.CreateParameter("@client", SqlDbType.VarChar, client, ParameterDirection.Input, 50, false)

                );
            return dr;
        }


        public DataSet RptAllocSearch(string ClientName, string AppName, string ClientRefNo, string allocDate, string staff)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "RptAllocSearch",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

                SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, AppName, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@ClientRefNo", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@allocdate", SqlDbType.VarChar, allocDate, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@staff", SqlDbType.VarChar, staff, ParameterDirection.Input, 50, false)


              );
            return dr;

        }


        public DataSet CounterMyDashBoardCall(string str)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "CounterMyDashBoardCall",
                SQLDataAccess.CreateParameter("@str", SqlDbType.VarChar, str, ParameterDirection.Input, 50, false)

                );
            return dr;
        }


        public DataSet MyDashBoardSearchByCounter(string strCounter, string strClientName, string str, string strOtherSearch)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "MyDashBoardSearchByCounter",
                //SQLDataAccess.CreateParameter("@Criminal", SqlDbType.VarChar, Criminal, ParameterDirection.Input, 20, false),

               //SQLDataAccess.CreateParameter("@StaffName", SqlDbType.VarChar, StaffName, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@strCounter", SqlDbType.VarChar, strCounter, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@strClientName", SqlDbType.VarChar, strClientName, ParameterDirection.Input, 100, false),
                 SQLDataAccess.CreateParameter("@str", SqlDbType.VarChar, str, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@strOtherSearch", SqlDbType.VarChar, strOtherSearch, ParameterDirection.Input, 50, false)




              );
            return dr;

        }



        public DataSet DoubleCheckList()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DoubleCheckList");
            return dr;

        }

        public DataSet DoubleCheckDetail(string refid, String type)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DoubleCheckDetail",
                SQLDataAccess.CreateParameter("@refid", SqlDbType.VarChar, refid, ParameterDirection.Input, 10, false),
                SQLDataAccess.CreateParameter("@type", SqlDbType.VarChar, type, ParameterDirection.Input, 50, false)
               );
            return dr;

        }


        public DataSet ExportedDashBoardSearchByCounter(string strBillingMonth, string strClientName)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ExportedDashBoardSearchByCounter",
                 SQLDataAccess.CreateParameter("@strBillingMonth", SqlDbType.VarChar, strBillingMonth, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@strClientName", SqlDbType.VarChar, strClientName, ParameterDirection.Input, 100, false)


              );
            return dr;

        }

        public DataSet showHoliday()
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "showHoliday"
                );
            return dr;
        }
        public DataSet eduWRTSearch(string ClientRefNo, string appName, string client)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "eduWRTSearch",
                SQLDataAccess.CreateParameter("@RefID", SqlDbType.VarChar, ClientRefNo, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@AppName", SqlDbType.VarChar, appName, ParameterDirection.Input, 100, false),
                SQLDataAccess.CreateParameter("@Client", SqlDbType.VarChar, client, ParameterDirection.Input, 100, false)



              );
            return dr;

        }
        public DataSet QtyErrorReport(string QualityDateFrm, String QualityDateTo, string ClientName)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Qtyerrorreport",
                 SQLDataAccess.CreateParameter("@QualityDateFrm", SqlDbType.VarChar, QualityDateFrm, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@QualityDateTo", SqlDbType.VarChar, QualityDateTo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@ClientName", SqlDbType.VarChar, ClientName, ParameterDirection.Input, 100, false));
            return dr;
        }

        public DataSet PriceCheckDB(string strBilDateFrm, string strBilDateTo, string strClientName)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "PriceCheckDB",
                 SQLDataAccess.CreateParameter("@strBilDateFrm", SqlDbType.VarChar, strBilDateFrm, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@strBilDateTo", SqlDbType.VarChar, strBilDateTo, ParameterDirection.Input, 50, false),
                 SQLDataAccess.CreateParameter("@strClientName", SqlDbType.VarChar, strClientName, ParameterDirection.Input, 100, false)


              );
            return dr;

        }

        public DataSet BillUpdate(string datefrm, string dateto, string candname, string caller)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "BillUpdate",
                SQLDataAccess.CreateParameter("@datefrm", SqlDbType.VarChar, datefrm, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@dateto", SqlDbType.VarChar, dateto, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@cand", SqlDbType.VarChar, candname, ParameterDirection.Input, 150, false),
                SQLDataAccess.CreateParameter("@caller", SqlDbType.VarChar, caller, ParameterDirection.Input, 150, false)



                );
            return dr;

        }

        public DataSet saveRemarks(string empid, string check, string remarks, string user)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "saveRemarks",

                SQLDataAccess.CreateParameter("@empid", SqlDbType.VarChar, empid, ParameterDirection.Input, 20, false),
                SQLDataAccess.CreateParameter("@check", SqlDbType.VarChar, check, ParameterDirection.Input, 50, false),
                SQLDataAccess.CreateParameter("@remarks", SqlDbType.VarChar, remarks, ParameterDirection.Input, 500, false),
                SQLDataAccess.CreateParameter("@user", SqlDbType.VarChar, user, ParameterDirection.Input, 500, false)

              );
            return dr;

        }
        public DataSet ShowRemarks(string empid)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ShowRemarks",
                SQLDataAccess.CreateParameter("@empid", SqlDbType.VarChar, empid, ParameterDirection.Input, 50, false)

                );
            return dr;

        }
    }
}

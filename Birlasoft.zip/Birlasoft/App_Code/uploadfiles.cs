﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using DataAccess;
using uploadfiles;

namespace uploadfiles
{

    public class uploaddownloadfiles
    {
        private string strFileName;
        private string strUploadStatus;
        private string strCandidateID;
        private string strBackgroundType;
        private string strActiveStatus;
        private string strFileSize;

        private string strFirstName;
        private string strMiddleName;
        private string strSurname;
        private string strFatherName;
        private string strMobile;

        public string FileName
        {
            get
            {
                return strFileName;
            }
            set
            {
                strFileName = value;
            }
        }
        public string UploadStatus
        {
            get
            {
                return strUploadStatus;
            }
            set
            {
                strUploadStatus = value;
            }
        }
        public string CandidateID
        {
            get
            {
                return strCandidateID;
            }
            set
            {
                strCandidateID = value;
            }
        }
        public string ActiveStatus
        {
            get
            {
                return strActiveStatus;
            }
            set
            {
                strActiveStatus = value;
            }
        }
        public string FirstName
        {
            get
            {
                return strFirstName;
            }
            set
            {
                strFirstName = value;
            }
        }
        public string MiddleName
        {
            get
            {
                return strMiddleName;
            }
            set
            {
                strMiddleName = value;
            }
        }
        public string Surname
        {
            get
            {
                return strSurname;
            }
            set
            {
                strSurname = value;
            }
        }
        public string FatherName
        {
            get
            {
                return strFatherName;
            }
            set
            {
                strFatherName = value;
            }
        }
        public string Mobile
        {
            get
            {
                return strMobile;
            }
            set
            {
                strMobile = value;
            }
        }
        public string FileSize
        {
            get
            {
                return strFileSize;
            }
            set
            {
                strFileSize = value;
            }
        }
        public string BackgroundType
        {
            get
            {
                return strBackgroundType;
            }
            set
            {
                strBackgroundType = value;
            }
        }
        public string saveFile(uploaddownloadfiles objFileUD)
        {

            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[11];

            paramsToStore[0] = new SqlParameter("@FileName", SqlDbType.VarChar);
            paramsToStore[0].Value = objFileUD.FileName;
            paramsToStore[1] = new SqlParameter("@CandidateID", SqlDbType.VarChar);
            paramsToStore[1].Value = objFileUD.CandidateID;
            paramsToStore[2] = new SqlParameter("@UploadStatus", SqlDbType.VarChar);
            paramsToStore[2].Value = objFileUD.UploadStatus;
            paramsToStore[3] = new SqlParameter("@ActiveStatus", SqlDbType.VarChar);
            paramsToStore[3].Value = objFileUD.ActiveStatus;
            paramsToStore[4] = new SqlParameter("@FileSize", SqlDbType.VarChar);
            paramsToStore[4].Value = objFileUD.FileSize;
            paramsToStore[5] = new SqlParameter("@BackgroundType", SqlDbType.VarChar);
            paramsToStore[5].Value = objFileUD.BackgroundType;

            paramsToStore[6] = new SqlParameter("@FirstName", SqlDbType.VarChar);
            paramsToStore[6].Value = objFileUD.FirstName;
            paramsToStore[7] = new SqlParameter("@MiddleName", SqlDbType.VarChar);
            paramsToStore[7].Value = objFileUD.MiddleName;
            paramsToStore[8] = new SqlParameter("@Surname", SqlDbType.VarChar);
            paramsToStore[8].Value = objFileUD.Surname;
            paramsToStore[9] = new SqlParameter("@FatherName", SqlDbType.VarChar);
            paramsToStore[9].Value = objFileUD.FatherName;
            paramsToStore[10] = new SqlParameter("@Mobile", SqlDbType.VarChar);
            paramsToStore[10].Value = objFileUD.Mobile;

            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "Uploadfiles", paramsToStore));
        }

        public string saverpt(uploaddownloadfiles objFileUD)
        {

            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[2];

            paramsToStore[0] = new SqlParameter("@FileName", SqlDbType.VarChar);
            paramsToStore[0].Value = objFileUD.FileName;
            paramsToStore[1] = new SqlParameter("@CandidateID", SqlDbType.VarChar);
            paramsToStore[1].Value = objFileUD.CandidateID;


            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "saverpt", paramsToStore));
        }


        public string saveBand4File(uploaddownloadfiles objFileUD)
        {

            string i = "";
            SqlParameter[] paramsToStore = new SqlParameter[8];

            paramsToStore[0] = new SqlParameter("@FileName", SqlDbType.VarChar);
            paramsToStore[0].Value = objFileUD.FileName;

            //paramsToStore[1] = new SqlParameter("@CandidateID", SqlDbType.VarChar);
            //paramsToStore[1].Value = objFileUD.CandidateID;

            paramsToStore[1] = new SqlParameter("@UploadStatus", SqlDbType.VarChar);
            paramsToStore[1].Value = objFileUD.UploadStatus;

            paramsToStore[2] = new SqlParameter("@ActiveStatus", SqlDbType.VarChar);
            paramsToStore[2].Value = objFileUD.ActiveStatus;

            paramsToStore[3] = new SqlParameter("@FileSize", SqlDbType.VarChar);
            paramsToStore[3].Value = objFileUD.FileSize;

            paramsToStore[4] = new SqlParameter("@BackgroundType", SqlDbType.VarChar);
            paramsToStore[4].Value = objFileUD.BackgroundType;

            paramsToStore[5] = new SqlParameter("@FirstName", SqlDbType.VarChar);
            paramsToStore[5].Value = objFileUD.FirstName;
            
            paramsToStore[6] = new SqlParameter("@EmailID", SqlDbType.VarChar);
            paramsToStore[6].Value = objFileUD.FatherName;

            paramsToStore[7] = new SqlParameter("@Mobile", SqlDbType.VarChar);
            paramsToStore[7].Value = objFileUD.Mobile;

            return i = Convert.ToString(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UploadBand4files", paramsToStore));
        }



       
    }

}

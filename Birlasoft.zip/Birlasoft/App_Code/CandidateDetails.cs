using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using DataAccess;
using connection_layer;



namespace CandidateInfonamespace
{
    /// <summary>
    /// Generated Class for Table : EmployeeInfo.
    /// </summary>
    public class CandidateDetails
    {
        //cls_connection con = new cls_connection();

        private string Stxt_ResumeNo;
        private string Stxt_CaseReceivedBy;
        private string StxtPercentage;


        private string strMode;
        private string strCurrentAddress;
        private string strEmpHis1_CompnayNameandLocation;
        private string strEmpHis2_EmployeeCode;
        private string strEmpHis1RLvl2_TelepnoneNo;
        private string strEmpHis2RLvl2_MobileNo;
        private string strEmpHis1RLvl2_MobileNo;
        private string strPer_LivingSince;
        private string strEmpHis1_EmployeeCode;
        private string strTAT2;
        private string strEmpHis2RLvl1_TelepnoneNo;
        private string strEdu1_Address;
        private string strDateofJoining;
        private string strTATDate;
        private string strEmpHis1_TelephoneNo;
        private string strEmpHis2RLvl2_TelepnoneNo;
        private string strEmpHis2_IncaseOfGap;
        private string strEmpHis2RLvl1_EmailId;
        private string strEdu1_UniversityName;
        private string strPer_Landmark;
        private string strEmpHis2_AgencyDetails;
        private string strEmpHis1_referenceYN;
        private string strPer_PostOffice;
        private string strFatherName;
        private string strEmpHis1_LastPositionHeldnDepartmentName;
        private string strEmpHis2_CompnayNameandLocation;
        private string strEmpHis1_PeriodofEmployment;
        private string strEducation1State;
        private string strplaceofjoing;
        private string strEmpHis1_NoticePeriodorNot;
        private string strEmpHis2_NoticePeriodorNot;
        private string strEmpHis3_NoticePeriodorNot;
        private string strEmpHis4_NoticePeriodorNot;
        private string strEmpHis5_NoticePeriodorNot;
        private string strExperienceInYears1;
        private string strExperienceInYears2;
        private string strExperienceInYears3;
        private string strExperienceInYears4;
        private string strExperienceInYears5;

        private string strdatetoemphis1;//chng




        private string strVendor;
        private string strMonth;
        private string strDCSV;
        private string strDDV;
        private string strDVR;
        private string strDVU;


        private string strDOB;
        private string strEmpHis2_referenceYN;
        private string strEdu1_RollNo;
        private string strEmpHis1RLvl1_MobileNo;
        private string strEmpHis1_TempPerma;
        private string strEmpHis2_Address;
        private string strEmpHis1_PeriodofEmploymentRemark;
        private string strEmpHis1_IncaseOfGap;
        private string strEmpHis2_TempPerma;
        private string strEmpHis1RLvl2_NameDesignatinOfSupervisor;
        private string strEmpHis2RLvl1_MobileNo;
        private string strMiddleName;
        private string strEdu1_CollegeName;
        private string strEmpHis2RLvl2_NameDesignatinOfSupervisor;
        private string strEmpHis1_AgencyDetails;
        private string strEmpHis2RLvl1_NameDesignatinOfSupervisor;
        private string strFirstName;
        private string strPer_AddressPhoneNo;
        private string strEmpHis2_PeriodofEmployment;
        private string strdatetoemphis2;
        private string SCaseStatus;


        private string strEmpHis2RLvl2_EmailId;
        private string strCOE;
        private string strSNo;
        private string strClientName;
        private string strMobile;
        private string strPer_City;
        private string strCurr_PhoneNo;
        private string strEmpHis2_LastPositionHeldnDepartmentName;
        private string strEmpHis1_Address;
        private string strEdu1_EducationalQualification;
        private string strEmpHis1RLvl1_EmailId;
        private string strInDate;
        private string strPer_PoliceStation;
        private string strEmpHis2_TelephoneNo;
        private string strEmpHis1_ReasonOfLeaving;
        private string strEmpHis1_RemunerationOrSalary;
        private string strEnteredByLoginIdType;
        private string strBand;
        private string strEmpHis2_ReasonOfLeaving;
        private string strPer_State;
        private string strEmpIdProvidedByClient;
        private string strPlaceofBirth;
        private string strSurname;
        private string strExperienceInYears;
        private string strPermanentAddress;
        private string strCurr_City;
        private string strEmpHis2_RemunerationOrSalary;
        //private int    intEmployeeID;
        private string strCurr_State;
        private string strEmpHis1RLvl1_TelepnoneNo;
        private string strEmpHis1RLvl2_EmailId;
        private string strEmpHis2_PeriodofEmploymentRemark;
        private string strEmpHis1RLvl1_NameDesignatinOfSupervisor;
        private string strEdu1_YearOfPassing;
        // private EmployeeInfo_Criteria z_WhereClause;
        private int strEmployeeId;
        private int strCandidateId;
        private string strCaseStatus;
        private string strAllocatedStatus;
        private string strEmployeeIDProvidedByClient;
        private string strAddressStatus;
        //private string strAddressRemarks;
        private string strEducationStatus;
        //private string strEducationRemarks;
        //private string strEmploymentStatus2SUP;
        //private string strEmploymentRemarks2SUP;
        private string strCriminalStatus;
        private string strCriminalCourtStatus;
        private string strDrugStatus;
        //private string strCriminalRemarks;
        private string strIdentityStatus;
        private string strGap;
        //private string strDrugtestStatus;
        //private string strDrugtestRemarks;
        private string strDataBaseStatus;
        //private string strDataBaseRemarks;
        private string strb;
        private string strReportingLevel2emp1;
        private string strReportingLevel2emp2;
        //Employment Type
        private string stremploymentType;
        private string strRejectedRemarks1;
        private string strRejectedRemarks2;
        private string strRejectedRemarks3;
        private string strRejectedRemarks4;
        private string strRejectedRemarks5;
        private string strFresherOrExp;
        private string strNoOfComp;
        private string strCaseSubmmissionDate;


        ////////////For University/College Module
        private string strUniName;
        private string strUniLoc;
        private string strUniConPer;
        private string strUniDesig;
        private string strUniNo1;
        private string strUniNo2;
        private string strUniConPer1;
        private string strUniDesig1;
        private string strUniNo3;
        private string strUniNo4;
        private string strUniDD;
        private string strUniDDto;
        private string strUniDDadd;
        private string strUniTime;
        private string strUniMail;
        private string strUniWeb;
        private string strUniRemark;
        private string strColName;
        private string strColLoc;
        private string strColConPer;
        private string strColDesig;
        private string strColNo1;
        private string strColNo2;
        private string strColConPer1;
        private string strColDesig1;
        private string strColNo3;
        private string strColNo4;
        private string strColDD;
        private string strColDDto;
        private string strColDDadd;
        private string strColTime;
        private string strColMail;
        private string strColWeb;
        private string strColRemark;
        private string struser;
        private string stradd1logeststay;
        private string stradd1logeststarystate;
        private string stradd1logeststarycity;
        private string stradd1logeststarypolicestation;
        private string stradd1logeststaryphonenumber;
        private string stradd1logeststarypincode;
        private string stradd1logeststarylandmark;
        private string stradd1logeststaryLeavingsince;
        private string strcomment1;
        private string strcomment2;
        private string strcomment3;
        private string strcomment4;
        private string strcomment5;
        private string strkey;
        private string strcmp1department;
        private string strcmp2department;
        private string strcmp3department;
        private string strcmp4department;
        private string strcmp5department;

        private string strcmp1HRdesignation;
        private string strcmp2HRdesignation;
        private string strcmp3HRdesignation;
        private string strcmp4HRdesignation;
        private string strcmp5HRdesignation;

        private string strcmp1RMdesignation;
        private string strcmp2RMdesignation;
        private string strcmp3RMdesignation;
        private string strcmp4RMdesignation;
        private string strcmp5RMdesignation;
        private string strcurrentemployment;

        private string strdruglist;
        private string strdrugcheck;
        private string strdrugcity;
        private string strdrugremark;
        private string strdrugstate;


        private string stridentitylist;
        private string stridentitycheck;
        private string stridentitycity;
        private string stridentityremark;
        private string stridentitystate;
        private string strcriminalchk1;
        private string strcriminalchk2;
        private string strcriminalchk3;
        private string strEdu2_CollegeName;
        private string strEdu2_UniversityName;
        private string strEdu2_Address;
        private string strEdu2_RollNo;
        private string strEdu2_YearOfPassing;
        private string strEdu2_EducationalQualification;
        private string strdbcheck;
        private string strdbcity;
        private string strdbstate;
        private string strdbremark;


        //Band 4 

        private string strband4candidatename;
        private string strband4middlename;
        private string strband4surname;
        private string strband4emailid;
        private string strband4mobile;
        private string strband4coe;
        private string strband4hiring;
        private string strcandidatealternateno;
        private string strcandidateremarks;


        private string strBankwithGenpact;
        private string strHavePFmember;
        private string strPFnomineeName;
        private string strPFrelationship;
        private string strPFdob;

        private string strSkillset1;
        private string strSkillset2;
        private string strSkillset3;
        private string strMediNominee1Name;
        private string strMediNominee1Relation;

        private string strMediNominee1DOB;
        private string strSameasNominee1;
        private string strMediNominee2Name;
        private string strMediNominee2Relation;
        private string strMediNominee2DOB;

        private string strSameasNominee2;
        private string strMediNominee3Name;
        private string strMediNominee3Relation;
        private string strMediNominee3DOB;
        private string strHavePAN;

        private string strPanNo;
        private string strPANhaveApplied;
        private string strCompTrans;
        private string strCompTransAddress;
        private string strCompTransCity;

        private string strCompTransState;
        private string strCompTransSTD;
        private string strHaveAccount;
        private string strBankName;
        private string strBankAC;
        private string strgender;
        private string strmaritalstatus;
        private string stremfirstname;
        private string stremlastname;
        private string stremrelation;
        private string stremcontact;
        private string stremtitle;
        private string strCAmemeber;
        private string strCategory;


        private string strddlaccount;
        public string ddlaccount
        {
            get
            {
                return strddlaccount;
            }
            set
            {
                strddlaccount = value;
            }
        }


        private string refList;
        public string RefList
        {
            get
            {
                return refList;
            }
            set
            {
                refList = value;
            }
        }
        private string ref1RefName;
        public string Ref1RefName
        {
            get
            {
                return ref1RefName;
            }
            set
            {
                ref1RefName = value;
            }
        }
        private string ref2RefName;
        public string Ref2RefName
        {
            get
            {
                return ref2RefName;
            }
            set
            {
                ref2RefName = value;
            }
        }
        private string ref1CompName;
        public string Ref1CompName
        {
            get
            {
                return ref1CompName;
            }
            set
            {
                ref1CompName = value;
            }
        }
        private string ref2CompName;
        public string Ref2CompName
        {
            get
            {
                return ref2CompName;
            }
            set
            {
                ref2CompName = value;
            }
        }
        private string ref1Designation;
        public string Ref1Designation
        {
            get
            {
                return ref1Designation;
            }
            set
            {
                ref1Designation = value;
            }
        }
        private string ref2Designation;
        public string Ref2Designation
        {
            get
            {
                return ref2Designation;
            }
            set
            {
                ref2Designation = value;
            }
        }
        private string ref1Email;
        public string Ref1Email
        {
            get
            {
                return ref1Email;
            }
            set
            {
                ref1Email = value;
            }
        }
        private string ref2Email;
        public string Ref2Email
        {
            get
            {
                return ref2Email;
            }
            set
            {
                ref2Email = value;
            }
        }
        private string ref1Contact;
        public string Ref1Contact
        {
            get
            {
                return ref1Contact;
            }
            set
            {
                ref1Contact = value;
            }
        }
        private string ref2Contact;
        public string Ref2Contact
        {
            get
            {
                return ref2Contact;
            }
            set
            {
                ref2Contact = value;
            }
        }

        private string cIBILFullName;
        public string CIBILFullName
        {
            get
            {
                return cIBILFullName;
            }
            set
            {
                cIBILFullName = value;
            }
        }
        private string cIBILDOB;
        public string CIBILDOB
        {
            get
            {
                return cIBILDOB;
            }
            set
            {
                cIBILDOB = value;
            }
        }
        private string cIBILGender;
        public string CIBILGender
        {
            get
            {
                return cIBILGender;
            }
            set
            {
                cIBILGender = value;
            }
        }
        private string cIBILEmail;
        public string CIBILEmail
        {
            get
            {
                return cIBILEmail;
            }
            set
            {
                cIBILEmail = value;
            }
        }
        private string cIBILContact;
        public string CIBILContact
        {
            get
            {
                return cIBILContact;
            }
            set
            {
                cIBILContact = value;
            }
        }
        private string cIBILPanCard;
        public string CIBILPanCard
        {
            get
            {
                return cIBILPanCard;
            }
            set
            {
                cIBILPanCard = value;
            }
        }
        private string cIBILDrivinglicense;
        public string CIBILDrivinglicense
        {
            get
            {
                return cIBILDrivinglicense;
            }
            set
            {
                cIBILDrivinglicense = value;
            }
        }

        private string cIBILpassportno;
        public string CIBILpassportno
        {
            get
            {
                return cIBILpassportno;
            }
            set
            {
                cIBILpassportno = value;
            }
        }



        private string cIBILvoterID;
        public string CIBILvoterID
        {
            get
            {
                return cIBILvoterID;
            }
            set
            {
                cIBILvoterID = value;
            }
        }


        private string cIBILList;
        public string CIBILList
        {
            get
            {
                return cIBILList;
            }
            set
            {
                cIBILList = value;
            }
        }

        public string Category
        {
            get
            {
                return strCategory;
            }
            set
            {
                strCategory = value;
            }
        }


        public string CAmemeber
        {
            get
            {
                return strCAmemeber;
            }
            set
            {
                strCAmemeber = value;
            }
        }

        public string BankAC
        {
            get
            {
                return strBankAC;
            }
            set
            {
                strBankAC = value;
            }
        }

        public string BankName
        {
            get
            {
                return strBankName;
            }
            set
            {
                strBankName = value;
            }
        }
        public string HaveAccount
        {
            get
            {
                return strHaveAccount;
            }
            set
            {
                strHaveAccount = value;
            }
        }
        public string CompTransState
        {
            get
            {
                return strCompTransState;
            }
            set
            {
                strCompTransState = value;
            }
        }

        public string CompTransSTD
        {
            get
            {
                return strCompTransSTD;
            }
            set
            {
                strCompTransSTD = value;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public string PanNo
        {
            get
            {
                return strPanNo;
            }
            set
            {
                strPanNo = value;
            }
        }

        public string PANhaveApplied
        {
            get
            {
                return strPANhaveApplied;
            }
            set
            {
                strPANhaveApplied = value;
            }
        }
        public string CompTrans
        {
            get
            {
                return strCompTrans;
            }
            set
            {
                strCompTrans = value;
            }
        }
        public string CompTransAddress
        {
            get
            {
                return strCompTransAddress;
            }
            set
            {
                strCompTransAddress = value;
            }
        }

        public string CompTransCity
        {
            get
            {
                return strCompTransCity;
            }
            set
            {
                strCompTransCity = value;
            }
        }
        /// <summary>
        /// 
        /// </summary>

        public string SameasNominee2
        {
            get
            {
                return strSameasNominee2;
            }
            set
            {
                strSameasNominee2 = value;
            }
        }

        public string MediNominee3Name
        {
            get
            {
                return strMediNominee3Name;
            }
            set
            {
                strMediNominee3Name = value;
            }
        }
        public string MediNominee3Relation
        {
            get
            {
                return strMediNominee3Relation;
            }
            set
            {
                strMediNominee3Relation = value;
            }
        }
        public string MediNominee3DOB
        {
            get
            {
                return strMediNominee3DOB;
            }
            set
            {
                strMediNominee3DOB = value;
            }
        }

        public string HavePAN
        {
            get
            {
                return strHavePAN;
            }
            set
            {
                strHavePAN = value;
            }
        }





        /// <summary>
        /// 
        /// </summary>
        public string MediNominee1DOB
        {
            get
            {
                return strMediNominee1DOB;
            }
            set
            {
                strMediNominee1DOB = value;
            }
        }

        public string SameasNominee1
        {
            get
            {
                return strSameasNominee1;
            }
            set
            {
                strSameasNominee1 = value;
            }
        }
        public string MediNominee2Name
        {
            get
            {
                return strMediNominee2Name;
            }
            set
            {
                strMediNominee2Name = value;
            }
        }
        public string MediNominee2Relation
        {
            get
            {
                return strMediNominee2Relation;
            }
            set
            {
                strMediNominee2Relation = value;
            }
        }

        public string MediNominee2DOB
        {
            get
            {
                return strMediNominee2DOB;
            }
            set
            {
                strMediNominee2DOB = value;
            }
        }


        /// <summary>
        /// 
        /// </summary>

        public string MediNominee1Relation
        {
            get
            {
                return strMediNominee1Relation;
            }
            set
            {
                strMediNominee1Relation = value;
            }
        }

        public string MediNominee1Name
        {
            get
            {
                return strMediNominee1Name;
            }
            set
            {
                strMediNominee1Name = value;
            }
        }
        public string Skillset3
        {
            get
            {
                return strSkillset3;
            }
            set
            {
                strSkillset3 = value;
            }
        }
        public string Skillset2
        {
            get
            {
                return strSkillset2;
            }
            set
            {
                strSkillset2 = value;
            }
        }

        public string Skillset1
        {
            get
            {
                return strSkillset1;
            }
            set
            {
                strSkillset1 = value;
            }
        }
        /// <summary>
        /// /
        /// </summary>


        public string PFdob
        {
            get
            {
                return strPFdob;
            }
            set
            {
                strPFdob = value;
            }
        }

        public string PFrelationship
        {
            get
            {
                return strPFrelationship;
            }
            set
            {
                strPFrelationship = value;
            }
        }
        public string PFnomineeName
        {
            get
            {
                return strPFnomineeName;
            }
            set
            {
                strPFnomineeName = value;
            }
        }
        public string HavePFmember
        {
            get
            {
                return strHavePFmember;
            }
            set
            {
                strHavePFmember = value;
            }
        }

        public string BankwithGenpact
        {
            get
            {
                return strBankwithGenpact;
            }
            set
            {
                strBankwithGenpact = value;
            }
        }

        public string emtitle
        {
            get
            {
                return stremtitle;
            }
            set
            {
                stremtitle = value;
            }
        }

        public string emcontact
        {
            get
            {
                return stremcontact;
            }
            set
            {
                stremcontact = value;
            }
        }

        public string emrelation
        {
            get
            {
                return stremrelation;
            }
            set
            {
                stremrelation = value;
            }
        }

        public string emlastname
        {
            get
            {
                return stremlastname;
            }
            set
            {
                stremlastname = value;
            }
        }

        public string emfirstname
        {
            get
            {
                return stremfirstname;
            }
            set
            {
                stremfirstname = value;
            }
        }

        public string maritalstatus
        {
            get
            {
                return strmaritalstatus;
            }
            set
            {
                strmaritalstatus = value;
            }
        }

        public string gender
        {
            get
            {
                return strgender;
            }
            set
            {
                strgender = value;
            }
        }


        public string candidateremarks
        {
            get
            {
                return strcandidateremarks;
            }
            set
            {
                strcandidateremarks = value;
            }
        }


        public string candidatealternateno
        {
            get
            {
                return strcandidatealternateno;
            }
            set
            {
                strcandidatealternateno = value;
            }
        }


        public string band4candidatename
        {
            get
            {
                return strband4candidatename;
            }
            set
            {
                strband4candidatename = value;
            }
        }
        public string band4middlename
        {
            get
            {
                return strband4middlename;
            }
            set
            {
                strband4middlename = value;
            }
        }
        public string band4surname
        {
            get
            {
                return strband4surname;
            }
            set
            {
                strband4surname = value;
            }
        }
        public string band4emailid
        {
            get
            {
                return strband4emailid;
            }
            set
            {
                strband4emailid = value;
            }
        }
        public string band4mobile
        {
            get
            {
                return strband4mobile;
            }
            set
            {
                strband4mobile = value;
            }
        }
        public string band4coe
        {
            get
            {
                return strband4coe;
            }
            set
            {
                strband4coe = value;
            }
        }
        public string band4hiring
        {
            get
            {
                return strband4hiring;
            }
            set
            {
                strband4hiring = value;
            }
        }
        /// <summary>
        /// //
        /// </summary>







        public string dbcheck
        {
            get
            {
                return strdbcheck;
            }
            set
            {
                strdbcheck = value;
            }
        }

        public string dbcity
        {
            get
            {
                return strdbcity;
            }
            set
            {
                strdbcity = value;
            }
        }

        public string dbstate
        {
            get
            {
                return strdbstate;
            }
            set
            {
                strdbstate = value;
            }
        }


        public string dbremark
        {
            get
            {
                return strdbremark;
            }
            set
            {
                strdbremark = value;
            }
        }


        public string Edu2_UniversityName
        {
            get
            {
                return strEdu2_UniversityName;
            }
            set
            {
                strEdu2_UniversityName = value;
            }
        }


        public string Edu2_Address
        {
            get
            {
                return strEdu2_Address;
            }
            set
            {
                strEdu2_Address = value;
            }
        }


        public string Edu2_RollNo
        {
            get
            {
                return strEdu2_RollNo;
            }
            set
            {
                strEdu2_RollNo = value;
            }
        }

        public string Edu2_YearOfPassing
        {
            get
            {
                return strEdu2_YearOfPassing;
            }
            set
            {
                strEdu2_YearOfPassing = value;
            }
        }

        public string Edu2_EducationalQualification
        {
            get
            {
                return strEdu2_EducationalQualification;
            }
            set
            {
                strEdu2_EducationalQualification = value;
            }
        }

        public string Edu2_CollegeName
        {
            get
            {
                return strEdu2_CollegeName;
            }
            set
            {
                strEdu2_CollegeName = value;
            }
        }



        public string Gap
        {
            get
            {
                return strGap;
            }
            set
            {
                strGap = value;
            }
        }

        public string IdentityStatus
        {
            get
            {
                return strIdentityStatus;
            }
            set
            {
                strIdentityStatus = value;
            }
        }

        public string criminalchk3
        {
            get
            {
                return strcriminalchk3;
            }
            set
            {
                strcriminalchk3 = value;
            }
        }

        public string criminalchk2
        {
            get
            {
                return strcriminalchk2;
            }
            set
            {
                strcriminalchk2 = value;
            }
        }

        public string criminalchk1
        {
            get
            {
                return strcriminalchk1;
            }
            set
            {
                strcriminalchk1 = value;
            }
        }




        public string IdentityState
        {
            get
            {
                return stridentitystate;
            }
            set
            {
                stridentitystate = value;
            }
        }


        public string IdentityRemark
        {
            get
            {
                return stridentityremark;
            }
            set
            {
                stridentityremark = value;
            }
        }


        public string IdentityCity
        {
            get
            {
                return stridentitycity;
            }
            set
            {
                stridentitycity = value;
            }
        }

        public string IdentityCheck
        {
            get
            {
                return stridentitycheck;
            }
            set
            {
                stridentitycheck = value;
            }
        }




        public string IdentityList
        {
            get
            {
                return stridentitylist;
            }
            set
            {
                stridentitylist = value;
            }
        }



        public string DrugState
        {
            get
            {
                return strdrugstate;
            }
            set
            {
                strdrugstate = value;
            }
        }


        public string DrugRemark
        {
            get
            {
                return strdrugremark;
            }
            set
            {
                strdrugremark = value;
            }
        }


        public string DrugCity
        {
            get
            {
                return strdrugcity;
            }
            set
            {
                strdrugcity = value;
            }
        }

        public string DrugCheck
        {
            get
            {
                return strdrugcheck;
            }
            set
            {
                strdrugcheck = value;
            }
        }




        public string DrugList
        {
            get
            {
                return strdruglist;
            }
            set
            {
                strdruglist = value;
            }
        }



        public string CurrentEmployment
        {
            get
            {
                return strcurrentemployment;
            }
            set
            {
                strcurrentemployment = value;
            }
        }






        public string DrugStatus
        {
            get
            {
                return strDrugStatus;
            }
            set
            {
                strDrugStatus = value;
            }
        }
        public string cmp1department
        {
            get
            {
                return strcmp1department;
            }
            set
            {
                strcmp1department = value;
            }
        }
        public string cmp2department
        {
            get
            {
                return strcmp2department;
            }
            set
            {
                strcmp2department = value;
            }
        }
        public string cmp3department
        {
            get
            {
                return strcmp3department;
            }
            set
            {
                strcmp3department = value;
            }
        }
        public string cmp4department
        {
            get
            {
                return strcmp4department;
            }
            set
            {
                strcmp4department = value;
            }
        }
        public string cmp5department
        {
            get
            {
                return strcmp5department;
            }
            set
            {
                strcmp5department = value;
            }
        }

        public string cmp1HRdesignation
        {
            get
            {
                return strcmp1HRdesignation;
            }
            set
            {
                strcmp1HRdesignation = value;
            }
        }
        public string cmp2HRdesignation
        {
            get
            {
                return strcmp2HRdesignation;
            }
            set
            {
                strcmp2HRdesignation = value;
            }
        }
        public string cmp3HRdesignation
        {
            get
            {
                return strcmp3HRdesignation;
            }
            set
            {
                strcmp3HRdesignation = value;
            }
        }
        public string cmp4HRdesignation
        {
            get
            {
                return strcmp4HRdesignation;
            }
            set
            {
                strcmp4HRdesignation = value;
            }
        }
        public string cmp5HRdesignation
        {
            get
            {
                return strcmp5HRdesignation;
            }
            set
            {
                strcmp5HRdesignation = value;
            }
        }
        /// <summary>
        /// /
        /// 
        /// </summary>
        public string cmp1RMdesignation
        {
            get
            {
                return strcmp1RMdesignation;
            }
            set
            {
                strcmp1RMdesignation = value;
            }
        }
        public string cmp2RMdesignation
        {
            get
            {
                return strcmp2RMdesignation;
            }
            set
            {
                strcmp2RMdesignation = value;
            }
        }
        public string cmp3RMdesignation
        {
            get
            {
                return strcmp3RMdesignation;
            }
            set
            {
                strcmp3RMdesignation = value;
            }
        }
        public string cmp4RMdesignation
        {
            get
            {
                return strcmp4RMdesignation;
            }
            set
            {
                strcmp4RMdesignation = value;
            }
        }
        public string cmp5RMdesignation
        {
            get
            {
                return strcmp5RMdesignation;
            }
            set
            {
                strcmp5RMdesignation = value;
            }
        }










        public string key
        {
            get
            {
                return strkey;
            }
            set
            {
                strkey = value;
            }
        }

        public string comment1
        {
            get
            {
                return strcomment1;
            }
            set
            {
                strcomment1 = value;
            }
        }
        public string comment2
        {
            get
            {
                return strcomment2;
            }
            set
            {
                strcomment2 = value;
            }
        }

        public string comment3
        {
            get
            {
                return strcomment3;
            }
            set
            {
                strcomment3 = value;
            }
        }

        public string comment4
        {
            get
            {
                return strcomment4;
            }
            set
            {
                strcomment4 = value;
            }
        }

        public string comment5
        {
            get
            {
                return strcomment5;
            }
            set
            {
                strcomment5 = value;
            }
        }


        public string EmpHis1_NoticePeriodorNot
        {
            get
            {
                return strEmpHis1_NoticePeriodorNot;
            }
            set
            {
                strEmpHis1_NoticePeriodorNot = value;
            }
        }
        public string EmpHis2_NoticePeriodorNot
        {
            get
            {
                return strEmpHis2_NoticePeriodorNot;
            }
            set
            {
                strEmpHis2_NoticePeriodorNot = value;
            }
        }
        public string EmpHis3_NoticePeriodorNot
        {
            get
            {
                return strEmpHis3_NoticePeriodorNot;
            }
            set
            {
                strEmpHis3_NoticePeriodorNot = value;
            }
        }
        public string EmpHis4_NoticePeriodorNot
        {
            get
            {
                return strEmpHis4_NoticePeriodorNot;
            }
            set
            {
                strEmpHis4_NoticePeriodorNot = value;
            }
        }
        public string EmpHis5_NoticePeriodorNot
        {
            get
            {
                return strEmpHis5_NoticePeriodorNot;
            }
            set
            {
                strEmpHis5_NoticePeriodorNot = value;
            }
        }

        public string add1logeststaryLeavingsince
        {
            get
            {
                return stradd1logeststaryLeavingsince;
            }
            set
            {
                stradd1logeststaryLeavingsince = value;
            }
        }
        public string add1logeststarylandmark
        {
            get
            {
                return stradd1logeststarylandmark;
            }
            set
            {
                stradd1logeststarylandmark = value;
            }
        }


        public string add1logeststay
        {
            get
            {
                return stradd1logeststay;
            }
            set
            {
                stradd1logeststay = value;
            }
        }
        public string add1logeststarypincode
        {
            get
            {
                return stradd1logeststarypincode;
            }
            set
            {
                stradd1logeststarypincode = value;
            }
        }
        public string add1logeststaryphonenumber
        {
            get
            {
                return stradd1logeststaryphonenumber;
            }
            set
            {
                stradd1logeststaryphonenumber = value;
            }
        }
        public string add1logeststarypolicestation
        {
            get
            {
                return stradd1logeststarypolicestation;
            }
            set
            {
                stradd1logeststarypolicestation = value;
            }
        }
        public string add1logeststarycity
        {
            get
            {
                return stradd1logeststarycity;
            }
            set
            {
                stradd1logeststarycity = value;
            }
        }
        public string add1logeststarystate
        {
            get
            {
                return stradd1logeststarystate;
            }
            set
            {
                stradd1logeststarystate = value;
            }
        }

        public string user
        {
            get
            {
                return struser;
            }
            set
            {
                struser = value;
            }
        }




        //..........................


        public string txt_ResumeNo
        { get { return Stxt_ResumeNo; } set { Stxt_ResumeNo = value; } }

        public string txt_CaseReceivedBy
        { get { return Stxt_CaseReceivedBy; } set { Stxt_CaseReceivedBy = value; } }

        public string txtPercentage
        { get { return StxtPercentage; } set { StxtPercentage = value; } }





        //  ................................
        public string CaseSubmmissionDate
        {
            get
            {
                return strCaseSubmmissionDate;
            }
            set
            {
                strCaseSubmmissionDate = value;
            }

        }
        public string PlaceofJoing
        {
            get
            {
                return strplaceofjoing;
            }
            set
            {
                strplaceofjoing = value;
            }

        }



        //for company 3           
        private string strEmpHis3_CompnayNameandLocation;
        public string EmpHis3_CompnayNameandLocation
        {
            get
            {
                return strEmpHis3_CompnayNameandLocation;
            }
            set
            {
                strEmpHis3_CompnayNameandLocation = value;
            }
        }

        private string strEmpHis3_LastPositionHeldnDepartmentName;
        public string EmpHis3_LastPositionHeldnDepartmentName
        {
            get
            {
                return strEmpHis3_LastPositionHeldnDepartmentName;

            }
            set
            {
                strEmpHis3_LastPositionHeldnDepartmentName = value;

            }
        }

        private string strEmpHis3_TelephoneNo;
        public string EmpHis3_TelephoneNo
        {
            get
            {
                return strEmpHis3_TelephoneNo;
            }
            set
            {
                strEmpHis3_TelephoneNo = value;

            }
        }
        private string strEmpHis3_Address;
        public string EmpHis3_Address
        {
            get
            {
                return strEmpHis3_Address;
            }
            set
            {
                strEmpHis3_Address = value;
            }
        }

        private string strEmpHis3_EmployeeCode;
        public string EmpHis3_EmployeeCode
        {
            get
            {
                return strEmpHis3_EmployeeCode;
            }
            set
            {
                strEmpHis3_EmployeeCode = value;
            }
        }
        private string strEmpHis3_PeriodofEmployment;
        public string EmpHis3_PeriodofEmployment
        {
            get
            {
                return strEmpHis3_PeriodofEmployment;
            }
            set
            {
                strEmpHis3_PeriodofEmployment = value;
            }
        }
        private string strdatetoempHis3;
        public string datetoempHis3
        {
            get
            {
                return strdatetoempHis3;
            }
            set
            {
                strdatetoempHis3 = value;
            }

        }
        private string strEmpHis3_PeriodofEmploymentRemark;
        public string EmpHis3_PeriodofEmploymentRemark
        {
            get
            {
                return strEmpHis3_PeriodofEmploymentRemark;
            }
            set
            {
                strEmpHis3_PeriodofEmploymentRemark = value;
            }
        }
        private string strEmpHis3RLvl1_NameDesignatinOfSupervisor;
        public string EmpHis3RLvl1_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis3RLvl1_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis3RLvl1_NameDesignatinOfSupervisor = value;
            }
        }

        private string strEmpHis3RLvl1_TelepnoneNo;
        public string EmpHis3RLvl1_TelepnoneNo
        {
            get
            {
                return strEmpHis3RLvl1_TelepnoneNo;
            }
            set
            {
                strEmpHis3RLvl1_TelepnoneNo = value;
            }
        }

        private string strEmpHis3RLvl1_MobileNo;
        public string EmpHis3RLvl1_MobileNo
        {
            get
            {
                return strEmpHis3RLvl1_MobileNo;
            }
            set
            {
                strEmpHis3RLvl1_MobileNo = value;
            }
        }
        private string strEmpHis3RLvl1_EmailId;

        public string EmpHis3RLvl1_EmailId
        {
            get
            {
                return strEmpHis3RLvl1_EmailId;
            }
            set
            {
                strEmpHis3RLvl1_EmailId = value;
            }

        }
        private string strEmpHis3RLvl2_NameDesignatinOfSupervisor;
        public string EmpHis3RLvl2_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis3RLvl2_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis3RLvl2_NameDesignatinOfSupervisor = value;
            }

        }
        private string strEmpHis3RLvl2_TelepnoneNo;
        public string EmpHis3RLvl2_TelepnoneNo
        {
            get
            {
                return strEmpHis3RLvl2_TelepnoneNo;
            }
            set
            {
                strEmpHis3RLvl2_TelepnoneNo = value;
            }

        }

        private string strEmpHis3RLvl2_MobileNo;
        public string EmpHis3RLvl2_MobileNo
        {
            get
            {
                return strEmpHis3RLvl2_MobileNo;
            }
            set
            {
                strEmpHis3RLvl2_MobileNo = value;
            }


        }

        private string strEmpHis3RLvl2_EmailId;
        public string EmpHis3RLvl2_EmailId
        {
            get
            {
                return strEmpHis3RLvl2_EmailId;
            }
            set
            {
                strEmpHis3RLvl2_EmailId = value;
            }

        }
        private string strEmpHis3_TempPerma;
        public string EmpHis3_TempPerma
        {
            get
            {
                return strEmpHis3_TempPerma;
            }
            set
            {
                strEmpHis3_TempPerma = value;
            }

        }

        private string strEmpHis3_AgencyDetails;
        public string EmpHis3_AgencyDetails
        {
            get
            {
                return strEmpHis3_AgencyDetails;

            }
            set
            {
                strEmpHis3_AgencyDetails = value;
            }
        }
        private string strEmpHis3_RemunerationOrSalary;
        public string EmpHis3_RemunerationOrSalary
        {
            get
            {
                return strEmpHis3_RemunerationOrSalary;

            }
            set
            {
                strEmpHis3_RemunerationOrSalary = value;
            }
        }

        private string strEmpHis3_ReasonOfLeaving;
        public string EmpHis3_ReasonOfLeaving
        {
            get
            {
                return strEmpHis3_ReasonOfLeaving;

            }
            set
            {
                strEmpHis3_ReasonOfLeaving = value;
            }
        }
        private string strEmpHis3_referenceYN;
        public string EmpHis3_referenceYN
        {
            get
            {
                return strEmpHis3_referenceYN;
            }
            set
            {
                strEmpHis3_referenceYN = value;
            }
        }
        private string strEmpHis3_IncaseOfGap;
        public string EmpHis3_IncaseOfGap
        {
            get
            {
                return strEmpHis3_IncaseOfGap;
            }
            set
            {
                strEmpHis3_IncaseOfGap = value;
            }
        }


        public string ExperienceInYears3
        {
            get
            {
                return strExperienceInYears3;

            }
            set
            {
                strExperienceInYears3 = value;
            }

        }

        private string strReportingLevel2emp3;
        public string ReportingLevel2emp3
        {
            get
            {
                return strReportingLevel2emp3;
            }
            set
            {
                strReportingLevel2emp3 = value;
            }

        }

        //For company 4
        private string strEmpHis4_CompnayNameandLocation;
        public string EmpHis4_CompnayNameandLocation
        {
            get
            {
                return strEmpHis4_CompnayNameandLocation;
            }
            set
            {
                strEmpHis4_CompnayNameandLocation = value;
            }
        }

        private string strEmpHis4_LastPositionHeldnDepartmentName;
        public string EmpHis4_LastPositionHeldnDepartmentName
        {
            get
            {
                return strEmpHis4_LastPositionHeldnDepartmentName;

            }
            set
            {
                strEmpHis4_LastPositionHeldnDepartmentName = value;

            }
        }

        private string strEmpHis4_TelephoneNo;
        public string EmpHis4_TelephoneNo
        {
            get
            {
                return strEmpHis4_TelephoneNo;
            }
            set
            {
                strEmpHis4_TelephoneNo = value;

            }
        }
        private string strEmpHis4_Address;
        public string EmpHis4_Address
        {
            get
            {
                return strEmpHis4_Address;
            }
            set
            {
                strEmpHis4_Address = value;
            }
        }

        private string strEmpHis4_EmployeeCode;
        public string EmpHis4_EmployeeCode
        {
            get
            {
                return strEmpHis4_EmployeeCode;
            }
            set
            {
                strEmpHis4_EmployeeCode = value;
            }
        }
        private string strEmpHis4_PeriodofEmployment;
        public string EmpHis4_PeriodofEmployment
        {
            get
            {
                return strEmpHis4_PeriodofEmployment;
            }
            set
            {
                strEmpHis4_PeriodofEmployment = value;
            }
        }
        private string strdatetoempHis4;
        public string datetoempHis4
        {
            get
            {
                return strdatetoempHis4;
            }
            set
            {
                strdatetoempHis4 = value;
            }

        }
        private string strEmpHis4_PeriodofEmploymentRemark;
        public string EmpHis4_PeriodofEmploymentRemark
        {
            get
            {
                return strEmpHis4_PeriodofEmploymentRemark;
            }
            set
            {
                strEmpHis4_PeriodofEmploymentRemark = value;
            }
        }
        private string strEmpHis4RLvl1_NameDesignatinOfSupervisor;
        public string EmpHis4RLvl1_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis4RLvl1_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis4RLvl1_NameDesignatinOfSupervisor = value;
            }
        }

        private string strEmpHis4RLvl1_TelepnoneNo;
        public string EmpHis4RLvl1_TelepnoneNo
        {
            get
            {
                return strEmpHis4RLvl1_TelepnoneNo;
            }
            set
            {
                strEmpHis4RLvl1_TelepnoneNo = value;
            }
        }

        private string strEmpHis4RLvl1_MobileNo;
        public string EmpHis4RLvl1_MobileNo
        {
            get
            {
                return strEmpHis4RLvl1_MobileNo;
            }
            set
            {
                strEmpHis4RLvl1_MobileNo = value;
            }
        }
        private string strEmpHis4RLvl1_EmailId;

        public string EmpHis4RLvl1_EmailId
        {
            get
            {
                return strEmpHis4RLvl1_EmailId;
            }
            set
            {
                strEmpHis4RLvl1_EmailId = value;
            }

        }
        private string strEmpHis4RLvl2_NameDesignatinOfSupervisor;
        public string EmpHis4RLvl2_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis4RLvl2_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis4RLvl2_NameDesignatinOfSupervisor = value;
            }

        }
        private string strEmpHis4RLvl2_TelepnoneNo;
        public string EmpHis4RLvl2_TelepnoneNo
        {
            get
            {
                return strEmpHis4RLvl2_TelepnoneNo;
            }
            set
            {
                strEmpHis4RLvl2_TelepnoneNo = value;
            }

        }

        private string strEmpHis4RLvl2_MobileNo;
        public string EmpHis4RLvl2_MobileNo
        {
            get
            {
                return strEmpHis4RLvl2_MobileNo;
            }
            set
            {
                strEmpHis4RLvl2_MobileNo = value;
            }


        }

        private string strEmpHis4RLvl2_EmailId;
        public string EmpHis4RLvl2_EmailId
        {
            get
            {
                return strEmpHis4RLvl2_EmailId;
            }
            set
            {
                strEmpHis4RLvl2_EmailId = value;
            }

        }
        private string strEmpHis4_TempPerma;
        public string EmpHis4_TempPerma
        {
            get
            {
                return strEmpHis4_TempPerma;
            }
            set
            {
                strEmpHis4_TempPerma = value;
            }

        }

        private string strEmpHis4_AgencyDetails;
        public string EmpHis4_AgencyDetails
        {
            get
            {
                return strEmpHis4_AgencyDetails;

            }
            set
            {
                strEmpHis4_AgencyDetails = value;
            }
        }
        private string strEmpHis4_RemunerationOrSalary;
        public string EmpHis4_RemunerationOrSalary
        {
            get
            {
                return strEmpHis4_RemunerationOrSalary;

            }
            set
            {
                strEmpHis4_RemunerationOrSalary = value;
            }
        }

        private string strEmpHis4_ReasonOfLeaving;
        public string EmpHis4_ReasonOfLeaving
        {
            get
            {
                return strEmpHis4_ReasonOfLeaving;

            }
            set
            {
                strEmpHis4_ReasonOfLeaving = value;
            }
        }
        private string strEmpHis4_referenceYN;
        public string EmpHis4_referenceYN
        {
            get
            {
                return strEmpHis4_referenceYN;
            }
            set
            {
                strEmpHis4_referenceYN = value;
            }
        }
        private string strEmpHis4_IncaseOfGap;
        public string EmpHis4_IncaseOfGap
        {
            get
            {
                return strEmpHis4_IncaseOfGap;
            }
            set
            {
                strEmpHis4_IncaseOfGap = value;
            }
        }


        public string ExperienceInYears4
        {
            get
            {
                return strExperienceInYears4;

            }
            set
            {
                strExperienceInYears4 = value;
            }

        }

        private string strReportingLevel2emp4;
        public string ReportingLevel2emp4
        {
            get
            {
                return strReportingLevel2emp4;
            }
            set
            {
                strReportingLevel2emp4 = value;
            }

        }


        //For comapny 5
        private string strEmpHis5_CompnayNameandLocation;
        public string EmpHis5_CompnayNameandLocation
        {
            get
            {
                return strEmpHis5_CompnayNameandLocation;
            }
            set
            {
                strEmpHis5_CompnayNameandLocation = value;
            }
        }

        private string strEmpHis5_LastPositionHeldnDepartmentName;
        public string EmpHis5_LastPositionHeldnDepartmentName
        {
            get
            {
                return strEmpHis5_LastPositionHeldnDepartmentName;

            }
            set
            {
                strEmpHis5_LastPositionHeldnDepartmentName = value;

            }
        }

        private string strEmpHis5_TelephoneNo;
        public string EmpHis5_TelephoneNo
        {
            get
            {
                return strEmpHis5_TelephoneNo;
            }
            set
            {
                strEmpHis5_TelephoneNo = value;

            }
        }
        private string strEmpHis5_Address;
        public string EmpHis5_Address
        {
            get
            {
                return strEmpHis5_Address;
            }
            set
            {
                strEmpHis5_Address = value;
            }
        }

        private string strEmpHis5_EmployeeCode;
        public string EmpHis5_EmployeeCode
        {
            get
            {
                return strEmpHis5_EmployeeCode;
            }
            set
            {
                strEmpHis5_EmployeeCode = value;
            }
        }
        private string strEmpHis5_PeriodofEmployment;
        public string EmpHis5_PeriodofEmployment
        {
            get
            {
                return strEmpHis5_PeriodofEmployment;
            }
            set
            {
                strEmpHis5_PeriodofEmployment = value;
            }
        }
        private string strdatetoempHis5;
        public string datetoempHis5
        {
            get
            {
                return strdatetoempHis5;
            }
            set
            {
                strdatetoempHis5 = value;
            }

        }
        private string strEmpHis5_PeriodofEmploymentRemark;
        public string EmpHis5_PeriodofEmploymentRemark
        {
            get
            {
                return strEmpHis5_PeriodofEmploymentRemark;
            }
            set
            {
                strEmpHis5_PeriodofEmploymentRemark = value;
            }
        }
        private string strEducationList;
        public string EducationList
        {
            get
            {
                return strEducationList;
            }
            set
            {
                strEducationList = value;
            }
        }
        private string strEmpHis5RLvl1_NameDesignatinOfSupervisor;
        public string EmpHis5RLvl1_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis5RLvl1_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis5RLvl1_NameDesignatinOfSupervisor = value;
            }
        }

        private string strEmpHis5RLvl1_TelepnoneNo;
        public string EmpHis5RLvl1_TelepnoneNo
        {
            get
            {
                return strEmpHis5RLvl1_TelepnoneNo;
            }
            set
            {
                strEmpHis5RLvl1_TelepnoneNo = value;
            }
        }

        private string strEmpHis5RLvl1_MobileNo;
        public string EmpHis5RLvl1_MobileNo
        {
            get
            {
                return strEmpHis5RLvl1_MobileNo;
            }
            set
            {
                strEmpHis5RLvl1_MobileNo = value;
            }
        }
        private string strEmpHis5RLvl1_EmailId;

        public string EmpHis5RLvl1_EmailId
        {
            get
            {
                return strEmpHis5RLvl1_EmailId;
            }
            set
            {
                strEmpHis5RLvl1_EmailId = value;
            }

        }
        private string strEmpHis5RLvl2_NameDesignatinOfSupervisor;
        public string EmpHis5RLvl2_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis5RLvl2_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis5RLvl2_NameDesignatinOfSupervisor = value;
            }

        }
        private string strEmpHis5RLvl2_TelepnoneNo;
        public string EmpHis5RLvl2_TelepnoneNo
        {
            get
            {
                return strEmpHis5RLvl2_TelepnoneNo;
            }
            set
            {
                strEmpHis5RLvl2_TelepnoneNo = value;
            }

        }

        private string strEmpHis5RLvl2_MobileNo;
        public string EmpHis5RLvl2_MobileNo
        {
            get
            {
                return strEmpHis5RLvl2_MobileNo;
            }
            set
            {
                strEmpHis5RLvl2_MobileNo = value;
            }


        }

        private string strEmpHis5RLvl2_EmailId;
        public string EmpHis5RLvl2_EmailId
        {
            get
            {
                return strEmpHis5RLvl2_EmailId;
            }
            set
            {
                strEmpHis5RLvl2_EmailId = value;
            }

        }
        private string strEmpHis5_TempPerma;
        public string EmpHis5_TempPerma
        {
            get
            {
                return strEmpHis5_TempPerma;
            }
            set
            {
                strEmpHis5_TempPerma = value;
            }

        }

        private string strEmpHis5_AgencyDetails;
        public string EmpHis5_AgencyDetails
        {
            get
            {
                return strEmpHis5_AgencyDetails;

            }
            set
            {
                strEmpHis5_AgencyDetails = value;
            }
        }
        private string strEmpHis5_RemunerationOrSalary;
        public string EmpHis5_RemunerationOrSalary
        {
            get
            {
                return strEmpHis5_RemunerationOrSalary;

            }
            set
            {
                strEmpHis5_RemunerationOrSalary = value;
            }
        }

        private string strEmpHis5_ReasonOfLeaving;
        public string EmpHis5_ReasonOfLeaving
        {
            get
            {
                return strEmpHis5_ReasonOfLeaving;

            }
            set
            {
                strEmpHis5_ReasonOfLeaving = value;
            }
        }
        private string strEmpHis5_referenceYN;
        public string EmpHis5_referenceYN
        {
            get
            {
                return strEmpHis5_referenceYN;
            }
            set
            {
                strEmpHis5_referenceYN = value;
            }
        }
        private string strEmpHis5_IncaseOfGap;
        public string EmpHis5_IncaseOfGap
        {
            get
            {
                return strEmpHis5_IncaseOfGap;
            }
            set
            {
                strEmpHis5_IncaseOfGap = value;
            }
        }


        public string ExperienceInYears5
        {
            get
            {
                return strExperienceInYears5;

            }
            set
            {
                strExperienceInYears5 = value;
            }

        }

        private string strReportingLevel2emp5;
        public string ReportingLevel2emp5
        {
            get
            {
                return strReportingLevel2emp5;
            }
            set
            {
                strReportingLevel2emp5 = value;
            }

        }




        //company 2


        public string ExperienceInYears2
        {
            get
            {
                return strExperienceInYears2;

            }
            set
            {
                strExperienceInYears2 = value;
            }

        }








        //  private string strb;



        public string CurrentAddress
        {
            get
            {
                return strCurrentAddress;
            }
            set
            {
                strCurrentAddress = value;
            }
        }
        public string EmpHis1_CompnayNameandLocation
        {
            get
            {
                return strEmpHis1_CompnayNameandLocation;
            }
            set
            {
                strEmpHis1_CompnayNameandLocation = value;
            }
        }
        public string EmpHis2_EmployeeCode
        {
            get
            {
                return strEmpHis2_EmployeeCode;
            }
            set
            {
                strEmpHis2_EmployeeCode = value;
            }
        }
        public string EmpHis1RLvl2_TelepnoneNo
        {
            get
            {
                return strEmpHis1RLvl2_TelepnoneNo;
            }
            set
            {
                strEmpHis1RLvl2_TelepnoneNo = value;
            }
        }
        public string EmpHis2RLvl2_MobileNo
        {
            get
            {
                return strEmpHis2RLvl2_MobileNo;
            }
            set
            {
                strEmpHis2RLvl2_MobileNo = value;
            }
        }
        public string EmpHis1RLvl2_MobileNo
        {
            get
            {
                return strEmpHis1RLvl2_MobileNo;
            }
            set
            {
                strEmpHis1RLvl2_MobileNo = value;
            }
        }
        public string Per_LivingSince
        {
            get
            {
                return strPer_LivingSince;
            }
            set
            {
                strPer_LivingSince = value;
            }
        }
        public string EmpHis1_EmployeeCode
        {
            get
            {
                return strEmpHis1_EmployeeCode;
            }
            set
            {
                strEmpHis1_EmployeeCode = value;
            }
        }
        public string TAT2
        {
            get
            {
                return strTAT2;
            }
            set
            {
                strTAT2 = value;
            }
        }
        public string EmpHis2RLvl1_TelepnoneNo
        {
            get
            {
                return strEmpHis2RLvl1_TelepnoneNo;
            }
            set
            {
                strEmpHis2RLvl1_TelepnoneNo = value;
            }
        }
        public string Edu1_Address
        {
            get
            {
                return strEdu1_Address;
            }
            set
            {
                strEdu1_Address = value;
            }
        }
        public string DateofJoining
        {
            get
            {
                return strDateofJoining;
            }
            set
            {
                strDateofJoining = value;
            }
        }

        

        public string Vender
        {
            get
            {
                return strVendor;
            }
            set
            {
                strVendor = value;
            }
        }
        public string Month
        {
            get
            {
                return strMonth;
            }
            set
            {
                strMonth = value;
            }
        }
        public string DCSV
        {
            get
            {
                return strDCSV;
            }
            set
            {
                strDCSV = value;
            }
        }
        public string DDV
        {
            get
            {
                return strDDV;
            }
            set
            {
                strDDV = value;
            }
        }
        public string DVR
        {
            get
            {
                return strDVR;
            }
            set
            {
                strDVR = value;
            }
        }
        public string DVU
        {
            get
            {
                return strDVU;
            }
            set
            {
                strDVU = value;
            }
        }
        //objEmpInfo.Vendor = myds.Tables[0].Rows[i][12].ToString().Trim();
        //objEmpInfo.Month = myds.Tables[0].Rows[i][13].ToString().Trim();              
        //objEmpInfo.DCSV = myds.Tables[0].Rows[i][15].ToString().Trim();
        //objEmpInfo.DDV = myds.Tables[0].Rows[i][16].ToString().Trim();
        //objEmpInfo.DVR = myds.Tables[0].Rows[i][17].ToString().Trim();
        //objEmpInfo.DVU = myds.Tables[0].Rows[i][18].ToString().Trim();


        public string TATDate
        {
            get
            {
                return strTATDate;
            }
            set
            {
                strTATDate = value;
            }
        }

        public string EmpHis1_TelephoneNo
        {
            get
            {
                return strEmpHis1_TelephoneNo;
            }
            set
            {
                strEmpHis1_TelephoneNo = value;
            }
        }
        public string EmpHis2RLvl2_TelepnoneNo
        {
            get
            {
                return strEmpHis2RLvl2_TelepnoneNo;
            }
            set
            {
                strEmpHis2RLvl2_TelepnoneNo = value;
            }
        }
        public string EmpHis2_IncaseOfGap
        {
            get
            {
                return strEmpHis2_IncaseOfGap;
            }
            set
            {
                strEmpHis2_IncaseOfGap = value;
            }
        }
        public string EmpHis2RLvl1_EmailId
        {
            get
            {
                return strEmpHis2RLvl1_EmailId;
            }
            set
            {
                strEmpHis2RLvl1_EmailId = value;
            }
        }
        public string Edu1_UniversityName
        {
            get
            {
                return strEdu1_UniversityName;
            }
            set
            {
                strEdu1_UniversityName = value;
            }
        }

        public string Education1State
        {
            get
            {
                return strEducation1State;
            }
            set
            {
                strEducation1State = value;
            }
        }

        public string Per_Landmark
        {
            get
            {
                return strPer_Landmark;
            }
            set
            {
                strPer_Landmark = value;
            }
        }
        public string EmpHis2_AgencyDetails
        {
            get
            {
                return strEmpHis2_AgencyDetails;
            }
            set
            {
                strEmpHis2_AgencyDetails = value;
            }
        }
        public string EmpHis1_referenceYN
        {
            get
            {
                return strEmpHis1_referenceYN;
            }
            set
            {
                strEmpHis1_referenceYN = value;
            }
        }
        public string Per_PostOffice
        {
            get
            {
                return strPer_PostOffice;
            }
            set
            {
                strPer_PostOffice = value;
            }
        }
        public string FatherName
        {
            get
            {
                return strFatherName;
            }
            set
            {
                strFatherName = value;
            }
        }
        public string EmpHis1_LastPositionHeldnDepartmentName
        {
            get
            {
                return strEmpHis1_LastPositionHeldnDepartmentName;
            }
            set
            {
                strEmpHis1_LastPositionHeldnDepartmentName = value;
            }
        }
        public string EmpHis2_CompnayNameandLocation
        {
            get
            {
                return strEmpHis2_CompnayNameandLocation;
            }
            set
            {
                strEmpHis2_CompnayNameandLocation = value;
            }
        }
        public string EmpHis1_PeriodofEmployment
        {
            get
            {
                return strEmpHis1_PeriodofEmployment;
            }
            set
            {
                strEmpHis1_PeriodofEmployment = value;
            }
        }


        public string datetoemphis1  // chng 
        {
            get
            {
                return strdatetoemphis1;
            }
            set
            {
                strdatetoemphis1 = value;
            }
        }


        public string DOB
        {
            get
            {
                return strDOB;
            }
            set
            {
                strDOB = value;
            }
        }

        private string strEmpid;
        public string Empid
        {
            get
            {
                return strEmpid;
            }
            set
            {
                strEmpid = value;
            }
        }

        public string EmpHis2_referenceYN
        {
            get
            {
                return strEmpHis2_referenceYN;
            }
            set
            {
                strEmpHis2_referenceYN = value;
            }
        }
        public string Edu1_RollNo
        {
            get
            {
                return strEdu1_RollNo;
            }
            set
            {
                strEdu1_RollNo = value;
            }
        }
        public string EmpHis1RLvl1_MobileNo
        {
            get
            {
                return strEmpHis1RLvl1_MobileNo;
            }
            set
            {
                strEmpHis1RLvl1_MobileNo = value;
            }
        }
        public string EmpHis1_TempPerma
        {
            get
            {
                return strEmpHis1_TempPerma;
            }
            set
            {
                strEmpHis1_TempPerma = value;
            }
        }
        public string EmpHis2_Address
        {
            get
            {
                return strEmpHis2_Address;
            }
            set
            {
                strEmpHis2_Address = value;
            }
        }
        public string EmpHis1_PeriodofEmploymentRemark
        {
            get
            {
                return strEmpHis1_PeriodofEmploymentRemark;
            }
            set
            {
                strEmpHis1_PeriodofEmploymentRemark = value;
            }
        }
        public string EmpHis1_IncaseOfGap
        {
            get
            {
                return strEmpHis1_IncaseOfGap;
            }
            set
            {
                strEmpHis1_IncaseOfGap = value;
            }
        }
        public string EmpHis2_TempPerma
        {
            get
            {
                return strEmpHis2_TempPerma;
            }
            set
            {
                strEmpHis2_TempPerma = value;
            }
        }
        public string EmpHis1RLvl2_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis1RLvl2_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis1RLvl2_NameDesignatinOfSupervisor = value;
            }
        }
        public string EmpHis2RLvl1_MobileNo
        {
            get
            {
                return strEmpHis2RLvl1_MobileNo;
            }
            set
            {
                strEmpHis2RLvl1_MobileNo = value;
            }
        }
        public string MiddleName
        {
            get
            {
                return strMiddleName;
            }
            set
            {
                strMiddleName = value;
            }
        }
        public string Edu1_CollegeName
        {
            get
            {
                return strEdu1_CollegeName;
            }
            set
            {
                strEdu1_CollegeName = value;
            }
        }
        public string EmpHis2RLvl2_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis2RLvl2_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis2RLvl2_NameDesignatinOfSupervisor = value;
            }
        }
        public string EmpHis1_AgencyDetails
        {
            get
            {
                return strEmpHis1_AgencyDetails;
            }
            set
            {
                strEmpHis1_AgencyDetails = value;
            }
        }
        public string EmpHis2RLvl1_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis2RLvl1_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis2RLvl1_NameDesignatinOfSupervisor = value;
            }
        }
        public string FirstName
        {
            get
            {
                return strFirstName;
            }
            set
            {
                strFirstName = value;
            }
        }
        public string Per_AddressPhoneNo
        {
            get
            {
                return strPer_AddressPhoneNo;
            }
            set
            {
                strPer_AddressPhoneNo = value;
            }
        }
        public string EmpHis2_PeriodofEmployment
        {
            get
            {
                return strEmpHis2_PeriodofEmployment;
            }
            set
            {
                strEmpHis2_PeriodofEmployment = value;
            }
        }

        public string datetoemphis2  // chng
        {
            get
            {
                return strdatetoemphis2;
            }
            set
            {
                strdatetoemphis2 = value;
            }
        }

        public string EmpHis2RLvl2_EmailId
        {
            get
            {
                return strEmpHis2RLvl2_EmailId;
            }
            set
            {
                strEmpHis2RLvl2_EmailId = value;
            }
        }
        public string COE
        {
            get
            {
                return strCOE;
            }
            set
            {
                strCOE = value;
            }
        }

        public string SNo
        {
            get
            {
                return strSNo;
            }
            set
            {
                strSNo = value;
            }
        }



        public string Mobile
        {
            get
            {
                return strMobile;
            }
            set
            {
                strMobile = value;
            }
        }
        public string Per_City
        {
            get
            {
                return strPer_City;
            }
            set
            {
                strPer_City = value;
            }
        }
        public string Curr_PhoneNo
        {
            get
            {
                return strCurr_PhoneNo;
            }
            set
            {
                strCurr_PhoneNo = value;
            }
        }
        public string EmpHis2_LastPositionHeldnDepartmentName
        {
            get
            {
                return strEmpHis2_LastPositionHeldnDepartmentName;
            }
            set
            {
                strEmpHis2_LastPositionHeldnDepartmentName = value;
            }
        }
        public string EmpHis1_Address
        {
            get
            {
                return strEmpHis1_Address;
            }
            set
            {
                strEmpHis1_Address = value;
            }
        }
        public string Edu1_EducationalQualification
        {
            get
            {
                return strEdu1_EducationalQualification;
            }
            set
            {
                strEdu1_EducationalQualification = value;
            }
        }
        public string EmpHis1RLvl1_EmailId
        {
            get
            {
                return strEmpHis1RLvl1_EmailId;
            }
            set
            {
                strEmpHis1RLvl1_EmailId = value;
            }
        }
        public string InDate
        {
            get
            {
                return strInDate;
            }
            set
            {
                strInDate = value;
            }
        }
        public string Per_PoliceStation
        {
            get
            {
                return strPer_PoliceStation;
            }
            set
            {
                strPer_PoliceStation = value;
            }
        }
        public string EmpHis2_TelephoneNo
        {
            get
            {
                return strEmpHis2_TelephoneNo;
            }
            set
            {
                strEmpHis2_TelephoneNo = value;
            }
        }
        public string EmpHis1_ReasonOfLeaving
        {
            get
            {
                return strEmpHis1_ReasonOfLeaving;
            }
            set
            {
                strEmpHis1_ReasonOfLeaving = value;
            }
        }
        public string EmpHis1_RemunerationOrSalary
        {
            get
            {
                return strEmpHis1_RemunerationOrSalary;
            }
            set
            {
                strEmpHis1_RemunerationOrSalary = value;
            }
        }
        public string EnteredByLoginIdType
        {
            get
            {
                return strEnteredByLoginIdType;
            }
            set
            {
                strEnteredByLoginIdType = value;
            }
        }
        public string Band
        {
            get
            {
                return strBand;
            }
            set
            {
                strBand = value;
            }
        }
        public string EmpHis2_ReasonOfLeaving
        {
            get
            {
                return strEmpHis2_ReasonOfLeaving;
            }
            set
            {
                strEmpHis2_ReasonOfLeaving = value;
            }
        }
        public string Per_State
        {
            get
            {
                return strPer_State;
            }
            set
            {
                strPer_State = value;
            }
        }
        public string EmpIdProvidedByClient
        {
            get
            {
                return strEmpIdProvidedByClient;
            }
            set
            {
                strEmpIdProvidedByClient = value;
            }
        }
        public string PlaceofBirth
        {
            get
            {
                return strPlaceofBirth;
            }
            set
            {
                strPlaceofBirth = value;
            }
        }
        public string Surname
        {
            get
            {
                return strSurname;
            }
            set
            {
                strSurname = value;
            }
        }
        public string ExperienceInYears1
        {
            get
            {
                return strExperienceInYears1;
            }
            set
            {
                strExperienceInYears1 = value;
            }
        }


        public string PermanentAddress
        {
            get
            {
                return strPermanentAddress;
            }
            set
            {
                strPermanentAddress = value;
            }
        }
        public string Curr_City
        {
            get
            {
                return strCurr_City;
            }
            set
            {
                strCurr_City = value;
            }
        }
        public string EmpHis2_RemunerationOrSalary
        {
            get
            {
                return strEmpHis2_RemunerationOrSalary;
            }
            set
            {
                strEmpHis2_RemunerationOrSalary = value;
            }
        }
        //public int EmployeeID
        //{
        //    get
        //    {
        //        return intEmployeeID;
        //    }
        //    set
        //    {
        //        intEmployeeID = value;
        //    }
        //}
        public string Curr_State
        {
            get
            {
                return strCurr_State;
            }
            set
            {
                strCurr_State = value;
            }
        }
        public string EmpHis1RLvl1_TelepnoneNo
        {
            get
            {
                return strEmpHis1RLvl1_TelepnoneNo;
            }
            set
            {
                strEmpHis1RLvl1_TelepnoneNo = value;
            }
        }
        public string EmpHis1RLvl2_EmailId
        {
            get
            {
                return strEmpHis1RLvl2_EmailId;
            }
            set
            {
                strEmpHis1RLvl2_EmailId = value;
            }
        }
        public string EmpHis2_PeriodofEmploymentRemark
        {
            get
            {
                return strEmpHis2_PeriodofEmploymentRemark;
            }
            set
            {
                strEmpHis2_PeriodofEmploymentRemark = value;
            }
        }
        public string EmpHis1RLvl1_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis1RLvl1_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis1RLvl1_NameDesignatinOfSupervisor = value;
            }
        }
        public string Edu1_YearOfPassing
        {
            get
            {
                return strEdu1_YearOfPassing;
            }
            set
            {
                strEdu1_YearOfPassing = value;
            }
        }
        public int EmployeeID
        {
            get
            {
                return strEmployeeId;
            }
            set
            {
                strEmployeeId = value;
            }
        }
        public int CandidateID
        {
            get
            {
                return strCandidateId;
            }
            set
            {
                strCandidateId = value;
            }
        }

        //public string EmployeeIDProvidedByClient
        //{
        //    get
        //    {
        //        return strEmployeeIDProvidedByClient;
        //    }
        //    set
        //    {
        //        strEmployeeIDProvidedByClient = value;
        //    }
        //}


        public string Mode
        {
            get
            {
                return strMode;
            }
            set
            {
                strMode = value;
            }
        }
        //Education2





        private string strYearOfPassing2;
        public string YearOfPassing2
        {
            get
            {
                return strYearOfPassing2;
            }
            set
            {
                strYearOfPassing2 = value;
            }
        }
        //Education3
        private string strEdu3_CollegeName;
        public string Edu3_CollegeName
        {
            get
            {
                return strEdu3_CollegeName;
            }
            set
            {
                strEdu3_CollegeName = value;
            }
        }

        private string strEdu3_UniversityName;
        public string Edu3_UniversityName
        {
            get
            {
                return strEdu3_UniversityName;
            }
            set
            {
                strEdu3_UniversityName = value;
            }
        }

        private string strEdu3_Address;
        public string Edu3_Address
        {
            get
            {
                return strEdu3_Address;
            }
            set
            {
                strEdu3_Address = value;
            }
        }



        private string strEdu3_EducationalQualification;
        public string Edu3_EducationalQualification
        {
            get
            {
                return strEdu3_EducationalQualification;
            }
            set
            {
                strEdu3_EducationalQualification = value;
            }
        }
        private string strEdu3_RollNo;
        public string Edu3_RollNo
        {
            get
            {
                return strEdu3_RollNo;
            }
            set
            {
                strEdu3_RollNo = value;
            }
        }


        private string strYearOfPassing3;
        public string YearOfPassing3
        {
            get
            {
                return strYearOfPassing3;
            }
            set
            {
                strYearOfPassing3 = value;
            }
        }
        //Education4
        private string strEdu4_CollegeName;
        public string Edu4_CollegeName
        {
            get
            {
                return strEdu4_CollegeName;
            }
            set
            {
                strEdu4_CollegeName = value;
            }
        }

        private string strEdu4_UniversityName;
        public string Edu4_UniversityName
        {
            get
            {
                return strEdu4_UniversityName;
            }
            set
            {
                strEdu4_UniversityName = value;
            }
        }

        private string strEdu4_Address;
        public string Edu4_Address
        {
            get
            {
                return strEdu4_Address;
            }
            set
            {
                strEdu4_Address = value;
            }
        }



        private string strEdu4_EducationalQualification;
        public string Edu4_EducationalQualification
        {
            get
            {
                return strEdu4_EducationalQualification;
            }
            set
            {
                strEdu4_EducationalQualification = value;
            }
        }
        private string strEdu4_RollNo;
        public string Edu4_RollNo
        {
            get
            {
                return strEdu4_RollNo;
            }
            set
            {
                strEdu4_RollNo = value;
            }
        }


        private string strYearOfPassing4;
        public string YearOfPassing4
        {
            get
            {
                return strYearOfPassing4;
            }
            set
            {
                strYearOfPassing4 = value;
            }
        }

        //Education5
        private string strEdu5_CollegeName;
        public string Edu5_CollegeName
        {
            get
            {
                return strEdu5_CollegeName;
            }
            set
            {
                strEdu5_CollegeName = value;
            }
        }

        private string strEdu5_UniversityName;
        public string Edu5_UniversityName
        {
            get
            {
                return strEdu5_UniversityName;
            }
            set
            {
                strEdu5_UniversityName = value;
            }
        }

        private string strEdu5_Address;
        public string Edu5_Address
        {
            get
            {
                return strEdu5_Address;
            }
            set
            {
                strEdu5_Address = value;
            }
        }



        private string strEdu5_EducationalQualification;
        public string Edu5_EducationalQualification
        {
            get
            {
                return strEdu5_EducationalQualification;
            }
            set
            {
                strEdu5_EducationalQualification = value;
            }
        }
        private string strEdu5_RollNo;
        public string Edu5_RollNo
        {
            get
            {
                return strEdu5_RollNo;
            }
            set
            {
                strEdu5_RollNo = value;
            }
        }


        private string strYearOfPassing5;
        public string YearOfPassing5
        {
            get
            {
                return strYearOfPassing5;
            }
            set
            {
                strYearOfPassing5 = value;
            }
        }

        //Education6
        private string strEdu6_CollegeName;
        public string Edu6_CollegeName
        {
            get
            {
                return strEdu6_CollegeName;
            }
            set
            {
                strEdu6_CollegeName = value;
            }
        }

        private string strEdu6_UniversityName;
        public string Edu6_UniversityName
        {
            get
            {
                return strEdu6_UniversityName;
            }
            set
            {
                strEdu6_UniversityName = value;
            }
        }

        private string strEdu6_Address;
        public string Edu6_Address
        {
            get
            {
                return strEdu6_Address;
            }
            set
            {
                strEdu6_Address = value;
            }
        }



        private string strEdu6_EducationalQualification;
        public string Edu6_EducationalQualification
        {
            get
            {
                return strEdu6_EducationalQualification;
            }
            set
            {
                strEdu6_EducationalQualification = value;
            }
        }
        private string strEdu6_RollNo;
        public string Edu6_RollNo
        {
            get
            {
                return strEdu6_RollNo;
            }
            set
            {
                strEdu6_RollNo = value;
            }
        }


        private string strYearOfPassing6;
        public string YearOfPassing6
        {
            get
            {
                return strYearOfPassing6;
            }
            set
            {
                strYearOfPassing6 = value;
            }
        }

        //Education7
        private string strEdu7_CollegeName;
        public string Edu7_CollegeName
        {
            get
            {
                return strEdu7_CollegeName;
            }
            set
            {
                strEdu7_CollegeName = value;
            }
        }

        private string strEdu7_UniversityName;
        public string Edu7_UniversityName
        {
            get
            {
                return strEdu7_UniversityName;
            }
            set
            {
                strEdu7_UniversityName = value;
            }
        }

        private string strEdu7_Address;
        public string Edu7_Address
        {
            get
            {
                return strEdu7_Address;
            }
            set
            {
                strEdu7_Address = value;
            }
        }



        private string strEdu7_EducationalQualification;
        public string Edu7_EducationalQualification
        {
            get
            {
                return strEdu7_EducationalQualification;
            }
            set
            {
                strEdu7_EducationalQualification = value;
            }
        }
        private string strEdu7_RollNo;
        public string Edu7_RollNo
        {
            get
            {
                return strEdu7_RollNo;
            }
            set
            {
                strEdu7_RollNo = value;
            }
        }


        private string strYearOfPassing7;
        public string YearOfPassing7
        {
            get
            {
                return strYearOfPassing7;
            }
            set
            {
                strYearOfPassing7 = value;
            }
        }

        //Education7
        private string strEdu8_CollegeName;
        public string Edu8_CollegeName
        {
            get
            {
                return strEdu8_CollegeName;
            }
            set
            {
                strEdu8_CollegeName = value;
            }
        }

        private string strEdu8_UniversityName;
        public string Edu8_UniversityName
        {
            get
            {
                return strEdu8_UniversityName;
            }
            set
            {
                strEdu8_UniversityName = value;
            }
        }

        private string strEdu8_Address;
        public string Edu8_Address
        {
            get
            {
                return strEdu8_Address;
            }
            set
            {
                strEdu8_Address = value;
            }
        }



        private string strEdu8_EducationalQualification;
        public string Edu8_EducationalQualification
        {
            get
            {
                return strEdu8_EducationalQualification;
            }
            set
            {
                strEdu8_EducationalQualification = value;
            }
        }
        private string strEdu8_RollNo;
        public string Edu8_RollNo
        {
            get
            {
                return strEdu8_RollNo;
            }
            set
            {
                strEdu8_RollNo = value;
            }
        }


        private string strYearOfPassing8;
        public string YearOfPassing8
        {
            get
            {
                return strYearOfPassing8;
            }
            set
            {
                strYearOfPassing8 = value;
            }
        }

        private string strUserName;
        public string UserName
        {
            get
            {
                return strUserName;
            }
            set
            {
                strUserName = value;
            }
        }

        public string EducationStatus
        {
            get
            {
                return strEducationStatus;
            }
            set
            {
                strEducationStatus = value;
            }
        }





        //private int strEmployeeId;
        //private string strCaseStatus;
        //private string strAllocatedStatus;
        //private string strAddressStatus;
        //private string strAddressRemarks;
        //private string strEducationStatus;
        //private string strEducationRemarks;
        private string strEmploymentStatus;
        //private string strEmploymentRemarks;
        //private string strCriminalStatus;
        //private string strCriminalRemarks;
        //private string strReferenceStatus;
        //private string strReferenceRemarks;
        //private string strDrugtestStatus;
        //private string strDrugtestRemarks;
        public string CaseStatus
        {
            get
            {
                return strCaseStatus;
            }
            set
            {
                strCaseStatus = value;
            }
        }
        public string AllocatedStatus
        {
            get
            {
                return strAllocatedStatus;
            }
            set
            {
                strAllocatedStatus = value;
            }
        }
        public string AddressStatus
        {
            get
            {
                return strAddressStatus;
            }
            set
            {
                strAddressStatus = value;
            }
        }
        //public string AddressRemarks
        //{
        //    get
        //    {
        //        return strAddressRemarks;
        //    }
        //    set
        //    {
        //        strAddressRemarks = value;
        //    }
        //}
        //public string EducationRemarks
        //{
        //    get
        //    {
        //        return strEducationRemarks;
        //    }
        //    set
        //    {
        //        strEducationRemarks = value;
        //    }
        //}
        public string EmploymentStatus
        {
            get
            {
                return strEmploymentStatus;
            }
            set
            {
                strEmploymentStatus = value;
            }
        }
        //public string EmploymentRemarks2SUP
        //{
        //    get
        //    {
        //        return strEmploymentRemarks2SUP;
        //    }
        //    set
        //    {
        //        strEmploymentRemarks2SUP = value;
        //    }
        //}
        //public string CriminalRemarks
        //{
        //    get
        //    {
        //        return strCriminalRemarks;
        //    }
        //    set
        //    {
        //        strCriminalRemarks = value;
        //    }
        //}

        public string CriminalCourtStatus
        {
            get
            {
                return strCriminalCourtStatus;
            }
            set
            {
                strCriminalCourtStatus = value;
            }
        }

        public string CriminalStatus
        {
            get
            {
                return strCriminalStatus;
            }
            set
            {
                strCriminalStatus = value;
            }
        }
        //public string ReferenceStatus
        //{
        //    get
        //    {
        //        return strReferenceStatus;
        //    }
        //    set
        //    {
        //        strReferenceStatus = value;
        //    }
        //}
        //public string ReferenceRemarks
        //{
        //    get
        //    {
        //        return strReferenceRemarks;
        //    }
        //    set
        //    {
        //        strReferenceRemarks = value;
        //    }
        //}
        //public string DrugtestStatus
        //{
        //    get
        //    {
        //        return strDrugtestStatus;
        //    }
        //    set
        //    {
        //        strDrugtestStatus = value;
        //    }
        //}
        //public string DrugtestRemarks
        //{
        //    get
        //    {
        //        return strDrugtestRemarks;
        //    }
        //    set
        //    {
        //        strDrugtestRemarks = value;
        //    }
        //}
        //public string DataBaseRemarks
        //{
        //    get
        //    {
        //        return strDataBaseRemarks;
        //    }
        //    set
        //    {
        //        strDataBaseRemarks = value;
        //    }
        //}
        public string DataBaseStatus
        {
            get
            {
                return strDataBaseStatus;
            }
            set
            {
                strDataBaseStatus = value;
            }
        }
        //public string b
        //{
        //    get
        //    {
        //        return strb;
        //    }
        //    set
        //    {
        //        strb = value;
        //    }
        //}
        //public string b
        //{
        //    get
        //    {
        //        return strb;
        //    }
        //    set
        //    {
        //        strb = value;
        //    }
        //}
        //public string b
        //{
        //    get
        //    {
        //        return strb;
        //    }
        //    set
        //    {
        //        strb = value;
        //    }
        //}

        public string ReportingLevel2emp1
        {
            get
            {
                return strReportingLevel2emp1;
            }
            set
            {
                strReportingLevel2emp1 = value;
            }
        }
        public string ReportingLevel2emp2
        {
            get
            {
                return strReportingLevel2emp1;
            }
            set
            {
                strReportingLevel2emp1 = value;
            }
        }

        public string employmentType
        {
            get
            {
                return stremploymentType;
            }
            set
            {
                stremploymentType = value;
            }
        }
        public string RejectedRemarks1
        {
            get
            {
                return strRejectedRemarks1;
            }
            set
            {
                strRejectedRemarks1 = value;
            }
        }
        public string RejectedRemarks2
        {
            get
            {
                return strRejectedRemarks2;
            }
            set
            {
                strRejectedRemarks2 = value;
            }
        }
        public string RejectedRemarks3
        {
            get
            {
                return strRejectedRemarks3;
            }
            set
            {
                strRejectedRemarks3 = value;
            }
        }
        public string RejectedRemarks4
        {
            get
            {
                return strRejectedRemarks4;
            }
            set
            {
                strRejectedRemarks4 = value;
            }
        }
        public string RejectedRemarks5
        {
            get
            {
                return strRejectedRemarks5;
            }
            set
            {
                strRejectedRemarks5 = value;
            }
        }
        public string ClientName
        {
            get
            {
                return strClientName;
            }
            set
            {
                strClientName = value;
            }
        }
        //NoOfComp
        public string FresherOrExp
        {
            get
            {
                return strFresherOrExp;
            }
            set
            {
                strFresherOrExp = value;
            }
        }


        public string NoOfComp { get { return strNoOfComp; } set { strNoOfComp = value; } }

        //Start all Checks..................
        //Address 3

        //  AddressCheck, CriminalCheck

        private string SAddressCheck;
        public string AddressCheck { get { return SAddressCheck; } set { SAddressCheck = value; } }

        private string SCriminalCheck;
        public string CriminalCheck { get { return SCriminalCheck; } set { SCriminalCheck = value; } }


        private string StxtAddress2CurrentAddress;
        public string txtAddress2CurrentAddress { get { return StxtAddress2CurrentAddress; } set { StxtAddress2CurrentAddress = value; } }

        private string StxtAddress2City;
        public string txtAddress2City { get { return StxtAddress2City; } set { StxtAddress2City = value; } }

        private string StxtAddress2State;
        public string txtAddress2State { get { return StxtAddress2State; } set { StxtAddress2State = value; } }

        private string StxtAddress2PhoneNo1;
        public string txtAddress2PhoneNo1 { get { return StxtAddress2PhoneNo1; } set { StxtAddress2PhoneNo1 = value; } }

        private string StxtAddress2PhoneNo2;
        public string txtAddress2PhoneNo2 { get { return StxtAddress2PhoneNo2; } set { StxtAddress2PhoneNo2 = value; } }

        //txtAddress2CurrentAddress
        //txtAddress2City
        //txtAddress2State
        //txtAddress2PhoneNo1
        //txtAddress2PhoneNo2
        // Address 4-
        private string StxtAddress3CurrentAddress;
        public string txtAddress3CurrentAddress { get { return StxtAddress3CurrentAddress; } set { StxtAddress3CurrentAddress = value; } }

        private string StxtAddress3City;
        public string txtAddress3City { get { return StxtAddress3City; } set { StxtAddress3City = value; } }

        private string StxtAddress3State;
        public string txtAddress3State { get { return StxtAddress3State; } set { StxtAddress3State = value; } }

        private string StxtAddress3PhoneNo1;
        public string txtAddress3PhoneNo1 { get { return StxtAddress3PhoneNo1; } set { StxtAddress3PhoneNo1 = value; } }

        private string StxtAddress3PhoneNo2;
        public string txtAddress3PhoneNo2 { get { return StxtAddress3PhoneNo2; } set { StxtAddress3PhoneNo2 = value; } }

        //txtAddress3CurrentAddress
        //txtAddress3City
        //txtAddress3State
        //txtAddress3PhoneNo1
        //txtAddress3PhoneNo2
        // Address 5-
        private string StxtAddress4CurrentAddress;
        public string txtAddress4CurrentAddress { get { return StxtAddress4CurrentAddress; } set { StxtAddress4CurrentAddress = value; } }

        private string StxtAddress4City;
        public string txtAddress4City { get { return StxtAddress4City; } set { StxtAddress4City = value; } }

        private string StxtAddress4State;
        public string txtAddress4State { get { return StxtAddress4State; } set { StxtAddress4State = value; } }

        private string StxtAddress4PhoneNo1;
        public string txtAddress4PhoneNo1 { get { return StxtAddress4PhoneNo1; } set { StxtAddress4PhoneNo1 = value; } }

        private string StxtAddress4PhoneNo2;
        public string txtAddress4PhoneNo2 { get { return StxtAddress4PhoneNo2; } set { StxtAddress4PhoneNo2 = value; } }

        //txtAddress4CurrentAddress
        //txtAddress4City
        //txtAddress4State
        //txtAddress4PhoneNo1
        //txtAddress4PhoneNo2
        // Address 6-
        private string StxtAddress5CurrentAddress;
        public string txtAddress5CurrentAddress { get { return StxtAddress5CurrentAddress; } set { StxtAddress5CurrentAddress = value; } }

        private string StxtAddress5City;
        public string txtAddress5City { get { return StxtAddress5City; } set { StxtAddress5City = value; } }

        private string StxtAddress5State;
        public string txtAddress5State { get { return StxtAddress5State; } set { StxtAddress5State = value; } }

        private string StxtAddress5PhoneNo1;
        public string txtAddress5PhoneNo1 { get { return StxtAddress5PhoneNo1; } set { StxtAddress5PhoneNo1 = value; } }

        private string StxtAddress5PhoneNo2;
        public string txtAddress5PhoneNo2 { get { return StxtAddress5PhoneNo2; } set { StxtAddress5PhoneNo2 = value; } }


        //txtAddress5CurrentAddress
        //txtAddress5City
        //txtAddress5State
        //txtAddress5PhoneNo1
        //txtAddress5PhoneNo2
        // Address 7-
        private string StxtAddress6CurrentAddress;
        public string txtAddress6CurrentAddress { get { return StxtAddress6CurrentAddress; } set { StxtAddress6CurrentAddress = value; } }

        private string StxtAddress6City;
        public string txtAddress6City { get { return StxtAddress6City; } set { StxtAddress6City = value; } }

        private string StxtAddress6State;
        public string txtAddress6State { get { return StxtAddress6State; } set { StxtAddress6State = value; } }

        private string StxtAddress6PhoneNo1;
        public string txtAddress6PhoneNo1 { get { return StxtAddress6PhoneNo1; } set { StxtAddress6PhoneNo1 = value; } }

        private string StxtAddress6PhoneNo2;
        public string txtAddress6PhoneNo2 { get { return StxtAddress6PhoneNo2; } set { StxtAddress6PhoneNo2 = value; } }

        //txtAddress6CurrentAddress
        //txtAddress6City
        //txtAddress6State
        //txtAddress6PhoneNo1
        //txtAddress6PhoneNo2
        // Address 8-
        private string StxtAddress7CurrentAddress;
        public string txtAddress7CurrentAddress { get { return StxtAddress7CurrentAddress; } set { StxtAddress7CurrentAddress = value; } }

        private string StxtAddress7City;
        public string txtAddress7City { get { return StxtAddress7City; } set { StxtAddress7City = value; } }

        private string StxtAddress7State;
        public string txtAddress7State { get { return StxtAddress7State; } set { StxtAddress7State = value; } }

        private string StxtAddress7PhoneNo1;
        public string txtAddress7PhoneNo1 { get { return StxtAddress7PhoneNo1; } set { StxtAddress7PhoneNo1 = value; } }

        private string StxtAddress7PhoneNo2;
        public string txtAddress7PhoneNo2 { get { return StxtAddress7PhoneNo2; } set { StxtAddress7PhoneNo2 = value; } }

        //txtAddress7CurrentAddress
        //txtAddress7City
        //txtAddress7State
        //txtAddress7PhoneNo1
        //txtAddress7PhoneNo2

        //Criminal Check
        //1-txtCriminal1Address,txtCriminal1Location

        private string StxtCriminal1Location;
        public string txtCriminal1Location { get { return StxtCriminal1Location; } set { StxtCriminal1Location = value; } }

        //2-txtCriminal2Address,txtCriminal2Location

        private string StxtCriminal2Location;
        public string txtCriminal2Location { get { return StxtCriminal2Location; } set { StxtCriminal2Location = value; } }


        //3-txtCriminal3Address,txtCriminal3Location

        private string StxtCriminal3Location;
        public string txtCriminal3Location { get { return StxtCriminal3Location; } set { StxtCriminal3Location = value; } }


        //4-txtCriminal4Address,txtCriminal4Location

        private string StxtCriminal4Location;
        public string txtCriminal4Location { get { return StxtCriminal4Location; } set { StxtCriminal4Location = value; } }

        //5-txtCriminal5Address,txtCriminal5Location


        private string StxtCriminal5Location;
        public string txtCriminal5Location { get { return StxtCriminal5Location; } set { StxtCriminal5Location = value; } }
        //6-txtCriminal6Address,txtCriminal6Location

        private string StxtCriminal6Location;
        public string txtCriminal6Location { get { return StxtCriminal6Location; } set { StxtCriminal6Location = value; } }


        //7-txtCriminal7Address,txtCriminal7Location

        private string StxtCriminal7Location;
        public string txtCriminal7Location { get { return StxtCriminal7Location; } set { StxtCriminal7Location = value; } }


        //8-txtCriminal8Address,txtCriminal8Location

        private string StxtCriminal8Location;
        public string txtCriminal8Location { get { return StxtCriminal8Location; } set { StxtCriminal8Location = value; } }



        //Education Check
        //5-
        //txtEducation5CollegeName
        //txtEducation5CollegeAddress
        //txtEducation5UniversityName
        //txtEducation5UniversityAddress
        //txtEducation5EQ
        //txtEducation5YearofPassing
        //txtEducation5RollNo
        //txtEducation5joainfrom
        //txtEducation5joainto
        //txtEducation5State
        //txtEducation5City
        //txtEducation5PinCode

        private string StxtEducation5CollegeName;
        public string txtEducation5CollegeName { get { return StxtEducation5CollegeName; } set { StxtEducation5CollegeName = value; } }


        private string StxtEducation5CollegeAddress;
        public string txtEducation5CollegeAddress { get { return StxtEducation5CollegeAddress; } set { StxtEducation5CollegeAddress = value; } }


        private string StxtEducation5UniversityName;
        public string txtEducation5UniversityName { get { return StxtEducation5UniversityName; } set { StxtEducation5UniversityName = value; } }


        private string StxtEducation5UniversityAddress;
        public string txtEducation5UniversityAddress { get { return StxtEducation5UniversityAddress; } set { StxtEducation5UniversityAddress = value; } }


        private string StxtEducation5EQ;
        public string txtEducation5EQ { get { return StxtEducation5EQ; } set { StxtEducation5EQ = value; } }


        private string StxtEducation5YearofPassing;
        public string txtEducation5YearofPassing { get { return StxtEducation5YearofPassing; } set { StxtEducation5YearofPassing = value; } }


        private string StxtEducation5RollNo;
        public string txtEducation5RollNo { get { return StxtEducation5RollNo; } set { StxtEducation5RollNo = value; } }


        private string StxtEducation5joinfrom;
        public string txtEducation5joinfrom { get { return StxtEducation5joinfrom; } set { StxtEducation5joinfrom = value; } }

        private string StxtEducation5jointo;
        public string txtEducation5jointo { get { return StxtEducation5jointo; } set { StxtEducation5jointo = value; } }


        private string StxtEducation5State;
        public string txtEducation5State { get { return StxtEducation5State; } set { StxtEducation5State = value; } }


        private string StxtEducation5City;
        public string txtEducation5City { get { return StxtEducation5City; } set { StxtEducation5City = value; } }


        private string StxtEducation5PinCode;
        public string txtEducation5PinCode { get { return StxtEducation5PinCode; } set { StxtEducation5PinCode = value; } }



        //6-
        //txtEducation6CollegeName
        //txtEducation6CollegeAddress
        //txtEducation6UniversityName
        //txtEducation6UniversityAddress
        //txtEducation6EQ
        //txtEducation6YearofPassing
        //txtEducation6RollNo
        //txtEducation6joainfrom
        //txtEducation6joainto
        //txtEducation6State
        //txtEducation6City
        //txtEducation6PinCode

        private string StxtEducation6CollegeName;
        public string txtEducation6CollegeName { get { return StxtEducation6CollegeName; } set { StxtEducation6CollegeName = value; } }


        private string StxtEducation6CollegeAddress;
        public string txtEducation6CollegeAddress { get { return StxtEducation6CollegeAddress; } set { StxtEducation6CollegeAddress = value; } }


        private string StxtEducation6UniversityName;
        public string txtEducation6UniversityName { get { return StxtEducation6UniversityName; } set { StxtEducation6UniversityName = value; } }


        private string StxtEducation6UniversityAddress;
        public string txtEducation6UniversityAddress { get { return StxtEducation6UniversityAddress; } set { StxtEducation6UniversityAddress = value; } }


        private string StxtEducation6EQ;
        public string txtEducation6EQ { get { return StxtEducation6EQ; } set { StxtEducation6EQ = value; } }


        private string StxtEducation6YearofPassing;
        public string txtEducation6YearofPassing { get { return StxtEducation6YearofPassing; } set { StxtEducation6YearofPassing = value; } }


        private string StxtEducation6RollNo;
        public string txtEducation6RollNo { get { return StxtEducation6RollNo; } set { StxtEducation6RollNo = value; } }


        private string StxtEducation6joinfrom;
        public string txtEducation6joinfrom { get { return StxtEducation6joinfrom; } set { StxtEducation6joinfrom = value; } }

        private string StxtEducation6jointo;
        public string txtEducation6jointo { get { return StxtEducation6jointo; } set { StxtEducation6jointo = value; } }


        private string StxtEducation6State;
        public string txtEducation6State { get { return StxtEducation6State; } set { StxtEducation6State = value; } }


        private string StxtEducation6City;
        public string txtEducation6City { get { return StxtEducation6City; } set { StxtEducation6City = value; } }


        private string StxtEducation6PinCode;
        public string txtEducation6PinCode { get { return StxtEducation6PinCode; } set { StxtEducation6PinCode = value; } }



        //7-
        //txtEducation7CollegeName
        //txtEducation7CollegeAddress
        //txtEducation7UniversityName
        //txtEducation7UniversityAddress
        //txtEducation7EQ
        //txtEducation7YearofPassing
        //txtEducation7RollNo
        //txtEducation7joainfrom
        //txtEducation7joainto
        //txtEducation7State
        //txtEducation7City
        //txtEducation7PinCode

        private string StxtEducation7CollegeName;
        public string txtEducation7CollegeName { get { return StxtEducation7CollegeName; } set { StxtEducation7CollegeName = value; } }


        private string StxtEducation7CollegeAddress;
        public string txtEducation7CollegeAddress { get { return StxtEducation7CollegeAddress; } set { StxtEducation7CollegeAddress = value; } }


        private string StxtEducation7UniversityName;
        public string txtEducation7UniversityName { get { return StxtEducation7UniversityName; } set { StxtEducation7UniversityName = value; } }


        private string StxtEducation7UniversityAddress;
        public string txtEducation7UniversityAddress { get { return StxtEducation7UniversityAddress; } set { StxtEducation7UniversityAddress = value; } }


        private string StxtEducation7EQ;
        public string txtEducation7EQ { get { return StxtEducation7EQ; } set { StxtEducation7EQ = value; } }


        private string StxtEducation7YearofPassing;
        public string txtEducation7YearofPassing { get { return StxtEducation7YearofPassing; } set { StxtEducation7YearofPassing = value; } }


        private string StxtEducation7RollNo;
        public string txtEducation7RollNo { get { return StxtEducation7RollNo; } set { StxtEducation7RollNo = value; } }


        private string StxtEducation7joinfrom;
        public string txtEducation7joinfrom { get { return StxtEducation7joinfrom; } set { StxtEducation7joinfrom = value; } }

        private string StxtEducation7jointo;
        public string txtEducation7jointo { get { return StxtEducation7jointo; } set { StxtEducation7jointo = value; } }


        private string StxtEducation7State;
        public string txtEducation7State { get { return StxtEducation7State; } set { StxtEducation7State = value; } }


        private string StxtEducation7City;
        public string txtEducation7City { get { return StxtEducation7City; } set { StxtEducation7City = value; } }


        private string StxtEducation7PinCode;
        public string txtEducation7PinCode { get { return StxtEducation7PinCode; } set { StxtEducation7PinCode = value; } }

        //8-
        //txtEducation8CollegeName
        //txtEducation8CollegeAddress
        //txtEducation8UniversityName
        //txtEducation8UniversityAddress
        //txtEducation8EQ
        //txtEducation8YearofPassing
        //txtEducation8RollNo
        //txtEducation8joainfrom
        //txtEducation8joainto
        //txtEducation8State
        //txtEducation8City
        //txtEducation8PinCode


        private string StxtEducation8CollegeName;
        public string txtEducation8CollegeName { get { return StxtEducation8CollegeName; } set { StxtEducation8CollegeName = value; } }


        private string StxtEducation8CollegeAddress;
        public string txtEducation8CollegeAddress { get { return StxtEducation8CollegeAddress; } set { StxtEducation8CollegeAddress = value; } }


        private string StxtEducation8UniversityName;
        public string txtEducation8UniversityName { get { return StxtEducation8UniversityName; } set { StxtEducation8UniversityName = value; } }


        private string StxtEducation8UniversityAddress;
        public string txtEducation8UniversityAddress { get { return StxtEducation8UniversityAddress; } set { StxtEducation8UniversityAddress = value; } }


        private string StxtEducation8EQ;
        public string txtEducation8EQ { get { return StxtEducation8EQ; } set { StxtEducation8EQ = value; } }


        private string StxtEducation8YearofPassing;
        public string txtEducation8YearofPassing { get { return StxtEducation8YearofPassing; } set { StxtEducation8YearofPassing = value; } }


        private string StxtEducation8RollNo;
        public string txtEducation8RollNo { get { return StxtEducation8RollNo; } set { StxtEducation8RollNo = value; } }


        private string StxtEducation8joinfrom;
        public string txtEducation8joinfrom { get { return StxtEducation8joinfrom; } set { StxtEducation8joinfrom = value; } }

        private string StxtEducation8jointo;
        public string txtEducation8jointo { get { return StxtEducation8jointo; } set { StxtEducation8jointo = value; } }


        private string StxtEducation8State;
        public string txtEducation8State { get { return StxtEducation8State; } set { StxtEducation8State = value; } }


        private string StxtEducation8City;
        public string txtEducation8City { get { return StxtEducation8City; } set { StxtEducation8City = value; } }


        private string StxtEducation8PinCode;
        public string txtEducation8PinCode { get { return StxtEducation8PinCode; } set { StxtEducation8PinCode = value; } }


        //EmployementCheck
        //6-
        //txtEmployement6CompanyName
        //txtEmployement6CompanyLocation
        //txtEmployement6OfficeAddress
        //txtEmployement6officeLocation
        //txtEmployement6Designation
        //txtEmployement6phone1
        //txtEmployement6phone2
        //txtEmployement6EmpCode
        //txtEmployement6DateFrom
        //txtEmployement6DateTo
        //txtEmployement6Salary
        //txtEmployement6State
        //txtEmployement6City
        //txtEmployement6PinCode
        //txtEmplyement6Sdesig
        //txtEmplyement6Semail
        //txtEmplyement6Sphone1
        //txtEmplyement6Sphone2
        //txtEmplyement6SMobile
        //txtEmplyement6SResofliv

        private string StxtEmployement6CompanyName;
        public string txtEmployement6CompanyName { get { return StxtEmployement6CompanyName; } set { StxtEmployement6CompanyName = value; } }

        private string StxtEmployement6CompanyLocation;
        public string txtEmployement6CompanyLocation { get { return StxtEmployement6CompanyLocation; } set { StxtEmployement6CompanyLocation = value; } }



        private string StxtEmployement6OfficeAddress;
        public string txtEmployement6OfficeAddress { get { return StxtEmployement6OfficeAddress; } set { StxtEmployement6OfficeAddress = value; } }


        private string StxtEmployement6officeLocation;
        public string txtEmployement6officeLocation { get { return StxtEmployement6officeLocation; } set { StxtEmployement6officeLocation = value; } }



        private string StxtEmployement6Designation;
        public string txtEmployement6Designation { get { return StxtEmployement6Designation; } set { StxtEmployement6Designation = value; } }


        private string StxtEmployement6phone1;
        public string txtEmployement6phone1 { get { return StxtEmployement6phone1; } set { StxtEmployement6phone1 = value; } }


        private string StxtEmployement6phone2;
        public string txtEmployement6phone2 { get { return StxtEmployement6phone2; } set { StxtEmployement6phone2 = value; } }


        private string StxtEmployement6EmpCode;
        public string txtEmployement6EmpCode { get { return StxtEmployement6EmpCode; } set { StxtEmployement6EmpCode = value; } }


        private string StxtEmployement6DateFrom;
        public string txtEmployement6DateFrom { get { return StxtEmployement6DateFrom; } set { StxtEmployement6DateFrom = value; } }


        private string StxtEmployement6DateTo;
        public string txtEmployement6DateTo { get { return StxtEmployement6DateTo; } set { StxtEmployement6DateTo = value; } }


        private string StxtEmployement6Salary;
        public string txtEmployement6Salary { get { return StxtEmployement6Salary; } set { StxtEmployement6Salary = value; } }


        private string StxtEmployement6State;
        public string txtEmployement6State { get { return StxtEmployement6State; } set { StxtEmployement6State = value; } }


        private string StxtEmployement6City;
        public string txtEmployement6City { get { return StxtEmployement6City; } set { StxtEmployement6City = value; } }

        private string StxtEmployement6PinCode;
        public string txtEmployement6PinCode { get { return StxtEmployement6PinCode; } set { StxtEmployement6PinCode = value; } }



        private string StxtEmployement6Sdesig;
        public string txtEmployement6Sdesig { get { return StxtEmployement6Sdesig; } set { StxtEmployement6Sdesig = value; } }

        private string StxtEmployement6Semail;
        public string txtEmployement6Semail { get { return StxtEmployement6Semail; } set { StxtEmployement6Semail = value; } }


        private string StxtEmployement6Sphone1;
        public string txtEmployement6Sphone1 { get { return StxtEmployement6Sphone1; } set { StxtEmployement6Sphone1 = value; } }

        private string StxtEmployement6Sphone2;
        public string txtEmployement6Sphone2 { get { return StxtEmployement6Sphone2; } set { StxtEmployement6Sphone2 = value; } }

        private string StxtEmployement6SMobile;
        public string txtEmployement6SMobile { get { return StxtEmployement6SMobile; } set { StxtEmployement6SMobile = value; } }

        private string StxtEmployement6SResofliv;
        public string txtEmployement6SResofliv { get { return StxtEmployement6SResofliv; } set { StxtEmployement6SResofliv = value; } }







        //7-


        //txtEmployement7CompanyName
        //txtEmployement7CompanyLocation
        //txtEmployement7OfficeAddress
        //txtEmployement7officeLocation
        //txtEmployement7Designation
        //txtEmployement7phone1
        //txtEmployement7phone2

        //txtEmployement7EmpCode
        //txtEmployement7DateFrom
        //txtEmployement7DateTo
        //txtEmployement7Salary
        //txtEmployement7State
        //txtEmployement7City
        //txtEmployement7PinCode
        //txtEmplyement7Sdesig
        //txtEmplyement7Semail
        //txtEmplyement7Sphone1
        //txtEmplyement7Sphone2
        //txtEmplyement7SMobile
        //txtEmplyement7SResofliv

        private string StxtEmployement7CompanyName;
        public string txtEmployement7CompanyName { get { return StxtEmployement7CompanyName; } set { StxtEmployement7CompanyName = value; } }

        private string StxtEmployement7CompanyLocation;
        public string txtEmployement7CompanyLocation { get { return StxtEmployement7CompanyLocation; } set { StxtEmployement7CompanyLocation = value; } }



        private string StxtEmployement7OfficeAddress;
        public string txtEmployement7OfficeAddress { get { return StxtEmployement7OfficeAddress; } set { StxtEmployement7OfficeAddress = value; } }


        private string StxtEmployement7officeLocation;
        public string txtEmployement7officeLocation { get { return StxtEmployement7officeLocation; } set { StxtEmployement7officeLocation = value; } }



        private string StxtEmployement7Designation;
        public string txtEmployement7Designation { get { return StxtEmployement7Designation; } set { StxtEmployement7Designation = value; } }


        private string StxtEmployement7phone1;
        public string txtEmployement7phone1 { get { return StxtEmployement7phone1; } set { StxtEmployement7phone1 = value; } }


        private string StxtEmployement7phone2;
        public string txtEmployement7phone2 { get { return StxtEmployement7phone2; } set { StxtEmployement7phone2 = value; } }


        private string StxtEmployement7EmpCode;
        public string txtEmployement7EmpCode { get { return StxtEmployement7EmpCode; } set { StxtEmployement7EmpCode = value; } }


        private string StxtEmployement7DateFrom;
        public string txtEmployement7DateFrom { get { return StxtEmployement7DateFrom; } set { StxtEmployement7DateFrom = value; } }


        private string StxtEmployement7DateTo;
        public string txtEmployement7DateTo { get { return StxtEmployement7DateTo; } set { StxtEmployement7DateTo = value; } }


        private string StxtEmployement7Salary;
        public string txtEmployement7Salary { get { return StxtEmployement7Salary; } set { StxtEmployement7Salary = value; } }


        private string StxtEmployement7State;
        public string txtEmployement7State { get { return StxtEmployement7State; } set { StxtEmployement7State = value; } }


        private string StxtEmployement7City;
        public string txtEmployement7City { get { return StxtEmployement7City; } set { StxtEmployement7City = value; } }


        private string StxtEmployement7PinCode;
        public string txtEmployement7PinCode { get { return StxtEmployement7PinCode; } set { StxtEmployement7PinCode = value; } }

        private string StxtEmployement7Sdesig;
        public string txtEmployement7Sdesig { get { return StxtEmployement7Sdesig; } set { StxtEmployement7Sdesig = value; } }

        private string StxtEmployement7Semail;
        public string txtEmployement7Semail { get { return StxtEmployement7Semail; } set { StxtEmployement7Semail = value; } }


        private string StxtEmployement7Sphone1;
        public string txtEmployement7Sphone1 { get { return StxtEmployement7Sphone1; } set { StxtEmployement7Sphone1 = value; } }

        private string StxtEmployement7Sphone2;
        public string txtEmployement7Sphone2 { get { return StxtEmployement7Sphone2; } set { StxtEmployement7Sphone2 = value; } }

        private string StxtEmployement7SMobile;
        public string txtEmployement7SMobile { get { return StxtEmployement7SMobile; } set { StxtEmployement7SMobile = value; } }

        private string StxtEmployement7SResofliv;
        public string txtEmployement7SResofliv { get { return StxtEmployement7SResofliv; } set { StxtEmployement7SResofliv = value; } }




        //8-


        //txtEmployement8CompanyName
        //txtEmployement8CompanyLocation
        //txtEmployement8OfficeAddress
        //txtEmployement8officeLocation
        //txtEmployement8Designation
        //txtEmployement8phone1
        //txtEmployement8phone2

        //txtEmployement8EmpCode
        //txtEmployement8DateFrom
        //txtEmployement8DateTo
        //txtEmployement8Salary
        //txtEmployement8State
        //txtEmployement8City
        //txtEmployement8PinCode
        //txtEmplyement8Sdesig
        //txtEmplyement8Semail
        //txtEmplyement8Sphone1
        //txtEmplyement8Sphone2
        //txtEmplyement8SMobile
        //txtEmplyement8SResofliv

        private string StxtEmployement8CompanyName;
        public string txtEmployement8CompanyName { get { return StxtEmployement8CompanyName; } set { StxtEmployement8CompanyName = value; } }

        private string StxtEmployement8CompanyLocation;
        public string txtEmployement8CompanyLocation { get { return StxtEmployement8CompanyLocation; } set { StxtEmployement8CompanyLocation = value; } }



        private string StxtEmployement8OfficeAddress;
        public string txtEmployement8OfficeAddress { get { return StxtEmployement8OfficeAddress; } set { StxtEmployement8OfficeAddress = value; } }


        private string StxtEmployement8officeLocation;
        public string txtEmployement8officeLocation { get { return StxtEmployement8officeLocation; } set { StxtEmployement8officeLocation = value; } }



        private string StxtEmployement8Designation;
        public string txtEmployement8Designation { get { return StxtEmployement8Designation; } set { StxtEmployement8Designation = value; } }


        private string StxtEmployement8phone1;
        public string txtEmployement8phone1 { get { return StxtEmployement8phone1; } set { StxtEmployement8phone1 = value; } }


        private string StxtEmployement8phone2;
        public string txtEmployement8phone2 { get { return StxtEmployement8phone2; } set { StxtEmployement8phone2 = value; } }


        private string StxtEmployement8EmpCode;
        public string txtEmployement8EmpCode { get { return StxtEmployement8EmpCode; } set { StxtEmployement8EmpCode = value; } }


        private string StxtEmployement8DateFrom;
        public string txtEmployement8DateFrom { get { return StxtEmployement8DateFrom; } set { StxtEmployement8DateFrom = value; } }


        private string StxtEmployement8DateTo;
        public string txtEmployement8DateTo { get { return StxtEmployement8DateTo; } set { StxtEmployement8DateTo = value; } }


        private string StxtEmployement8Salary;
        public string txtEmployement8Salary { get { return StxtEmployement8Salary; } set { StxtEmployement8Salary = value; } }


        private string StxtEmployement8State;
        public string txtEmployement8State { get { return StxtEmployement8State; } set { StxtEmployement8State = value; } }


        private string StxtEmployement8City;
        public string txtEmployement8City { get { return StxtEmployement8City; } set { StxtEmployement8City = value; } }


        private string StxtEmployement8PinCode;
        public string txtEmployement8PinCode { get { return StxtEmployement8PinCode; } set { StxtEmployement8PinCode = value; } }


        private string StxtEmployement8Sdesig;
        public string txtEmployement8Sdesig { get { return StxtEmployement8Sdesig; } set { StxtEmployement8Sdesig = value; } }

        private string StxtEmployement8Semail;
        public string txtEmployement8Semail { get { return StxtEmployement8Semail; } set { StxtEmployement8Semail = value; } }


        private string StxtEmployement8Sphone1;
        public string txtEmployement8Sphone1 { get { return StxtEmployement8Sphone1; } set { StxtEmployement8Sphone1 = value; } }

        private string StxtEmployement8Sphone2;
        public string txtEmployement8Sphone2 { get { return StxtEmployement8Sphone2; } set { StxtEmployement8Sphone2 = value; } }

        private string StxtEmployement8SMobile;
        public string txtEmployement8SMobile { get { return StxtEmployement8SMobile; } set { StxtEmployement8SMobile = value; } }

        private string StxtEmployement8SResofliv;
        public string txtEmployement8SResofliv { get { return StxtEmployement8SResofliv; } set { StxtEmployement8SResofliv = value; } }






        //REference Check

        //ddlReference
        //1-
        //txtRefCheck1AppName
        //txtRef1DOV
        //txtRefCheck1VerifierName
        //txtRef1Desi
        //txtRef1Company
        //txtRef1Email
        //txtRef1CN

        private string SddlReference;
        public string ddlReference { get { return SddlReference; } set { SddlReference = value; } }

        private string StxtRef1Remark;
        public string txtRef1Remark { get { return StxtRef1Remark; } set { StxtRef1Remark = value; } }

        private string StxtRefCheck1AppName;
        public string txtRefCheck1AppName { get { return StxtRefCheck1AppName; } set { StxtRefCheck1AppName = value; } }

        private string StxtRefCheck1VerifierName;
        public string txtRefCheck1VerifierName { get { return StxtRefCheck1VerifierName; } set { StxtRefCheck1VerifierName = value; } }

        private string StxtRef1Desi;
        public string txtRef1Desi { get { return StxtRef1Desi; } set { StxtRef1Desi = value; } }

        private string StxtRef1Company;
        public string txtRef1Company { get { return StxtRef1Company; } set { StxtRef1Company = value; } }

        private string StxtRef1Email;
        public string txtRef1Email { get { return StxtRef1Email; } set { StxtRef1Email = value; } }

        private string StxtRef1CN;
        public string txtRef1CN { get { return StxtRef1CN; } set { StxtRef1CN = value; } }






        //2-
        //txtRefCheck2AppName
        //txtRef2DOV
        //txtRefCheck2VerifierName
        //txtRef2Desi
        //txtRef2Company
        //txtRef2Email
        //txtRef2CN



        private string StxtRef2DOV;
        public string txtRef2DOV { get { return StxtRef2DOV; } set { StxtRef2DOV = value; } }

        private string StxtRefCheck2AppName;
        public string txtRefCheck2AppName { get { return StxtRefCheck2AppName; } set { StxtRefCheck2AppName = value; } }

        private string StxtRefCheck2VerifierName;
        public string txtRefCheck2VerifierName { get { return StxtRefCheck2VerifierName; } set { StxtRefCheck2VerifierName = value; } }

        private string StxtRef2Desi;
        public string txtRef2Desi { get { return StxtRef2Desi; } set { StxtRef2Desi = value; } }

        private string StxtRef2Company;
        public string txtRef2Company { get { return StxtRef2Company; } set { StxtRef2Company = value; } }

        private string StxtRef2Email;
        public string txtRef2Email { get { return StxtRef2Email; } set { StxtRef2Email = value; } }

        private string StxtRef2CN;
        public string txtRef2CN { get { return StxtRef2CN; } set { StxtRef2CN = value; } }


        //3-
        //txtRefCheck3AppName
        //txtRef3DOV
        //txtRefCheck3VerifierName
        //txtRef3Desi
        //txtRef3Company
        //txtRef3Email
        //txtRef3CN

        private string StxtRef3DOV;
        public string txtRef3DOV { get { return StxtRef3DOV; } set { StxtRef3DOV = value; } }

        private string StxtRefCheck3AppName;
        public string txtRefCheck3AppName { get { return StxtRefCheck3AppName; } set { StxtRefCheck3AppName = value; } }

        private string StxtRefCheck3VerifierName;
        public string txtRefCheck3VerifierName { get { return StxtRefCheck3VerifierName; } set { StxtRefCheck3VerifierName = value; } }

        private string StxtRef3Desi;
        public string txtRef3Desi { get { return StxtRef3Desi; } set { StxtRef3Desi = value; } }

        private string StxtRef3Company;
        public string txtRef3Company { get { return StxtRef3Company; } set { StxtRef3Company = value; } }

        private string StxtRef3Email;
        public string txtRef3Email { get { return StxtRef3Email; } set { StxtRef3Email = value; } }

        private string StxtRef3CN;
        public string txtRef3CN { get { return StxtRef3CN; } set { StxtRef3CN = value; } }


        //Database Check
        //ddlDatabase
        //1-
        //txtDatabaseCheck
        //txtDatabaseLocation
        private string SddlDatabase;
        public string ddlDatabase { get { return SddlDatabase; } set { SddlDatabase = value; } }

        private string StxtDatabaseCheck;
        public string txtDatabaseCheck { get { return StxtDatabaseCheck; } set { StxtDatabaseCheck = value; } }

        private string StxtDatabaseLocation;
        public string txtDatabaseLocation { get { return StxtDatabaseLocation; } set { StxtDatabaseLocation = value; } }


        //Drug Check
        //ddlDrug
        //1-txtDrugCheck
        //2-txtDrugLocation
        private string SddlDrug;
        public string ddlDrug { get { return SddlDrug; } set { SddlDrug = value; } }



        private string StxtDrugLocation;
        public string Drugcity { get { return StxtDrugLocation; } set { StxtDrugLocation = value; } }




        //Identity Check
        //ddlIndentity,
        //txtIdetityCheck,
        //txtIdentityLocation
        private string SddlIndentity;
        public string ddlIndentity { get { return SddlIndentity; } set { SddlIndentity = value; } }



        private string StxtIdentityLocation;
        public string Identitycity { get { return StxtIdentityLocation; } set { StxtIdentityLocation = value; } }


        //End All Checks


        //Criminal Address And State


        private string SCriminal1Address;
        public string Criminal1Address { get { return SCriminal1Address; } set { SCriminal1Address = value; } }

        private string SCriminal2Address;
        public string Criminal2Address { get { return SCriminal2Address; } set { SCriminal2Address = value; } }

        private string SCriminal3Address;
        public string Criminal3Address { get { return SCriminal3Address; } set { SCriminal3Address = value; } }


        private string SCriminal4Address;
        public string Criminal4Address { get { return SCriminal4Address; } set { SCriminal4Address = value; } }


        private string SCriminal5Address;
        public string Criminal5Address { get { return SCriminal5Address; } set { SCriminal5Address = value; } }


        private string SCriminal6Address;
        public string Criminal6Address { get { return SCriminal6Address; } set { SCriminal6Address = value; } }


        private string SCriminal7Address;
        public string Criminal7Address { get { return SCriminal7Address; } set { SCriminal7Address = value; } }


        private string SCriminal8Address;
        public string Criminal8Address { get { return SCriminal8Address; } set { SCriminal8Address = value; } }


        /// <summary>
        /// /////////// Criminal State
        /// </summary>

        private string SCriminal1State;
        public string Criminal1State { get { return SCriminal1State; } set { SCriminal1State = value; } }

        private string SCriminal2State;
        public string Criminal2State { get { return SCriminal2State; } set { SCriminal2State = value; } }

        private string SCriminal3State;
        public string Criminal3State { get { return SCriminal3State; } set { SCriminal3State = value; } }


        private string SCriminal4State;
        public string Criminal4State { get { return SCriminal4State; } set { SCriminal4State = value; } }


        private string SCriminal5State;
        public string Criminal5State { get { return SCriminal5State; } set { SCriminal5State = value; } }


        private string SCriminal6State;
        public string Criminal6State { get { return SCriminal6State; } set { SCriminal6State = value; } }


        private string SCriminal7State;
        public string Criminal7State { get { return SCriminal7State; } set { SCriminal7State = value; } }


        private string SCriminal8State;
        public string Criminal8State { get { return SCriminal8State; } set { SCriminal8State = value; } }







        ////////////////////For University/College Module

        public string SUniName
        {
            get { return strUniName; }
            set { strUniName = value; }
        }
        public string SUniLoc
        {
            get { return strUniLoc; }
            set { strUniLoc = value; }
        }
        public string SUniConPer
        {
            get { return strUniConPer; }
            set { strUniConPer = value; }
        }
        public string SUniDesig
        {
            get { return strUniDesig; }
            set { strUniDesig = value; }
        }
        public string SUniNo1
        {
            get { return strUniNo1; }
            set { strUniNo1 = value; }
        }
        public string SUniNo2
        {
            get { return strUniNo2; }
            set { strUniNo2 = value; }
        }
        public string SUniConPer1
        {
            get { return strUniConPer1; }
            set { strUniConPer1 = value; }
        }
        public string SUniDesig1
        {
            get { return strUniDesig1; }
            set { strUniDesig1 = value; }
        }
        public string SUniNo3
        {
            get { return strUniNo3; }
            set { strUniNo3 = value; }
        }
        public string SUniNo4
        {
            get { return strUniNo4; }
            set { strUniNo4 = value; }
        }
        public string SUniDD
        {
            get { return strUniDD; }
            set { strUniDD = value; }
        }
        public string SUniDDto
        {
            get { return strUniDDto; }
            set { strUniDDto = value; }
        }
        public string SUniDDadd
        {
            get { return strUniDDadd; }
            set { strUniDDadd = value; }
        }
        public string SUniTime
        {
            get { return strUniTime; }
            set { strUniTime = value; }
        }
        public string SUniMail
        {
            get { return strUniMail; }
            set { strUniMail = value; }
        }
        public string SUniWeb
        {
            get { return strUniWeb; }
            set { strUniWeb = value; }
        }
        public string SUniRemark
        {
            get { return strUniRemark; }
            set { strUniRemark = value; }
        }
        public string SColName
        {
            get { return strColName; }
            set { strColName = value; }
        }
        public string SColLoc
        {
            get { return strColLoc; }
            set { strColLoc = value; }
        }
        public string SColConPer
        {
            get { return strColConPer; }
            set { strColConPer = value; }
        }
        public string SColDesig
        {
            get { return strColDesig; }
            set { strColDesig = value; }
        }
        public string SColNo1
        {
            get { return strColNo1; }
            set { strColNo1 = value; }
        }
        public string SColNo2
        {
            get { return strColNo2; }
            set { strColNo2 = value; }
        }
        public string SColConPer1
        {
            get { return strColConPer1; }
            set { strColConPer1 = value; }
        }
        public string SColDesig1
        {
            get { return strColDesig1; }
            set { strColDesig1 = value; }
        }
        public string SColNo3
        {
            get { return strColNo3; }
            set { strColNo3 = value; }
        }
        public string SColNo4
        {
            get { return strColNo4; }
            set { strColNo4 = value; }
        }
        public string SColDD
        {
            get { return strColDD; }
            set { strColDD = value; }
        }
        public string SColDDto
        {
            get { return strColDDto; }
            set { strColDDto = value; }
        }
        public string SColDDadd
        {
            get { return strColDDadd; }
            set { strColDDadd = value; }
        }
        public string SColTime
        {
            get { return strColTime; }
            set { strColTime = value; }
        }
        public string SColMail
        {
            get { return strColMail; }
            set { strColMail = value; }
        }
        public string SColWeb
        {
            get { return strColWeb; }
            set { strColWeb = value; }
        }
        public string SColRemark
        {
            get { return strColRemark; }
            set { strColRemark = value; }
        }
        public DataSet SelectData(int CandidateID)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SelectAllData",
                  SQLDataAccess.CreateParameter("@CandidateID", SqlDbType.Int, CandidateID, ParameterDirection.Input, 4, false)


                );
            return dsServiceType;
        }


        public int Savepartial(CandidateDetails candidateobj)
        {
            int i;
            SqlParameter[] store = new SqlParameter[246];
            store[0] = new SqlParameter("@PlaceofJoing", PlaceofJoing);
            store[1] = new SqlParameter("@Band", Band);
            store[2] = new SqlParameter("@FirstName", FirstName);
            store[3] = new SqlParameter("@MiddleName", MiddleName);
            store[4] = new SqlParameter("@Surname", Surname);
            store[5] = new SqlParameter("@FatherName", FatherName);
            store[6] = new SqlParameter("@DOB", DOB);
            store[7] = new SqlParameter("@Mobile", Mobile);
            store[8] = new SqlParameter("@DOJ", DateofJoining);
            store[190] = new SqlParameter("@gender", gender);
            store[191] = new SqlParameter("@maritalstatus", maritalstatus);
            store[9] = new SqlParameter("@Refcheck ", RefList);
            store[10] = new SqlParameter("@refcheck1appname", Ref1RefName);
            store[11] = new SqlParameter("@ref1company ", Ref1CompName);
            store[12] = new SqlParameter("@ref1desig", Ref1Designation);
            store[13] = new SqlParameter("@ref1email", Ref1Email);
            store[14] = new SqlParameter("@ref1cn", Ref1Contact);
            store[15] = new SqlParameter("@refcheck2appname", Ref2RefName);
            store[16] = new SqlParameter("@ref2company", Ref2CompName);
            store[17] = new SqlParameter("@ref2desig", Ref2Designation);
            store[18] = new SqlParameter("@ref2email", Ref2Email);
            store[19] = new SqlParameter("@ref2cn", Ref2Contact);
            store[20] = new SqlParameter("@cibilcheck", CIBILList);
            store[21] = new SqlParameter("@cibilcn", CIBILContact);
            store[22] = new SqlParameter("@cibildob", CIBILDOB);
            store[23] = new SqlParameter("@cibilemailid", CIBILEmail);
            store[24] = new SqlParameter("@cibilname", CIBILFullName);
            store[25] = new SqlParameter("@cibilgender", CIBILGender);
            store[26] = new SqlParameter("@cibilpancardno", CIBILPanCard);
            store[192] = new SqlParameter("@cibilpasport", CIBILpassportno);
            store[193] = new SqlParameter("@cibilvoterid", CIBILvoterID);
            store[194] = new SqlParameter("@cibillicence", CIBILDrivinglicense);
            store[195] = new SqlParameter("@addresschecks", AddressCheck);
            store[196] = new SqlParameter("@PermanentAddress", PermanentAddress);
            store[197] = new SqlParameter("@Per_City", Per_City);
            store[198] = new SqlParameter("@Per_State", Per_State);
            store[199] = new SqlParameter("@Per_AddressPhoneNo", Per_AddressPhoneNo);
            store[200] = new SqlParameter("@Per_Landmark", Per_Landmark);
            store[201] = new SqlParameter("@Per_LivingSince", Per_LivingSince);
            store[202] = new SqlParameter("@Per_PoliceStation", Per_PoliceStation);
            store[203] = new SqlParameter("@Per_PostOffice", Per_PostOffice);
            store[204] = new SqlParameter("@CurrentAddress", CurrentAddress);
            store[205] = new SqlParameter("@Curr_City", Curr_City);
            store[206] = new SqlParameter("@Curr_State", Curr_State);
            store[207] = new SqlParameter("@Curr_PhoneNo  ", Curr_PhoneNo);
            store[208] = new SqlParameter("@LogestStay_address  ", add1logeststay);
            store[209] = new SqlParameter("@LogestStay_State  ", add1logeststarystate);
            store[210] = new SqlParameter("@LogestStay_City ", add1logeststarycity);
            store[211] = new SqlParameter("@LogestStay_PhoneNo  ", add1logeststaryphonenumber);
            store[212] = new SqlParameter("@LogestStay_Landmark  ", add1logeststarylandmark);
            store[213] = new SqlParameter("@LogestStay_LivingSince  ", add1logeststaryLeavingsince);
            store[214] = new SqlParameter("@LogestStay_PoliceStation  ", add1logeststarypolicestation);
            store[215] = new SqlParameter("@LogestStay_Pincode  ", add1logeststarypincode);

            store[216] = new SqlParameter("@Edu4_CollegeName", Edu4_CollegeName);
            store[217] = new SqlParameter("@Edu4_UniversityName", Edu4_UniversityName);
            store[218] = new SqlParameter("@Edu4_Address", Edu4_Address);
            store[219] = new SqlParameter("@Edu4_EducationalQualification", Edu4_EducationalQualification);
            store[220] = new SqlParameter("@Edu4_RollNo", Edu4_RollNo);
            store[221] = new SqlParameter("@YearofPassing4", YearOfPassing4);
            store[222] = new SqlParameter("@Edu5_CollegeName", Edu5_CollegeName);
            store[223] = new SqlParameter("@Edu5_UniversityName", Edu5_UniversityName);
            store[224] = new SqlParameter("@Edu5_Address", Edu5_Address);
            store[225] = new SqlParameter("@Edu5_EducationalQualification", Edu5_EducationalQualification);
            store[226] = new SqlParameter("@Edu5_RollNo", Edu5_RollNo);
            store[227] = new SqlParameter("@YearofPassing5", YearOfPassing5);
            store[228] = new SqlParameter("@Edu6_CollegeName", Edu6_CollegeName);
            store[229] = new SqlParameter("@Edu6_UniversityName", Edu6_UniversityName);
            store[230] = new SqlParameter("@Edu6_Address", Edu6_Address);
            store[231] = new SqlParameter("@Edu6_EducationalQualification", Edu6_EducationalQualification);
            store[232] = new SqlParameter("@Edu6_RollNo", Edu6_RollNo);
            store[233] = new SqlParameter("@YearofPassing6", YearOfPassing6);
            store[234] = new SqlParameter("@Edu7_CollegeName", Edu7_CollegeName);
            store[235] = new SqlParameter("@Edu7_UniversityName", Edu7_UniversityName);
            store[236] = new SqlParameter("@Edu7_Address", Edu7_Address);
            store[237] = new SqlParameter("@Edu7_EducationalQualification", Edu7_EducationalQualification);
            store[238] = new SqlParameter("@Edu7_RollNo", Edu7_RollNo);
            store[239] = new SqlParameter("@YearofPassing7", YearOfPassing7);
            store[240] = new SqlParameter("@Edu8_CollegeName", Edu8_CollegeName);
            store[241] = new SqlParameter("@Edu8_UniversityName", Edu8_UniversityName);
            store[242] = new SqlParameter("@Edu8_Address", Edu8_Address);
            store[243] = new SqlParameter("@Edu8_EducationalQualification", Edu8_EducationalQualification);
            store[244] = new SqlParameter("@Edu8_RollNo", Edu8_RollNo);
            store[245] = new SqlParameter("@YearofPassing8", YearOfPassing8);


            store[181] = new SqlParameter("@Fresher_experience", FresherOrExp);
            store[182] = new SqlParameter("@educationcheck", EducationList);
            store[183] = new SqlParameter("@Edu1_CollegeName", Edu1_CollegeName);
            store[184] = new SqlParameter("@Edu1_UniversityName", Edu1_UniversityName);
            store[185] = new SqlParameter("@Edu1_Address", Edu1_Address);
            store[186] = new SqlParameter("@Edu1_EducationalQualification  ", Edu1_EducationalQualification);
            store[187] = new SqlParameter("@Edu1_RollNo", Edu1_RollNo);
            store[188] = new SqlParameter("@YearofPassing", Edu1_YearOfPassing);
            store[189] = new SqlParameter("@Edu2_CollegeName", Edu2_CollegeName);
            store[27] = new SqlParameter("@Edu2_UniversityName", Edu2_UniversityName);
            store[28] = new SqlParameter("@Edu2_Address", Edu2_Address);
            store[29] = new SqlParameter("@Edu2_EducationalQualification", Edu2_EducationalQualification);
            store[30] = new SqlParameter("@Edu2_RollNo", Edu2_RollNo);
            store[31] = new SqlParameter("@YearofPassing2", Edu2_YearOfPassing);
            store[32] = new SqlParameter("@Edu3_CollegeName", Edu3_CollegeName);
            store[33] = new SqlParameter("@Edu3_UniversityName", Edu3_UniversityName);
            store[34] = new SqlParameter("@Edu3_Address", Edu3_Address);
            store[35] = new SqlParameter("@Edu3_EducationalQualification", Edu3_EducationalQualification);
            store[36] = new SqlParameter("@Edu3_RollNo", Edu3_RollNo);
            store[37] = new SqlParameter("@YearofPassing3", YearOfPassing3);
            store[38] = new SqlParameter("@Noofcompany", NoOfComp);            //cmp 1
            store[39] = new SqlParameter("@EmpHis1_CompnayNameandLocation", EmpHis1_CompnayNameandLocation);
            store[40] = new SqlParameter("@EmpHis1_LastPositionHeldnDepartmentName", EmpHis1_LastPositionHeldnDepartmentName);
            store[41] = new SqlParameter("@EmpHis1_TelephoneNo", EmpHis1_TelephoneNo);
            store[42] = new SqlParameter("@EmpHis1_Address", EmpHis1_Address);
            store[43] = new SqlParameter("@EmpHis1_EmployeeCode", EmpHis1_EmployeeCode);
            store[44] = new SqlParameter("@EmpHis1_Experienceinyear", ExperienceInYears1);
            store[45] = new SqlParameter("@EmpHis1_PeriodofEmployment", EmpHis1_PeriodofEmployment);
            store[46] = new SqlParameter("@EmpHis1_PeriodofEmploymentTillDate", EmpHis1_PeriodofEmploymentRemark);
            store[47] = new SqlParameter("@EmpHis1RLvl1_NameDesignatinOfSupervisor", EmpHis1RLvl1_NameDesignatinOfSupervisor);
            store[48] = new SqlParameter("@EmpHis1RLvl1_TelepnoneNo", EmpHis1RLvl1_TelepnoneNo);
            store[49] = new SqlParameter("@EmpHis1RLvl1_MobileNo", EmpHis1RLvl1_MobileNo);
            store[50] = new SqlParameter("@EmpHis1RLvl1_EmailId", EmpHis1RLvl1_EmailId);
            store[51] = new SqlParameter("@EmpHis1RLvl2_NameDesignatinOfSupervisor", EmpHis1RLvl2_NameDesignatinOfSupervisor);
            store[52] = new SqlParameter("@EmpHis1RLvl2_TelepnoneNo  ", EmpHis1RLvl2_TelepnoneNo);
            store[53] = new SqlParameter("@EmpHis1RLvl2_MobileNo  ", EmpHis1RLvl2_MobileNo);
            store[54] = new SqlParameter("@EmpHis1RLvl2_EmailId   ", EmpHis1RLvl2_EmailId);
            store[55] = new SqlParameter("@EmpHis1_TempPerma  ", EmpHis1_TempPerma);
            store[56] = new SqlParameter("@EmpHis1_AgencyDetails  ", EmpHis1_AgencyDetails);
            store[57] = new SqlParameter("@EmpHis1_RemunerationOrSalary  ", EmpHis1_RemunerationOrSalary);
            store[58] = new SqlParameter("@EmpHis1_ReasonOfLeaving   ", EmpHis1_ReasonOfLeaving);
            store[59] = new SqlParameter("@EmpHis1_referenceYN   ", EmpHis1_referenceYN);
            store[60] = new SqlParameter("@cmp1department   ", cmp1department);
            store[61] = new SqlParameter("@EmpHis1_NoticePeriodorNot  ", EmpHis1_NoticePeriodorNot);
            store[62] = new SqlParameter("@EmpHis2_CompnayNameandLocation  ", EmpHis2_CompnayNameandLocation);
            store[63] = new SqlParameter("@EmpHis2_LastPositionHeldnDepartmentName  ", EmpHis2_LastPositionHeldnDepartmentName);
            store[64] = new SqlParameter("@EmpHis2_TelephoneNo  ", EmpHis2_TelephoneNo);
            store[65] = new SqlParameter("@EmpHis2_Address  ", EmpHis2_Address);
            store[66] = new SqlParameter("@EmpHis2_EmployeeCode  ", EmpHis2_EmployeeCode);
            store[67] = new SqlParameter("@EmpHis2_Experienceinyear  ", ExperienceInYears2);
            store[68] = new SqlParameter("@EmpHis2_PeriodofEmployment  ", EmpHis2_PeriodofEmployment);
            store[69] = new SqlParameter("@EmpHis2_PeriodofEmploymentTillDate  ", EmpHis2_PeriodofEmploymentRemark);
            store[70] = new SqlParameter("@EmpHis2RLvl1_NameDesignatinOfSupervisor  ", EmpHis2RLvl1_NameDesignatinOfSupervisor);
            store[71] = new SqlParameter("@EmpHis2RLvl1_TelepnoneNo  ", EmpHis2RLvl1_TelepnoneNo);
            store[72] = new SqlParameter("@EmpHis2RLvl1_MobileNo   ", EmpHis2RLvl1_MobileNo);
            store[73] = new SqlParameter("@EmpHis2RLvl1_EmailId  ", EmpHis2RLvl1_EmailId);
            store[74] = new SqlParameter("@EmpHis2RLvl2_NameDesignatinOfSupervisor  ", EmpHis2RLvl2_NameDesignatinOfSupervisor);
            store[75] = new SqlParameter("@EmpHis2RLvl2_TelepnoneNo  ", EmpHis2RLvl2_TelepnoneNo);
            store[76] = new SqlParameter("@EmpHis2RLvl2_MobileNo  ", EmpHis2RLvl2_MobileNo);
            store[77] = new SqlParameter("@EmpHis2RLvl2_EmailId   ", EmpHis2RLvl2_EmailId);
            store[78] = new SqlParameter("@EmpHis2_TempPerma   ", EmpHis2_TempPerma);
            store[79] = new SqlParameter("@EmpHis2_AgencyDetails  ", EmpHis2_AgencyDetails);
            store[80] = new SqlParameter("@EmpHis2_RemunerationOrSalary  ", EmpHis2_RemunerationOrSalary);
            store[81] = new SqlParameter("@EmpHis2_ReasonOfLeaving  ", EmpHis2_ReasonOfLeaving);
            store[82] = new SqlParameter("@EmpHis2_referenceYN  ", EmpHis2_referenceYN);
            store[83] = new SqlParameter("@cmp2department   ", cmp2department);
            store[84] = new SqlParameter("@EmpHis2_NoticePeriodorNot  ", EmpHis2_NoticePeriodorNot);
            store[85] = new SqlParameter("@EmpHis3_CompnayNameandLocation  ", EmpHis3_CompnayNameandLocation);
            store[86] = new SqlParameter("@EmpHis3_LastPositionHeldnDepartmentName  ", EmpHis3_LastPositionHeldnDepartmentName);
            store[87] = new SqlParameter("@EmpHis3_TelephoneNo  ", EmpHis3_TelephoneNo);
            store[88] = new SqlParameter("@EmpHis3_Address  ", EmpHis3_Address);
            store[89] = new SqlParameter("@EmpHis3_EmployeeCode  ", EmpHis3_EmployeeCode);
            store[90] = new SqlParameter("@EmpHis3_Experienceinyear  ", ExperienceInYears3);
            store[91] = new SqlParameter("@EmpHis3_PeriodofEmployment  ", EmpHis3_PeriodofEmployment);
            store[92] = new SqlParameter("@EmpHis3_PeriodofEmploymentTillDate  ", EmpHis3_PeriodofEmploymentRemark);
            store[93] = new SqlParameter("@EmpHis3RLvl1_NameDesignatinOfSupervisor  ", EmpHis3RLvl1_NameDesignatinOfSupervisor);
            store[94] = new SqlParameter("@EmpHis3RLvl1_TelepnoneNo  ", EmpHis3RLvl1_TelepnoneNo);
            store[95] = new SqlParameter("@EmpHis3RLvl1_MobileNo  ", EmpHis3RLvl1_MobileNo);
            store[96] = new SqlParameter("@EmpHis3RLvl1_EmailId  ", EmpHis3RLvl1_EmailId);
            store[97] = new SqlParameter("@EmpHis3RLvl2_NameDesignatinOfSupervisor  ", EmpHis3RLvl2_NameDesignatinOfSupervisor);
            store[98] = new SqlParameter("@EmpHis3RLvl2_TelepnoneNo  ", EmpHis3RLvl2_TelepnoneNo);
            store[99] = new SqlParameter("@EmpHis3RLvl2_MobileNo  ", EmpHis3RLvl2_MobileNo);
            store[100] = new SqlParameter("@EmpHis3RLvl2_EmailId  ", EmpHis3RLvl2_EmailId);
            store[101] = new SqlParameter("@EmpHis3_TempPerma  ", EmpHis3_TempPerma);
            store[102] = new SqlParameter("@EmpHis3_AgencyDetails  ", EmpHis3_AgencyDetails);
            store[103] = new SqlParameter("@EmpHis3_RemunerationOrSalary  ", EmpHis3_RemunerationOrSalary);
            store[104] = new SqlParameter("@EmpHis3_ReasonOfLeaving  ", EmpHis3_ReasonOfLeaving);
            store[105] = new SqlParameter("@EmpHis3_referenceYN  ", EmpHis3_referenceYN);
            store[106] = new SqlParameter("@cmp3department   ", cmp3department);
            store[107] = new SqlParameter("@EmpHis3_NoticePeriodorNot  ", EmpHis3_NoticePeriodorNot);
            store[108] = new SqlParameter("@EmpHis4_CompnayNameandLocation  ", EmpHis4_CompnayNameandLocation);
            store[109] = new SqlParameter("@EmpHis4_LastPositionHeldnDepartmentName  ", EmpHis4_LastPositionHeldnDepartmentName);
            store[110] = new SqlParameter("@EmpHis4_TelephoneNo  ", EmpHis4_TelephoneNo);
            store[111] = new SqlParameter("@EmpHis4_Address  ", EmpHis4_Address);
            store[112] = new SqlParameter("@EmpHis4_EmployeeCode  ", EmpHis4_EmployeeCode);
            store[113] = new SqlParameter("@EmpHis4_Experienceinyear  ", ExperienceInYears4);
            store[114] = new SqlParameter("@EmpHis4_PeriodofEmployment  ", EmpHis4_PeriodofEmployment);
            store[115] = new SqlParameter("@EmpHis4_PeriodofEmploymentTillDate  ", EmpHis4_PeriodofEmploymentRemark);
            store[116] = new SqlParameter("@EmpHis4RLvl1_NameDesignatinOfSupervisor  ", EmpHis4RLvl1_NameDesignatinOfSupervisor);
            store[117] = new SqlParameter("@EmpHis4RLvl1_TelepnoneNo  ", EmpHis4RLvl1_TelepnoneNo);
            store[118] = new SqlParameter("@EmpHis4RLvl1_MobileNo  ", EmpHis4RLvl1_MobileNo);
            store[119] = new SqlParameter("@EmpHis4RLvl1_EmailId  ", EmpHis4RLvl1_EmailId);
            store[120] = new SqlParameter("@EmpHis4RLvl2_NameDesignatinOfSupervisor  ", EmpHis4RLvl2_NameDesignatinOfSupervisor);
            store[121] = new SqlParameter("@EmpHis4RLvl2_TelepnoneNo  ", EmpHis4RLvl2_TelepnoneNo);
            store[122] = new SqlParameter("@EmpHis4RLvl2_MobileNo  ", EmpHis4RLvl2_MobileNo);
            store[123] = new SqlParameter("@EmpHis4RLvl2_EmailId  ", EmpHis4RLvl2_EmailId);
            store[124] = new SqlParameter("@EmpHis4_TempPerma   ", EmpHis4_TempPerma);
            store[125] = new SqlParameter("@EmpHis4_AgencyDetails  ", EmpHis4_AgencyDetails);
            store[126] = new SqlParameter("@EmpHis4_RemunerationOrSalary  ", EmpHis4_RemunerationOrSalary);
            store[127] = new SqlParameter("@EmpHis4_ReasonOfLeaving   ", EmpHis4_ReasonOfLeaving);
            store[128] = new SqlParameter("@EmpHis4_referenceYN  ", EmpHis4_referenceYN);
            store[129] = new SqlParameter("@cmp4department   ", cmp4department);
            store[130] = new SqlParameter("@EmpHis4_NoticePeriodorNot  ", EmpHis4_NoticePeriodorNot);
            store[131] = new SqlParameter("@EmpHis5_CompnayNameandLocation  ", EmpHis5_CompnayNameandLocation);
            store[132] = new SqlParameter("@EmpHis5_LastPositionHeldnDepartmentName  ", EmpHis5_LastPositionHeldnDepartmentName);
            store[133] = new SqlParameter("@EmpHis5_TelephoneNo  ", EmpHis5_TelephoneNo);
            store[134] = new SqlParameter("@EmpHis5_Address  ", EmpHis5_Address);
            store[135] = new SqlParameter("@EmpHis5_EmployeeCode  ", EmpHis5_EmployeeCode);
            store[136] = new SqlParameter("@EmpHis5_Experienceinyear  ", ExperienceInYears5);
            store[137] = new SqlParameter("@EmpHis5_PeriodofEmployment  ", EmpHis5_PeriodofEmployment);
            store[138] = new SqlParameter("@EmpHis5_PeriodofEmploymentTillDate  ", EmpHis5_PeriodofEmploymentRemark);
            store[139] = new SqlParameter("@EmpHis5RLvl1_NameDesignatinOfSupervisor   ", EmpHis5RLvl1_NameDesignatinOfSupervisor);
            store[140] = new SqlParameter("@EmpHis5RLvl1_TelepnoneNo  ", EmpHis5RLvl1_TelepnoneNo);
            store[141] = new SqlParameter("@EmpHis5RLvl1_MobileNo  ", EmpHis5RLvl1_MobileNo);
            store[142] = new SqlParameter("@EmpHis5RLvl1_EmailId  ", EmpHis5RLvl1_EmailId);
            store[143] = new SqlParameter("@EmpHis5RLvl2_NameDesignatinOfSupervisor  ", EmpHis5RLvl2_NameDesignatinOfSupervisor);
            store[144] = new SqlParameter("@EmpHis5RLvl2_TelepnoneNo  ", EmpHis5RLvl2_TelepnoneNo);
            store[145] = new SqlParameter("@EmpHis5RLvl2_MobileNo  ", EmpHis5RLvl2_MobileNo);
            store[146] = new SqlParameter("@EmpHis5RLvl2_EmailId  ", EmpHis5RLvl2_EmailId);
            store[147] = new SqlParameter("@EmpHis5_TempPerma  ", EmpHis5_TempPerma);
            store[148] = new SqlParameter("@EmpHis5_AgencyDetails  ", EmpHis5_AgencyDetails);
            store[149] = new SqlParameter("@EmpHis5_RemunerationOrSalary  ", EmpHis5_RemunerationOrSalary);
            store[150] = new SqlParameter("@EmpHis5_ReasonOfLeaving   ", EmpHis5_ReasonOfLeaving);
            store[151] = new SqlParameter("@EmpHis5_referenceYN", EmpHis5_referenceYN);
            store[152] = new SqlParameter("@cmp5department   ", cmp5department);
            store[153] = new SqlParameter("@EmpHis5_NoticePeriodorNot", EmpHis5_NoticePeriodorNot);
            store[154] = new SqlParameter("@COE", COE);
            store[155] = new SqlParameter("@MODE", Mode);
            store[156] = new SqlParameter("@RejectedRemarks1", RejectedRemarks1);
            store[157] = new SqlParameter("@RejectedRemarks2", RejectedRemarks2);
            store[158] = new SqlParameter("@RejectedRemarks3", RejectedRemarks3);
            store[159] = new SqlParameter("@RejectedRemarks4", RejectedRemarks4);
            store[160] = new SqlParameter("@RejectedRemarks5", RejectedRemarks5);
            store[161] = new SqlParameter("@comment1", comment1);
            store[162] = new SqlParameter("@comment2", comment2);
            store[163] = new SqlParameter("@comment3", comment3);
            store[164] = new SqlParameter("@comment4", comment4);
            store[165] = new SqlParameter("@comment5", comment5);
            store[166] = new SqlParameter("@cmp1HRdesignation", cmp1HRdesignation);
            store[167] = new SqlParameter("@cmp2HRdesignation", cmp2HRdesignation);
            store[168] = new SqlParameter("@cmp3HRdesignation", cmp3HRdesignation);
            store[169] = new SqlParameter("@cmp4HRdesignation", cmp4HRdesignation);
            store[170] = new SqlParameter("@cmp5HRdesignation", cmp5HRdesignation);
            store[171] = new SqlParameter("@cmp1RMdesignation", cmp1RMdesignation);
            store[172] = new SqlParameter("@cmp2RMdesignation", cmp2RMdesignation);
            store[173] = new SqlParameter("@cmp3RMdesignation", cmp3RMdesignation);
            store[174] = new SqlParameter("@cmp4RMdesignation", cmp4RMdesignation);
            store[175] = new SqlParameter("@cmp5RMdesignation", cmp5RMdesignation);
            store[176] = new SqlParameter("@CandidateID", CandidateID);
            store[177] = new SqlParameter("@CurrentEmployment", CurrentEmployment);
            store[178] = new SqlParameter("@user", user);
            store[179] = new SqlParameter("@candidatealternateno", candidatealternateno);
            store[180] = new SqlParameter("@candidateremarks", candidateremarks);

            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "saveband4partial", store));
        }


        public int insertband4info(CandidateDetails candidateobj)
        {
            int i;
            SqlParameter[] store = new SqlParameter[4];


            store[0] = new SqlParameter("@FirstName", FirstName);
            store[1] = new SqlParameter("@Mobile", Mobile);
            store[2] = new SqlParameter("@COE", COE);
            store[3] = new SqlParameter("@user", user);


            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "insertband4info", store));
        }

        public int saveband4CandidateDetails(CandidateDetails candidateobj)
        {
            int i;
            SqlParameter[] store = new SqlParameter[246];
            store[0] = new SqlParameter("@PlaceofJoing", PlaceofJoing);
            store[1] = new SqlParameter("@Band", Band);
            store[2] = new SqlParameter("@FirstName", FirstName);
            store[3] = new SqlParameter("@MiddleName", MiddleName);
            store[4] = new SqlParameter("@Surname", Surname);
            store[5] = new SqlParameter("@FatherName", FatherName);
            store[6] = new SqlParameter("@DOB", DOB);
            store[7] = new SqlParameter("@Mobile", Mobile);
            store[8] = new SqlParameter("@DOJ", DateofJoining);
            store[190] = new SqlParameter("@gender", gender);
            store[191] = new SqlParameter("@maritalstatus",maritalstatus);
            store[9] = new SqlParameter("@Refcheck ", RefList);
            store[10] = new SqlParameter("@refcheck1appname", Ref1RefName);
            store[11] = new SqlParameter("@ref1company ", Ref1CompName);
            store[12] = new SqlParameter("@ref1desig", Ref1Designation);
            store[13] = new SqlParameter("@ref1email", Ref1Email);
            store[14] = new SqlParameter("@ref1cn", Ref1Contact);
            store[15] = new SqlParameter("@refcheck2appname", Ref2RefName);
            store[16] = new SqlParameter("@ref2company", Ref2CompName);
            store[17] = new SqlParameter("@ref2desig", Ref2Designation);
            store[18] = new SqlParameter("@ref2email", Ref2Email);
            store[19] = new SqlParameter("@ref2cn", Ref2Contact);
            store[20] = new SqlParameter("@cibilcheck", CIBILList);
            store[21] = new SqlParameter("@cibilcn", CIBILContact);
            store[22] = new SqlParameter("@cibildob", CIBILDOB);
            store[23] = new SqlParameter("@cibilemailid", CIBILEmail);
            store[24] = new SqlParameter("@cibilname", CIBILFullName);
            store[25] = new SqlParameter("@cibilgender", CIBILGender);
            store[26] = new SqlParameter("@cibilpancardno", CIBILPanCard);
            store[192] = new SqlParameter("@cibilpasport",CIBILpassportno);
            store[193] = new SqlParameter("@cibilvoterid",CIBILvoterID);
            store[194] = new SqlParameter("@cibillicence",CIBILDrivinglicense);
            store[195] = new SqlParameter("@addresschecks", AddressCheck);
            store[196] = new SqlParameter("@PermanentAddress", PermanentAddress);
            store[197] = new SqlParameter("@Per_City", Per_City);
            store[198] = new SqlParameter("@Per_State", Per_State);
            store[199] = new SqlParameter("@Per_AddressPhoneNo", Per_AddressPhoneNo);
            store[200] = new SqlParameter("@Per_Landmark", Per_Landmark);
            store[201] = new SqlParameter("@Per_LivingSince", Per_LivingSince);
            store[202] = new SqlParameter("@Per_PoliceStation", Per_PoliceStation);
            store[203] = new SqlParameter("@Per_PostOffice", Per_PostOffice);
            store[204] = new SqlParameter("@CurrentAddress", CurrentAddress);
            store[205] = new SqlParameter("@Curr_City", Curr_City);
            store[206] = new SqlParameter("@Curr_State", Curr_State);
            store[207] = new SqlParameter("@Curr_PhoneNo  ", Curr_PhoneNo);
            store[208] = new SqlParameter("@LogestStay_address  ", add1logeststay);
            store[209] = new SqlParameter("@LogestStay_State  ", add1logeststarystate);
            store[210] = new SqlParameter("@LogestStay_City ", add1logeststarycity);
            store[211] = new SqlParameter("@LogestStay_PhoneNo  ", add1logeststaryphonenumber);
            store[212] = new SqlParameter("@LogestStay_Landmark  ", add1logeststarylandmark);
            store[213] = new SqlParameter("@LogestStay_LivingSince  ", add1logeststaryLeavingsince);
            store[214] = new SqlParameter("@LogestStay_PoliceStation  ", add1logeststarypolicestation);
            store[215] = new SqlParameter("@LogestStay_Pincode  ", add1logeststarypincode);

            store[216] = new SqlParameter("@Edu4_CollegeName", Edu4_CollegeName);
            store[217] = new SqlParameter("@Edu4_UniversityName", Edu4_UniversityName);
            store[218] = new SqlParameter("@Edu4_Address", Edu4_Address);
            store[219] = new SqlParameter("@Edu4_EducationalQualification", Edu4_EducationalQualification);
            store[220] = new SqlParameter("@Edu4_RollNo", Edu4_RollNo);
            store[221] = new SqlParameter("@YearofPassing4", YearOfPassing4);
            store[222] = new SqlParameter("@Edu5_CollegeName", Edu5_CollegeName);
            store[223] = new SqlParameter("@Edu5_UniversityName", Edu5_UniversityName);
            store[224] = new SqlParameter("@Edu5_Address", Edu5_Address);
            store[225] = new SqlParameter("@Edu5_EducationalQualification", Edu5_EducationalQualification);
            store[226] = new SqlParameter("@Edu5_RollNo", Edu5_RollNo);
            store[227] = new SqlParameter("@YearofPassing5", YearOfPassing5);
            store[228] = new SqlParameter("@Edu6_CollegeName", Edu6_CollegeName);
            store[229] = new SqlParameter("@Edu6_UniversityName", Edu6_UniversityName);
            store[230] = new SqlParameter("@Edu6_Address", Edu6_Address);
            store[231] = new SqlParameter("@Edu6_EducationalQualification", Edu6_EducationalQualification);
            store[232] = new SqlParameter("@Edu6_RollNo", Edu6_RollNo);
            store[233] = new SqlParameter("@YearofPassing6", YearOfPassing6);
            store[234] = new SqlParameter("@Edu7_CollegeName", Edu7_CollegeName);
            store[235] = new SqlParameter("@Edu7_UniversityName", Edu7_UniversityName);
            store[236] = new SqlParameter("@Edu7_Address", Edu7_Address);
            store[237] = new SqlParameter("@Edu7_EducationalQualification", Edu7_EducationalQualification);
            store[238] = new SqlParameter("@Edu7_RollNo", Edu7_RollNo);
            store[239] = new SqlParameter("@YearofPassing7", YearOfPassing7);
            store[240] = new SqlParameter("@Edu8_CollegeName", Edu8_CollegeName);
            store[241] = new SqlParameter("@Edu8_UniversityName", Edu8_UniversityName);
            store[242] = new SqlParameter("@Edu8_Address", Edu8_Address);
            store[243] = new SqlParameter("@Edu8_EducationalQualification", Edu8_EducationalQualification);
            store[244] = new SqlParameter("@Edu8_RollNo", Edu8_RollNo);
            store[245] = new SqlParameter("@YearofPassing8", YearOfPassing8);


            store[181] = new SqlParameter("@Fresher_experience", FresherOrExp);
            store[182] = new SqlParameter("@educationcheck", EducationList);
            store[183] = new SqlParameter("@Edu1_CollegeName", Edu1_CollegeName);
            store[184] = new SqlParameter("@Edu1_UniversityName", Edu1_UniversityName);
            store[185] = new SqlParameter("@Edu1_Address", Edu1_Address);
            store[186] = new SqlParameter("@Edu1_EducationalQualification  ", Edu1_EducationalQualification);
            store[187] = new SqlParameter("@Edu1_RollNo", Edu1_RollNo);
            store[188] = new SqlParameter("@YearofPassing", Edu1_YearOfPassing);
            store[189] = new SqlParameter("@Edu2_CollegeName", Edu2_CollegeName);
            store[27] = new SqlParameter("@Edu2_UniversityName", Edu2_UniversityName);
            store[28] = new SqlParameter("@Edu2_Address", Edu2_Address);
            store[29] = new SqlParameter("@Edu2_EducationalQualification", Edu2_EducationalQualification);
            store[30] = new SqlParameter("@Edu2_RollNo", Edu2_RollNo);
            store[31] = new SqlParameter("@YearofPassing2", Edu2_YearOfPassing);
            store[32] = new SqlParameter("@Edu3_CollegeName", Edu3_CollegeName);
            store[33] = new SqlParameter("@Edu3_UniversityName", Edu3_UniversityName);
            store[34] = new SqlParameter("@Edu3_Address", Edu3_Address);
            store[35] = new SqlParameter("@Edu3_EducationalQualification", Edu3_EducationalQualification);
            store[36] = new SqlParameter("@Edu3_RollNo", Edu3_RollNo);
            store[37] = new SqlParameter("@YearofPassing3", YearOfPassing3);
            store[38] = new SqlParameter("@Noofcompany", NoOfComp);            //cmp 1
            store[39] = new SqlParameter("@EmpHis1_CompnayNameandLocation", EmpHis1_CompnayNameandLocation);
            store[40] = new SqlParameter("@EmpHis1_LastPositionHeldnDepartmentName", EmpHis1_LastPositionHeldnDepartmentName);
            store[41] = new SqlParameter("@EmpHis1_TelephoneNo", EmpHis1_TelephoneNo);
            store[42] = new SqlParameter("@EmpHis1_Address", EmpHis1_Address);
            store[43] = new SqlParameter("@EmpHis1_EmployeeCode", EmpHis1_EmployeeCode);
            store[44] = new SqlParameter("@EmpHis1_Experienceinyear", ExperienceInYears1);
            store[45] = new SqlParameter("@EmpHis1_PeriodofEmployment", EmpHis1_PeriodofEmployment);
            store[46] = new SqlParameter("@EmpHis1_PeriodofEmploymentTillDate", EmpHis1_PeriodofEmploymentRemark);
            store[47] = new SqlParameter("@EmpHis1RLvl1_NameDesignatinOfSupervisor", EmpHis1RLvl1_NameDesignatinOfSupervisor);
            store[48] = new SqlParameter("@EmpHis1RLvl1_TelepnoneNo", EmpHis1RLvl1_TelepnoneNo);
            store[49] = new SqlParameter("@EmpHis1RLvl1_MobileNo", EmpHis1RLvl1_MobileNo);
            store[50] = new SqlParameter("@EmpHis1RLvl1_EmailId", EmpHis1RLvl1_EmailId);
            store[51] = new SqlParameter("@EmpHis1RLvl2_NameDesignatinOfSupervisor", EmpHis1RLvl2_NameDesignatinOfSupervisor);
            store[52] = new SqlParameter("@EmpHis1RLvl2_TelepnoneNo  ", EmpHis1RLvl2_TelepnoneNo);
            store[53] = new SqlParameter("@EmpHis1RLvl2_MobileNo  ", EmpHis1RLvl2_MobileNo);
            store[54] = new SqlParameter("@EmpHis1RLvl2_EmailId   ", EmpHis1RLvl2_EmailId);
            store[55] = new SqlParameter("@EmpHis1_TempPerma  ", EmpHis1_TempPerma);
            store[56] = new SqlParameter("@EmpHis1_AgencyDetails  ", EmpHis1_AgencyDetails);
            store[57] = new SqlParameter("@EmpHis1_RemunerationOrSalary  ", EmpHis1_RemunerationOrSalary);
            store[58] = new SqlParameter("@EmpHis1_ReasonOfLeaving   ", EmpHis1_ReasonOfLeaving);
            store[59] = new SqlParameter("@EmpHis1_referenceYN   ", EmpHis1_referenceYN);
            store[60] = new SqlParameter("@cmp1department   ", cmp1department);
            store[61] = new SqlParameter("@EmpHis1_NoticePeriodorNot  ", EmpHis1_NoticePeriodorNot);
            store[62] = new SqlParameter("@EmpHis2_CompnayNameandLocation  ", EmpHis2_CompnayNameandLocation);
            store[63] = new SqlParameter("@EmpHis2_LastPositionHeldnDepartmentName  ", EmpHis2_LastPositionHeldnDepartmentName);
            store[64] = new SqlParameter("@EmpHis2_TelephoneNo  ", EmpHis2_TelephoneNo);
            store[65] = new SqlParameter("@EmpHis2_Address  ", EmpHis2_Address);
            store[66] = new SqlParameter("@EmpHis2_EmployeeCode  ", EmpHis2_EmployeeCode);
            store[67] = new SqlParameter("@EmpHis2_Experienceinyear  ", ExperienceInYears2);
            store[68] = new SqlParameter("@EmpHis2_PeriodofEmployment  ", EmpHis2_PeriodofEmployment);
            store[69] = new SqlParameter("@EmpHis2_PeriodofEmploymentTillDate  ", EmpHis2_PeriodofEmploymentRemark);
            store[70] = new SqlParameter("@EmpHis2RLvl1_NameDesignatinOfSupervisor  ", EmpHis2RLvl1_NameDesignatinOfSupervisor);
            store[71] = new SqlParameter("@EmpHis2RLvl1_TelepnoneNo  ", EmpHis2RLvl1_TelepnoneNo);
            store[72] = new SqlParameter("@EmpHis2RLvl1_MobileNo   ", EmpHis2RLvl1_MobileNo);
            store[73] = new SqlParameter("@EmpHis2RLvl1_EmailId  ", EmpHis2RLvl1_EmailId);
            store[74] = new SqlParameter("@EmpHis2RLvl2_NameDesignatinOfSupervisor  ", EmpHis2RLvl2_NameDesignatinOfSupervisor);
            store[75] = new SqlParameter("@EmpHis2RLvl2_TelepnoneNo  ", EmpHis2RLvl2_TelepnoneNo);
            store[76] = new SqlParameter("@EmpHis2RLvl2_MobileNo  ", EmpHis2RLvl2_MobileNo);
            store[77] = new SqlParameter("@EmpHis2RLvl2_EmailId   ", EmpHis2RLvl2_EmailId);
            store[78] = new SqlParameter("@EmpHis2_TempPerma   ", EmpHis2_TempPerma);
            store[79] = new SqlParameter("@EmpHis2_AgencyDetails  ", EmpHis2_AgencyDetails);
            store[80] = new SqlParameter("@EmpHis2_RemunerationOrSalary  ", EmpHis2_RemunerationOrSalary);
            store[81] = new SqlParameter("@EmpHis2_ReasonOfLeaving  ", EmpHis2_ReasonOfLeaving);
            store[82] = new SqlParameter("@EmpHis2_referenceYN  ", EmpHis2_referenceYN);
            store[83] = new SqlParameter("@cmp2department   ", cmp2department);
            store[84] = new SqlParameter("@EmpHis2_NoticePeriodorNot  ", EmpHis2_NoticePeriodorNot);
            store[85] = new SqlParameter("@EmpHis3_CompnayNameandLocation  ", EmpHis3_CompnayNameandLocation);
            store[86] = new SqlParameter("@EmpHis3_LastPositionHeldnDepartmentName  ", EmpHis3_LastPositionHeldnDepartmentName);
            store[87] = new SqlParameter("@EmpHis3_TelephoneNo  ", EmpHis3_TelephoneNo);
            store[88] = new SqlParameter("@EmpHis3_Address  ", EmpHis3_Address);
            store[89] = new SqlParameter("@EmpHis3_EmployeeCode  ", EmpHis3_EmployeeCode);
            store[90] = new SqlParameter("@EmpHis3_Experienceinyear  ", ExperienceInYears3);
            store[91] = new SqlParameter("@EmpHis3_PeriodofEmployment  ", EmpHis3_PeriodofEmployment);
            store[92] = new SqlParameter("@EmpHis3_PeriodofEmploymentTillDate  ", EmpHis3_PeriodofEmploymentRemark);
            store[93] = new SqlParameter("@EmpHis3RLvl1_NameDesignatinOfSupervisor  ", EmpHis3RLvl1_NameDesignatinOfSupervisor);
            store[94] = new SqlParameter("@EmpHis3RLvl1_TelepnoneNo  ", EmpHis3RLvl1_TelepnoneNo);
            store[95] = new SqlParameter("@EmpHis3RLvl1_MobileNo  ", EmpHis3RLvl1_MobileNo);
            store[96] = new SqlParameter("@EmpHis3RLvl1_EmailId  ", EmpHis3RLvl1_EmailId);
            store[97] = new SqlParameter("@EmpHis3RLvl2_NameDesignatinOfSupervisor  ", EmpHis3RLvl2_NameDesignatinOfSupervisor);
            store[98] = new SqlParameter("@EmpHis3RLvl2_TelepnoneNo  ", EmpHis3RLvl2_TelepnoneNo);
            store[99] = new SqlParameter("@EmpHis3RLvl2_MobileNo  ", EmpHis3RLvl2_MobileNo);
            store[100] = new SqlParameter("@EmpHis3RLvl2_EmailId  ", EmpHis3RLvl2_EmailId);
            store[101] = new SqlParameter("@EmpHis3_TempPerma  ", EmpHis3_TempPerma);
            store[102] = new SqlParameter("@EmpHis3_AgencyDetails  ", EmpHis3_AgencyDetails);
            store[103] = new SqlParameter("@EmpHis3_RemunerationOrSalary  ", EmpHis3_RemunerationOrSalary);
            store[104] = new SqlParameter("@EmpHis3_ReasonOfLeaving  ", EmpHis3_ReasonOfLeaving);
            store[105] = new SqlParameter("@EmpHis3_referenceYN  ", EmpHis3_referenceYN);
            store[106] = new SqlParameter("@cmp3department   ", cmp3department);
            store[107] = new SqlParameter("@EmpHis3_NoticePeriodorNot  ", EmpHis3_NoticePeriodorNot);
            store[108] = new SqlParameter("@EmpHis4_CompnayNameandLocation  ", EmpHis4_CompnayNameandLocation);
            store[109] = new SqlParameter("@EmpHis4_LastPositionHeldnDepartmentName  ", EmpHis4_LastPositionHeldnDepartmentName);
            store[110] = new SqlParameter("@EmpHis4_TelephoneNo  ", EmpHis4_TelephoneNo);
            store[111] = new SqlParameter("@EmpHis4_Address  ", EmpHis4_Address);
            store[112] = new SqlParameter("@EmpHis4_EmployeeCode  ", EmpHis4_EmployeeCode);
            store[113] = new SqlParameter("@EmpHis4_Experienceinyear  ", ExperienceInYears4);
            store[114] = new SqlParameter("@EmpHis4_PeriodofEmployment  ", EmpHis4_PeriodofEmployment);
            store[115] = new SqlParameter("@EmpHis4_PeriodofEmploymentTillDate  ", EmpHis4_PeriodofEmploymentRemark);
            store[116] = new SqlParameter("@EmpHis4RLvl1_NameDesignatinOfSupervisor  ", EmpHis4RLvl1_NameDesignatinOfSupervisor);
            store[117] = new SqlParameter("@EmpHis4RLvl1_TelepnoneNo  ", EmpHis4RLvl1_TelepnoneNo);
            store[118] = new SqlParameter("@EmpHis4RLvl1_MobileNo  ", EmpHis4RLvl1_MobileNo);
            store[119] = new SqlParameter("@EmpHis4RLvl1_EmailId  ", EmpHis4RLvl1_EmailId);
            store[120] = new SqlParameter("@EmpHis4RLvl2_NameDesignatinOfSupervisor  ", EmpHis4RLvl2_NameDesignatinOfSupervisor);
            store[121] = new SqlParameter("@EmpHis4RLvl2_TelepnoneNo  ", EmpHis4RLvl2_TelepnoneNo);
            store[122] = new SqlParameter("@EmpHis4RLvl2_MobileNo  ", EmpHis4RLvl2_MobileNo);
            store[123] = new SqlParameter("@EmpHis4RLvl2_EmailId  ", EmpHis4RLvl2_EmailId);
            store[124] = new SqlParameter("@EmpHis4_TempPerma   ", EmpHis4_TempPerma);
            store[125] = new SqlParameter("@EmpHis4_AgencyDetails  ", EmpHis4_AgencyDetails);
            store[126] = new SqlParameter("@EmpHis4_RemunerationOrSalary  ", EmpHis4_RemunerationOrSalary);
            store[127] = new SqlParameter("@EmpHis4_ReasonOfLeaving   ", EmpHis4_ReasonOfLeaving);
            store[128] = new SqlParameter("@EmpHis4_referenceYN  ", EmpHis4_referenceYN);
            store[129] = new SqlParameter("@cmp4department   ", cmp4department);
            store[130] = new SqlParameter("@EmpHis4_NoticePeriodorNot  ", EmpHis4_NoticePeriodorNot);
            store[131] = new SqlParameter("@EmpHis5_CompnayNameandLocation  ", EmpHis5_CompnayNameandLocation);
            store[132] = new SqlParameter("@EmpHis5_LastPositionHeldnDepartmentName  ", EmpHis5_LastPositionHeldnDepartmentName);
            store[133] = new SqlParameter("@EmpHis5_TelephoneNo  ", EmpHis5_TelephoneNo);
            store[134] = new SqlParameter("@EmpHis5_Address  ", EmpHis5_Address);
            store[135] = new SqlParameter("@EmpHis5_EmployeeCode  ", EmpHis5_EmployeeCode);
            store[136] = new SqlParameter("@EmpHis5_Experienceinyear  ", ExperienceInYears5);
            store[137] = new SqlParameter("@EmpHis5_PeriodofEmployment  ", EmpHis5_PeriodofEmployment);
            store[138] = new SqlParameter("@EmpHis5_PeriodofEmploymentTillDate  ", EmpHis5_PeriodofEmploymentRemark);
            store[139] = new SqlParameter("@EmpHis5RLvl1_NameDesignatinOfSupervisor   ", EmpHis5RLvl1_NameDesignatinOfSupervisor);
            store[140] = new SqlParameter("@EmpHis5RLvl1_TelepnoneNo  ", EmpHis5RLvl1_TelepnoneNo);
            store[141] = new SqlParameter("@EmpHis5RLvl1_MobileNo  ", EmpHis5RLvl1_MobileNo);
            store[142] = new SqlParameter("@EmpHis5RLvl1_EmailId  ", EmpHis5RLvl1_EmailId);
            store[143] = new SqlParameter("@EmpHis5RLvl2_NameDesignatinOfSupervisor  ", EmpHis5RLvl2_NameDesignatinOfSupervisor);
            store[144] = new SqlParameter("@EmpHis5RLvl2_TelepnoneNo  ", EmpHis5RLvl2_TelepnoneNo);
            store[145] = new SqlParameter("@EmpHis5RLvl2_MobileNo  ", EmpHis5RLvl2_MobileNo);
            store[146] = new SqlParameter("@EmpHis5RLvl2_EmailId  ", EmpHis5RLvl2_EmailId);
            store[147] = new SqlParameter("@EmpHis5_TempPerma  ", EmpHis5_TempPerma);
            store[148] = new SqlParameter("@EmpHis5_AgencyDetails  ", EmpHis5_AgencyDetails);
            store[149] = new SqlParameter("@EmpHis5_RemunerationOrSalary  ", EmpHis5_RemunerationOrSalary);
            store[150] = new SqlParameter("@EmpHis5_ReasonOfLeaving   ", EmpHis5_ReasonOfLeaving);
            store[151] = new SqlParameter("@EmpHis5_referenceYN", EmpHis5_referenceYN);
            store[152] = new SqlParameter("@cmp5department   ", cmp5department);
            store[153] = new SqlParameter("@EmpHis5_NoticePeriodorNot", EmpHis5_NoticePeriodorNot);
            store[154] = new SqlParameter("@COE", COE);
            store[155] = new SqlParameter("@MODE", Mode);
            store[156] = new SqlParameter("@RejectedRemarks1", RejectedRemarks1);
            store[157] = new SqlParameter("@RejectedRemarks2", RejectedRemarks2);
            store[158] = new SqlParameter("@RejectedRemarks3", RejectedRemarks3);
            store[159] = new SqlParameter("@RejectedRemarks4", RejectedRemarks4);
            store[160] = new SqlParameter("@RejectedRemarks5", RejectedRemarks5);
            store[161] = new SqlParameter("@comment1", comment1);
            store[162] = new SqlParameter("@comment2", comment2);
            store[163] = new SqlParameter("@comment3", comment3);
            store[164] = new SqlParameter("@comment4", comment4);
            store[165] = new SqlParameter("@comment5", comment5);
            store[166] = new SqlParameter("@cmp1HRdesignation", cmp1HRdesignation);
            store[167] = new SqlParameter("@cmp2HRdesignation", cmp2HRdesignation);
            store[168] = new SqlParameter("@cmp3HRdesignation", cmp3HRdesignation);
            store[169] = new SqlParameter("@cmp4HRdesignation", cmp4HRdesignation);
            store[170] = new SqlParameter("@cmp5HRdesignation", cmp5HRdesignation);
            store[171] = new SqlParameter("@cmp1RMdesignation", cmp1RMdesignation);
            store[172] = new SqlParameter("@cmp2RMdesignation", cmp2RMdesignation);
            store[173] = new SqlParameter("@cmp3RMdesignation", cmp3RMdesignation);
            store[174] = new SqlParameter("@cmp4RMdesignation", cmp4RMdesignation);
            store[175] = new SqlParameter("@cmp5RMdesignation", cmp5RMdesignation);
            store[176] = new SqlParameter("@CandidateID", CandidateID);
            store[177] = new SqlParameter("@CurrentEmployment", CurrentEmployment);
            store[178] = new SqlParameter("@user", user);
            store[179] = new SqlParameter("@candidatealternateno", candidatealternateno);
            store[180] = new SqlParameter("@candidateremarks", candidateremarks);

            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "saveband4CandidateDetails", store));
        }
        public int saveHeadstrongCandidateDetails(CandidateDetails candidateobj)
        {
            int i;
            SqlParameter[] store = new SqlParameter[145];
            store[0] = new SqlParameter("@PlaceofJoing", PlaceofJoing);
            store[1] = new SqlParameter("@Band", Band);
            store[2] = new SqlParameter("@FirstName", FirstName);
            store[3] = new SqlParameter("@MiddleName", MiddleName);
            store[4] = new SqlParameter("@Surname", Surname);
            store[5] = new SqlParameter("@FatherName", FatherName);
            store[6] = new SqlParameter("@DOB", DOB);
            store[7] = new SqlParameter("@Mobile", Mobile);
            store[8] = new SqlParameter("@DOJ", DateofJoining);

            store[9] = new SqlParameter("@addresschecks", AddressCheck);
            store[10] = new SqlParameter("@PermanentAddress", PermanentAddress);
            store[11] = new SqlParameter("@Per_City", Per_City);
            store[12] = new SqlParameter("@Per_State", Per_State);
            store[13] = new SqlParameter("@Per_AddressPhoneNo", Per_AddressPhoneNo);
            store[14] = new SqlParameter("@Per_Landmark", Per_Landmark);
            store[15] = new SqlParameter("@Per_LivingSince", Per_LivingSince);
            store[16] = new SqlParameter("@Per_PoliceStation", Per_PoliceStation);
            store[17] = new SqlParameter("@Per_PostOffice", Per_PostOffice);

            store[18] = new SqlParameter("@Edu2_CollegeName", Edu2_CollegeName);
            store[19] = new SqlParameter("@Edu2_UniversityName", Edu2_UniversityName);
            store[20] = new SqlParameter("@Edu2_Address", Edu2_Address);
            store[21] = new SqlParameter("@Edu2_EducationalQualification", Edu2_EducationalQualification);
            store[22] = new SqlParameter("@Edu2_RollNo  ", Edu2_RollNo);
            store[23] = new SqlParameter("@YearofPassing2  ", Edu2_YearOfPassing);


            store[24] = new SqlParameter("@txtRefCheck1AppName", txtRefCheck1AppName);
            store[25] = new SqlParameter("@txtRef1Company ", txtRef1Company);
            store[26] = new SqlParameter("@txtRef1Desi", txtRef1Desi);
            store[27] = new SqlParameter("@txtRef1Email", txtRef1Email);
            store[28] = new SqlParameter("@txtRef1CN", txtRef1CN);
            store[29] = new SqlParameter("@txtRef1Remark", txtRef1Remark);

            store[30] = new SqlParameter("@Fresher_experience", FresherOrExp);
            store[31] = new SqlParameter("@educationcheck", EducationList);
            store[32] = new SqlParameter("@Edu1_CollegeName", Edu1_CollegeName);
            store[33] = new SqlParameter("@Edu1_UniversityName", Edu1_UniversityName);
            store[34] = new SqlParameter("@Edu1_Address", Edu1_Address);
            store[35] = new SqlParameter("@Edu1_EducationalQualification", Edu1_EducationalQualification);
            store[36] = new SqlParameter("@Edu1_RollNo", Edu1_RollNo);
            store[37] = new SqlParameter("@YearofPassing", Edu1_YearOfPassing);
            store[38] = new SqlParameter("@Noofcompany", NoOfComp);
            //cmp 1
            store[39] = new SqlParameter("@EmpHis1_CompnayNameandLocation  ", EmpHis1_CompnayNameandLocation);
            store[40] = new SqlParameter("@EmpHis1_LastPositionHeldnDepartmentName  ", EmpHis1_LastPositionHeldnDepartmentName);
            store[41] = new SqlParameter("@EmpHis1_TelephoneNo  ", EmpHis1_TelephoneNo);
            store[42] = new SqlParameter("@EmpHis1_Address  ", EmpHis1_Address);

            store[43] = new SqlParameter("@EmpHis1_EmployeeCode  ", EmpHis1_EmployeeCode);
            store[44] = new SqlParameter("@EmpHis1_Experienceinyear   ", ExperienceInYears1);
            store[45] = new SqlParameter("@EmpHis1_PeriodofEmployment  ", EmpHis1_PeriodofEmployment);
            store[46] = new SqlParameter("@EmpHis1_PeriodofEmploymentTillDate  ", EmpHis1_PeriodofEmploymentRemark);

            store[47] = new SqlParameter("@EmpHis1RLvl1_NameDesignatinOfSupervisor  ", EmpHis1RLvl1_NameDesignatinOfSupervisor);
            store[48] = new SqlParameter("@EmpHis1RLvl1_TelepnoneNo  ", EmpHis1RLvl1_TelepnoneNo);
            store[49] = new SqlParameter("@EmpHis1RLvl1_MobileNo  ", EmpHis1RLvl1_MobileNo);
            store[50] = new SqlParameter("@EmpHis1RLvl1_EmailId   ", EmpHis1RLvl1_EmailId);

            store[51] = new SqlParameter("@EmpHis1RLvl2_NameDesignatinOfSupervisor  ", EmpHis1RLvl2_NameDesignatinOfSupervisor);
            store[52] = new SqlParameter("@EmpHis1RLvl2_TelepnoneNo  ", EmpHis1RLvl2_TelepnoneNo);
            store[53] = new SqlParameter("@EmpHis1RLvl2_MobileNo  ", EmpHis1RLvl2_MobileNo);
            store[54] = new SqlParameter("@EmpHis1RLvl2_EmailId   ", EmpHis1RLvl2_EmailId);

            store[55] = new SqlParameter("@EmpHis1_TempPerma  ", EmpHis1_TempPerma);
            store[56] = new SqlParameter("@EmpHis1_AgencyDetails  ", EmpHis1_AgencyDetails);
            store[57] = new SqlParameter("@EmpHis1_RemunerationOrSalary  ", EmpHis1_RemunerationOrSalary);
            store[58] = new SqlParameter("@EmpHis1_ReasonOfLeaving   ", EmpHis1_ReasonOfLeaving);

            store[59] = new SqlParameter("@EmpHis1_referenceYN   ", EmpHis1_referenceYN);
            store[60] = new SqlParameter("@cmp1department   ", cmp1department);
            store[61] = new SqlParameter("@EmpHis1_NoticePeriodorNot  ", EmpHis1_NoticePeriodorNot);

            store[62] = new SqlParameter("@EmpHis2_CompnayNameandLocation  ", EmpHis2_CompnayNameandLocation);
            store[63] = new SqlParameter("@EmpHis2_LastPositionHeldnDepartmentName  ", EmpHis2_LastPositionHeldnDepartmentName);
            store[64] = new SqlParameter("@EmpHis2_TelephoneNo  ", EmpHis2_TelephoneNo);
            store[65] = new SqlParameter("@EmpHis2_Address  ", EmpHis2_Address);

            store[66] = new SqlParameter("@EmpHis2_EmployeeCode  ", EmpHis2_EmployeeCode);
            store[67] = new SqlParameter("@EmpHis2_Experienceinyear  ", ExperienceInYears2);
            store[68] = new SqlParameter("@EmpHis2_PeriodofEmployment  ", EmpHis2_PeriodofEmployment);
            store[69] = new SqlParameter("@EmpHis2_PeriodofEmploymentTillDate  ", EmpHis2_PeriodofEmploymentRemark);

            store[70] = new SqlParameter("@EmpHis2RLvl1_NameDesignatinOfSupervisor  ", EmpHis2RLvl1_NameDesignatinOfSupervisor);
            store[71] = new SqlParameter("@EmpHis2RLvl1_TelepnoneNo  ", EmpHis2RLvl1_TelepnoneNo);
            store[72] = new SqlParameter("@EmpHis2RLvl1_MobileNo   ", EmpHis2RLvl1_MobileNo);
            store[73] = new SqlParameter("@EmpHis2RLvl1_EmailId  ", EmpHis2RLvl1_EmailId);

            store[74] = new SqlParameter("@EmpHis2RLvl2_NameDesignatinOfSupervisor  ", EmpHis2RLvl2_NameDesignatinOfSupervisor);
            store[75] = new SqlParameter("@EmpHis2RLvl2_TelepnoneNo  ", EmpHis2RLvl2_TelepnoneNo);
            store[76] = new SqlParameter("@EmpHis2RLvl2_MobileNo  ", EmpHis2RLvl2_MobileNo);
            store[77] = new SqlParameter("@EmpHis2RLvl2_EmailId   ", EmpHis2RLvl2_EmailId);

            store[78] = new SqlParameter("@EmpHis2_TempPerma   ", EmpHis2_TempPerma);
            store[79] = new SqlParameter("@EmpHis2_AgencyDetails  ", EmpHis2_AgencyDetails);
            store[80] = new SqlParameter("@EmpHis2_RemunerationOrSalary  ", EmpHis2_RemunerationOrSalary);
            store[81] = new SqlParameter("@EmpHis2_ReasonOfLeaving  ", EmpHis2_ReasonOfLeaving);

            store[82] = new SqlParameter("@EmpHis2_referenceYN  ", EmpHis2_referenceYN);
            store[83] = new SqlParameter("@cmp2department   ", cmp2department);
            store[84] = new SqlParameter("@EmpHis2_NoticePeriodorNot  ", EmpHis2_NoticePeriodorNot);

            store[85] = new SqlParameter("@EmpHis3_CompnayNameandLocation  ", EmpHis3_CompnayNameandLocation);
            store[86] = new SqlParameter("@EmpHis3_LastPositionHeldnDepartmentName  ", EmpHis3_LastPositionHeldnDepartmentName);
            store[87] = new SqlParameter("@EmpHis3_TelephoneNo  ", EmpHis3_TelephoneNo);
            store[88] = new SqlParameter("@EmpHis3_Address  ", EmpHis3_Address);

            store[89] = new SqlParameter("@EmpHis3_EmployeeCode  ", EmpHis3_EmployeeCode);
            store[90] = new SqlParameter("@EmpHis3_Experienceinyear  ", ExperienceInYears3);
            store[91] = new SqlParameter("@EmpHis3_PeriodofEmployment  ", EmpHis3_PeriodofEmployment);
            store[92] = new SqlParameter("@EmpHis3_PeriodofEmploymentTillDate  ", EmpHis3_PeriodofEmploymentRemark);

            store[93] = new SqlParameter("@EmpHis3RLvl1_NameDesignatinOfSupervisor  ", EmpHis3RLvl1_NameDesignatinOfSupervisor);
            store[94] = new SqlParameter("@EmpHis3RLvl1_TelepnoneNo  ", EmpHis3RLvl1_TelepnoneNo);
            store[95] = new SqlParameter("@EmpHis3RLvl1_MobileNo  ", EmpHis3RLvl1_MobileNo);
            store[96] = new SqlParameter("@EmpHis3RLvl1_EmailId  ", EmpHis3RLvl1_EmailId);

            store[97] = new SqlParameter("@EmpHis3RLvl2_NameDesignatinOfSupervisor  ", EmpHis3RLvl2_NameDesignatinOfSupervisor);
            store[98] = new SqlParameter("@EmpHis3RLvl2_TelepnoneNo  ", EmpHis3RLvl2_TelepnoneNo);
            store[99] = new SqlParameter("@EmpHis3RLvl2_MobileNo  ", EmpHis3RLvl2_MobileNo);
            store[100] = new SqlParameter("@EmpHis3RLvl2_EmailId  ", EmpHis3RLvl2_EmailId);

            store[101] = new SqlParameter("@EmpHis3_TempPerma  ", EmpHis3_TempPerma);
            store[102] = new SqlParameter("@EmpHis3_AgencyDetails  ", EmpHis3_AgencyDetails);
            store[103] = new SqlParameter("@EmpHis3_RemunerationOrSalary  ", EmpHis3_RemunerationOrSalary);
            store[104] = new SqlParameter("@EmpHis3_ReasonOfLeaving  ", EmpHis3_ReasonOfLeaving);

            store[105] = new SqlParameter("@EmpHis3_referenceYN  ", EmpHis3_referenceYN);
            store[106] = new SqlParameter("@cmp3department   ", cmp3department);
            store[107] = new SqlParameter("@EmpHis3_NoticePeriodorNot  ", EmpHis3_NoticePeriodorNot);

            store[108] = new SqlParameter("@COE", COE);
            store[109] = new SqlParameter("@MODE", Mode);
            store[110] = new SqlParameter("@ddlReference", ddlReference);


            store[111] = new SqlParameter("@RejectedRemarks1", RejectedRemarks1);
            store[112] = new SqlParameter("@RejectedRemarks2", RejectedRemarks2);
            store[113] = new SqlParameter("@RejectedRemarks3", RejectedRemarks3);
            store[114] = new SqlParameter("@RejectedRemarks4", RejectedRemarks4);
            store[115] = new SqlParameter("@RejectedRemarks5", RejectedRemarks5);

            store[116] = new SqlParameter("@comment1", comment1);
            store[117] = new SqlParameter("@comment2", comment2);
            store[118] = new SqlParameter("@comment3", comment3);
            store[119] = new SqlParameter("@comment4", comment4);
            store[120] = new SqlParameter("@comment5", comment5);


            store[121] = new SqlParameter("@cmp1HRdesignation", cmp1HRdesignation);
            store[122] = new SqlParameter("@cmp2HRdesignation", cmp2HRdesignation);
            store[123] = new SqlParameter("@cmp3HRdesignation", cmp3HRdesignation);

            store[124] = new SqlParameter("@cmp1RMdesignation", cmp1RMdesignation);
            store[125] = new SqlParameter("@cmp2RMdesignation", cmp2RMdesignation);
            store[126] = new SqlParameter("@cmp3RMdesignation", cmp3RMdesignation);

            store[127] = new SqlParameter("@CandidateID", CandidateID);
            store[128] = new SqlParameter("@CurrentEmployment", CurrentEmployment);


            store[129] = new SqlParameter("@DrugList", DrugList);
            store[130] = new SqlParameter("@DrugCheck", DrugCheck);
            store[131] = new SqlParameter("@DrugCity", DrugCity);
            store[132] = new SqlParameter("@DrugState", DrugState);
            store[133] = new SqlParameter("@DrugRemark", DrugRemark);

            store[134] = new SqlParameter("@IdentityList", IdentityList);
            store[135] = new SqlParameter("@IdentityCheck", IdentityCheck);
            store[136] = new SqlParameter("@IdentityCity", IdentityCity);
            store[137] = new SqlParameter("@IdentityState", IdentityState);
            store[138] = new SqlParameter("@IdentityRemark", IdentityRemark);
            store[139] = new SqlParameter("@criminalchk1", criminalchk1);

            store[140] = new SqlParameter("@user", user);

            store[141] = new SqlParameter("@dbcheck", dbcheck);
            store[142] = new SqlParameter("@dbcity", dbcity);
            store[143] = new SqlParameter("@dbstate", dbstate);
            store[144] = new SqlParameter("@dbremark", dbremark);






            // return con.insert_with_SP("saveCandidateDetails",store);
            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "saveHeadstrongCandidateDetails", store));



        }





        public int saveStatus(CandidateDetails candidateobj)
        {
            int i;
            SqlParameter[] store = new SqlParameter[10];
            store[0] = new SqlParameter("@candidateid", CandidateID);
            store[1] = new SqlParameter("@AddressStatus", AddressStatus);
            store[2] = new SqlParameter("@EducationStatus", EducationStatus);
            store[3] = new SqlParameter("@EmploymentStatus", EmploymentStatus);
            store[4] = new SqlParameter("@CriminalStatus", CriminalStatus);
            store[5] = new SqlParameter("@DrugStatus", DrugStatus);
            store[6] = new SqlParameter("@DataBaseStatus", DataBaseStatus);
            store[7] = new SqlParameter("@IdentityStatus", IdentityStatus);
            store[8] = new SqlParameter("@Gap", Gap);
            store[9] = new SqlParameter("@CriminalCourtStatus", CriminalCourtStatus);



            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "saveStatus", store));



        }

        public DataSet SmsMobileNumber(string candidateid)
        {
            DataSet dr;
            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SmsMobileNumber",
                SQLDataAccess.CreateParameter("@candidateid", SqlDbType.VarChar, candidateid, ParameterDirection.Input, 50, false)

                );
            return dr;

        }


        public string accept(string candidateid, string name, string acceptuser)
        {

            string i;
            SqlParameter[] store = new SqlParameter[3];

            store[0] = new SqlParameter("@candidateid", candidateid);
            store[1] = new SqlParameter("@name", name);
            
            store[2] = new SqlParameter("@acceptuser", acceptuser);
           


            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "accept", store));


        }

        public DataSet showfile(CandidateDetails candidateobj)
        {
            DataSet dr;

            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "showuploadfile",
                 SQLDataAccess.CreateParameter("@FirstName", SqlDbType.VarChar, FirstName, ParameterDirection.Input, 50, false),
                  SQLDataAccess.CreateParameter("@MiddleName", SqlDbType.VarChar, MiddleName, ParameterDirection.Input, 50, false),
                       SQLDataAccess.CreateParameter("@Surname", SqlDbType.VarChar, Surname, ParameterDirection.Input, 50, false),
                            SQLDataAccess.CreateParameter("@FatherName", SqlDbType.VarChar, FatherName, ParameterDirection.Input, 100, false),
                                 SQLDataAccess.CreateParameter("@Mobile", SqlDbType.VarChar, Mobile, ParameterDirection.Input, 50, false)



                );
            return dr;


        }

        public int candidateband4info(CandidateDetails candidateobj, string password)
        {
            int i;

            SqlParameter[] paramsToStore = new SqlParameter[11];

            paramsToStore[0] = new SqlParameter("@band4candidatename", SqlDbType.VarChar);
            paramsToStore[0].Value = candidateobj.band4candidatename;
            paramsToStore[0].Size = 150;



            paramsToStore[1] = new SqlParameter("@band4emailid", SqlDbType.VarChar);
            paramsToStore[1].Value = candidateobj.band4emailid;
            paramsToStore[1].Size = 150;

            paramsToStore[2] = new SqlParameter("@band4mobile", SqlDbType.VarChar);
            paramsToStore[2].Value = candidateobj.band4mobile;
            paramsToStore[2].Size = 50;

            paramsToStore[3] = new SqlParameter("@fathername", SqlDbType.VarChar);
            paramsToStore[3].Value = candidateobj.FatherName;
            paramsToStore[3].Size = 50;

            paramsToStore[4] = new SqlParameter("@dateofbirth", SqlDbType.VarChar);
            paramsToStore[4].Value = candidateobj.DOB;
            paramsToStore[4].Size = 50;


            paramsToStore[5] = new SqlParameter("@Category", SqlDbType.VarChar);
            paramsToStore[5].Value = candidateobj.Category;
            paramsToStore[5].Size = 50;

            paramsToStore[6] = new SqlParameter("@password", SqlDbType.VarChar);
            paramsToStore[6].Value = password;
            paramsToStore[6].Size = 50;

            paramsToStore[7] = new SqlParameter("@DOJ", SqlDbType.VarChar);
            paramsToStore[7].Value = candidateobj.DateofJoining;
            paramsToStore[7].Size = 50;

            paramsToStore[8] = new SqlParameter("@band4middlename", SqlDbType.VarChar);
            paramsToStore[8].Value = candidateobj.band4middlename;
            paramsToStore[8].Size = 150;

            paramsToStore[9] = new SqlParameter("@band4surname", SqlDbType.VarChar);
            paramsToStore[9].Value = candidateobj.band4surname;
            paramsToStore[9].Size = 150;


            paramsToStore[10] = new SqlParameter("@Empid", SqlDbType.VarChar);
            paramsToStore[10].Value = candidateobj.Empid;
            paramsToStore[10].Size = 150;

            

            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "savecandidateband4info", paramsToStore));

        }


        public int forgetpassword(CandidateDetails candidateobj)
        {
            int i;

            SqlParameter[] paramsToStore = new SqlParameter[1];

            paramsToStore[0] = new SqlParameter("@Email", SqlDbType.VarChar);
            paramsToStore[0].Value = candidateobj.UserName;
            paramsToStore[0].Size = 150;

            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "HRforgetpassword", paramsToStore));

        }

        public string send(string username, string candidateid, string name, string location)
        {

            string i;
            SqlParameter[] store = new SqlParameter[4];

            store[0] = new SqlParameter("@username", username);
            store[1] = new SqlParameter("@candidateid", candidateid);
            store[2] = new SqlParameter("@name", name);
            store[3] = new SqlParameter("@location", location);

            return i = Convert.ToString(SQLDataAccess.ExecuteNonQuery(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "send", store));


        }



        public DataSet deleteupload(CandidateDetails candidateobj)
        {
            DataSet dr;

            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "deleteupload",
                 SQLDataAccess.CreateParameter("@FirstName", SqlDbType.VarChar, FirstName, ParameterDirection.Input, 50, false),
                  SQLDataAccess.CreateParameter("@MiddleName", SqlDbType.VarChar, MiddleName, ParameterDirection.Input, 50, false),
                       SQLDataAccess.CreateParameter("@Surname", SqlDbType.VarChar, Surname, ParameterDirection.Input, 50, false),
                            SQLDataAccess.CreateParameter("@FatherName", SqlDbType.VarChar, FatherName, ParameterDirection.Input, 100, false),
                                 SQLDataAccess.CreateParameter("@Mobile", SqlDbType.VarChar, Mobile, ParameterDirection.Input, 50, false),
                                   SQLDataAccess.CreateParameter("@Key", SqlDbType.VarChar, key, ParameterDirection.Input, 100, false)






                );
            return dr;





        }



        public int doublecheckheadstrong(CandidateDetails candidateobj)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[6];
            // 213+173


            paramsToStore[2] = new SqlParameter("@DateofJoining", SqlDbType.VarChar);
            paramsToStore[2].Value = candidateobj.DateofJoining;
            paramsToStore[2].Size = 50;


            paramsToStore[1] = new SqlParameter("@FatherName", SqlDbType.VarChar);
            paramsToStore[1].Value = candidateobj.FatherName;
            paramsToStore[1].Size = 150;



            paramsToStore[3] = new SqlParameter("@DOB", SqlDbType.VarChar);
            paramsToStore[3].Value = candidateobj.DOB;
            paramsToStore[3].Size = 50;

            paramsToStore[4] = new SqlParameter("@Mobile", SqlDbType.VarChar);
            paramsToStore[4].Value = candidateobj.Mobile;
            paramsToStore[4].Size = 50;

            paramsToStore[0] = new SqlParameter("@FirstName", SqlDbType.VarChar);
            paramsToStore[0].Value = candidateobj.FirstName;
            paramsToStore[0].Size = 150;

            paramsToStore[5] = new SqlParameter("@COE", SqlDbType.VarChar);
            paramsToStore[5].Value = candidateobj.COE;
            paramsToStore[5].Size = 150;






            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "doublecheckheadstrong", paramsToStore));



        }

        public int doublecheck(CandidateDetails candidateobj)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[3];
            // 213+173


            paramsToStore[0] = new SqlParameter("@band4candidatename", SqlDbType.VarChar);
            paramsToStore[0].Value = candidateobj.band4candidatename;
            paramsToStore[0].Size = 50;


            paramsToStore[1] = new SqlParameter("@band4emailid", SqlDbType.VarChar);
            paramsToStore[1].Value = candidateobj.band4emailid;
            paramsToStore[1].Size = 50;



            paramsToStore[2] = new SqlParameter("@band4mobile", SqlDbType.VarChar);
            paramsToStore[2].Value = candidateobj.band4mobile;
            paramsToStore[2].Size = 50;


            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "doublecheck", paramsToStore));

        }
    }
}
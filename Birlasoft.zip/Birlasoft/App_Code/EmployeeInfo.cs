using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using DataAccess;



namespace EmployeeInfonamespace
{
    /// <summary>
    /// Generated Class for Table : EmployeeInfo.
    /// </summary>
    public class EmployeeInfo
    {

        
        private string Stxt_ResumeNo;
        private string Stxt_CaseReceivedBy;
        private string StxtPercentage;

        private string StxtEducation1State;
        private string StxtEducation1City;
        private string StxtEducation1PinCode;

        private string StxtEducation2State;
        private string StxtEducation2City;
        private string StxtEducation2PinCode;

        private string StxtEducation3State;
        private string StxtEducation3City;
        private string StxtEducation3PinCode;

        private string StxtEducation4State;
        private string StxtEducation4City;
        private string StxtEducation4PinCode;


        private string StxtEmployemenmt1State;
        private string StxtEmployemenmt2State;
        private string StxtEmployemenmt3State;
        private string StxtEmployemenmt4State;
        private string StxtEmployemenmt5State;





        private string StxtEmployemenmt1City;
        private string StxtEmployemenmt2City;
        private string StxtEmployemenmt3City;
        private string StxtEmployemenmt4City;
        private string StxtEmployemenmt5City;




        private string StxtEmployemenmt1PinCode;
        private string StxtEmployemenmt2PinCode;
        private string StxtEmployemenmt3PinCode;
        private string StxtEmployemenmt4PinCode;
        private string StxtEmployemenmt5PinCode;

        private string strMode;
        private string strCurrentAddress;
        private string strEmpHis1_CompnayNameandLocation;
        private string strEmpHis2_EmployeeCode;
        private string strEmpHis1RLvl2_TelepnoneNo;
        private string strEmpHis2RLvl2_MobileNo;
        private string strPer_LivingSince;
        private string strEmpHis1_EmployeeCode;
        private string strTAT2;
        private string strEmpHis2RLvl1_TelepnoneNo;
        private string strEdu1_Address;
        private string strDateofJoining;
        private string strTATDate;
        private string strEmpHis1_TelephoneNo;
        private string strEmpHis2RLvl2_TelepnoneNo;
        private string strEmpHis2_IncaseOfGap;
        private string strEmpHis2RLvl1_EmailId;
        private string strEdu1_UniversityName;
        private string strPer_Landmark;
        private string strEmpHis2_AgencyDetails;
        private string strEmpHis1_referenceYN;
        private string strPer_PostOffice;
        private string strFatherName;
        private string strEmpHis1_LastPositionHeldnDepartmentName;
        private string strEmpHis2_CompnayNameandLocation;
        private string strEmpHis1_PeriodofEmployment;

        private string strdatetoemphis1;//chng




        private string strVendor;
        private string strMonth;
        private string strDCSV;
        private string strDDV;
        private string strDVR;
        private string strDVU;
        private string strEducation1State;


        private string strDOB;
        private string strEmpHis2_referenceYN;
        private string strEdu1_RollNo;
        private string strEmpHis1RLvl1_MobileNo;
        private string strEmpHis1_TempPerma;
        private string strEmpHis2_Address;
        private string strEmpHis1_PeriodofEmploymentRemark;
        private string strEmpHis1_IncaseOfGap;
        private string strEmpHis2_TempPerma;
        private string strEmpHis1RLvl2_NameDesignatinOfSupervisor;
        private string strEmpHis2RLvl1_MobileNo;
        private string strMiddleName;
        private string strEdu1_CollegeName;
        private string strEmpHis2RLvl2_NameDesignatinOfSupervisor;
        private string strEmpHis1_AgencyDetails;
        private string strEmpHis2RLvl1_NameDesignatinOfSupervisor;
        private string strFirstName;
        private string strPer_AddressPhoneNo;
        private string strEmpHis2_PeriodofEmployment;
        private string strdatetoemphis2;//chng
        private string SCaseStatus;


        private string strEmpHis2RLvl2_EmailId;
        private string strCOE;
        private string strSNo;
        private string strClientName;
        private string strMobile;
        private string strPer_City;
        private string strCurr_PhoneNo;
        private string strEmpHis2_LastPositionHeldnDepartmentName;
        private string strEmpHis1_Address;
        private string strEdu1_EducationalQualification;
        private string strEmpHis1RLvl1_EmailId;
        private string strInDate;
        private string strPer_PoliceStation;
        private string strEmpHis2_TelephoneNo;
        private string strEmpHis1_ReasonOfLeaving;
        private string strEmpHis1_RemunerationOrSalary;
        private string strEnteredByLoginIdType;
        private string strBand;
        private string strEmpHis2_ReasonOfLeaving;
        private string strPer_State;
        private string strEmpIdProvidedByClient;
        private string strPlaceofBirth;
        private string strSurname;
        private string strExperienceInYears;
        private string strPermanentAddress;
        private string strCurr_City;
        private string strEmpHis2_RemunerationOrSalary;
        //private int    intEmployeeID;
        private string strCurr_State;
        private string strEmpHis1RLvl1_TelepnoneNo;
        private string strEmpHis1RLvl2_EmailId;
        private string strEmpHis2_PeriodofEmploymentRemark;
        private string strEmpHis1RLvl1_NameDesignatinOfSupervisor;
        private string strEdu1_YearOfPassing;
        // private EmployeeInfo_Criteria z_WhereClause;
        private int strEmployeeId;
        private string strCaseStatus;
        private string strAllocatedStatus;
        private string strEmployeeIDProvidedByClient;
        //private string strAddressStatus;
        //private string strAddressRemarks;
        //private string strEducationStatus;
        //private string strEducationRemarks;
        //private string strEmploymentStatus2SUP;
        //private string strEmploymentRemarks2SUP;
        //private string strCriminalStatus;
        //private string strCriminalRemarks;
        //private string strReferenceStatus;
        //private string strReferenceRemarks;
        //private string strDrugtestStatus;
        //private string strDrugtestRemarks;
        //private string strDataBaseStatus;
        //private string strDataBaseRemarks;
        private string strb;
        private string strReportingLevel2emp1;
        private string strReportingLevel2emp2;
        //Employment Type
        private string stremploymentType;
        private string strRejectedRemarks;
        private string strFresherOrExp;
        private string strNoOfComp;
        private string strCaseSubmmissionDate;
        private string strWithin_TATOut;
        private string strOnline_Offline;
        private string strReallocation;
        private string strSpecialization;
        private string strGraduatedYearMonth;
        private string strPercentage;
        private string strRevertRecd;
        private string strStampedVerbal;
        private string strDateofExport;
        private string strFinalStatus;
        private string strColorofReport;
        private string strNoofDaysDelay;
        private string strDDAmount;
        private string strDDDate;
        private string strRequestedby;
        private string strDateofCompeletion;
        private string strRemarks;
        private string strClientRefNo;
        private string strResumeNo;
        private string strEducation1City;
        private string strEducation1PinCode;
        private string strprice;
        private string strCasestatuswiproedu;
        private string strEdu1_Address2;

        private string strMonthInitiation;
        private string strDateofAllocation;
        private string strImpInfo;
        private string strReinitiateCaseStatus;
        private string strReinitiateChecks;
        private string strCheksID;
        private string strTypeofCheck;
        private string strAdd_Emp_Deg_Idtity;
        private string strCollegeName_Lastposheld;
        private string strCollegeLocation;
        private string strUniversityName_SupervisorName;
        private string strYearofPassing_Emp_Duration_DOB;
        private string strRollNo_RegNo_Empcode;
        private string strLocation;
        private string strState;
        private string strStamp_Verbal;
        private string strStatus;
        private string strTeam;
        private string strMonthPrice;
        private string strPrice;
        private string strMonths;
        private string strEducationRemarks;
        private string strInsufficiencyDate;
        private string strCaseStatus1;
        private string strCaseStatus2;
        private string strNameofVeri_Desg;
        private string strVerifiedLocation;
        private string strReasonforRed_Orange;
        private string strInsufficiencyLevel;
        private string strReasonforInsufficiency;
        private string strAnand;
        private string strSandeep;
        private string strAmountofDD;
        private string strDDRequestedby;
        private string strInterimReports;
        private string strCasestatuswiprocity;
        private string strRequirement_edu1;
        private string strRequirement_edu2;
        private string strRequirement_edu3;
        private string strRequirement_edu4;
        private string strRequirement_edu5;
        private string strRequirement_edu6;
        private string strRequirement_edu7;
        private string strRequirement_edu8;


        ////////////For University/College Module
        private string strUniName;
        private string strUniLoc;
        private string strUniConPer;
        private string strUniDesig;
        private string strUniNo1;
        private string strUniNo2;
        private string strUniConPer1;
        private string strUniDesig1;
        private string strUniNo3;
        private string strUniNo4;
        private string strUniDD;
        private string strUniDDto;
        private string strUniDDadd;
        private string strUniTime;
        private string strUniMail;
        private string strUniWeb;
        private string strUniRemark;
        private string strColName;
        private string strColLoc;
        private string strColConPer;
        private string strColDesig;
        private string strColNo1;
        private string strColNo2;
        private string strColConPer1;
        private string strColDesig1;
        private string strColNo3;
        private string strColNo4;
        private string strColDD;
        private string strColDDto;
        private string strColDDadd;
        private string strColTime;
        private string strColMail;
        private string strColWeb;
        private string strColRemark;
        private string strUser;
        private string mode;



        /////For DD/Courier Module
        private string strDReqDate;
        private string strReqCaller;
        private string strDDate;
        private string strDNumber;
        private string strDAmount;
        private string strDSentTo;
        private string strDAdr;
        private string strDMadeAt;
        private string strCDate;
        private string strCPOD;
        private string strCCSP;
        private string strCSentTo;
        private string strCStreet1;
        private string strCStreet2;
        private string strCState;
        private string strCCity;
        private string strCZip;
        private string strCContact;
        private string strSAppName;


        ////// For Employment

        private string strOrganisation1;
        private string strEmpDates1;
        private string strDesignation1;
        private string strEmpID1;
        private string strSalary1;
        private string strMGR1;
        private string strLeaving1;
        private string strExit1;
        private string strIssue1;
        private string strDisciplinary1;
        private string strReHire1;
        private string strBehaviour1;
        private string strOrganisation2;
        private string strEmpDates2;
        private string strDesignation2;
        private string strEmpID2;
        private string strSalary2;
        private string strMGR2;
        private string strLeaving2;
        private string strExit2;
        private string strIssue2;
        private string strDisciplinary2;
        private string strReHire2;
        private string strBehaviour2;
        private string strOrganisation3;
        private string strEmpDates3;
        private string strDesignation3;
        private string strEmpID3;
        private string strSalary3;
        private string strMGR3;
        private string strLeaving3;
        private string strExit3;
        private string strIssue3;
        private string strDisciplinary3;
        private string strReHire3;
        private string strBehaviour3;
        private string strOrganisation4;
        private string strEmpDates4;
        private string strDesignation4;
        private string strEmpID4;
        private string strSalary4;
        private string strMGR4;
        private string strLeaving4;
        private string strExit4;
        private string strIssue4;
        private string strDisciplinary4;
        private string strReHire4;
        private string strBehaviour4;
        private string strOrganisation5;
        private string strEmpDates5;
        private string strDesignation5;
        private string strEmpID5;
        private string strSalary5;
        private string strMGR5;
        private string strLeaving5;
        private string strExit5;
        private string strIssue5;
        private string strDisciplinary5;
        private string strReHire5;
        private string strBehaviour5;
        private string strOrganisation6;
        private string strEmpDates6;
        private string strDesignation6;
        private string strEmpID6;
        private string strSalary6;
        private string strMGR6;
        private string strLeaving6;
        private string strExit6;
        private string strIssue6;
        private string strDisciplinary6;
        private string strReHire6;
        private string strBehaviour6;
        private string strOrganisation7;
        private string strEmpDates7;
        private string strDesignation7;
        private string strEmpID7;
        private string strSalary7;
        private string strMGR7;
        private string strLeaving7;
        private string strExit7;
        private string strIssue7;
        private string strDisciplinary7;
        private string strReHire7;
        private string strBehaviour7;
        private string strOrganisation8;
        private string strEmpDates8;
        private string strDesignation8;
        private string strEmpID8;
        private string strSalary8;
        private string strMGR8;
        private string strLeaving8;
        private string strExit8;
        private string strIssue8;
        private string strDisciplinary8;
        private string strReHire8;
        private string strBehaviour8;
        private string strOrganisationR1;
        private string strRefName1;
        private string strDesignationR1;
        private string strContact1;
        private string strMail1;
        private string strOrganisationR2;
        private string strRefName2;
        private string strDesignationR2;
        private string strContact2;
        private string strMail2;
        private string strOrganisationR3;
        private string strRefName3;
        private string strDesignationR3;
        private string strContact3;
        private string strMail3;


        //new operaration requirement

        private string strCategory;
        private string strSubCategory;

        private string strAddDateFrm1;
        private string strAddDateFrm2;
        private string strAddDateFrm3;
        private string strAddDateFrm4;
        private string strAddDateFrm5;
        private string strAddDateFrm6;
        private string strAddDateFrm7;
        private string strAddDateFrm8;
        private string strAddDateTo1;
        private string strAddDateTo2;
        private string strAddDateTo3;
        private string strAddDateTo4;
        private string strAddDateTo5;
        private string strAddDateTo6;
        private string strAddDateTo7;
        private string strAddDateTo8;

        private string strCriDateFrm1;
        private string strCriDateFrm2;
        private string strCriDateFrm3;
        private string strCriDateFrm4;
        private string strCriDateFrm5;
        private string strCriDateFrm6;
        private string strCriDateFrm7;
        private string strCriDateFrm8;
        private string strCriDateTo1;
        private string strCriDateTo2;
        private string strCriDateTo3;
        private string strCriDateTo4;
        private string strCriDateTo5;
        private string strCriDateTo6;
        private string strCriDateTo7;
        private string strCriDateTo8;

        private string strEduDateFrm1;
        private string strEduDateFrm2;
        private string strEduDateFrm3;
        private string strEduDateFrm4;
        private string strEduDateFrm5;
        private string strEduDateFrm6;
        private string strEduDateFrm7;
        private string strEduDateFrm8;
        private string strEduDateTo1;
        private string strEduDateTo2;
        private string strEduDateTo3;
        private string strEduDateTo4;
        private string strEduDateTo5;
        private string strEduDateTo6;
        private string strEduDateTo7;
        private string strEduDateTo8;

        private string strAddStatus1;
        private string strAddStatus2;
        private string strAddStatus3;
        private string strAddStatus4;
        private string strAddStatus5;
        private string strAddStatus6;
        private string strAddStatus7;
        private string strAddStatus8;
        private string strAddRemarks1;
        private string strAddRemarks2;
        private string strAddRemarks3;
        private string strAddRemarks4;
        private string strAddRemarks5;
        private string strAddRemarks6;
        private string strAddRemarks7;
        private string strAddRemarks8;

        private string strCriStatus1;
        private string strCriStatus2;
        private string strCriStatus3;
        private string strCriStatus4;
        private string strCriStatus5;
        private string strCriStatus6;
        private string strCriStatus7;
        private string strCriStatus8;
        private string strCriRemarks1;
        private string strCriRemarks2;
        private string strCriRemarks3;
        private string strCriRemarks4;
        private string strCriRemarks5;
        private string strCriRemarks6;
        private string strCriRemarks7;
        private string strCriRemarks8;

        private string strEduStatus1;
        private string strEduStatus2;
        private string strEduStatus3;
        private string strEduStatus4;
        private string strEduStatus5;
        private string strEduStatus6;
        private string strEduStatus7;
        private string strEduStatus8;
        private string strEduRemarks1;
        private string strEduRemarks2;
        private string strEduRemarks3;
        private string strEduRemarks4;
        private string strEduRemarks5;
        private string strEduRemarks6;
        private string strEduRemarks7;
        private string strEduRemarks8;

        private string strEmpStatus1;
        private string strEmpStatus2;
        private string strEmpStatus3;
        private string strEmpStatus4;
        private string strEmpStatus5;
        private string strEmpStatus6;
        private string strEmpStatus7;
        private string strEmpStatus8;
        private string strEmpRemarks1;
        private string strEmpRemarks2;
        private string strEmpRemarks3;
        private string strEmpRemarks4;
        private string strEmpRemarks5;
        private string strEmpRemarks6;
        private string strEmpRemarks7;
        private string strEmpRemarks8;

        private string strRefStatus1;
        private string strRefStatus2;
        private string strRefStatus3;
        private string strRefRemarks1;
        private string strRefRemarks2;
        private string strRefRemarks3;

        private string strDBStatus;
        private string strDBRemarks;

        private string strDrugStatus;
        private string strDrugRemarks;

        private string strIDStatus1;
        private string strIDStatus2;
        private string strIDStatus3;
        private string strIDStatus4;
        private string strIDRemarks1;
        private string strIDRemarks2;
        private string strIDRemarks3;
        private string strIDRemarks4;
        private string strTATStartDate;

        private string strPriceEntryCatagory;
        private string strBillingType;
        private string strEduRate;
        private string strEmpRate;
        private string strAddRate;
        private string strCriRate;
        private string strRefRate;
        private string strIdRate;
        private string strDBRate;
        private string strCourtRate;
        // private string strDBRate;
        private string strDrugRate;
        private string strPriceEntryFormRemarks;
        private string strCatagory;
        private string strfixedamount;
        private string strDrugpanel5;
        private string strDrugpanel9;
        private string strDrugpanel10;
        private string strDrugpanel5withalcohol;
        private string strDrugpanelspecial;

        private string strCourtCheck;
        private string strCourtAddress;
        private string strCourtAddLoc;
        private string strCourtAddState;
        private string strCourtAddStatus;
        private string strCourtAddRemarks; 

        private string strkey;


        public string Drugpanel9
        {
            get
            {
                return strDrugpanel9;
            }
            set
            {
                strDrugpanel9 = value;
            }
        }


        public string Drugpanel10
        {
            get
            {
                return strDrugpanel10;
            }
            set
            {
                strDrugpanel10 = value;
            }
        }


        public string Drugpanel5withalcohol
        {
            get
            {
                return strDrugpanel5withalcohol;
            }
            set
            {
                strDrugpanel5withalcohol = value;
            }
        }


        public string Drugpanelspecial
        {
            get
            {
                return strDrugpanelspecial;
            }
            set
            {
                strDrugpanelspecial = value;
            }
        }


        public string Drugpanel5
        {
            get
            {
                return strDrugpanel5;
            }
            set
            {
                strDrugpanel5 = value;
            }
        }


        public string FixedAmount
        {
            get
            {
                return strfixedamount;
            }
            set
            {
                strfixedamount = value;
            }
        }

        public string Catagory
        {
            get
            {
                return strCatagory;
            }
            set
            {
                strCatagory = value;
            }
        }


        public string PriceEntryCatagory
        {
            get
            {
                return strPriceEntryCatagory;
            }
            set
            {
                strPriceEntryCatagory = value;
            }
        }

        public string BillingType
        {
            get
            {
                return strBillingType;
            }
            set
            {
                strBillingType = value;
            }
        }

        public string EduRate
        {
            get
            {
                return strEduRate;
            }
            set
            {
                strEduRate = value;
            }
        }

        public string EmpRate
        {
            get
            {
                return strEmpRate;
            }
            set
            {
                strEmpRate = value;
            }
        }

        public string AddRate
        {
            get
            {
                return strAddRate;
            }
            set
            {
                strAddRate = value;
            }
        }

        public string CriRate
        {
            get
            {
                return strCriRate;
            }
            set
            {
                strCriRate = value;
            }
        }

        public string RefRate
        {
            get
            {
                return strRefRate;
            }
            set
            {
                strRefRate = value;
            }
        }

        public string IdRate
        {
            get
            {
                return strIdRate;
            }
            set
            {
                strIdRate = value;
            }
        }

        public string DBRate
        {
            get
            {
                return strDBRate;
            }
            set
            {
                strDBRate = value;
            }
        }

        public string CourtRate
        {
            get
            {
                return strCourtRate;
            }
            set
            {
                strCourtRate = value;
            }
        }

        public string DrugRate
        {
            get
            {
                return strDrugRate;
            }
            set
            {
                strDrugRate = value;
            }
        }

        public string PriceEntryFormRemarks
        {
            get
            {
                return strPriceEntryFormRemarks;
            }
            set
            {
                strPriceEntryFormRemarks = value;
            }
        }





        //..........................

        public string Casestatuswiprocity
        {
            get
            {
                return strCasestatuswiprocity;
            }
            set
            {
                strCasestatuswiprocity = value;
            }
        }

        public string ReasonforInsufficiency
        {
            get
            {
                return strReasonforInsufficiency;
            }
            set
            {
                strReasonforInsufficiency = value;
            }

        }

        public string InsufficiencyLevel
        {
            get
            {
                return strInsufficiencyLevel;
            }
            set
            {
                strInsufficiencyLevel = value;
            }

        }


        public string CaseStatus1
        {
            get
            {
                return strCaseStatus1;
            }
            set
            {
                strCaseStatus1 = value;
            }

        }


        public string InterimReports
        {
            get
            {
                return strInterimReports;
            }
            set
            {
                strInterimReports = value;
            }

        }

        public string DDRequestedby
        {
            get
            {
                return strDDRequestedby;
            }
            set
            {
                strDDRequestedby = value;
            }

        }

        public string AmountofDD
        {
            get
            {
                return strAmountofDD;
            }
            set
            {
                strAmountofDD = value;
            }

        }

        public string Sandeep
        {
            get
            {
                return strSandeep;
            }
            set
            {
                strSandeep = value;
            }

        }

        public string Anand
        {
            get
            {
                return strAnand;
            }
            set
            {
                strAnand = value;
            }

        }

        public string ReasonforRed_Orange
        {
            get
            {
                return strReasonforRed_Orange;
            }
            set
            {
                strReasonforRed_Orange = value;
            }

        }

        public string VerifiedLocation
        {
            get
            {
                return strVerifiedLocation;
            }
            set
            {
                strVerifiedLocation = value;
            }

        }


        public string NameofVeri_Desg
        {
            get
            {
                return strNameofVeri_Desg;
            }
            set
            {
                strNameofVeri_Desg = value;
            }

        }

        public string CaseStatus2
        {
            get
            {
                return strCaseStatus2;
            }
            set
            {
                strCaseStatus2 = value;
            }

        }



        public string InsufficiencyDate
        {
            get
            {
                return strInsufficiencyDate;
            }
            set
            {
                strInsufficiencyDate = value;
            }

        }


        public string EducationRemarks
        {
            get
            {
                return strEducationRemarks;
            }
            set
            {
                strEducationRemarks = value;
            }

        }

        public string Months
        {
            get
            {
                return strMonths;
            }
            set
            {
                strMonths = value;
            }

        }

        public string Price
        {
            get
            {
                return strPrice;
            }
            set
            {
                strPrice = value;
            }

        }

        public string MonthPrice
        {
            get
            {
                return strMonthPrice;
            }
            set
            {
                strMonthPrice = value;
            }

        }

        public string Team
        {
            get
            {
                return strTeam;
            }
            set
            {
                strTeam = value;
            }

        }

        public string Status
        {
            get
            {
                return strStatus;
            }
            set
            {
                strStatus = value;
            }

        }

        public string Stamp_Verbal
        {
            get
            {
                return strStamp_Verbal;
            }
            set
            {
                strStamp_Verbal = value;
            }

        }

        public string State
        {
            get
            {
                return strState;
            }
            set
            {
                strState = value;
            }

        }

        public string Location
        {
            get
            {
                return strLocation;
            }
            set
            {
                strLocation = value;
            }

        }

        public string RollNo_RegNo_Empcode
        {
            get
            {
                return strRollNo_RegNo_Empcode;
            }
            set
            {
                strRollNo_RegNo_Empcode = value;
            }

        }


        public string YearofPassing_Emp_Duration_DOB
        {
            get
            {
                return strYearofPassing_Emp_Duration_DOB;
            }
            set
            {
                strYearofPassing_Emp_Duration_DOB = value;
            }

        }

        public string UniversityName_SupervisorName
        {
            get
            {
                return strUniversityName_SupervisorName;
            }
            set
            {
                strUniversityName_SupervisorName = value;
            }

        }

        public string CollegeLocation
        {
            get
            {
                return strCollegeLocation;
            }
            set
            {
                strCollegeLocation = value;
            }

        }

        public string CollegeName_Lastposheld
        {
            get
            {
                return strCollegeName_Lastposheld;
            }
            set
            {
                strCollegeName_Lastposheld = value;
            }

        }



        public string Add_Emp_Deg_Idtity
        {
            get
            {
                return strAdd_Emp_Deg_Idtity;
            }
            set
            {
                strAdd_Emp_Deg_Idtity = value;
            }

        }

        public string MonthInitiation
        {
            get
            {
                return strMonthInitiation;
            }
            set
            {
                strMonthInitiation = value;
            }

        }
        public string DateofAllocation
        {
            get
            {
                return strDateofAllocation;
            }
            set
            {
                strDateofAllocation = value;
            }

        }

        public string ImpInfo
        {
            get
            {
                return strImpInfo;
            }
            set
            {
                strImpInfo = value;
            }

        }
        public string ReinitiateCaseStatus
        {
            get
            {
                return strReinitiateCaseStatus;
            }
            set
            {
                strReinitiateCaseStatus = value;
            }

        }
        public string ReinitiateChecks
        {
            get
            {
                return strReinitiateChecks;
            }
            set
            {
                strReinitiateChecks = value;
            }

        }

        public string CheksID
        {
            get
            {
                return strCheksID;
            }
            set
            {
                strCheksID = value;
            }

        }
        public string TypeofCheck
        {
            get
            {
                return strTypeofCheck;
            }
            set
            {
                strTypeofCheck = value;
            }

        }





        public string txt_ResumeNo
        { get { return Stxt_ResumeNo; } set { Stxt_ResumeNo = value; } }

        public string txt_CaseReceivedBy
        { get { return Stxt_CaseReceivedBy; } set { Stxt_CaseReceivedBy = value; } }

        public string txtPercentage
        { get { return StxtPercentage; } set { StxtPercentage = value; } }

        public string txtEducation1State
        { get { return StxtEducation1State; } set { StxtEducation1State = value; } }

        public string CaseStatusKPMG
        { get { return SCaseStatus; } set { SCaseStatus = value; } }

        public string txtEducation1City
        { get { return StxtEducation1City; } set { StxtEducation1City = value; } }

        public string txtEducation1PinCode
        { get { return StxtEducation1PinCode; } set { StxtEducation1PinCode = value; } }

        public string txtEducation2State
        { get { return StxtEducation2State; } set { StxtEducation2State = value; } }

        public string txtEducation2City
        { get { return StxtEducation2City; } set { StxtEducation2City = value; } }

        //public string txtEducation2City
        //{ get { return StxtEducation2City; } set { StxtEducation2City = value; } }

        public string txtEducation2PinCode
        { get { return StxtEducation2PinCode; } set { StxtEducation2PinCode = value; } }

        public string txtEducation3State
        { get { return StxtEducation3State; } set { StxtEducation3State = value; } }

        public string txtEducation3City
        { get { return StxtEducation3City; } set { StxtEducation3City = value; } }

        public string txtEducation3PinCode
        { get { return StxtEducation3PinCode; } set { StxtEducation3PinCode = value; } }

        public string txtEducation4State
        { get { return StxtEducation4State; } set { StxtEducation4State = value; } }

        public string txtEducation4City
        { get { return StxtEducation4City; } set { StxtEducation4City = value; } }

        public string txtEducation4PinCode
        { get { return StxtEducation4PinCode; } set { StxtEducation4PinCode = value; } }

        public string txtEmployemenmt1State
        { get { return StxtEmployemenmt1State; } set { StxtEmployemenmt1State = value; } }

        public string txtEmployemenmt2State
        { get { return StxtEmployemenmt2State; } set { StxtEmployemenmt2State = value; } }

        public string txtEmployemenmt3State
        { get { return StxtEmployemenmt3State; } set { StxtEmployemenmt3State = value; } }

        public string txtEmployemenmt4State
        { get { return StxtEmployemenmt4State; } set { StxtEmployemenmt4State = value; } }

        public string txtEmployemenmt5State
        { get { return StxtEmployemenmt5State; } set { StxtEmployemenmt5State = value; } }

        public string txtEmployemenmt1City
        { get { return StxtEmployemenmt1City; } set { StxtEmployemenmt1City = value; } }

        public string txtEmployemenmt2City
        { get { return StxtEmployemenmt2City; } set { StxtEmployemenmt2City = value; } }

        public string txtEmployemenmt3City
        { get { return StxtEmployemenmt3City; } set { StxtEmployemenmt3City = value; } }

        public string txtEmployemenmt4City
        { get { return StxtEmployemenmt4City; } set { StxtEmployemenmt4City = value; } }

        public string txtEmployemenmt5City
        { get { return StxtEmployemenmt5City; } set { StxtEmployemenmt5City = value; } }

        public string txtEmployemenmt1PinCode
        { get { return StxtEmployemenmt1PinCode; } set { StxtEmployemenmt1PinCode = value; } }

        public string txtEmployemenmt2PinCode
        { get { return StxtEmployemenmt2PinCode; } set { StxtEmployemenmt2PinCode = value; } }


        public string txtEmployemenmt3PinCode
        { get { return StxtEmployemenmt3PinCode; } set { StxtEmployemenmt3PinCode = value; } }

        public string txtEmployemenmt4PinCode
        { get { return StxtEmployemenmt4PinCode; } set { StxtEmployemenmt4PinCode = value; } }

        public string txtEmployemenmt5PinCode
        { get { return StxtEmployemenmt5PinCode; } set { StxtEmployemenmt5PinCode = value; } }


        public string CaseStatusWIPROEdu
        {
            get
            {
                return strCasestatuswiproedu;
            }
            set
            {
                strCasestatuswiproedu = value;
            }
        }
        //  ................................
        public string CaseSubmmissionDate
        {
            get
            {
                return strCaseSubmmissionDate;
            }
            set
            {
                strCaseSubmmissionDate = value;
            }

        }



        //for company 3           
        private string strEmpHis3_CompnayNameandLocation;
        public string EmpHis3_CompnayNameandLocation
        {
            get
            {
                return strEmpHis3_CompnayNameandLocation;
            }
            set
            {
                strEmpHis3_CompnayNameandLocation = value;
            }
        }

        private string strEmpHis3_LastPositionHeldnDepartmentName;
        public string EmpHis3_LastPositionHeldnDepartmentName
        {
            get
            {
                return strEmpHis3_LastPositionHeldnDepartmentName;

            }
            set
            {
                strEmpHis3_LastPositionHeldnDepartmentName = value;

            }
        }

        private string strEmpHis3_TelephoneNo;
        public string EmpHis3_TelephoneNo
        {
            get
            {
                return strEmpHis3_TelephoneNo;
            }
            set
            {
                strEmpHis3_TelephoneNo = value;

            }
        }
        private string strEmpHis3_Address;
        public string EmpHis3_Address
        {
            get
            {
                return strEmpHis3_Address;
            }
            set
            {
                strEmpHis3_Address = value;
            }
        }

        private string strEmpHis3_EmployeeCode;
        public string EmpHis3_EmployeeCode
        {
            get
            {
                return strEmpHis3_EmployeeCode;
            }
            set
            {
                strEmpHis3_EmployeeCode = value;
            }
        }
        private string strEmpHis3_PeriodofEmployment;
        public string EmpHis3_PeriodofEmployment
        {
            get
            {
                return strEmpHis3_PeriodofEmployment;
            }
            set
            {
                strEmpHis3_PeriodofEmployment = value;
            }
        }
        private string strdatetoempHis3;
        public string datetoempHis3
        {
            get
            {
                return strdatetoempHis3;
            }
            set
            {
                strdatetoempHis3 = value;
            }

        }
        private string strEmpHis3_PeriodofEmploymentRemark;
        public string EmpHis3_PeriodofEmploymentRemark
        {
            get
            {
                return strEmpHis3_PeriodofEmploymentRemark;
            }
            set
            {
                strEmpHis3_PeriodofEmploymentRemark = value;
            }
        }
        private string strEmpHis3RLvl1_NameDesignatinOfSupervisor;
        public string EmpHis3RLvl1_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis3RLvl1_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis3RLvl1_NameDesignatinOfSupervisor = value;
            }
        }

        private string strEmpHis3RLvl1_TelepnoneNo;
        public string EmpHis3RLvl1_TelepnoneNo
        {
            get
            {
                return strEmpHis3RLvl1_TelepnoneNo;
            }
            set
            {
                strEmpHis3RLvl1_TelepnoneNo = value;
            }
        }

        private string strEmpHis3RLvl1_MobileNo;
        public string EmpHis3RLvl1_MobileNo
        {
            get
            {
                return strEmpHis3RLvl1_MobileNo;
            }
            set
            {
                strEmpHis3RLvl1_MobileNo = value;
            }
        }
        private string strEmpHis3RLvl1_EmailId;

        public string EmpHis3RLvl1_EmailId
        {
            get
            {
                return strEmpHis3RLvl1_EmailId;
            }
            set
            {
                strEmpHis3RLvl1_EmailId = value;
            }

        }
        private string strEmpHis3RLvl2_NameDesignatinOfSupervisor;
        public string EmpHis3RLvl2_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis3RLvl2_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis3RLvl2_NameDesignatinOfSupervisor = value;
            }

        }
        private string strEmpHis3RLvl2_TelepnoneNo;
        public string EmpHis3RLvl2_TelepnoneNo
        {
            get
            {
                return strEmpHis3RLvl2_TelepnoneNo;
            }
            set
            {
                strEmpHis3RLvl2_TelepnoneNo = value;
            }

        }

        private string strEmpHis3RLvl2_MobileNo;
        public string EmpHis3RLvl2_MobileNo
        {
            get
            {
                return strEmpHis3RLvl2_MobileNo;
            }
            set
            {
                strEmpHis3RLvl2_MobileNo = value;
            }


        }

        private string strEmpHis3RLvl2_EmailId;
        public string EmpHis3RLvl2_EmailId
        {
            get
            {
                return strEmpHis3RLvl2_EmailId;
            }
            set
            {
                strEmpHis3RLvl2_EmailId = value;
            }

        }
        private string strEmpHis3_TempPerma;
        public string EmpHis3_TempPerma
        {
            get
            {
                return strEmpHis3_TempPerma;
            }
            set
            {
                strEmpHis3_TempPerma = value;
            }

        }

        private string strEmpHis3_AgencyDetails;
        public string EmpHis3_AgencyDetails
        {
            get
            {
                return strEmpHis3_AgencyDetails;

            }
            set
            {
                strEmpHis3_AgencyDetails = value;
            }
        }
        private string strEmpHis3_RemunerationOrSalary;
        public string EmpHis3_RemunerationOrSalary
        {
            get
            {
                return strEmpHis3_RemunerationOrSalary;

            }
            set
            {
                strEmpHis3_RemunerationOrSalary = value;
            }
        }

        private string strEmpHis3_ReasonOfLeaving;
        public string EmpHis3_ReasonOfLeaving
        {
            get
            {
                return strEmpHis3_ReasonOfLeaving;

            }
            set
            {
                strEmpHis3_ReasonOfLeaving = value;
            }
        }
        private string strEmpHis3_referenceYN;
        public string EmpHis3_referenceYN
        {
            get
            {
                return strEmpHis3_referenceYN;
            }
            set
            {
                strEmpHis3_referenceYN = value;
            }
        }
        private string strEmpHis3_IncaseOfGap;
        public string EmpHis3_IncaseOfGap
        {
            get
            {
                return strEmpHis3_IncaseOfGap;
            }
            set
            {
                strEmpHis3_IncaseOfGap = value;
            }
        }

        private string strExperienceInYears3;
        public string ExperienceInYears3
        {
            get
            {
                return strExperienceInYears3;

            }
            set
            {
                strExperienceInYears3 = value;
            }

        }

        private string strReportingLevel2emp3;
        public string ReportingLevel2emp3
        {
            get
            {
                return strReportingLevel2emp3;
            }
            set
            {
                strReportingLevel2emp3 = value;
            }

        }

        //For company 4
        private string strEmpHis4_CompnayNameandLocation;
        public string EmpHis4_CompnayNameandLocation
        {
            get
            {
                return strEmpHis4_CompnayNameandLocation;
            }
            set
            {
                strEmpHis4_CompnayNameandLocation = value;
            }
        }

        private string strEmpHis4_LastPositionHeldnDepartmentName;
        public string EmpHis4_LastPositionHeldnDepartmentName
        {
            get
            {
                return strEmpHis4_LastPositionHeldnDepartmentName;

            }
            set
            {
                strEmpHis4_LastPositionHeldnDepartmentName = value;

            }
        }

        private string strEmpHis4_TelephoneNo;
        public string EmpHis4_TelephoneNo
        {
            get
            {
                return strEmpHis4_TelephoneNo;
            }
            set
            {
                strEmpHis4_TelephoneNo = value;

            }
        }
        private string strEmpHis4_Address;
        public string EmpHis4_Address
        {
            get
            {
                return strEmpHis4_Address;
            }
            set
            {
                strEmpHis4_Address = value;
            }
        }

        private string strEmpHis4_EmployeeCode;
        public string EmpHis4_EmployeeCode
        {
            get
            {
                return strEmpHis4_EmployeeCode;
            }
            set
            {
                strEmpHis4_EmployeeCode = value;
            }
        }
        private string strEmpHis4_PeriodofEmployment;
        public string EmpHis4_PeriodofEmployment
        {
            get
            {
                return strEmpHis4_PeriodofEmployment;
            }
            set
            {
                strEmpHis4_PeriodofEmployment = value;
            }
        }
        private string strdatetoempHis4;
        public string datetoempHis4
        {
            get
            {
                return strdatetoempHis4;
            }
            set
            {
                strdatetoempHis4 = value;
            }

        }
        private string strEmpHis4_PeriodofEmploymentRemark;
        public string EmpHis4_PeriodofEmploymentRemark
        {
            get
            {
                return strEmpHis4_PeriodofEmploymentRemark;
            }
            set
            {
                strEmpHis4_PeriodofEmploymentRemark = value;
            }
        }
        private string strEmpHis4RLvl1_NameDesignatinOfSupervisor;
        public string EmpHis4RLvl1_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis4RLvl1_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis4RLvl1_NameDesignatinOfSupervisor = value;
            }
        }

        private string strEmpHis4RLvl1_TelepnoneNo;
        public string EmpHis4RLvl1_TelepnoneNo
        {
            get
            {
                return strEmpHis4RLvl1_TelepnoneNo;
            }
            set
            {
                strEmpHis4RLvl1_TelepnoneNo = value;
            }
        }

        private string strEmpHis4RLvl1_MobileNo;
        public string EmpHis4RLvl1_MobileNo
        {
            get
            {
                return strEmpHis4RLvl1_MobileNo;
            }
            set
            {
                strEmpHis4RLvl1_MobileNo = value;
            }
        }
        private string strEmpHis4RLvl1_EmailId;

        public string EmpHis4RLvl1_EmailId
        {
            get
            {
                return strEmpHis4RLvl1_EmailId;
            }
            set
            {
                strEmpHis4RLvl1_EmailId = value;
            }

        }
        private string strEmpHis4RLvl2_NameDesignatinOfSupervisor;
        public string EmpHis4RLvl2_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis4RLvl2_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis4RLvl2_NameDesignatinOfSupervisor = value;
            }

        }
        private string strEmpHis4RLvl2_TelepnoneNo;
        public string EmpHis4RLvl2_TelepnoneNo
        {
            get
            {
                return strEmpHis4RLvl2_TelepnoneNo;
            }
            set
            {
                strEmpHis4RLvl2_TelepnoneNo = value;
            }

        }

        private string strEmpHis4RLvl2_MobileNo;
        public string EmpHis4RLvl2_MobileNo
        {
            get
            {
                return strEmpHis4RLvl2_MobileNo;
            }
            set
            {
                strEmpHis4RLvl2_MobileNo = value;
            }


        }

        private string strEmpHis4RLvl2_EmailId;
        public string EmpHis4RLvl2_EmailId
        {
            get
            {
                return strEmpHis4RLvl2_EmailId;
            }
            set
            {
                strEmpHis4RLvl2_EmailId = value;
            }

        }
        private string strEmpHis4_TempPerma;
        public string EmpHis4_TempPerma
        {
            get
            {
                return strEmpHis4_TempPerma;
            }
            set
            {
                strEmpHis4_TempPerma = value;
            }

        }

        private string strEmpHis4_AgencyDetails;
        public string EmpHis4_AgencyDetails
        {
            get
            {
                return strEmpHis4_AgencyDetails;

            }
            set
            {
                strEmpHis4_AgencyDetails = value;
            }
        }
        private string strEmpHis4_RemunerationOrSalary;
        public string EmpHis4_RemunerationOrSalary
        {
            get
            {
                return strEmpHis4_RemunerationOrSalary;

            }
            set
            {
                strEmpHis4_RemunerationOrSalary = value;
            }
        }

        private string strEmpHis4_ReasonOfLeaving;
        public string EmpHis4_ReasonOfLeaving
        {
            get
            {
                return strEmpHis4_ReasonOfLeaving;

            }
            set
            {
                strEmpHis4_ReasonOfLeaving = value;
            }
        }
        private string strEmpHis4_referenceYN;
        public string EmpHis4_referenceYN
        {
            get
            {
                return strEmpHis4_referenceYN;
            }
            set
            {
                strEmpHis4_referenceYN = value;
            }
        }
        private string strEmpHis4_IncaseOfGap;
        public string EmpHis4_IncaseOfGap
        {
            get
            {
                return strEmpHis4_IncaseOfGap;
            }
            set
            {
                strEmpHis4_IncaseOfGap = value;
            }
        }

        private string strExperienceInYears4;
        public string ExperienceInYears4
        {
            get
            {
                return strExperienceInYears4;

            }
            set
            {
                strExperienceInYears4 = value;
            }

        }

        private string strReportingLevel2emp4;
        public string ReportingLevel2emp4
        {
            get
            {
                return strReportingLevel2emp4;
            }
            set
            {
                strReportingLevel2emp4 = value;
            }

        }


        //For comapny 5
        private string strEmpHis5_CompnayNameandLocation;
        public string EmpHis5_CompnayNameandLocation
        {
            get
            {
                return strEmpHis5_CompnayNameandLocation;
            }
            set
            {
                strEmpHis5_CompnayNameandLocation = value;
            }
        }

        private string strEmpHis5_LastPositionHeldnDepartmentName;
        public string EmpHis5_LastPositionHeldnDepartmentName
        {
            get
            {
                return strEmpHis5_LastPositionHeldnDepartmentName;

            }
            set
            {
                strEmpHis5_LastPositionHeldnDepartmentName = value;

            }
        }

        private string strEmpHis5_TelephoneNo;
        public string EmpHis5_TelephoneNo
        {
            get
            {
                return strEmpHis5_TelephoneNo;
            }
            set
            {
                strEmpHis5_TelephoneNo = value;

            }
        }
        private string strEmpHis5_Address;
        public string EmpHis5_Address
        {
            get
            {
                return strEmpHis5_Address;
            }
            set
            {
                strEmpHis5_Address = value;
            }
        }

        private string strEmpHis5_EmployeeCode;
        public string EmpHis5_EmployeeCode
        {
            get
            {
                return strEmpHis5_EmployeeCode;
            }
            set
            {
                strEmpHis5_EmployeeCode = value;
            }
        }
        private string strEmpHis5_PeriodofEmployment;
        public string EmpHis5_PeriodofEmployment
        {
            get
            {
                return strEmpHis5_PeriodofEmployment;
            }
            set
            {
                strEmpHis5_PeriodofEmployment = value;
            }
        }
        private string strdatetoempHis5;
        public string datetoempHis5
        {
            get
            {
                return strdatetoempHis5;
            }
            set
            {
                strdatetoempHis5 = value;
            }

        }
        private string strEmpHis5_PeriodofEmploymentRemark;
        public string EmpHis5_PeriodofEmploymentRemark
        {
            get
            {
                return strEmpHis5_PeriodofEmploymentRemark;
            }
            set
            {
                strEmpHis5_PeriodofEmploymentRemark = value;
            }
        }
        private string strEducationList;
        public string EducationList
        {
            get
            {
                return strEducationList;
            }
            set
            {
                strEducationList = value;
            }
        }
        private string strEmpHis5RLvl1_NameDesignatinOfSupervisor;
        public string EmpHis5RLvl1_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis5RLvl1_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis5RLvl1_NameDesignatinOfSupervisor = value;
            }
        }

        private string strEmpHis5RLvl1_TelepnoneNo;
        public string EmpHis5RLvl1_TelepnoneNo
        {
            get
            {
                return strEmpHis5RLvl1_TelepnoneNo;
            }
            set
            {
                strEmpHis5RLvl1_TelepnoneNo = value;
            }
        }

        private string strEmpHis5RLvl1_MobileNo;
        public string EmpHis5RLvl1_MobileNo
        {
            get
            {
                return strEmpHis5RLvl1_MobileNo;
            }
            set
            {
                strEmpHis5RLvl1_MobileNo = value;
            }
        }
        private string strEmpHis5RLvl1_EmailId;

        public string EmpHis5RLvl1_EmailId
        {
            get
            {
                return strEmpHis5RLvl1_EmailId;
            }
            set
            {
                strEmpHis5RLvl1_EmailId = value;
            }

        }
        private string strEmpHis5RLvl2_NameDesignatinOfSupervisor;
        public string EmpHis5RLvl2_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis5RLvl2_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis5RLvl2_NameDesignatinOfSupervisor = value;
            }

        }
        private string strEmpHis5RLvl2_TelepnoneNo;
        public string EmpHis5RLvl2_TelepnoneNo
        {
            get
            {
                return strEmpHis5RLvl2_TelepnoneNo;
            }
            set
            {
                strEmpHis5RLvl2_TelepnoneNo = value;
            }

        }

        private string strEmpHis5RLvl2_MobileNo;
        public string EmpHis5RLvl2_MobileNo
        {
            get
            {
                return strEmpHis5RLvl2_MobileNo;
            }
            set
            {
                strEmpHis5RLvl2_MobileNo = value;
            }


        }

        private string strEmpHis5RLvl2_EmailId;
        public string EmpHis5RLvl2_EmailId
        {
            get
            {
                return strEmpHis5RLvl2_EmailId;
            }
            set
            {
                strEmpHis5RLvl2_EmailId = value;
            }

        }
        private string strEmpHis5_TempPerma;
        public string EmpHis5_TempPerma
        {
            get
            {
                return strEmpHis5_TempPerma;
            }
            set
            {
                strEmpHis5_TempPerma = value;
            }

        }

        private string strEmpHis5_AgencyDetails;
        public string EmpHis5_AgencyDetails
        {
            get
            {
                return strEmpHis5_AgencyDetails;

            }
            set
            {
                strEmpHis5_AgencyDetails = value;
            }
        }
        private string strEmpHis5_RemunerationOrSalary;
        public string EmpHis5_RemunerationOrSalary
        {
            get
            {
                return strEmpHis5_RemunerationOrSalary;

            }
            set
            {
                strEmpHis5_RemunerationOrSalary = value;
            }
        }

        private string strEmpHis5_ReasonOfLeaving;
        public string EmpHis5_ReasonOfLeaving
        {
            get
            {
                return strEmpHis5_ReasonOfLeaving;

            }
            set
            {
                strEmpHis5_ReasonOfLeaving = value;
            }
        }
        private string strEmpHis5_referenceYN;
        public string EmpHis5_referenceYN
        {
            get
            {
                return strEmpHis5_referenceYN;
            }
            set
            {
                strEmpHis5_referenceYN = value;
            }
        }
        private string strEmpHis5_IncaseOfGap;
        public string EmpHis5_IncaseOfGap
        {
            get
            {
                return strEmpHis5_IncaseOfGap;
            }
            set
            {
                strEmpHis5_IncaseOfGap = value;
            }
        }

        private string strExperienceInYears5;
        public string ExperienceInYears5
        {
            get
            {
                return strExperienceInYears5;

            }
            set
            {
                strExperienceInYears5 = value;
            }

        }

        private string strReportingLevel2emp5;
        public string ReportingLevel2emp5
        {
            get
            {
                return strReportingLevel2emp5;
            }
            set
            {
                strReportingLevel2emp5 = value;
            }

        }




        //company 2

        private string strExperienceInYears2;
        public string ExperienceInYears2
        {
            get
            {
                return strExperienceInYears2;

            }
            set
            {
                strExperienceInYears2 = value;
            }

        }








        //  private string strb;



        public string CurrentAddress
        {
            get
            {
                return strCurrentAddress;
            }
            set
            {
                strCurrentAddress = value;
            }
        }
        public string EmpHis1_CompnayNameandLocation
        {
            get
            {
                return strEmpHis1_CompnayNameandLocation;
            }
            set
            {
                strEmpHis1_CompnayNameandLocation = value;
            }
        }
        public string EmpHis2_EmployeeCode
        {
            get
            {
                return strEmpHis2_EmployeeCode;
            }
            set
            {
                strEmpHis2_EmployeeCode = value;
            }
        }
        public string EmpHis1RLvl2_TelepnoneNo
        {
            get
            {
                return strEmpHis1RLvl2_TelepnoneNo;
            }
            set
            {
                strEmpHis1RLvl2_TelepnoneNo = value;
            }
        }
        public string EmpHis2RLvl2_MobileNo
        {
            get
            {
                return strEmpHis2RLvl2_MobileNo;
            }
            set
            {
                strEmpHis2RLvl2_MobileNo = value;
            }
        }
        public string Per_LivingSince
        {
            get
            {
                return strPer_LivingSince;
            }
            set
            {
                strPer_LivingSince = value;
            }
        }
        public string EmpHis1_EmployeeCode
        {
            get
            {
                return strEmpHis1_EmployeeCode;
            }
            set
            {
                strEmpHis1_EmployeeCode = value;
            }
        }
        public string TAT2
        {
            get
            {
                return strTAT2;
            }
            set
            {
                strTAT2 = value;
            }
        }
        public string EmpHis2RLvl1_TelepnoneNo
        {
            get
            {
                return strEmpHis2RLvl1_TelepnoneNo;
            }
            set
            {
                strEmpHis2RLvl1_TelepnoneNo = value;
            }
        }
        public string Edu1_Address
        {
            get
            {
                return strEdu1_Address;
            }
            set
            {
                strEdu1_Address = value;
            }
        }

        public string Edu1_Address2
        {
            get
            {
                return strEdu1_Address2;
            }
            set
            {
                strEdu1_Address2 = value;
            }
        }

        public string DateofJoining
        {
            get
            {
                return strDateofJoining;
            }
            set
            {
                strDateofJoining = value;
            }
        }


        public string Vender
        {
            get
            {
                return strVendor;
            }
            set
            {
                strVendor = value;
            }
        }
        public string Month
        {
            get
            {
                return strMonth;
            }
            set
            {
                strMonth = value;
            }
        }
        public string DCSV
        {
            get
            {
                return strDCSV;
            }
            set
            {
                strDCSV = value;
            }
        }
        public string DDV
        {
            get
            {
                return strDDV;
            }
            set
            {
                strDDV = value;
            }
        }
        public string DVR
        {
            get
            {
                return strDVR;
            }
            set
            {
                strDVR = value;
            }
        }
        public string DVU
        {
            get
            {
                return strDVU;
            }
            set
            {
                strDVU = value;
            }
        }
        //objEmpInfo.Vendor = myds.Tables[0].Rows[i][12].ToString().Trim();
        //objEmpInfo.Month = myds.Tables[0].Rows[i][13].ToString().Trim();              
        //objEmpInfo.DCSV = myds.Tables[0].Rows[i][15].ToString().Trim();
        //objEmpInfo.DDV = myds.Tables[0].Rows[i][16].ToString().Trim();
        //objEmpInfo.DVR = myds.Tables[0].Rows[i][17].ToString().Trim();
        //objEmpInfo.DVU = myds.Tables[0].Rows[i][18].ToString().Trim();


        public string TATDate
        {
            get
            {
                return strTATDate;
            }
            set
            {
                strTATDate = value;
            }
        }

        public string EmpHis1_TelephoneNo
        {
            get
            {
                return strEmpHis1_TelephoneNo;
            }
            set
            {
                strEmpHis1_TelephoneNo = value;
            }
        }
        public string EmpHis2RLvl2_TelepnoneNo
        {
            get
            {
                return strEmpHis2RLvl2_TelepnoneNo;
            }
            set
            {
                strEmpHis2RLvl2_TelepnoneNo = value;
            }
        }
        public string EmpHis2_IncaseOfGap
        {
            get
            {
                return strEmpHis2_IncaseOfGap;
            }
            set
            {
                strEmpHis2_IncaseOfGap = value;
            }
        }
        public string EmpHis2RLvl1_EmailId
        {
            get
            {
                return strEmpHis2RLvl1_EmailId;
            }
            set
            {
                strEmpHis2RLvl1_EmailId = value;
            }
        }
        public string Edu1_UniversityName
        {
            get
            {
                return strEdu1_UniversityName;
            }
            set
            {
                strEdu1_UniversityName = value;
            }
        }
        public string Per_Landmark
        {
            get
            {
                return strPer_Landmark;
            }
            set
            {
                strPer_Landmark = value;
            }
        }
        public string EmpHis2_AgencyDetails
        {
            get
            {
                return strEmpHis2_AgencyDetails;
            }
            set
            {
                strEmpHis2_AgencyDetails = value;
            }
        }
        public string EmpHis1_referenceYN
        {
            get
            {
                return strEmpHis1_referenceYN;
            }
            set
            {
                strEmpHis1_referenceYN = value;
            }
        }
        public string Per_PostOffice
        {
            get
            {
                return strPer_PostOffice;
            }
            set
            {
                strPer_PostOffice = value;
            }
        }
        public string FatherName
        {
            get
            {
                return strFatherName;
            }
            set
            {
                strFatherName = value;
            }
        }
        public string EmpHis1_LastPositionHeldnDepartmentName
        {
            get
            {
                return strEmpHis1_LastPositionHeldnDepartmentName;
            }
            set
            {
                strEmpHis1_LastPositionHeldnDepartmentName = value;
            }
        }
        public string EmpHis2_CompnayNameandLocation
        {
            get
            {
                return strEmpHis2_CompnayNameandLocation;
            }
            set
            {
                strEmpHis2_CompnayNameandLocation = value;
            }
        }
        public string EmpHis1_PeriodofEmployment
        {
            get
            {
                return strEmpHis1_PeriodofEmployment;
            }
            set
            {
                strEmpHis1_PeriodofEmployment = value;
            }
        }


        public string datetoemphis1  // chng 
        {
            get
            {
                return strdatetoemphis1;
            }
            set
            {
                strdatetoemphis1 = value;
            }
        }


        public string DOB
        {
            get
            {
                return strDOB;
            }
            set
            {
                strDOB = value;
            }
        }
        public string EmpHis2_referenceYN
        {
            get
            {
                return strEmpHis2_referenceYN;
            }
            set
            {
                strEmpHis2_referenceYN = value;
            }
        }
        public string Edu1_RollNo
        {
            get
            {
                return strEdu1_RollNo;
            }
            set
            {
                strEdu1_RollNo = value;
            }
        }
        public string EmpHis1RLvl1_MobileNo
        {
            get
            {
                return strEmpHis1RLvl1_MobileNo;
            }
            set
            {
                strEmpHis1RLvl1_MobileNo = value;
            }
        }
        public string EmpHis1_TempPerma
        {
            get
            {
                return strEmpHis1_TempPerma;
            }
            set
            {
                strEmpHis1_TempPerma = value;
            }
        }
        public string EmpHis2_Address
        {
            get
            {
                return strEmpHis2_Address;
            }
            set
            {
                strEmpHis2_Address = value;
            }
        }
        public string EmpHis1_PeriodofEmploymentRemark
        {
            get
            {
                return strEmpHis1_PeriodofEmploymentRemark;
            }
            set
            {
                strEmpHis1_PeriodofEmploymentRemark = value;
            }
        }
        public string EmpHis1_IncaseOfGap
        {
            get
            {
                return strEmpHis1_IncaseOfGap;
            }
            set
            {
                strEmpHis1_IncaseOfGap = value;
            }
        }
        public string EmpHis2_TempPerma
        {
            get
            {
                return strEmpHis2_TempPerma;
            }
            set
            {
                strEmpHis2_TempPerma = value;
            }
        }
        public string EmpHis1RLvl2_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis1RLvl2_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis1RLvl2_NameDesignatinOfSupervisor = value;
            }
        }
        public string EmpHis2RLvl1_MobileNo
        {
            get
            {
                return strEmpHis2RLvl1_MobileNo;
            }
            set
            {
                strEmpHis2RLvl1_MobileNo = value;
            }
        }
        public string MiddleName
        {
            get
            {
                return strMiddleName;
            }
            set
            {
                strMiddleName = value;
            }
        }
        public string Edu1_CollegeName
        {
            get
            {
                return strEdu1_CollegeName;
            }
            set
            {
                strEdu1_CollegeName = value;
            }
        }
        public string EmpHis2RLvl2_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis2RLvl2_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis2RLvl2_NameDesignatinOfSupervisor = value;
            }
        }
        public string EmpHis1_AgencyDetails
        {
            get
            {
                return strEmpHis1_AgencyDetails;
            }
            set
            {
                strEmpHis1_AgencyDetails = value;
            }
        }
        public string EmpHis2RLvl1_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis2RLvl1_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis2RLvl1_NameDesignatinOfSupervisor = value;
            }
        }
        public string FirstName
        {
            get
            {
                return strFirstName;
            }
            set
            {
                strFirstName = value;
            }
        }
        public string Per_AddressPhoneNo
        {
            get
            {
                return strPer_AddressPhoneNo;
            }
            set
            {
                strPer_AddressPhoneNo = value;
            }
        }
        public string EmpHis2_PeriodofEmployment
        {
            get
            {
                return strEmpHis2_PeriodofEmployment;
            }
            set
            {
                strEmpHis2_PeriodofEmployment = value;
            }
        }

        public string datetoemphis2  // chng
        {
            get
            {
                return strdatetoemphis2;
            }
            set
            {
                strdatetoemphis2 = value;
            }
        }

        public string EmpHis2RLvl2_EmailId
        {
            get
            {
                return strEmpHis2RLvl2_EmailId;
            }
            set
            {
                strEmpHis2RLvl2_EmailId = value;
            }
        }
        public string COE
        {
            get
            {
                return strCOE;
            }
            set
            {
                strCOE = value;
            }
        }

        public string SNo
        {
            get
            {
                return strSNo;
            }
            set
            {
                strSNo = value;
            }
        }




        public string Mobile
        {
            get
            {
                return strMobile;
            }
            set
            {
                strMobile = value;
            }
        }
        public string Per_City
        {
            get
            {
                return strPer_City;
            }
            set
            {
                strPer_City = value;
            }
        }
        public string Curr_PhoneNo
        {
            get
            {
                return strCurr_PhoneNo;
            }
            set
            {
                strCurr_PhoneNo = value;
            }
        }
        public string EmpHis2_LastPositionHeldnDepartmentName
        {
            get
            {
                return strEmpHis2_LastPositionHeldnDepartmentName;
            }
            set
            {
                strEmpHis2_LastPositionHeldnDepartmentName = value;
            }
        }
        public string EmpHis1_Address
        {
            get
            {
                return strEmpHis1_Address;
            }
            set
            {
                strEmpHis1_Address = value;
            }
        }
        public string Edu1_EducationalQualification
        {
            get
            {
                return strEdu1_EducationalQualification;
            }
            set
            {
                strEdu1_EducationalQualification = value;
            }
        }
        public string EmpHis1RLvl1_EmailId
        {
            get
            {
                return strEmpHis1RLvl1_EmailId;
            }
            set
            {
                strEmpHis1RLvl1_EmailId = value;
            }
        }
        public string InDate
        {
            get
            {
                return strInDate;
            }
            set
            {
                strInDate = value;
            }
        }
        public string Per_PoliceStation
        {
            get
            {
                return strPer_PoliceStation;
            }
            set
            {
                strPer_PoliceStation = value;
            }
        }
        public string EmpHis2_TelephoneNo
        {
            get
            {
                return strEmpHis2_TelephoneNo;
            }
            set
            {
                strEmpHis2_TelephoneNo = value;
            }
        }
        public string EmpHis1_ReasonOfLeaving
        {
            get
            {
                return strEmpHis1_ReasonOfLeaving;
            }
            set
            {
                strEmpHis1_ReasonOfLeaving = value;
            }
        }
        public string EmpHis1_RemunerationOrSalary
        {
            get
            {
                return strEmpHis1_RemunerationOrSalary;
            }
            set
            {
                strEmpHis1_RemunerationOrSalary = value;
            }
        }
        public string EnteredByLoginIdType
        {
            get
            {
                return strEnteredByLoginIdType;
            }
            set
            {
                strEnteredByLoginIdType = value;
            }
        }
        public string Band
        {
            get
            {
                return strBand;
            }
            set
            {
                strBand = value;
            }
        }
        public string EmpHis2_ReasonOfLeaving
        {
            get
            {
                return strEmpHis2_ReasonOfLeaving;
            }
            set
            {
                strEmpHis2_ReasonOfLeaving = value;
            }
        }
        public string Per_State
        {
            get
            {
                return strPer_State;
            }
            set
            {
                strPer_State = value;
            }
        }
        public string EmpIdProvidedByClient
        {
            get
            {
                return strEmpIdProvidedByClient;
            }
            set
            {
                strEmpIdProvidedByClient = value;
            }
        }
        public string PlaceofBirth
        {
            get
            {
                return strPlaceofBirth;
            }
            set
            {
                strPlaceofBirth = value;
            }
        }
        public string Surname
        {
            get
            {
                return strSurname;
            }
            set
            {
                strSurname = value;
            }
        }
        public string ExperienceInYears
        {
            get
            {
                return strExperienceInYears;
            }
            set
            {
                strExperienceInYears = value;
            }
        }
        public string PermanentAddress
        {
            get
            {
                return strPermanentAddress;
            }
            set
            {
                strPermanentAddress = value;
            }
        }
        public string Curr_City
        {
            get
            {
                return strCurr_City;
            }
            set
            {
                strCurr_City = value;
            }
        }
        public string Education1State
        {
            get
            {
                return strEducation1State;
            }
            set
            {
                strEducation1State = value;
            }

        }
        public string EmpHis2_RemunerationOrSalary
        {
            get
            {
                return strEmpHis2_RemunerationOrSalary;
            }
            set
            {
                strEmpHis2_RemunerationOrSalary = value;
            }
        }
        //public int EmployeeID
        //{
        //    get
        //    {
        //        return intEmployeeID;
        //    }
        //    set
        //    {
        //        intEmployeeID = value;
        //    }
        //}
        public string Curr_State
        {
            get
            {
                return strCurr_State;
            }
            set
            {
                strCurr_State = value;
            }
        }
        public string EmpHis1RLvl1_TelepnoneNo
        {
            get
            {
                return strEmpHis1RLvl1_TelepnoneNo;
            }
            set
            {
                strEmpHis1RLvl1_TelepnoneNo = value;
            }
        }
        public string EmpHis1RLvl2_EmailId
        {
            get
            {
                return strEmpHis1RLvl2_EmailId;
            }
            set
            {
                strEmpHis1RLvl2_EmailId = value;
            }
        }
        public string EmpHis2_PeriodofEmploymentRemark
        {
            get
            {
                return strEmpHis2_PeriodofEmploymentRemark;
            }
            set
            {
                strEmpHis2_PeriodofEmploymentRemark = value;
            }
        }
        public string EmpHis1RLvl1_NameDesignatinOfSupervisor
        {
            get
            {
                return strEmpHis1RLvl1_NameDesignatinOfSupervisor;
            }
            set
            {
                strEmpHis1RLvl1_NameDesignatinOfSupervisor = value;
            }
        }
        public string Edu1_YearOfPassing
        {
            get
            {
                return strEdu1_YearOfPassing;
            }
            set
            {
                strEdu1_YearOfPassing = value;
            }
        }
        public int EmployeeID
        {
            get
            {
                return strEmployeeId;
            }
            set
            {
                strEmployeeId = value;
            }
        }
        public string Within_TATOut
        {
            get
            {
                return strWithin_TATOut;
            }
            set
            {
                strWithin_TATOut = value;
            }
        }
        public string Online_Offline
        {
            get
            {
                return strOnline_Offline;
            }
            set
            {
                strOnline_Offline = value;
            }
        }
        public string Reallocation
        {
            get
            {
                return strReallocation;
            }
            set
            {
                strReallocation = value;
            }
        }
        public string Specialization
        {
            get
            {
                return strSpecialization;
            }
            set
            {
                strSpecialization = value;
            }
        }
        public string GraduatedYearMonth
        {
            get
            {
                return strGraduatedYearMonth;
            }
            set
            {
                strGraduatedYearMonth = value;
            }
        }
        public string Percentage
        {
            get
            {
                return strPercentage;
            }
            set
            {
                strPercentage = value;
            }
        }
        public string RevertRecd
        {
            get
            {
                return strRevertRecd;

            }
            set
            {
                strRevertRecd = value;
            }
        }
        public string StampedVerbal
        {
            get
            {
                return strStampedVerbal;
            }
            set
            {
                strStampedVerbal = value;
            }
        }
        public string DateofExport
        {
            get
            {
                return strDateofExport;
            }
            set
            {
                strDateofExport = value;
            }
        }
        public string FinalStatus
        {
            get
            {
                return strFinalStatus;
            }
            set
            {
                strFinalStatus = value;
            }
        }
        public string ColorofReport
        {
            get
            {
                return strColorofReport;
            }
            set
            {
                strColorofReport = value;
            }
        }
        public string NoofDaysDelay
        {
            get
            {
                return strNoofDaysDelay;
            }
            set
            {
                strNoofDaysDelay = value;
            }
        }
        public string DDAmount
        {
            get
            {
                return strDDAmount;
            }
            set
            {
                strDDAmount = value;
            }
        }
        public string DDDate
        {
            get
            {
                return strDDDate;
            }
            set
            {
                strDDDate = value;
            }
        }
        public string Requestedby
        {
            get
            {
                return strRequestedby;
            }
            set
            {
                strRequestedby = value;
            }
        }
        public string DateofCompeletion
        {
            get
            {
                return strDateofCompeletion;
            }
            set
            {
                strDateofCompeletion = value;
            }
        }
        public string Remarks
        {
            get
            {
                return strRemarks;
            }
            set
            {
                strRemarks = value;
            }
        }
        public string ClientRefNo
        {
            get
            {
                return strClientRefNo;
            }
            set
            {
                strClientRefNo = value;
            }
        }
        public string ResumeNo
        {
            get
            {
                return strResumeNo;
            }
            set
            {
                strResumeNo = value;
            }
        }
        public string Education1City
        {
            get
            {
                return strEducation1City;
            }
            set
            {
                strEducation1City = value;
            }
        }
        public string Education1PinCode
        {
            get
            {
                return strEducation1PinCode;
            }
            set
            {
                strEducation1PinCode = value;
            }
        }
        public string price
        {
            get
            {
                return strprice;
            }
            set
            {
                strprice = value;
            }
        }


        //public string EmployeeIDProvidedByClient
        //{
        //    get
        //    {
        //        return strEmployeeIDProvidedByClient;
        //    }
        //    set
        //    {
        //        strEmployeeIDProvidedByClient = value;
        //    }
        //}


        public string Mode
        {
            get
            {
                return strMode;
            }
            set
            {
                strMode = value;
            }
        }
        //Education2


        private string strEdu2_CollegeName;
        public string Edu2_CollegeName
        {
            get
            {
                return strEdu2_CollegeName;
            }
            set
            {
                strEdu2_CollegeName = value;
            }
        }

        private string strEdu2_UniversityName;
        public string Edu2_UniversityName
        {
            get
            {
                return strEdu2_UniversityName;
            }
            set
            {
                strEdu2_UniversityName = value;
            }
        }

        private string strEdu2_Address;
        public string Edu2_Address
        {
            get
            {
                return strEdu2_Address;
            }
            set
            {
                strEdu2_Address = value;
            }
        }



        private string strEdu2_EducationalQualification;
        public string Edu2_EducationalQualification
        {
            get
            {
                return strEdu2_EducationalQualification;
            }
            set
            {
                strEdu2_EducationalQualification = value;
            }
        }
        private string strEdu2_RollNo;
        public string Edu2_RollNo
        {
            get
            {
                return strEdu2_RollNo;
            }
            set
            {
                strEdu2_RollNo = value;
            }
        }


        private string strYearOfPassing2;
        public string YearOfPassing2
        {
            get
            {
                return strYearOfPassing2;
            }
            set
            {
                strYearOfPassing2 = value;
            }
        }
        //Education3
        private string strEdu3_CollegeName;
        public string Edu3_CollegeName
        {
            get
            {
                return strEdu3_CollegeName;
            }
            set
            {
                strEdu3_CollegeName = value;
            }
        }

        private string strEdu3_UniversityName;
        public string Edu3_UniversityName
        {
            get
            {
                return strEdu3_UniversityName;
            }
            set
            {
                strEdu3_UniversityName = value;
            }
        }

        private string strEdu3_Address;
        public string Edu3_Address
        {
            get
            {
                return strEdu3_Address;
            }
            set
            {
                strEdu3_Address = value;
            }
        }



        private string strEdu3_EducationalQualification;
        public string Edu3_EducationalQualification
        {
            get
            {
                return strEdu3_EducationalQualification;
            }
            set
            {
                strEdu3_EducationalQualification = value;
            }
        }
        private string strEdu3_RollNo;
        public string Edu3_RollNo
        {
            get
            {
                return strEdu3_RollNo;
            }
            set
            {
                strEdu3_RollNo = value;
            }
        }


        private string strYearOfPassing3;
        public string YearOfPassing3
        {
            get
            {
                return strYearOfPassing3;
            }
            set
            {
                strYearOfPassing3 = value;
            }
        }
        //Education4
        private string strEdu4_CollegeName;
        public string Edu4_CollegeName
        {
            get
            {
                return strEdu4_CollegeName;
            }
            set
            {
                strEdu4_CollegeName = value;
            }
        }

        private string strEdu4_UniversityName;
        public string Edu4_UniversityName
        {
            get
            {
                return strEdu4_UniversityName;
            }
            set
            {
                strEdu4_UniversityName = value;
            }
        }

        private string strEdu4_Address;
        public string Edu4_Address
        {
            get
            {
                return strEdu4_Address;
            }
            set
            {
                strEdu4_Address = value;
            }
        }



        private string strEdu4_EducationalQualification;
        public string Edu4_EducationalQualification
        {
            get
            {
                return strEdu4_EducationalQualification;
            }
            set
            {
                strEdu4_EducationalQualification = value;
            }
        }
        private string strEdu4_RollNo;
        public string Edu4_RollNo
        {
            get
            {
                return strEdu4_RollNo;
            }
            set
            {
                strEdu4_RollNo = value;
            }
        }


        private string strYearOfPassing4;
        public string YearOfPassing4
        {
            get
            {
                return strYearOfPassing4;
            }
            set
            {
                strYearOfPassing4 = value;
            }
        }

        private string strUserName;
        public string UserName
        {
            get
            {
                return strUserName;
            }
            set
            {
                strUserName = value;
            }
        }





        //private int strEmployeeId;
        //private string strCaseStatus;
        //private string strAllocatedStatus;
        //private string strAddressStatus;
        //private string strAddressRemarks;
        //private string strEducationStatus;
        //private string strEducationRemarks;
        //private string strEmploymentStatus;
        //private string strEmploymentRemarks;
        //private string strCriminalStatus;
        //private string strCriminalRemarks;
        //private string strReferenceStatus;
        //private string strReferenceRemarks;
        //private string strDrugtestStatus;
        //private string strDrugtestRemarks;
        public string CaseStatus
        {
            get
            {
                return strCaseStatus;
            }
            set
            {
                strCaseStatus = value;
            }
        }
        public string AllocatedStatus
        {
            get
            {
                return strAllocatedStatus;
            }
            set
            {
                strAllocatedStatus = value;
            }
        }
        //public string AddressStatus
        //{
        //    get
        //    {
        //        return strAddressStatus;
        //    }
        //    set
        //    {
        //        strAddressStatus = value;
        //    }
        //}
        //public string AddressRemarks
        //{
        //    get
        //    {
        //        return strAddressRemarks;
        //    }
        //    set
        //    {
        //        strAddressRemarks = value;
        //    }
        //}
        //public string EducationRemarks
        //{
        //    get
        //    {
        //        return strEducationRemarks;
        //    }
        //    set
        //    {
        //        strEducationRemarks = value;
        //    }
        //}
        //public string EmploymentStatus2SUP
        //{
        //    get
        //    {
        //        return strEmploymentStatus2SUP;
        //    }
        //    set
        //    {
        //        strEmploymentStatus2SUP = value;
        //    }
        //}
        //public string EmploymentRemarks2SUP
        //{
        //    get
        //    {
        //        return strEmploymentRemarks2SUP;
        //    }
        //    set
        //    {
        //        strEmploymentRemarks2SUP = value;
        //    }
        //}
        //public string CriminalRemarks
        //{
        //    get
        //    {
        //        return strCriminalRemarks;
        //    }
        //    set
        //    {
        //        strCriminalRemarks = value;
        //    }
        //}

        //public string CriminalStatus
        //{
        //    get
        //    {
        //        return strCriminalStatus;
        //    }
        //    set
        //    {
        //        strCriminalStatus = value;
        //    }
        //}
        //public string ReferenceStatus
        //{
        //    get
        //    {
        //        return strReferenceStatus;
        //    }
        //    set
        //    {
        //        strReferenceStatus = value;
        //    }
        //}
        //public string ReferenceRemarks
        //{
        //    get
        //    {
        //        return strReferenceRemarks;
        //    }
        //    set
        //    {
        //        strReferenceRemarks = value;
        //    }
        //}
        //public string DrugtestStatus
        //{
        //    get
        //    {
        //        return strDrugtestStatus;
        //    }
        //    set
        //    {
        //        strDrugtestStatus = value;
        //    }
        //}
        //public string DrugtestRemarks
        //{
        //    get
        //    {
        //        return strDrugtestRemarks;
        //    }
        //    set
        //    {
        //        strDrugtestRemarks = value;
        //    }
        //}
        //public string DataBaseRemarks
        //{
        //    get
        //    {
        //        return strDataBaseRemarks;
        //    }
        //    set
        //    {
        //        strDataBaseRemarks = value;
        //    }
        //}
        //public string DataBaseStatus
        //{
        //    get
        //    {
        //        return strDataBaseStatus;
        //    }
        //    set
        //    {
        //        strDataBaseStatus = value;
        //    }
        //}
        //public string b
        //{
        //    get
        //    {
        //        return strb;
        //    }
        //    set
        //    {
        //        strb = value;
        //    }
        //}
        //public string b
        //{
        //    get
        //    {
        //        return strb;
        //    }
        //    set
        //    {
        //        strb = value;
        //    }
        //}
        //public string b
        //{
        //    get
        //    {
        //        return strb;
        //    }
        //    set
        //    {
        //        strb = value;
        //    }
        //}

        public string ReportingLevel2emp1
        {
            get
            {
                return strReportingLevel2emp1;
            }
            set
            {
                strReportingLevel2emp1 = value;
            }
        }
        public string ReportingLevel2emp2
        {
            get
            {
                return strReportingLevel2emp1;
            }
            set
            {
                strReportingLevel2emp1 = value;
            }
        }

        public string employmentType
        {
            get
            {
                return stremploymentType;
            }
            set
            {
                stremploymentType = value;
            }
        }
        public string RejectedRemarks
        {
            get
            {
                return strRejectedRemarks;
            }
            set
            {
                strRejectedRemarks = value;
            }
        }
        public string ClientName
        {
            get
            {
                return strClientName;
            }
            set
            {
                strClientName = value;
            }
        }
        //NoOfComp
        public string FresherOrExp
        {
            get
            {
                return strFresherOrExp;
            }
            set
            {
                strFresherOrExp = value;
            }
        }

        public string NoOfComp { get { return strNoOfComp; } set { strNoOfComp = value; } }

        //Start all Checks..................
        //Address 3

        //  AddressCheck, CriminalCheck

        private string SAddressCheck;
        public string AddressCheck { get { return SAddressCheck; } set { SAddressCheck = value; } }

        private string SCriminalCheck;
        public string CriminalCheck { get { return SCriminalCheck; } set { SCriminalCheck = value; } }


        private string StxtAddress2CurrentAddress;
        public string txtAddress2CurrentAddress { get { return StxtAddress2CurrentAddress; } set { StxtAddress2CurrentAddress = value; } }

        private string StxtAddress2City;
        public string txtAddress2City { get { return StxtAddress2City; } set { StxtAddress2City = value; } }

        private string StxtAddress2State;
        public string txtAddress2State { get { return StxtAddress2State; } set { StxtAddress2State = value; } }

        private string StxtAddress2PhoneNo1;
        public string txtAddress2PhoneNo1 { get { return StxtAddress2PhoneNo1; } set { StxtAddress2PhoneNo1 = value; } }

        private string StxtAddress2PhoneNo2;
        public string txtAddress2PhoneNo2 { get { return StxtAddress2PhoneNo2; } set { StxtAddress2PhoneNo2 = value; } }

        //txtAddress2CurrentAddress
        //txtAddress2City
        //txtAddress2State
        //txtAddress2PhoneNo1
        //txtAddress2PhoneNo2
        // Address 4-
        private string StxtAddress3CurrentAddress;
        public string txtAddress3CurrentAddress { get { return StxtAddress3CurrentAddress; } set { StxtAddress3CurrentAddress = value; } }

        private string StxtAddress3City;
        public string txtAddress3City { get { return StxtAddress3City; } set { StxtAddress3City = value; } }

        private string StxtAddress3State;
        public string txtAddress3State { get { return StxtAddress3State; } set { StxtAddress3State = value; } }

        private string StxtAddress3PhoneNo1;
        public string txtAddress3PhoneNo1 { get { return StxtAddress3PhoneNo1; } set { StxtAddress3PhoneNo1 = value; } }

        private string StxtAddress3PhoneNo2;
        public string txtAddress3PhoneNo2 { get { return StxtAddress3PhoneNo2; } set { StxtAddress3PhoneNo2 = value; } }

        //txtAddress3CurrentAddress
        //txtAddress3City
        //txtAddress3State
        //txtAddress3PhoneNo1
        //txtAddress3PhoneNo2
        // Address 5-
        private string StxtAddress4CurrentAddress;
        public string txtAddress4CurrentAddress { get { return StxtAddress4CurrentAddress; } set { StxtAddress4CurrentAddress = value; } }

        private string StxtAddress4City;
        public string txtAddress4City { get { return StxtAddress4City; } set { StxtAddress4City = value; } }

        private string StxtAddress4State;
        public string txtAddress4State { get { return StxtAddress4State; } set { StxtAddress4State = value; } }

        private string StxtAddress4PhoneNo1;
        public string txtAddress4PhoneNo1 { get { return StxtAddress4PhoneNo1; } set { StxtAddress4PhoneNo1 = value; } }

        private string StxtAddress4PhoneNo2;
        public string txtAddress4PhoneNo2 { get { return StxtAddress4PhoneNo2; } set { StxtAddress4PhoneNo2 = value; } }

        //txtAddress4CurrentAddress
        //txtAddress4City
        //txtAddress4State
        //txtAddress4PhoneNo1
        //txtAddress4PhoneNo2
        // Address 6-
        private string StxtAddress5CurrentAddress;
        public string txtAddress5CurrentAddress { get { return StxtAddress5CurrentAddress; } set { StxtAddress5CurrentAddress = value; } }

        private string StxtAddress5City;
        public string txtAddress5City { get { return StxtAddress5City; } set { StxtAddress5City = value; } }

        private string StxtAddress5State;
        public string txtAddress5State { get { return StxtAddress5State; } set { StxtAddress5State = value; } }

        private string StxtAddress5PhoneNo1;
        public string txtAddress5PhoneNo1 { get { return StxtAddress5PhoneNo1; } set { StxtAddress5PhoneNo1 = value; } }

        private string StxtAddress5PhoneNo2;
        public string txtAddress5PhoneNo2 { get { return StxtAddress5PhoneNo2; } set { StxtAddress5PhoneNo2 = value; } }


        //txtAddress5CurrentAddress
        //txtAddress5City
        //txtAddress5State
        //txtAddress5PhoneNo1
        //txtAddress5PhoneNo2
        // Address 7-
        private string StxtAddress6CurrentAddress;
        public string txtAddress6CurrentAddress { get { return StxtAddress6CurrentAddress; } set { StxtAddress6CurrentAddress = value; } }

        private string StxtAddress6City;
        public string txtAddress6City { get { return StxtAddress6City; } set { StxtAddress6City = value; } }

        private string StxtAddress6State;
        public string txtAddress6State { get { return StxtAddress6State; } set { StxtAddress6State = value; } }

        private string StxtAddress6PhoneNo1;
        public string txtAddress6PhoneNo1 { get { return StxtAddress6PhoneNo1; } set { StxtAddress6PhoneNo1 = value; } }

        private string StxtAddress6PhoneNo2;
        public string txtAddress6PhoneNo2 { get { return StxtAddress6PhoneNo2; } set { StxtAddress6PhoneNo2 = value; } }

        //txtAddress6CurrentAddress
        //txtAddress6City
        //txtAddress6State
        //txtAddress6PhoneNo1
        //txtAddress6PhoneNo2
        // Address 8-
        private string StxtAddress7CurrentAddress;
        public string txtAddress7CurrentAddress { get { return StxtAddress7CurrentAddress; } set { StxtAddress7CurrentAddress = value; } }

        private string StxtAddress7City;
        public string txtAddress7City { get { return StxtAddress7City; } set { StxtAddress7City = value; } }

        private string StxtAddress7State;
        public string txtAddress7State { get { return StxtAddress7State; } set { StxtAddress7State = value; } }

        private string StxtAddress7PhoneNo1;
        public string txtAddress7PhoneNo1 { get { return StxtAddress7PhoneNo1; } set { StxtAddress7PhoneNo1 = value; } }

        private string StxtAddress7PhoneNo2;
        public string txtAddress7PhoneNo2 { get { return StxtAddress7PhoneNo2; } set { StxtAddress7PhoneNo2 = value; } }

        //txtAddress7CurrentAddress
        //txtAddress7City
        //txtAddress7State
        //txtAddress7PhoneNo1
        //txtAddress7PhoneNo2

        //Criminal Check
        //1-txtCriminal1Address,txtCriminal1Location

        private string StxtCriminal1Location;
        public string txtCriminal1Location { get { return StxtCriminal1Location; } set { StxtCriminal1Location = value; } }

        //2-txtCriminal2Address,txtCriminal2Location

        private string StxtCriminal2Location;
        public string txtCriminal2Location { get { return StxtCriminal2Location; } set { StxtCriminal2Location = value; } }


        //3-txtCriminal3Address,txtCriminal3Location

        private string StxtCriminal3Location;
        public string txtCriminal3Location { get { return StxtCriminal3Location; } set { StxtCriminal3Location = value; } }


        //4-txtCriminal4Address,txtCriminal4Location

        private string StxtCriminal4Location;
        public string txtCriminal4Location { get { return StxtCriminal4Location; } set { StxtCriminal4Location = value; } }

        //5-txtCriminal5Address,txtCriminal5Location


        private string StxtCriminal5Location;
        public string txtCriminal5Location { get { return StxtCriminal5Location; } set { StxtCriminal5Location = value; } }
        //6-txtCriminal6Address,txtCriminal6Location

        private string StxtCriminal6Location;
        public string txtCriminal6Location { get { return StxtCriminal6Location; } set { StxtCriminal6Location = value; } }


        //7-txtCriminal7Address,txtCriminal7Location

        private string StxtCriminal7Location;
        public string txtCriminal7Location { get { return StxtCriminal7Location; } set { StxtCriminal7Location = value; } }


        //8-txtCriminal8Address,txtCriminal8Location

        private string StxtCriminal8Location;
        public string txtCriminal8Location { get { return StxtCriminal8Location; } set { StxtCriminal8Location = value; } }



        //Education Check
        //5-
        //txtEducation5CollegeName
        //txtEducation5CollegeAddress
        //txtEducation5UniversityName
        //txtEducation5UniversityAddress
        //txtEducation5EQ
        //txtEducation5YearofPassing
        //txtEducation5RollNo
        //txtEducation5joainfrom
        //txtEducation5joainto
        //txtEducation5State
        //txtEducation5City
        //txtEducation5PinCode

        private string StxtEducation5CollegeName;
        public string txtEducation5CollegeName { get { return StxtEducation5CollegeName; } set { StxtEducation5CollegeName = value; } }


        private string StxtEducation5CollegeAddress;
        public string txtEducation5CollegeAddress { get { return StxtEducation5CollegeAddress; } set { StxtEducation5CollegeAddress = value; } }


        private string StxtEducation5UniversityName;
        public string txtEducation5UniversityName { get { return StxtEducation5UniversityName; } set { StxtEducation5UniversityName = value; } }


        private string StxtEducation5UniversityAddress;
        public string txtEducation5UniversityAddress { get { return StxtEducation5UniversityAddress; } set { StxtEducation5UniversityAddress = value; } }


        private string StxtEducation5EQ;
        public string txtEducation5EQ { get { return StxtEducation5EQ; } set { StxtEducation5EQ = value; } }


        private string StxtEducation5YearofPassing;
        public string txtEducation5YearofPassing { get { return StxtEducation5YearofPassing; } set { StxtEducation5YearofPassing = value; } }


        private string StxtEducation5RollNo;
        public string txtEducation5RollNo { get { return StxtEducation5RollNo; } set { StxtEducation5RollNo = value; } }


        private string StxtEducation5joinfrom;
        public string txtEducation5joinfrom { get { return StxtEducation5joinfrom; } set { StxtEducation5joinfrom = value; } }

        private string StxtEducation5jointo;
        public string txtEducation5jointo { get { return StxtEducation5jointo; } set { StxtEducation5jointo = value; } }


        private string StxtEducation5State;
        public string txtEducation5State { get { return StxtEducation5State; } set { StxtEducation5State = value; } }


        private string StxtEducation5City;
        public string txtEducation5City { get { return StxtEducation5City; } set { StxtEducation5City = value; } }


        private string StxtEducation5PinCode;
        public string txtEducation5PinCode { get { return StxtEducation5PinCode; } set { StxtEducation5PinCode = value; } }



        //6-
        //txtEducation6CollegeName
        //txtEducation6CollegeAddress
        //txtEducation6UniversityName
        //txtEducation6UniversityAddress
        //txtEducation6EQ
        //txtEducation6YearofPassing
        //txtEducation6RollNo
        //txtEducation6joainfrom
        //txtEducation6joainto
        //txtEducation6State
        //txtEducation6City
        //txtEducation6PinCode

        private string StxtEducation6CollegeName;
        public string txtEducation6CollegeName { get { return StxtEducation6CollegeName; } set { StxtEducation6CollegeName = value; } }


        private string StxtEducation6CollegeAddress;
        public string txtEducation6CollegeAddress { get { return StxtEducation6CollegeAddress; } set { StxtEducation6CollegeAddress = value; } }


        private string StxtEducation6UniversityName;
        public string txtEducation6UniversityName { get { return StxtEducation6UniversityName; } set { StxtEducation6UniversityName = value; } }


        private string StxtEducation6UniversityAddress;
        public string txtEducation6UniversityAddress { get { return StxtEducation6UniversityAddress; } set { StxtEducation6UniversityAddress = value; } }


        private string StxtEducation6EQ;
        public string txtEducation6EQ { get { return StxtEducation6EQ; } set { StxtEducation6EQ = value; } }


        private string StxtEducation6YearofPassing;
        public string txtEducation6YearofPassing { get { return StxtEducation6YearofPassing; } set { StxtEducation6YearofPassing = value; } }


        private string StxtEducation6RollNo;
        public string txtEducation6RollNo { get { return StxtEducation6RollNo; } set { StxtEducation6RollNo = value; } }


        private string StxtEducation6joinfrom;
        public string txtEducation6joinfrom { get { return StxtEducation6joinfrom; } set { StxtEducation6joinfrom = value; } }

        private string StxtEducation6jointo;
        public string txtEducation6jointo { get { return StxtEducation6jointo; } set { StxtEducation6jointo = value; } }


        private string StxtEducation6State;
        public string txtEducation6State { get { return StxtEducation6State; } set { StxtEducation6State = value; } }


        private string StxtEducation6City;
        public string txtEducation6City { get { return StxtEducation6City; } set { StxtEducation6City = value; } }


        private string StxtEducation6PinCode;
        public string txtEducation6PinCode { get { return StxtEducation6PinCode; } set { StxtEducation6PinCode = value; } }



        //7-
        //txtEducation7CollegeName
        //txtEducation7CollegeAddress
        //txtEducation7UniversityName
        //txtEducation7UniversityAddress
        //txtEducation7EQ
        //txtEducation7YearofPassing
        //txtEducation7RollNo
        //txtEducation7joainfrom
        //txtEducation7joainto
        //txtEducation7State
        //txtEducation7City
        //txtEducation7PinCode

        private string StxtEducation7CollegeName;
        public string txtEducation7CollegeName { get { return StxtEducation7CollegeName; } set { StxtEducation7CollegeName = value; } }


        private string StxtEducation7CollegeAddress;
        public string txtEducation7CollegeAddress { get { return StxtEducation7CollegeAddress; } set { StxtEducation7CollegeAddress = value; } }


        private string StxtEducation7UniversityName;
        public string txtEducation7UniversityName { get { return StxtEducation7UniversityName; } set { StxtEducation7UniversityName = value; } }


        private string StxtEducation7UniversityAddress;
        public string txtEducation7UniversityAddress { get { return StxtEducation7UniversityAddress; } set { StxtEducation7UniversityAddress = value; } }


        private string StxtEducation7EQ;
        public string txtEducation7EQ { get { return StxtEducation7EQ; } set { StxtEducation7EQ = value; } }


        private string StxtEducation7YearofPassing;
        public string txtEducation7YearofPassing { get { return StxtEducation7YearofPassing; } set { StxtEducation7YearofPassing = value; } }


        private string StxtEducation7RollNo;
        public string txtEducation7RollNo { get { return StxtEducation7RollNo; } set { StxtEducation7RollNo = value; } }


        private string StxtEducation7joinfrom;
        public string txtEducation7joinfrom { get { return StxtEducation7joinfrom; } set { StxtEducation7joinfrom = value; } }

        private string StxtEducation7jointo;
        public string txtEducation7jointo { get { return StxtEducation7jointo; } set { StxtEducation7jointo = value; } }


        private string StxtEducation7State;
        public string txtEducation7State { get { return StxtEducation7State; } set { StxtEducation7State = value; } }


        private string StxtEducation7City;
        public string txtEducation7City { get { return StxtEducation7City; } set { StxtEducation7City = value; } }


        private string StxtEducation7PinCode;
        public string txtEducation7PinCode { get { return StxtEducation7PinCode; } set { StxtEducation7PinCode = value; } }

        //8-
        //txtEducation8CollegeName
        //txtEducation8CollegeAddress
        //txtEducation8UniversityName
        //txtEducation8UniversityAddress
        //txtEducation8EQ
        //txtEducation8YearofPassing
        //txtEducation8RollNo
        //txtEducation8joainfrom
        //txtEducation8joainto
        //txtEducation8State
        //txtEducation8City
        //txtEducation8PinCode


        private string StxtEducation8CollegeName;
        public string txtEducation8CollegeName { get { return StxtEducation8CollegeName; } set { StxtEducation8CollegeName = value; } }


        private string StxtEducation8CollegeAddress;
        public string txtEducation8CollegeAddress { get { return StxtEducation8CollegeAddress; } set { StxtEducation8CollegeAddress = value; } }


        private string StxtEducation8UniversityName;
        public string txtEducation8UniversityName { get { return StxtEducation8UniversityName; } set { StxtEducation8UniversityName = value; } }


        private string StxtEducation8UniversityAddress;
        public string txtEducation8UniversityAddress { get { return StxtEducation8UniversityAddress; } set { StxtEducation8UniversityAddress = value; } }


        private string StxtEducation8EQ;
        public string txtEducation8EQ { get { return StxtEducation8EQ; } set { StxtEducation8EQ = value; } }


        private string StxtEducation8YearofPassing;
        public string txtEducation8YearofPassing { get { return StxtEducation8YearofPassing; } set { StxtEducation8YearofPassing = value; } }


        private string StxtEducation8RollNo;
        public string txtEducation8RollNo { get { return StxtEducation8RollNo; } set { StxtEducation8RollNo = value; } }


        private string StxtEducation8joinfrom;
        public string txtEducation8joinfrom { get { return StxtEducation8joinfrom; } set { StxtEducation8joinfrom = value; } }

        private string StxtEducation8jointo;
        public string txtEducation8jointo { get { return StxtEducation8jointo; } set { StxtEducation8jointo = value; } }


        private string StxtEducation8State;
        public string txtEducation8State { get { return StxtEducation8State; } set { StxtEducation8State = value; } }


        private string StxtEducation8City;
        public string txtEducation8City { get { return StxtEducation8City; } set { StxtEducation8City = value; } }


        private string StxtEducation8PinCode;
        public string txtEducation8PinCode { get { return StxtEducation8PinCode; } set { StxtEducation8PinCode = value; } }


        //EmployementCheck
        //6-
        //txtEmployement6CompanyName
        //txtEmployement6CompanyLocation
        //txtEmployement6OfficeAddress
        //txtEmployement6officeLocation
        //txtEmployement6Designation
        //txtEmployement6phone1
        //txtEmployement6phone2
        //txtEmployement6EmpCode
        //txtEmployement6DateFrom
        //txtEmployement6DateTo
        //txtEmployement6Salary
        //txtEmployement6State
        //txtEmployement6City
        //txtEmployement6PinCode
        //txtEmplyement6Sdesig
        //txtEmplyement6Semail
        //txtEmplyement6Sphone1
        //txtEmplyement6Sphone2
        //txtEmplyement6SMobile
        //txtEmplyement6SResofliv

        private string StxtEmployement6CompanyName;
        public string txtEmployement6CompanyName { get { return StxtEmployement6CompanyName; } set { StxtEmployement6CompanyName = value; } }

        private string StxtEmployement6CompanyLocation;
        public string txtEmployement6CompanyLocation { get { return StxtEmployement6CompanyLocation; } set { StxtEmployement6CompanyLocation = value; } }



        private string StxtEmployement6OfficeAddress;
        public string txtEmployement6OfficeAddress { get { return StxtEmployement6OfficeAddress; } set { StxtEmployement6OfficeAddress = value; } }


        private string StxtEmployement6officeLocation;
        public string txtEmployement6officeLocation { get { return StxtEmployement6officeLocation; } set { StxtEmployement6officeLocation = value; } }



        private string StxtEmployement6Designation;
        public string txtEmployement6Designation { get { return StxtEmployement6Designation; } set { StxtEmployement6Designation = value; } }


        private string StxtEmployement6phone1;
        public string txtEmployement6phone1 { get { return StxtEmployement6phone1; } set { StxtEmployement6phone1 = value; } }


        private string StxtEmployement6phone2;
        public string txtEmployement6phone2 { get { return StxtEmployement6phone2; } set { StxtEmployement6phone2 = value; } }


        private string StxtEmployement6EmpCode;
        public string txtEmployement6EmpCode { get { return StxtEmployement6EmpCode; } set { StxtEmployement6EmpCode = value; } }


        private string StxtEmployement6DateFrom;
        public string txtEmployement6DateFrom { get { return StxtEmployement6DateFrom; } set { StxtEmployement6DateFrom = value; } }


        private string StxtEmployement6DateTo;
        public string txtEmployement6DateTo { get { return StxtEmployement6DateTo; } set { StxtEmployement6DateTo = value; } }


        private string StxtEmployement6Salary;
        public string txtEmployement6Salary { get { return StxtEmployement6Salary; } set { StxtEmployement6Salary = value; } }


        private string StxtEmployement6State;
        public string txtEmployement6State { get { return StxtEmployement6State; } set { StxtEmployement6State = value; } }


        private string StxtEmployement6City;
        public string txtEmployement6City { get { return StxtEmployement6City; } set { StxtEmployement6City = value; } }

        private string StxtEmployement6PinCode;
        public string txtEmployement6PinCode { get { return StxtEmployement6PinCode; } set { StxtEmployement6PinCode = value; } }



        private string StxtEmployement6Sdesig;
        public string txtEmployement6Sdesig { get { return StxtEmployement6Sdesig; } set { StxtEmployement6Sdesig = value; } }

        private string StxtEmployement6Semail;
        public string txtEmployement6Semail { get { return StxtEmployement6Semail; } set { StxtEmployement6Semail = value; } }


        private string StxtEmployement6Sphone1;
        public string txtEmployement6Sphone1 { get { return StxtEmployement6Sphone1; } set { StxtEmployement6Sphone1 = value; } }

        private string StxtEmployement6Sphone2;
        public string txtEmployement6Sphone2 { get { return StxtEmployement6Sphone2; } set { StxtEmployement6Sphone2 = value; } }

        private string StxtEmployement6SMobile;
        public string txtEmployement6SMobile { get { return StxtEmployement6SMobile; } set { StxtEmployement6SMobile = value; } }

        private string StxtEmployement6SResofliv;
        public string txtEmployement6SResofliv { get { return StxtEmployement6SResofliv; } set { StxtEmployement6SResofliv = value; } }







        //7-


        //txtEmployement7CompanyName
        //txtEmployement7CompanyLocation
        //txtEmployement7OfficeAddress
        //txtEmployement7officeLocation
        //txtEmployement7Designation
        //txtEmployement7phone1
        //txtEmployement7phone2

        //txtEmployement7EmpCode
        //txtEmployement7DateFrom
        //txtEmployement7DateTo
        //txtEmployement7Salary
        //txtEmployement7State
        //txtEmployement7City
        //txtEmployement7PinCode
        //txtEmplyement7Sdesig
        //txtEmplyement7Semail
        //txtEmplyement7Sphone1
        //txtEmplyement7Sphone2
        //txtEmplyement7SMobile
        //txtEmplyement7SResofliv

        private string StxtEmployement7CompanyName;
        public string txtEmployement7CompanyName { get { return StxtEmployement7CompanyName; } set { StxtEmployement7CompanyName = value; } }

        private string StxtEmployement7CompanyLocation;
        public string txtEmployement7CompanyLocation { get { return StxtEmployement7CompanyLocation; } set { StxtEmployement7CompanyLocation = value; } }



        private string StxtEmployement7OfficeAddress;
        public string txtEmployement7OfficeAddress { get { return StxtEmployement7OfficeAddress; } set { StxtEmployement7OfficeAddress = value; } }


        private string StxtEmployement7officeLocation;
        public string txtEmployement7officeLocation { get { return StxtEmployement7officeLocation; } set { StxtEmployement7officeLocation = value; } }



        private string StxtEmployement7Designation;
        public string txtEmployement7Designation { get { return StxtEmployement7Designation; } set { StxtEmployement7Designation = value; } }


        private string StxtEmployement7phone1;
        public string txtEmployement7phone1 { get { return StxtEmployement7phone1; } set { StxtEmployement7phone1 = value; } }


        private string StxtEmployement7phone2;
        public string txtEmployement7phone2 { get { return StxtEmployement7phone2; } set { StxtEmployement7phone2 = value; } }


        private string StxtEmployement7EmpCode;
        public string txtEmployement7EmpCode { get { return StxtEmployement7EmpCode; } set { StxtEmployement7EmpCode = value; } }


        private string StxtEmployement7DateFrom;
        public string txtEmployement7DateFrom { get { return StxtEmployement7DateFrom; } set { StxtEmployement7DateFrom = value; } }


        private string StxtEmployement7DateTo;
        public string txtEmployement7DateTo { get { return StxtEmployement7DateTo; } set { StxtEmployement7DateTo = value; } }


        private string StxtEmployement7Salary;
        public string txtEmployement7Salary { get { return StxtEmployement7Salary; } set { StxtEmployement7Salary = value; } }


        private string StxtEmployement7State;
        public string txtEmployement7State { get { return StxtEmployement7State; } set { StxtEmployement7State = value; } }


        private string StxtEmployement7City;
        public string txtEmployement7City { get { return StxtEmployement7City; } set { StxtEmployement7City = value; } }


        private string StxtEmployement7PinCode;
        public string txtEmployement7PinCode { get { return StxtEmployement7PinCode; } set { StxtEmployement7PinCode = value; } }

        private string StxtEmployement7Sdesig;
        public string txtEmployement7Sdesig { get { return StxtEmployement7Sdesig; } set { StxtEmployement7Sdesig = value; } }

        private string StxtEmployement7Semail;
        public string txtEmployement7Semail { get { return StxtEmployement7Semail; } set { StxtEmployement7Semail = value; } }


        private string StxtEmployement7Sphone1;
        public string txtEmployement7Sphone1 { get { return StxtEmployement7Sphone1; } set { StxtEmployement7Sphone1 = value; } }

        private string StxtEmployement7Sphone2;
        public string txtEmployement7Sphone2 { get { return StxtEmployement7Sphone2; } set { StxtEmployement7Sphone2 = value; } }

        private string StxtEmployement7SMobile;
        public string txtEmployement7SMobile { get { return StxtEmployement7SMobile; } set { StxtEmployement7SMobile = value; } }

        private string StxtEmployement7SResofliv;
        public string txtEmployement7SResofliv { get { return StxtEmployement7SResofliv; } set { StxtEmployement7SResofliv = value; } }




        //8-


        //txtEmployement8CompanyName
        //txtEmployement8CompanyLocation
        //txtEmployement8OfficeAddress
        //txtEmployement8officeLocation
        //txtEmployement8Designation
        //txtEmployement8phone1
        //txtEmployement8phone2

        //txtEmployement8EmpCode
        //txtEmployement8DateFrom
        //txtEmployement8DateTo
        //txtEmployement8Salary
        //txtEmployement8State
        //txtEmployement8City
        //txtEmployement8PinCode
        //txtEmplyement8Sdesig
        //txtEmplyement8Semail
        //txtEmplyement8Sphone1
        //txtEmplyement8Sphone2
        //txtEmplyement8SMobile
        //txtEmplyement8SResofliv

        private string StxtEmployement8CompanyName;
        public string txtEmployement8CompanyName { get { return StxtEmployement8CompanyName; } set { StxtEmployement8CompanyName = value; } }

        private string StxtEmployement8CompanyLocation;
        public string txtEmployement8CompanyLocation { get { return StxtEmployement8CompanyLocation; } set { StxtEmployement8CompanyLocation = value; } }



        private string StxtEmployement8OfficeAddress;
        public string txtEmployement8OfficeAddress { get { return StxtEmployement8OfficeAddress; } set { StxtEmployement8OfficeAddress = value; } }


        private string StxtEmployement8officeLocation;
        public string txtEmployement8officeLocation { get { return StxtEmployement8officeLocation; } set { StxtEmployement8officeLocation = value; } }



        private string StxtEmployement8Designation;
        public string txtEmployement8Designation { get { return StxtEmployement8Designation; } set { StxtEmployement8Designation = value; } }


        private string StxtEmployement8phone1;
        public string txtEmployement8phone1 { get { return StxtEmployement8phone1; } set { StxtEmployement8phone1 = value; } }


        private string StxtEmployement8phone2;
        public string txtEmployement8phone2 { get { return StxtEmployement8phone2; } set { StxtEmployement8phone2 = value; } }


        private string StxtEmployement8EmpCode;
        public string txtEmployement8EmpCode { get { return StxtEmployement8EmpCode; } set { StxtEmployement8EmpCode = value; } }


        private string StxtEmployement8DateFrom;
        public string txtEmployement8DateFrom { get { return StxtEmployement8DateFrom; } set { StxtEmployement8DateFrom = value; } }


        private string StxtEmployement8DateTo;
        public string txtEmployement8DateTo { get { return StxtEmployement8DateTo; } set { StxtEmployement8DateTo = value; } }


        private string StxtEmployement8Salary;
        public string txtEmployement8Salary { get { return StxtEmployement8Salary; } set { StxtEmployement8Salary = value; } }


        private string StxtEmployement8State;
        public string txtEmployement8State { get { return StxtEmployement8State; } set { StxtEmployement8State = value; } }


        private string StxtEmployement8City;
        public string txtEmployement8City { get { return StxtEmployement8City; } set { StxtEmployement8City = value; } }


        private string StxtEmployement8PinCode;
        public string txtEmployement8PinCode { get { return StxtEmployement8PinCode; } set { StxtEmployement8PinCode = value; } }


        private string StxtEmployement8Sdesig;
        public string txtEmployement8Sdesig { get { return StxtEmployement8Sdesig; } set { StxtEmployement8Sdesig = value; } }

        private string StxtEmployement8Semail;
        public string txtEmployement8Semail { get { return StxtEmployement8Semail; } set { StxtEmployement8Semail = value; } }


        private string StxtEmployement8Sphone1;
        public string txtEmployement8Sphone1 { get { return StxtEmployement8Sphone1; } set { StxtEmployement8Sphone1 = value; } }

        private string StxtEmployement8Sphone2;
        public string txtEmployement8Sphone2 { get { return StxtEmployement8Sphone2; } set { StxtEmployement8Sphone2 = value; } }

        private string StxtEmployement8SMobile;
        public string txtEmployement8SMobile { get { return StxtEmployement8SMobile; } set { StxtEmployement8SMobile = value; } }

        private string StxtEmployement8SResofliv;
        public string txtEmployement8SResofliv { get { return StxtEmployement8SResofliv; } set { StxtEmployement8SResofliv = value; } }






        //REference Check

        //ddlReference
        //1-
        //txtRefCheck1AppName
        //txtRef1DOV
        //txtRefCheck1VerifierName
        //txtRef1Desi
        //txtRef1Company
        //txtRef1Email
        //txtRef1CN

        private string SddlReference;
        public string ddlReference { get { return SddlReference; } set { SddlReference = value; } }

        private string StxtRef1DOV;
        public string txtRef1DOV { get { return StxtRef1DOV; } set { StxtRef1DOV = value; } }

        private string StxtRefCheck1AppName;
        public string txtRefCheck1AppName { get { return StxtRefCheck1AppName; } set { StxtRefCheck1AppName = value; } }

        private string StxtRefCheck1VerifierName;
        public string txtRefCheck1VerifierName { get { return StxtRefCheck1VerifierName; } set { StxtRefCheck1VerifierName = value; } }

        private string StxtRef1Desi;
        public string txtRef1Desi { get { return StxtRef1Desi; } set { StxtRef1Desi = value; } }

        private string StxtRef1Company;
        public string txtRef1Company { get { return StxtRef1Company; } set { StxtRef1Company = value; } }

        private string StxtRef1Email;
        public string txtRef1Email { get { return StxtRef1Email; } set { StxtRef1Email = value; } }

        private string StxtRef1CN;
        public string txtRef1CN { get { return StxtRef1CN; } set { StxtRef1CN = value; } }






        //2-
        //txtRefCheck2AppName
        //txtRef2DOV
        //txtRefCheck2VerifierName
        //txtRef2Desi
        //txtRef2Company
        //txtRef2Email
        //txtRef2CN



        private string StxtRef2DOV;
        public string txtRef2DOV { get { return StxtRef2DOV; } set { StxtRef2DOV = value; } }

        private string StxtRefCheck2AppName;
        public string txtRefCheck2AppName { get { return StxtRefCheck2AppName; } set { StxtRefCheck2AppName = value; } }

        private string StxtRefCheck2VerifierName;
        public string txtRefCheck2VerifierName { get { return StxtRefCheck2VerifierName; } set { StxtRefCheck2VerifierName = value; } }

        private string StxtRef2Desi;
        public string txtRef2Desi { get { return StxtRef2Desi; } set { StxtRef2Desi = value; } }

        private string StxtRef2Company;
        public string txtRef2Company { get { return StxtRef2Company; } set { StxtRef2Company = value; } }

        private string StxtRef2Email;
        public string txtRef2Email { get { return StxtRef2Email; } set { StxtRef2Email = value; } }

        private string StxtRef2CN;
        public string txtRef2CN { get { return StxtRef2CN; } set { StxtRef2CN = value; } }


        //3-
        //txtRefCheck3AppName
        //txtRef3DOV
        //txtRefCheck3VerifierName
        //txtRef3Desi
        //txtRef3Company
        //txtRef3Email
        //txtRef3CN

        private string StxtRef3DOV;
        public string txtRef3DOV { get { return StxtRef3DOV; } set { StxtRef3DOV = value; } }

        private string StxtRefCheck3AppName;
        public string txtRefCheck3AppName { get { return StxtRefCheck3AppName; } set { StxtRefCheck3AppName = value; } }

        private string StxtRefCheck3VerifierName;
        public string txtRefCheck3VerifierName { get { return StxtRefCheck3VerifierName; } set { StxtRefCheck3VerifierName = value; } }

        private string StxtRef3Desi;
        public string txtRef3Desi { get { return StxtRef3Desi; } set { StxtRef3Desi = value; } }

        private string StxtRef3Company;
        public string txtRef3Company { get { return StxtRef3Company; } set { StxtRef3Company = value; } }

        private string StxtRef3Email;
        public string txtRef3Email { get { return StxtRef3Email; } set { StxtRef3Email = value; } }

        private string StxtRef3CN;
        public string txtRef3CN { get { return StxtRef3CN; } set { StxtRef3CN = value; } }


        //Database Check
        //ddlDatabase
        //1-
        //txtDatabaseCheck
        //txtDatabaseLocation
        private string SddlDatabase;
        public string ddlDatabase { get { return SddlDatabase; } set { SddlDatabase = value; } }

        private string StxtDatabaseCheck;
        public string txtDatabaseCheck { get { return StxtDatabaseCheck; } set { StxtDatabaseCheck = value; } }

        private string StxtDatabaseLocation;
        public string txtDatabaseLocation { get { return StxtDatabaseLocation; } set { StxtDatabaseLocation = value; } }


        //Drug Check
        //ddlDrug
        //1-txtDrugCheck
        //2-txtDrugLocation
        private string SddlDrug;
        public string ddlDrug { get { return SddlDrug; } set { SddlDrug = value; } }

        private string StxtDrugCheck;
        public string txtDrugCheck { get { return StxtDrugCheck; } set { StxtDrugCheck = value; } }

        private string StxtDrugLocation;
        public string txtDrugLocation { get { return StxtDrugLocation; } set { StxtDrugLocation = value; } }



        //Identity Check
        //ddlIndentity,
        //txtIdetityCheck,
        //txtIdentityLocation
        private string SddlIndentity;
        public string ddlIndentity { get { return SddlIndentity; } set { SddlIndentity = value; } }

        private string StxtIdentityCheck;
        public string txtIdentityCheck { get { return StxtIdentityCheck; } set { StxtIdentityCheck = value; } }

        private string StxtIdentityLocation;
        public string txtIdentityLocation { get { return StxtIdentityLocation; } set { StxtIdentityLocation = value; } }

        //Identity 2


        private string StxtIdentityCheck2;
        public string txtIdentityCheck2 { get { return StxtIdentityCheck2; } set { StxtIdentityCheck2 = value; } }

        private string StxtIdentityLocation2;
        public string txtIdentityLocation2 { get { return StxtIdentityLocation2; } set { StxtIdentityLocation2 = value; } }

        private string StxtIdentityState2;
        public string txtIdentityState2 { get { return StxtIdentityState2; } set { StxtIdentityState2 = value; } }

        //Identity 3



        private string StxtIdentityCheck3;
        public string txtIdentityCheck3 { get { return StxtIdentityCheck3; } set { StxtIdentityCheck3 = value; } }

        private string StxtIdentityLocation3;
        public string txtIdentityLocation3 { get { return StxtIdentityLocation3; } set { StxtIdentityLocation3 = value; } }

        private string StxtIdentityState3;
        public string txtIdentityState3 { get { return StxtIdentityState3; } set { StxtIdentityState3 = value; } }

        //Identity 4



        private string StxtIdentityCheck4;
        public string txtIdentityCheck4 { get { return StxtIdentityCheck4; } set { StxtIdentityCheck4 = value; } }

        private string StxtIdentityLocation4;
        public string txtIdentityLocation4 { get { return StxtIdentityLocation4; } set { StxtIdentityLocation4 = value; } }

        private string StxtIdentityState4;
        public string txtIdentityState4 { get { return StxtIdentityState4; } set { StxtIdentityState4 = value; } }

        //End All Checks


        //Criminal Address And State


        private string SCriminal1Address;
        public string Criminal1Address { get { return SCriminal1Address; } set { SCriminal1Address = value; } }

        private string SCriminal2Address;
        public string Criminal2Address { get { return SCriminal2Address; } set { SCriminal2Address = value; } }

        private string SCriminal3Address;
        public string Criminal3Address { get { return SCriminal3Address; } set { SCriminal3Address = value; } }


        private string SCriminal4Address;
        public string Criminal4Address { get { return SCriminal4Address; } set { SCriminal4Address = value; } }


        private string SCriminal5Address;
        public string Criminal5Address { get { return SCriminal5Address; } set { SCriminal5Address = value; } }


        private string SCriminal6Address;
        public string Criminal6Address { get { return SCriminal6Address; } set { SCriminal6Address = value; } }


        private string SCriminal7Address;
        public string Criminal7Address { get { return SCriminal7Address; } set { SCriminal7Address = value; } }


        private string SCriminal8Address;
        public string Criminal8Address { get { return SCriminal8Address; } set { SCriminal8Address = value; } }


        /// <summary>
        /// /////////// Criminal State
        /// </summary>

        private string SCriminal1State;
        public string Criminal1State { get { return SCriminal1State; } set { SCriminal1State = value; } }

        private string SCriminal2State;
        public string Criminal2State { get { return SCriminal2State; } set { SCriminal2State = value; } }

        private string SCriminal3State;
        public string Criminal3State { get { return SCriminal3State; } set { SCriminal3State = value; } }


        private string SCriminal4State;
        public string Criminal4State { get { return SCriminal4State; } set { SCriminal4State = value; } }


        private string SCriminal5State;
        public string Criminal5State { get { return SCriminal5State; } set { SCriminal5State = value; } }


        private string SCriminal6State;
        public string Criminal6State { get { return SCriminal6State; } set { SCriminal6State = value; } }


        private string SCriminal7State;
        public string Criminal7State { get { return SCriminal7State; } set { SCriminal7State = value; } }


        private string SCriminal8State;
        public string Criminal8State { get { return SCriminal8State; } set { SCriminal8State = value; } }

        //////////////Requirement Type Verbal/Written

        public string SRequirement_edu1
        {
            get { return strRequirement_edu1; }
            set { strRequirement_edu1 = value; }
        }

        public string SRequirement_edu2
        {
            get { return strRequirement_edu2; }
            set { strRequirement_edu2 = value; }
        }

        public string SRequirement_edu3
        {
            get { return strRequirement_edu3; }
            set { strRequirement_edu3 = value; }
        }

        public string SRequirement_edu4
        {
            get { return strRequirement_edu4; }
            set { strRequirement_edu4 = value; }
        }

        public string SRequirement_edu5
        {
            get { return strRequirement_edu5; }
            set { strRequirement_edu5 = value; }
        }

        public string SRequirement_edu6
        {
            get { return strRequirement_edu6; }
            set { strRequirement_edu6 = value; }
        }

        public string SRequirement_edu7
        {
            get { return strRequirement_edu7; }
            set { strRequirement_edu7 = value; }
        }

        public string SRequirement_edu8
        {
            get { return strRequirement_edu8; }
            set { strRequirement_edu8 = value; }
        }





        ////////////////////For University/College Module

        public string SUniName
        {
            get { return strUniName; }
            set { strUniName = value; }
        }
        public string SUniLoc
        {
            get { return strUniLoc; }
            set { strUniLoc = value; }
        }
        public string SUniConPer
        {
            get { return strUniConPer; }
            set { strUniConPer = value; }
        }
        public string SUniDesig
        {
            get { return strUniDesig; }
            set { strUniDesig = value; }
        }
        public string SUniNo1
        {
            get { return strUniNo1; }
            set { strUniNo1 = value; }
        }
        public string SUniNo2
        {
            get { return strUniNo2; }
            set { strUniNo2 = value; }
        }
        public string SUniConPer1
        {
            get { return strUniConPer1; }
            set { strUniConPer1 = value; }
        }
        public string SUniDesig1
        {
            get { return strUniDesig1; }
            set { strUniDesig1 = value; }
        }
        public string SUniNo3
        {
            get { return strUniNo3; }
            set { strUniNo3 = value; }
        }
        public string SUniNo4
        {
            get { return strUniNo4; }
            set { strUniNo4 = value; }
        }
        public string SUniDD
        {
            get { return strUniDD; }
            set { strUniDD = value; }
        }
        public string SUniDDto
        {
            get { return strUniDDto; }
            set { strUniDDto = value; }
        }
        public string SUniDDadd
        {
            get { return strUniDDadd; }
            set { strUniDDadd = value; }
        }
        public string SUniTime
        {
            get { return strUniTime; }
            set { strUniTime = value; }
        }
        public string SUniMail
        {
            get { return strUniMail; }
            set { strUniMail = value; }
        }
        public string SUniWeb
        {
            get { return strUniWeb; }
            set { strUniWeb = value; }
        }
        public string SUniRemark
        {
            get { return strUniRemark; }
            set { strUniRemark = value; }
        }
        public string SColName
        {
            get { return strColName; }
            set { strColName = value; }
        }
        public string SColLoc
        {
            get { return strColLoc; }
            set { strColLoc = value; }
        }
        public string SColConPer
        {
            get { return strColConPer; }
            set { strColConPer = value; }
        }
        public string SColDesig
        {
            get { return strColDesig; }
            set { strColDesig = value; }
        }
        public string SColNo1
        {
            get { return strColNo1; }
            set { strColNo1 = value; }
        }
        public string SColNo2
        {
            get { return strColNo2; }
            set { strColNo2 = value; }
        }
        public string SColConPer1
        {
            get { return strColConPer1; }
            set { strColConPer1 = value; }
        }
        public string SColDesig1
        {
            get { return strColDesig1; }
            set { strColDesig1 = value; }
        }
        public string SColNo3
        {
            get { return strColNo3; }
            set { strColNo3 = value; }
        }
        public string SColNo4
        {
            get { return strColNo4; }
            set { strColNo4 = value; }
        }
        public string SColDD
        {
            get { return strColDD; }
            set { strColDD = value; }
        }
        public string SColDDto
        {
            get { return strColDDto; }
            set { strColDDto = value; }
        }
        public string SColDDadd
        {
            get { return strColDDadd; }
            set { strColDDadd = value; }
        }
        public string SColTime
        {
            get { return strColTime; }
            set { strColTime = value; }
        }
        public string SColMail
        {
            get { return strColMail; }
            set { strColMail = value; }
        }
        public string SColWeb
        {
            get { return strColWeb; }
            set { strColWeb = value; }
        }
        public string SColRemark
        {
            get { return strColRemark; }
            set { strColRemark = value; }
        }
        public string SUser
        {
            get { return strUser; }
            set { strUser = value; }
        }
        public string SMode
        {
            get { return strMode; }
            set { strMode = value; }
        }




        //For DD/Courrier Module


        public string SDDReq
        {
            get { return strDReqDate; }
            set { strDReqDate = value; }
        }
        public string SReqCaller
        {
            get { return strReqCaller; }
            set { strReqCaller = value; }
        }
        public string SDDate
        {
            get { return strDDate; }
            set { strDDate = value; }
        }
        public string SDNumber
        {
            get { return strDNumber; }
            set { strDNumber = value; }
        }
        public string SDAmount
        {
            get { return strDAmount; }
            set { strDAmount = value; }
        }
        public string SDSentTo
        {
            get { return strDSentTo; }
            set { strDSentTo = value; }
        }
        public string SDAdr
        {
            get { return strDAdr; }
            set { strDAdr = value; }
        }
        public string SDMadeAt
        {
            get { return strDMadeAt; }
            set { strDMadeAt = value; }
        }
        public string SCDate
        {
            get { return strCDate; }
            set { strCDate = value; }
        }
        public string SCPOD
        {
            get { return strCPOD; }
            set { strCPOD = value; }
        }
        public string SCSP
        {
            get { return strCCSP; }
            set { strCCSP = value; }
        }
        public string SCSentTo
        {
            get { return strCSentTo; }
            set { strCSentTo = value; }
        }
        public string SCStreet1
        {
            get { return strCStreet1; }
            set { strCStreet1 = value; }
        }
        public string SCStreet2
        {
            get { return strCStreet2; }
            set { strCStreet2 = value; }
        }
        public string SCState
        {
            get { return strCState; }
            set { strCState = value; }
        }
        public string SCCity
        {
            get { return strCCity; }
            set { strCCity = value; }
        }
        public string SCZip
        {
            get { return strCZip; }
            set { strCZip = value; }
        }
        public string SCContact
        {
            get { return strCContact; }
            set { strCContact = value; }
        }
        public string SAppName
        {
            get { return strSAppName; }
            set { strSAppName = value; }
        }

        /// <summary>
        /// For employment
        /// </summary>

        public string SOrganisation1
        {
            get { return strOrganisation1; }
            set { strOrganisation1 = value; }
        }

        public string SEmpDates1
        {
            get { return strEmpDates1; }
            set { strEmpDates1 = value; }
        }

        public string SDesig1
        {
            get { return strDesignation1; }
            set { strDesignation1 = value; }
        }

        public string SEmpID1
        {
            get { return strEmpID1; }
            set { strEmpID1 = value; }
        }

        public string Ssalary1
        {
            get { return strSalary1; }
            set { strSalary1 = value; }
        }

        public string SMGR1
        {
            get { return strMGR1; }
            set { strMGR1 = value; }
        }

        public string SLeaving1
        {
            get { return strLeaving1; }
            set { strLeaving1 = value; }
        }

        public string SExit1
        {
            get { return strExit1; }
            set { strExit1 = value; }
        }
        
        public string SIssue1
        {
            get { return strIssue1; }
            set { strIssue1 = value; }
        }

        public string SDiscip1
        {
            get { return strDisciplinary1; }
            set { strDisciplinary1 = value; }
        }

        public string SReHire1
        {
            get { return strReHire1; }
            set { strReHire1 = value; }
        }

        public string SBehaviour1
        {
            get { return strBehaviour1; }
            set { strBehaviour1 = value; }
        }

        //////////////////Employment2

        public string SOrganisation2
        {
            get { return strOrganisation2; }
            set { strOrganisation2 = value; }
        }

        public string SEmpDates2
        {
            get { return strEmpDates2; }
            set { strEmpDates2 = value; }
        }

        public string SDesig2
        {
            get { return strDesignation2; }
            set { strDesignation2 = value; }
        }

        public string SEmpID2
        {
            get { return strEmpID2; }
            set { strEmpID2 = value; }
        }

        public string Ssalary2
        {
            get { return strSalary2; }
            set { strSalary2 = value; }
        }

        public string SMGR2
        {
            get { return strMGR2; }
            set { strMGR2 = value; }
        }

        public string SLeaving2
        {
            get { return strLeaving2; }
            set { strLeaving2 = value; }
        }

        public string SExit2
        {
            get { return strExit2; }
            set { strExit2 = value; }
        }

        public string SIssue2
        {
            get { return strIssue2; }
            set { strIssue2 = value; }
        }

        public string SDiscip2
        {
            get { return strDisciplinary2; }
            set { strDisciplinary2 = value; }
        }

        public string SReHire2
        {
            get { return strReHire2; }
            set { strReHire2 = value; }
        }

        public string SBehaviour2
        {
            get { return strBehaviour2; }
            set { strBehaviour2 = value; }
        }

        // //// // / / ///////Employment3

        public string SOrganisation3
        {
            get { return strOrganisation3; }
            set { strOrganisation3 = value; }
        }

        public string SEmpDates3
        {
            get { return strEmpDates3; }
            set { strEmpDates3 = value; }
        }

        public string SDesig3
        {
            get { return strDesignation3; }
            set { strDesignation3 = value; }
        }

        public string SEmpID3
        {
            get { return strEmpID3; }
            set { strEmpID3 = value; }
        }

        public string Ssalary3
        {
            get { return strSalary3; }
            set { strSalary3 = value; }
        }

        public string SMGR3
        {
            get { return strMGR3; }
            set { strMGR3 = value; }
        }

        public string SLeaving3
        {
            get { return strLeaving3; }
            set { strLeaving3 = value; }
        }

        public string SExit3
        {
            get { return strExit3; }
            set { strExit3 = value; }
        }

        public string SIssue3
        {
            get { return strIssue3; }
            set { strIssue3 = value; }
        }

        public string SDiscip3
        {
            get { return strDisciplinary3; }
            set { strDisciplinary3 = value; }
        }

        public string SReHire3
        {
            get { return strReHire3; }
            set { strReHire3 = value; }
        }

        public string SBehaviour3
        {
            get { return strBehaviour3; }
            set { strBehaviour3 = value; }
        }

        ///  ////////// Employment4
        ///  


        public string SOrganisation4
        {
            get { return strOrganisation4; }
            set { strOrganisation4 = value; }
        }

        public string SEmpDates4
        {
            get { return strEmpDates4; }
            set { strEmpDates4 = value; }
        }

        public string SDesig4
        {
            get { return strDesignation4; }
            set { strDesignation4 = value; }
        }

        public string SEmpID4
        {
            get { return strEmpID4; }
            set { strEmpID4 = value; }
        }

        public string Ssalary4
        {
            get { return strSalary4; }
            set { strSalary4 = value; }
        }

        public string SMGR4
        {
            get { return strMGR4; }
            set { strMGR4 = value; }
        }

        public string SLeaving4
        {
            get { return strLeaving4; }
            set { strLeaving4 = value; }
        }

        public string SExit4
        {
            get { return strExit4; }
            set { strExit4 = value; }
        }

        public string SIssue4
        {
            get { return strIssue4; }
            set { strIssue4 = value; }
        }

        public string SDiscip4
        {
            get { return strDisciplinary4; }
            set { strDisciplinary4 = value; }
        }

        public string SReHire4
        {
            get { return strReHire4; }
            set { strReHire4 = value; }
        }

        public string SBehaviour4
        {
            get { return strBehaviour4; }
            set { strBehaviour4 = value; }
        }

        public string SOrganisation5
        {
            get { return strOrganisation5; }
            set { strOrganisation5 = value; }
        }

        public string SEmpDates5
        {
            get { return strEmpDates5; }
            set { strEmpDates5 = value; }
        }

        public string SDesig5
        {
            get { return strDesignation5; }
            set { strDesignation5 = value; }
        }

        public string SEmpID5
        {
            get { return strEmpID5; }
            set { strEmpID5 = value; }
        }

        public string Ssalary5
        {
            get { return strSalary5; }
            set { strSalary5 = value; }
        }

        public string SMGR5
        {
            get { return strMGR5; }
            set { strMGR5 = value; }
        }

        public string SLeaving5
        {
            get { return strLeaving5; }
            set { strLeaving5 = value; }
        }

        public string SExit5
        {
            get { return strExit5; }
            set { strExit5 = value; }
        }

        public string SIssue5
        {
            get { return strIssue5; }
            set { strIssue5 = value; }
        }

        public string SDiscip5
        {
            get { return strDisciplinary5; }
            set { strDisciplinary5 = value; }
        }

        public string SReHire5
        {
            get { return strReHire5; }
            set { strReHire5 = value; }
        }

        public string SBehaviour5
        {
            get { return strBehaviour5; }
            set { strBehaviour5 = value; }
        }

        public string SOrganisation6
        {
            get { return strOrganisation6; }
            set { strOrganisation6 = value; }
        }

        public string SEmpDates6
        {
            get { return strEmpDates6; }
            set { strEmpDates6 = value; }
        }

        public string SDesig6
        {
            get { return strDesignation6; }
            set { strDesignation6 = value; }
        }

        public string SEmpID6
        {
            get { return strEmpID6; }
            set { strEmpID6 = value; }
        }

        public string Ssalary6
        {
            get { return strSalary6; }
            set { strSalary6 = value; }
        }

        public string SMGR6
        {
            get { return strMGR6; }
            set { strMGR6 = value; }
        }

        public string SLeaving6
        {
            get { return strLeaving6; }
            set { strLeaving6 = value; }
        }

        public string SExit6
        {
            get { return strExit6; }
            set { strExit6 = value; }
        }

        public string SIssue6
        {
            get { return strIssue6; }
            set { strIssue6 = value; }
        }

        public string SDiscip6
        {
            get { return strDisciplinary6; }
            set { strDisciplinary6 = value; }
        }

        public string SReHire6
        {
            get { return strReHire6; }
            set { strReHire6 = value; }
        }

        public string SBehaviour6
        {
            get { return strBehaviour6; }
            set { strBehaviour6 = value; }
        }


        public string SOrganisation7
        {
            get { return strOrganisation7; }
            set { strOrganisation7 = value; }
        }

        public string SEmpDates7
        {
            get { return strEmpDates7; }
            set { strEmpDates7 = value; }
        }

        public string SDesig7
        {
            get { return strDesignation7; }
            set { strDesignation7 = value; }
        }

        public string SEmpID7
        {
            get { return strEmpID7; }
            set { strEmpID7 = value; }
        }

        public string Ssalary7
        {
            get { return strSalary7; }
            set { strSalary7 = value; }
        }

        public string SMGR7
        {
            get { return strMGR7; }
            set { strMGR7 = value; }
        }

        public string SLeaving7
        {
            get { return strLeaving7; }
            set { strLeaving7 = value; }
        }

        public string SExit7
        {
            get { return strExit7; }
            set { strExit7 = value; }
        }

        public string SIssue7
        {
            get { return strIssue7; }
            set { strIssue7 = value; }
        }

        public string SDiscip7
        {
            get { return strDisciplinary7; }
            set { strDisciplinary7 = value; }
        }

        public string SReHire7
        {
            get { return strReHire7; }
            set { strReHire7 = value; }
        }

        public string SBehaviour7
        {
            get { return strBehaviour7; }
            set { strBehaviour7 = value; }
        }


        public string SOrganisation8
        {
            get { return strOrganisation8; }
            set { strOrganisation8 = value; }
        }

        public string SEmpDates8
        {
            get { return strEmpDates8; }
            set { strEmpDates8 = value; }
        }

        public string SDesig8
        {
            get { return strDesignation8; }
            set { strDesignation8 = value; }
        }

        public string SEmpID8
        {
            get { return strEmpID8; }
            set { strEmpID8 = value; }
        }

        public string Ssalary8
        {
            get { return strSalary8; }
            set { strSalary8 = value; }
        }

        public string SMGR8
        {
            get { return strMGR8; }
            set { strMGR8 = value; }
        }

        public string SLeaving8
        {
            get { return strLeaving8; }
            set { strLeaving8 = value; }
        }

        public string SExit8
        {
            get { return strExit8; }
            set { strExit8 = value; }
        }

        public string SIssue8
        {
            get { return strIssue8; }
            set { strIssue8 = value; }
        }

        public string SDiscip8
        {
            get { return strDisciplinary8; }
            set { strDisciplinary8 = value; }
        }

        public string SReHire8
        {
            get { return strReHire8; }
            set { strReHire8 = value; }
        }

        public string SBehaviour8
        {
            get { return strBehaviour8; }
            set { strBehaviour8 = value; }
        }

        public string SOrganisationR1
        {
            get { return strOrganisationR1; }
            set { strOrganisationR1 = value; }
        }

        public string SRefName1
        {
            get { return strRefName1; }
            set { strRefName1 = value; }
        }

        public string SDesgnationR1
        {
            get { return strDesignationR1; }
            set { strDesignationR1 = value; }
        }

        public string SContact1
        {
            get { return strContact1; }
            set { strContact1 = value; }
        }

        public string SMail1
        {
            get { return strMail1; }
            set { strMail1 = value; }
        }

        public string SOrganisationR2
        {
            get { return strOrganisationR2; }
            set { strOrganisationR2 = value; }
        }

        public string SRefName2
        {
            get { return strRefName2; }
            set { strRefName2 = value; }
        }

        public string SDesgnationR2
        {
            get { return strDesignationR2; }
            set { strDesignationR2 = value; }
        }

        public string SContact2
        {
            get { return strContact2; }
            set { strContact2 = value; }
        }

        public string SMail2
        {
            get { return strMail2; }
            set { strMail2 = value; }
        }

        public string SOrganisationR3
        {
            get { return strOrganisationR3; }
            set { strOrganisationR3 = value; }
        }

        public string SRefName3
        {
            get { return strRefName3; }
            set { strRefName3 = value; }
        }

        public string SDesgnationR3
        {
            get { return strDesignationR3; }
            set { strDesignationR3 = value; }
        }

        public string SContact3
        {
            get { return strContact3; }
            set { strContact3 = value; }
        }

        public string SMail3
        {
            get { return strMail3; }
            set { strMail3 = value; }
        }


        /// <summary>
        /// New Requirement of Operation
        /// </summary>
        /// 

        public string SCategory
        {
            get { return strCategory; }
            set { strCategory = value; }
        }

        public string SsubCategory
        {
            get { return strSubCategory; }
            set { strSubCategory = value; }
        }


        public string SAddDateFrm1
        {
            get { return strAddDateFrm1; }
            set { strAddDateFrm1 = value; }
        }

        public string SAddDateFrm2
        {
            get { return strAddDateFrm2; }
            set { strAddDateFrm2 = value; }
        }

        public string SAddDateFrm3
        {
            get { return strAddDateFrm3; }
            set { strAddDateFrm3 = value; }
        }
        public string SAddDateFrm4
        {
            get { return strAddDateFrm4; }
            set { strAddDateFrm4 = value; }
        }
        public string SAddDateFrm5
        {
            get { return strAddDateFrm5; }
            set { strAddDateFrm5 = value; }
        }
        public string SAddDateFrm6
        {
            get { return strAddDateFrm6; }
            set { strAddDateFrm6 = value; }
        }
        public string SAddDateFrm7
        {
            get { return strAddDateFrm7; }
            set { strAddDateFrm7 = value; }
        }
        public string SAddDateFrm8
        {
            get { return strAddDateFrm8; }
            set { strAddDateFrm8 = value; }
        }

        public string SCriDateFrm1
        {
            get { return strCriDateFrm1; }
            set { strCriDateFrm1 = value; }
        }

        public string SCriDateFrm2
        {
            get { return strCriDateFrm2; }
            set { strCriDateFrm2 = value; }
        }

        public string SCriDateFrm3
        {
            get { return strCriDateFrm3; }
            set { strCriDateFrm3 = value; }
        }
        public string SCriDateFrm4
        {
            get { return strCriDateFrm4; }
            set { strCriDateFrm4 = value; }
        }
        public string SCriDateFrm5
        {
            get { return strCriDateFrm5; }
            set { strCriDateFrm5 = value; }
        }
        public string SCriDateFrm6
        {
            get { return strCriDateFrm6; }
            set { strCriDateFrm6 = value; }
        }
        public string SCriDateFrm7
        {
            get { return strCriDateFrm7; }
            set { strCriDateFrm7 = value; }
        }
        public string SCriDateFrm8
        {
            get { return strCriDateFrm8; }
            set { strCriDateFrm8 = value; }
        }

        public string SEduDateFrm1
        {
            get { return strEduDateFrm1; }
            set { strEduDateFrm1 = value; }
        }

        public string SEduDateFrm2
        {
            get { return strEduDateFrm2; }
            set { strEduDateFrm2 = value; }
        }

        public string SEduDateFrm3
        {
            get { return strEduDateFrm3; }
            set { strEduDateFrm3 = value; }
        }
        public string SEduDateFrm4
        {
            get { return strEduDateFrm4; }
            set { strEduDateFrm4 = value; }
        }
        public string SEduDateFrm5
        {
            get { return strEduDateFrm5; }
            set { strEduDateFrm5 = value; }
        }
        public string SEduDateFrm6
        {
            get { return strEduDateFrm6; }
            set { strEduDateFrm6 = value; }
        }
        public string SEduDateFrm7
        {
            get { return strEduDateFrm7; }
            set { strEduDateFrm7 = value; }
        }
        public string SEduDateFrm8
        {
            get { return strEduDateFrm8; }
            set { strEduDateFrm8 = value; }
        }

        public string SAddDateTo1
        {
            get { return strAddDateTo1; }
            set { strAddDateTo1 = value; }
        }

        public string SAddDateTo2
        {
            get { return strAddDateTo2; }
            set { strAddDateTo2 = value; }
        }

        public string SAddDateTo3
        {
            get { return strAddDateTo3; }
            set { strAddDateTo3 = value; }
        }

        public string SAddDateTo4
        {
            get { return strAddDateTo4; }
            set { strAddDateTo4 = value; }
        }

        public string SAddDateTo5
        {
            get { return strAddDateTo5; }
            set { strAddDateTo5 = value; }
        }

        public string SAddDateTo6
        {
            get { return strAddDateTo6; }
            set { strAddDateTo6 = value; }
        }

        public string SAddDateTo7
        {
            get { return strAddDateTo7; }
            set { strAddDateTo7 = value; }
        }

        public string SAddDateTo8
        {
            get { return strAddDateTo8; }
            set { strAddDateTo8 = value; }
        }

        public string SCriDateTo1
        {
            get { return strCriDateTo1; }
            set { strCriDateTo1 = value; }
        }

        public string SCriDateTo2
        {
            get { return strCriDateTo2; }
            set { strCriDateTo2 = value; }
        }

        public string SCriDateTo3
        {
            get { return strCriDateTo3; }
            set { strCriDateTo3 = value; }
        }

        public string SCriDateTo4
        {
            get { return strCriDateTo4; }
            set { strCriDateTo4 = value; }
        }

        public string SCriDateTo5
        {
            get { return strCriDateTo5; }
            set { strCriDateTo5 = value; }
        }

        public string SCriDateTo6
        {
            get { return strCriDateTo6; }
            set { strCriDateTo6 = value; }
        }

        public string SCriDateTo7
        {
            get { return strCriDateTo7; }
            set { strCriDateTo7 = value; }
        }

        public string SCriDateTo8
        {
            get { return strCriDateTo8; }
            set { strCriDateTo8 = value; }
        }

         public string SEduDateTo1
        {
            get { return strEduDateTo1; }
            set { strEduDateTo1 = value; }
        }

        public string SEduDateTo2
        {
            get { return strEduDateTo2; }
            set { strEduDateTo2 = value; }
        }

        public string SEduDateTo3
        {
            get { return strEduDateTo3; }
            set { strEduDateTo3 = value; }
        }

        public string SEduDateTo4
        {
            get { return strEduDateTo4; }
            set { strEduDateTo4 = value; }
        }

        public string SEduDateTo5
        {
            get { return strEduDateTo5; }
            set { strEduDateTo5 = value; }
        }

        public string SEduDateTo6
        {
            get { return strEduDateTo6; }
            set { strEduDateTo6 = value; }
        }

        public string SEduDateTo7
        {
            get { return strEduDateTo7; }
            set { strEduDateTo7 = value; }
        }

        public string SEduDateTo8
        {
            get { return strEduDateTo8; }
            set { strEduDateTo8 = value; }
        }


        public string SAddStatus1
        {
            get { return strAddStatus1; }
            set { strAddStatus1 = value; }
        }
        public string SAddStatus2
        {
            get { return strAddStatus2; }
            set { strAddStatus2 = value; }
        }
        public string SAddStatus3
        {
            get { return strAddStatus3; }
            set { strAddStatus3 = value; }
        }
        public string SAddStatus4
        {
            get { return strAddStatus4; }
            set { strAddStatus4 = value; }
        }
        public string SAddStatus5
        {
            get { return strAddStatus5; }
            set { strAddStatus5 = value; }
        }
        public string SAddStatus6
        {
            get { return strAddStatus6; }
            set { strAddStatus6 = value; }
        }
        public string SAddStatus7
        {
            get { return strAddStatus7; }
            set { strAddStatus7 = value; }
        }
        public string SAddStatus8
        {
            get { return strAddStatus8; }
            set { strAddStatus8 = value; }
        }
        public string SAddRemark1
        {
            get { return strAddRemarks1; }
            set { strAddRemarks1 = value; }
        }
        public string SAddRemark2
        {
            get { return strAddRemarks2; }
            set { strAddRemarks2 = value; }
        }
        public string SAddRemark3
        {
            get { return strAddRemarks3; }
            set { strAddRemarks3 = value; }
        }
        public string SAddRemark4
        {
            get { return strAddRemarks4; }
            set { strAddRemarks4 = value; }
        }
        public string SAddRemark5
        {
            get { return strAddRemarks5; }
            set { strAddRemarks5 = value; }
        }
        public string SAddRemark6
        {
            get { return strAddRemarks6; }
            set { strAddRemarks6 = value; }
        }
        public string SAddRemark7
        {
            get { return strAddRemarks7; }
            set { strAddRemarks7 = value; }
        }
        public string SAddRemark8
        {
            get { return strAddRemarks8; }
            set { strAddRemarks8 = value; }
        }

        public string SCriStatus1
        {
            get { return strCriStatus1; }
            set { strCriStatus1 = value; }
        }
        public string SCriStatus2
        {
            get { return strCriStatus2; }
            set { strCriStatus2 = value; }
        }
        public string SCriStatus3
        {
            get { return strCriStatus3; }
            set { strCriStatus3 = value; }
        }
        public string SCriStatus4
        {
            get { return strCriStatus4; }
            set { strCriStatus4 = value; }
        }
        public string SCriStatus5
        {
            get { return strCriStatus5; }
            set { strCriStatus5 = value; }
        }
        public string SCriStatus6
        {
            get { return strCriStatus6; }
            set { strCriStatus6 = value; }
        }
        public string SCriStatus7
        {
            get { return strCriStatus7; }
            set { strCriStatus7 = value; }
        }
        public string SCriStatus8
        {
            get { return strCriStatus8; }
            set { strCriStatus8 = value; }
        }
        public string SCriRemark1
        {
            get { return strCriRemarks1; }
            set { strCriRemarks1 = value; }
        }
        public string SCriRemark2
        {
            get { return strCriRemarks2; }
            set { strCriRemarks2 = value; }
        }
        public string SCriRemark3
        {
            get { return strCriRemarks3; }
            set { strCriRemarks3 = value; }
        }
        public string SCriRemark4
        {
            get { return strCriRemarks4; }
            set { strCriRemarks4 = value; }
        }
        public string SCriRemark5
        {
            get { return strCriRemarks5; }
            set { strCriRemarks5 = value; }
        }
        public string SCriRemark6
        {
            get { return strCriRemarks6; }
            set { strCriRemarks6 = value; }
        }
        public string SCriRemark7
        {
            get { return strCriRemarks7; }
            set { strCriRemarks7 = value; }
        }
        public string SCriRemark8
        {
            get { return strCriRemarks8; }
            set { strCriRemarks8 = value; }
        }

        public string SEduStatus1
        {
            get { return strEduStatus1; }
            set { strEduStatus1 = value; }
        }
        public string SEduStatus2
        {
            get { return strEduStatus2; }
            set { strEduStatus2 = value; }
        }
        public string SEduStatus3
        {
            get { return strEduStatus3; }
            set { strEduStatus3 = value; }
        }
        public string SEduStatus4
        {
            get { return strEduStatus4; }
            set { strEduStatus4 = value; }
        }
        public string SEduStatus5
        {
            get { return strEduStatus5; }
            set { strEduStatus5 = value; }
        }
        public string SEduStatus6
        {
            get { return strEduStatus6; }
            set { strEduStatus6 = value; }
        }
        public string SEduStatus7
        {
            get { return strEduStatus7; }
            set { strEduStatus7 = value; }
        }
        public string SEduStatus8
        {
            get { return strEduStatus8; }
            set { strEduStatus8 = value; }
        }
        public string SEduRemark1
        {
            get { return strEduRemarks1; }
            set { strEduRemarks1 = value; }
        }
        public string SEduRemark2
        {
            get { return strEduRemarks2; }
            set { strEduRemarks2 = value; }
        }
        public string SEduRemark3
        {
            get { return strEduRemarks3; }
            set { strEduRemarks3 = value; }
        }
        public string SEduRemark4
        {
            get { return strEduRemarks4; }
            set { strEduRemarks4 = value; }
        }
        public string SEduRemark5
        {
            get { return strEduRemarks5; }
            set { strEduRemarks5 = value; }
        }
        public string SEduRemark6
        {
            get { return strEduRemarks6; }
            set { strEduRemarks6 = value; }
        }
        public string SEduRemark7
        {
            get { return strEduRemarks7; }
            set { strEduRemarks7 = value; }
        }
        public string SEduRemark8
        {
            get { return strEduRemarks8; }
            set { strEduRemarks8 = value; }
        }

        public string SEmpStatus1
        {
            get { return strEmpStatus1; }
            set { strEmpStatus1 = value; }
        }
        public string SEmpStatus2
        {
            get { return strEmpStatus2; }
            set { strEmpStatus2 = value; }
        }
        public string SEmpStatus3
        {
            get { return strEmpStatus3; }
            set { strEmpStatus3 = value; }
        }
        public string SEmpStatus4
        {
            get { return strEmpStatus4; }
            set { strEmpStatus4 = value; }
        }
        public string SEmpStatus5
        {
            get { return strEmpStatus5; }
            set { strEmpStatus5 = value; }
        }
        public string SEmpStatus6
        {
            get { return strEmpStatus6; }
            set { strEmpStatus6 = value; }
        }
        public string SEmpStatus7
        {
            get { return strEmpStatus7; }
            set { strEmpStatus7 = value; }
        }
        public string SEmpStatus8
        {
            get { return strEmpStatus8; }
            set { strEmpStatus8 = value; }
        }
        public string SEmpRemark1
        {
            get { return strEmpRemarks1; }
            set { strEmpRemarks1 = value; }
        }
        public string SEmpRemark2
        {
            get { return strEmpRemarks2; }
            set { strEmpRemarks2 = value; }
        }
        public string SEmpRemark3
        {
            get { return strEmpRemarks3; }
            set { strEmpRemarks3 = value; }
        }
        public string SEmpRemark4
        {
            get { return strEmpRemarks4; }
            set { strEmpRemarks4 = value; }
        }
        public string SEmpRemark5
        {
            get { return strEmpRemarks5; }
            set { strEmpRemarks5 = value; }
        }
        public string SEmpRemark6
        {
            get { return strEmpRemarks6; }
            set { strEmpRemarks6 = value; }
        }
        public string SEmpRemark7
        {
            get { return strEmpRemarks7; }
            set { strEmpRemarks7 = value; }
        }
        public string SEmpRemark8
        {
            get { return strEmpRemarks8; }
            set { strEmpRemarks8 = value; }
        }

        public string SRefStatus1
        {
            get { return strRefStatus1; }
            set { strRefStatus1 = value; }
        }
        public string SRefStatus2
        {
            get { return strRefStatus2; }
            set { strRefStatus2 = value; }
        }
        public string SRefStatus3
        {
            get { return strRefStatus3; }
            set { strRefStatus3 = value; }
        }


        public string SRefRemark1
        {
            get { return strRefRemarks1; }
            set { strRefRemarks1 = value; }
        }
        public string SRefRemark2
        {
            get { return strRefRemarks2; }
            set { strRefRemarks2 = value; }
        }
        public string SRefRemark3
        {
            get { return strRefRemarks3; }
            set { strRefRemarks3 = value; }
        }

        public string SDBStatus
        {
            get { return strDBStatus; }
            set { strDBStatus = value; }
        }


        public string SDBRemark1
        {
            get { return strDBRemarks; }
            set { strDBRemarks = value; }
        }
        public string SDrugStatus1
        {
            get { return strDrugStatus; }
            set { strDrugStatus = value; }
        }


        public string SDrugRemark
        {
            get { return strDrugRemarks; }
            set { strDrugRemarks = value; }
        }
      

        public string SIDStatus1
        {
            get { return strIDStatus1; }
            set { strIDStatus1 = value; }
        }
        public string SIDStatus2
        {
            get { return strIDStatus2; }
            set { strIDStatus2 = value; }
        }
        public string SIDStatus3
        {
            get { return strIDStatus3; }
            set { strIDStatus3 = value; }
        }
        public string SIDStatus4
        {
            get { return strIDStatus4; }
            set { strIDStatus4 = value; }
        }

        public string SIDRemark1
        {
            get { return strIDRemarks1; }
            set { strIDRemarks1 = value; }
        }
        public string SIDRemark2
        {
            get { return strIDRemarks2; }
            set { strIDRemarks2 = value; }
        }
        public string SIDRemark3
        {
            get { return strIDRemarks3; }
            set { strIDRemarks3 = value; }
        }
        public string SIDRemark4
        {
            get { return strIDRemarks4; }
            set { strIDRemarks4 = value; }
        }

        public string STATStartDate
        {
            get { return strTATStartDate; }
            set { strTATStartDate = value; }
        }

        public string key
        {
            get
            {
                return strkey;
            }
            set
            {
                strkey = value;
            }
        }

        public string SCourtCheck
        {
            get
            {
                return strCourtCheck;
            }
            set
            {
                strCourtCheck = value;
            }
        }
        public string SCourtAdd
        {
            get
            {
                return strCourtAddress;
            }
            set
            {
                strCourtAddress = value;
            }
        }
        public string SCourtAddLoc
        {
            get
            {
                return strCourtAddLoc;
            }
            set
            {
                strCourtAddLoc = value;
            }
        }
        public string SCourtAddState
        {
            get
            {
                return strCourtAddState;
            }
            set
            {
                strCourtAddState = value;
            }
        }
        public string SCourtStatus
        {
            get
            {
                return strCourtAddStatus;
            }
            set
            {
                strCourtAddStatus = value;
            }
        }
        public string SCourtRemarks
        {
            get
            {
                return strCourtAddRemarks;
            }
            set
            {
                strCourtAddRemarks = value;
            }
        }

       
        public DataSet Login(string Username, string Password)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "spLogin",
                         SQLDataAccess.CreateParameter("@UserName", SqlDbType.VarChar, Username, ParameterDirection.Input, 100, false),
                         SQLDataAccess.CreateParameter("@Password", SqlDbType.VarChar, Password, ParameterDirection.Input, 100, false)
                );
            return dsServiceType;
        }

        public DataSet SelectData(int EmployeeID)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SelectAllData",
                  SQLDataAccess.CreateParameter("@EmployeeID", SqlDbType.Int, EmployeeID, ParameterDirection.Input, 4, false)


                );
            return dsServiceType;
        }

        public DataSet SelectKPMGData(int EmployeeID)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SelectKPMGData",
                  SQLDataAccess.CreateParameter("@EmployeeID", SqlDbType.Int, EmployeeID, ParameterDirection.Input, 4, false)


                );
            return dsServiceType;
        }

        public DataSet SelectWIPROEduData(int EmployeeID)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SelectWIPROEduData",
                  SQLDataAccess.CreateParameter("@EmployeeID", SqlDbType.Int, EmployeeID, ParameterDirection.Input, 4, false)


                );
            return dsServiceType;
        }

        public DataSet SelectWIPROCityData(int EmployeeID)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SelectWIPROCityData",
                  SQLDataAccess.CreateParameter("@EmployeeID", SqlDbType.Int, EmployeeID, ParameterDirection.Input, 4, false)


                );
            return dsServiceType;
        }


        public DataSet SelectCountryCityInfo(EmployeeInfo objEmployeeInfo)
        {
            DataSet ds = new DataSet();
            SqlParameter[] paramsToStore = new SqlParameter[1];

            paramsToStore[0] = new SqlParameter("@Mode", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.Mode;
            paramsToStore[0].Size = 20;

            ds = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "FillAllDDLfillGrid", paramsToStore);
            return ds;
        }
        public DataSet selectcurrentid(string fname, string dob)
        {
            DataSet curr_id;
            curr_id = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "getcurr_id",
                  SQLDataAccess.CreateParameter("@firstname", SqlDbType.VarChar, fname, ParameterDirection.Input, 20, false),
                     SQLDataAccess.CreateParameter("@dob", SqlDbType.VarChar, dob, ParameterDirection.Input, 30, false)


                );
            return curr_id;
        }

        public DataSet SelectDataBand4plus()
        {
            DataSet band4plus;
            band4plus = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "spCOEband4plus");
            return band4plus;
        }
        public DataSet SelectDataBand5()
        {
            DataSet band5;
            band5 = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "spCOEband5");
            return band5;
        }




        public void ShowMessage(System.Web.UI.Page aspxPage, string str, string strKey)
        {
            string strScript = "<script>alert('" + str + "');</script>";

            if (!aspxPage.IsStartupScriptRegistered(strKey))
            {
                aspxPage.RegisterStartupScript(strKey, strScript);
            }
        }

        public int saveEmployeeInfo(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[557];
            // 213+173



            paramsToStore[0] = new SqlParameter("@CurrentAddress", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.CurrentAddress;
            paramsToStore[0].Size = 500;

            paramsToStore[1] = new SqlParameter("@EmpHis1_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.EmpHis1_CompnayNameandLocation;
            paramsToStore[1].Size = 150;

            paramsToStore[2] = new SqlParameter("@EmpHis2_EmployeeCode", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.EmpHis2_EmployeeCode;
            paramsToStore[2].Size = 50;

            paramsToStore[3] = new SqlParameter("@EmpHis1RLvl2_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.EmpHis1RLvl2_TelepnoneNo;
            paramsToStore[3].Size = 50;

            paramsToStore[4] = new SqlParameter("@EmpHis2RLvl2_MobileNo", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.EmpHis2RLvl2_MobileNo;
            paramsToStore[4].Size = 50;

            paramsToStore[5] = new SqlParameter("@Per_LivingSince", SqlDbType.VarChar);
            paramsToStore[5].Value = objEmployeeInfo.Per_LivingSince;
            paramsToStore[5].Size = 100;

            paramsToStore[6] = new SqlParameter("@EmpHis1_EmployeeCode", SqlDbType.VarChar);
            paramsToStore[6].Value = objEmployeeInfo.EmpHis1_EmployeeCode;
            paramsToStore[6].Size = 50;

            paramsToStore[7] = new SqlParameter("@TAT2Date", SqlDbType.VarChar);
            paramsToStore[7].Value = objEmployeeInfo.TAT2;
            paramsToStore[7].Size = 50;

            paramsToStore[8] = new SqlParameter("@EmpHis2RLvl1_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[8].Value = objEmployeeInfo.EmpHis2RLvl1_TelepnoneNo;
            paramsToStore[8].Size = 50;

            paramsToStore[9] = new SqlParameter("@Edu1_Address", SqlDbType.VarChar);
            paramsToStore[9].Value = objEmployeeInfo.Edu1_Address;
            paramsToStore[9].Size = 500;

            paramsToStore[10] = new SqlParameter("@DateofJoining", SqlDbType.VarChar);
            paramsToStore[10].Value = objEmployeeInfo.DateofJoining;
            paramsToStore[10].Size = 50;

            paramsToStore[11] = new SqlParameter("@EmpHis1_TelephoneNo", SqlDbType.VarChar);
            paramsToStore[11].Value = objEmployeeInfo.EmpHis1_TelephoneNo;
            paramsToStore[11].Size = 50;

            paramsToStore[12] = new SqlParameter("@EmpHis2RLvl2_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[12].Value = objEmployeeInfo.EmpHis2RLvl2_TelepnoneNo;
            paramsToStore[12].Size = 50;

            paramsToStore[13] = new SqlParameter("@EmpHis2_IncaseOfGap", SqlDbType.VarChar);
            paramsToStore[13].Value = objEmployeeInfo.EmpHis2_IncaseOfGap;
            paramsToStore[13].Size = 50;

            paramsToStore[14] = new SqlParameter("@EmpHis2RLvl1_EmailId", SqlDbType.VarChar);
            paramsToStore[14].Value = objEmployeeInfo.EmpHis2RLvl1_EmailId;
            paramsToStore[14].Size = 150;

            paramsToStore[15] = new SqlParameter("@Edu1_UniversityName", SqlDbType.VarChar);
            paramsToStore[15].Value = objEmployeeInfo.Edu1_UniversityName;
            paramsToStore[15].Size = 150;

            paramsToStore[16] = new SqlParameter("@Per_Landmark", SqlDbType.VarChar);
            paramsToStore[16].Value = objEmployeeInfo.Per_Landmark;
            paramsToStore[16].Size = 50;

            paramsToStore[17] = new SqlParameter("@EmpHis2_AgencyDetails", SqlDbType.VarChar);
            paramsToStore[17].Value = objEmployeeInfo.EmpHis2_AgencyDetails;
            paramsToStore[17].Size = 50;

            paramsToStore[18] = new SqlParameter("@EmpHis1_referenceYN", SqlDbType.VarChar);
            paramsToStore[18].Value = objEmployeeInfo.EmpHis1_referenceYN;
            paramsToStore[18].Size = 50;

            paramsToStore[19] = new SqlParameter("@Per_PostOffice", SqlDbType.VarChar);
            paramsToStore[19].Value = objEmployeeInfo.Per_PostOffice;
            paramsToStore[19].Size = 50;

            paramsToStore[20] = new SqlParameter("@FatherName", SqlDbType.VarChar);
            paramsToStore[20].Value = objEmployeeInfo.FatherName;
            paramsToStore[20].Size = 150;

            paramsToStore[21] = new SqlParameter("@EmpHis1_LastPositionHeldnDepartmentName", SqlDbType.VarChar);
            paramsToStore[21].Value = objEmployeeInfo.EmpHis1_LastPositionHeldnDepartmentName;
            paramsToStore[21].Size = 150;

            paramsToStore[22] = new SqlParameter("@EmpHis2_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[22].Value = objEmployeeInfo.EmpHis2_CompnayNameandLocation;
            paramsToStore[22].Size = 150;

            paramsToStore[23] = new SqlParameter("@EmpHis1_PeriodofEmployment", SqlDbType.VarChar);
            paramsToStore[23].Value = objEmployeeInfo.EmpHis1_PeriodofEmployment;
            paramsToStore[23].Size = 50;

            paramsToStore[24] = new SqlParameter("@DOB", SqlDbType.VarChar);
            paramsToStore[24].Value = objEmployeeInfo.DOB;
            paramsToStore[24].Size = 50;

            paramsToStore[25] = new SqlParameter("@EmpHis2_referenceYN", SqlDbType.VarChar);
            paramsToStore[25].Value = objEmployeeInfo.EmpHis2_referenceYN;
            paramsToStore[25].Size = 50;

            paramsToStore[26] = new SqlParameter("@Edu1_RollNo", SqlDbType.VarChar);
            paramsToStore[26].Value = objEmployeeInfo.Edu1_RollNo;
            paramsToStore[26].Size = 50;

            paramsToStore[27] = new SqlParameter("@EmpHis1RLvl1_MobileNo", SqlDbType.VarChar);
            paramsToStore[27].Value = objEmployeeInfo.EmpHis1RLvl1_MobileNo;
            paramsToStore[27].Size = 50;

            paramsToStore[28] = new SqlParameter("@EmpHis1_TempPerma", SqlDbType.VarChar);
            paramsToStore[28].Value = objEmployeeInfo.EmpHis1_TempPerma;
            paramsToStore[28].Size = 50;

            paramsToStore[29] = new SqlParameter("@EmpHis2_Address", SqlDbType.VarChar);
            paramsToStore[29].Value = objEmployeeInfo.EmpHis2_Address;
            paramsToStore[29].Size = 500;

            paramsToStore[30] = new SqlParameter("@EmpHis1_PeriodofEmploymentRemark", SqlDbType.VarChar);
            paramsToStore[30].Value = objEmployeeInfo.EmpHis1_PeriodofEmploymentRemark;
            paramsToStore[30].Size = 50;

            paramsToStore[31] = new SqlParameter("@EmpHis1_IncaseOfGap", SqlDbType.VarChar);
            paramsToStore[31].Value = objEmployeeInfo.EmpHis1_IncaseOfGap;
            paramsToStore[31].Size = 50;

            paramsToStore[32] = new SqlParameter("@EmpHis2_TempPerma", SqlDbType.VarChar);
            paramsToStore[32].Value = objEmployeeInfo.EmpHis2_TempPerma;
            paramsToStore[32].Size = 50;

            paramsToStore[33] = new SqlParameter("@EmpHis1RLvl2_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[33].Value = objEmployeeInfo.EmpHis1RLvl2_NameDesignatinOfSupervisor;
            paramsToStore[33].Size = 150;

            paramsToStore[34] = new SqlParameter("@EmpHis2RLvl1_MobileNo", SqlDbType.VarChar);
            paramsToStore[34].Value = objEmployeeInfo.EmpHis2RLvl1_MobileNo;
            paramsToStore[34].Size = 50;

            paramsToStore[35] = new SqlParameter("@MiddleName", SqlDbType.VarChar);
            paramsToStore[35].Value = objEmployeeInfo.MiddleName;
            paramsToStore[35].Size = 50;

            paramsToStore[36] = new SqlParameter("@Edu1_CollegeName", SqlDbType.VarChar);
            paramsToStore[36].Value = objEmployeeInfo.Edu1_CollegeName;
            paramsToStore[36].Size = 250;

            paramsToStore[37] = new SqlParameter("@EmpHis2RLvl2_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[37].Value = objEmployeeInfo.EmpHis2RLvl2_NameDesignatinOfSupervisor;
            paramsToStore[37].Size = 50;

            paramsToStore[38] = new SqlParameter("@EmpHis1_AgencyDetails", SqlDbType.VarChar);
            paramsToStore[38].Value = objEmployeeInfo.EmpHis1_AgencyDetails;
            paramsToStore[38].Size = 50;

            paramsToStore[39] = new SqlParameter("@EmpHis2RLvl1_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[39].Value = objEmployeeInfo.EmpHis2RLvl1_NameDesignatinOfSupervisor;
            paramsToStore[39].Size = 150;

            paramsToStore[40] = new SqlParameter("@FirstName", SqlDbType.VarChar);
            paramsToStore[40].Value = objEmployeeInfo.FirstName;
            paramsToStore[40].Size = 150;

            paramsToStore[41] = new SqlParameter("@Per_AddressPhoneNo", SqlDbType.VarChar);
            paramsToStore[41].Value = objEmployeeInfo.Per_AddressPhoneNo;
            paramsToStore[41].Size = 50;

            paramsToStore[42] = new SqlParameter("@EmpHis2_PeriodofEmployment", SqlDbType.VarChar);
            paramsToStore[42].Value = objEmployeeInfo.EmpHis2_PeriodofEmployment;
            paramsToStore[42].Size = 50;

            paramsToStore[43] = new SqlParameter("@EmpHis2RLvl2_EmailId", SqlDbType.VarChar);
            paramsToStore[43].Value = objEmployeeInfo.EmpHis2RLvl2_EmailId;
            paramsToStore[43].Size = 50;

            paramsToStore[44] = new SqlParameter("@COE", SqlDbType.VarChar);
            paramsToStore[44].Value = objEmployeeInfo.COE;
            paramsToStore[44].Size = 50;

            paramsToStore[45] = new SqlParameter("@Mobile", SqlDbType.VarChar);
            paramsToStore[45].Value = objEmployeeInfo.Mobile;
            paramsToStore[45].Size = 50;

            paramsToStore[46] = new SqlParameter("@Per_City", SqlDbType.VarChar);
            paramsToStore[46].Value = objEmployeeInfo.Per_City;
            paramsToStore[46].Size = 50;

            paramsToStore[47] = new SqlParameter("@Curr_PhoneNo", SqlDbType.VarChar);
            paramsToStore[47].Value = objEmployeeInfo.Curr_PhoneNo;
            paramsToStore[47].Size = 50;

            paramsToStore[48] = new SqlParameter("@EmpHis2_LastPositionHeldnDepartmentName", SqlDbType.VarChar);
            paramsToStore[48].Value = objEmployeeInfo.EmpHis2_LastPositionHeldnDepartmentName;
            paramsToStore[48].Size = 150;

            paramsToStore[49] = new SqlParameter("@EmpHis1_Address", SqlDbType.VarChar);
            paramsToStore[49].Value = objEmployeeInfo.EmpHis1_Address;
            paramsToStore[49].Size = 500;

            paramsToStore[50] = new SqlParameter("@Edu1_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[50].Value = objEmployeeInfo.Edu1_EducationalQualification;
            paramsToStore[50].Size = 100;

            paramsToStore[51] = new SqlParameter("@EmpHis1RLvl1_EmailId", SqlDbType.VarChar);
            paramsToStore[51].Value = objEmployeeInfo.EmpHis1RLvl1_EmailId;
            paramsToStore[51].Size = 150;

            paramsToStore[52] = new SqlParameter("@InDate", SqlDbType.VarChar);
            paramsToStore[52].Value = objEmployeeInfo.InDate;
            paramsToStore[52].Size = 50;

            paramsToStore[53] = new SqlParameter("@Per_PoliceStation", SqlDbType.VarChar);
            paramsToStore[53].Value = objEmployeeInfo.Per_PoliceStation;
            paramsToStore[53].Size = 50;

            paramsToStore[54] = new SqlParameter("@EmpHis2_TelephoneNo", SqlDbType.VarChar);
            paramsToStore[54].Value = objEmployeeInfo.EmpHis2_TelephoneNo;
            paramsToStore[54].Size = 50;

            paramsToStore[55] = new SqlParameter("@EmpHis1_ReasonOfLeaving", SqlDbType.VarChar);
            paramsToStore[55].Value = objEmployeeInfo.EmpHis1_ReasonOfLeaving;
            paramsToStore[55].Size = 50;

            paramsToStore[56] = new SqlParameter("@EmpHis1_RemunerationOrSalary", SqlDbType.VarChar);
            paramsToStore[56].Value = objEmployeeInfo.EmpHis1_RemunerationOrSalary;
            paramsToStore[56].Size = 50;

            paramsToStore[57] = new SqlParameter("@EnteredByLoginIdType", SqlDbType.VarChar);
            paramsToStore[57].Value = objEmployeeInfo.EnteredByLoginIdType;
            paramsToStore[57].Size = 50;

            paramsToStore[58] = new SqlParameter("@Band", SqlDbType.VarChar);
            paramsToStore[58].Value = objEmployeeInfo.Band;
            paramsToStore[58].Size = 50;

            paramsToStore[59] = new SqlParameter("@EmpHis2_ReasonOfLeaving", SqlDbType.VarChar);
            paramsToStore[59].Value = objEmployeeInfo.EmpHis2_ReasonOfLeaving;
            paramsToStore[59].Size = 50;

            paramsToStore[60] = new SqlParameter("@Per_State", SqlDbType.VarChar);
            paramsToStore[60].Value = objEmployeeInfo.Per_State;
            paramsToStore[60].Size = 50;

            paramsToStore[61] = new SqlParameter("@EmpIdProvidedByClient", SqlDbType.VarChar);
            paramsToStore[61].Value = objEmployeeInfo.EmpIdProvidedByClient;
            paramsToStore[61].Size = 50;

            paramsToStore[62] = new SqlParameter("@PlaceofBirth", SqlDbType.VarChar);
            paramsToStore[62].Value = objEmployeeInfo.PlaceofBirth;
            paramsToStore[62].Size = 150;

            paramsToStore[63] = new SqlParameter("@Surname", SqlDbType.VarChar);
            paramsToStore[63].Value = objEmployeeInfo.Surname;
            paramsToStore[63].Size = 50;

            paramsToStore[64] = new SqlParameter("@ExperienceInYears", SqlDbType.VarChar);
            paramsToStore[64].Value = objEmployeeInfo.ExperienceInYears;
            paramsToStore[64].Size = 50;

            paramsToStore[65] = new SqlParameter("@PermanentAddress", SqlDbType.VarChar);
            paramsToStore[65].Value = objEmployeeInfo.PermanentAddress;
            paramsToStore[65].Size = 500;

            paramsToStore[66] = new SqlParameter("@Curr_City", SqlDbType.VarChar);
            paramsToStore[66].Value = objEmployeeInfo.Curr_City;
            paramsToStore[66].Size = 50;

            paramsToStore[67] = new SqlParameter("@EmpHis2_RemunerationOrSalary", SqlDbType.VarChar);
            paramsToStore[67].Value = objEmployeeInfo.EmpHis2_RemunerationOrSalary;
            paramsToStore[67].Size = 50;

            //paramsToStore[68] = new SqlParameter("@EmployeeID", SqlDbType.VarChar);
            //paramsToStore[68].Value = objEmployeeInfo.EmployeeID;
            //paramsToStore[68].Size = 50;

            paramsToStore[68] = new SqlParameter("@Curr_State", SqlDbType.VarChar);
            paramsToStore[68].Value = objEmployeeInfo.Curr_State;
            paramsToStore[68].Size = 50;

            paramsToStore[69] = new SqlParameter("@EmpHis1RLvl1_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[69].Value = objEmployeeInfo.EmpHis1RLvl1_TelepnoneNo;
            paramsToStore[69].Size = 50;

            paramsToStore[70] = new SqlParameter("@EmpHis1RLvl2_EmailId", SqlDbType.VarChar);
            paramsToStore[70].Value = objEmployeeInfo.EmpHis1RLvl2_EmailId;
            paramsToStore[70].Size = 50;

            //paramsToStore[72] = new SqlParameter("@EmpHis2_PeriodofEmploymentRemark", SqlDbType.VarChar);
            //paramsToStore[72].Value = objEmployeeInfo.EmpHis2_PeriodofEmploymentRemark;
            //paramsToStore[72].Size = 50;

            paramsToStore[71] = new SqlParameter("@EmpHis2_PeriodofEmploymentRemark", SqlDbType.VarChar);
            paramsToStore[71].Value = objEmployeeInfo.EmpHis2_PeriodofEmploymentRemark;
            paramsToStore[71].Size = 50;

            paramsToStore[72] = new SqlParameter("@EmpHis1RLvl1_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[72].Value = objEmployeeInfo.EmpHis1RLvl1_NameDesignatinOfSupervisor;
            paramsToStore[72].Size = 150;

            paramsToStore[73] = new SqlParameter("@Edu1_YearOfPassing", SqlDbType.VarChar);
            paramsToStore[73].Value = objEmployeeInfo.Edu1_YearOfPassing;
            paramsToStore[73].Size = 50;

            paramsToStore[74] = new SqlParameter("@Mode", SqlDbType.VarChar);

            paramsToStore[74].Value = objEmployeeInfo.Mode;
            paramsToStore[74].Size = 20;

            paramsToStore[75] = new SqlParameter("@EmployeeID", SqlDbType.VarChar);
            paramsToStore[75].Value = objEmployeeInfo.EmployeeID;
            paramsToStore[75].Size = 20;
            //private int strEmployeeId;
            //private string CaseStatus;
            //private string AllocatedStatus;
            //private string AddressStatus;
            //private string AddressRemarks;
            //private string EducationStatus;
            //private string EducationRemarks;
            //private string EmploymentStatus;
            //private string EmploymentRemarks;
            //private string CriminalStatus;
            //private string CriminalRemarks;
            //private string ReferenceStatus;

            //private string ReferenceRemarks;
            //private string DrugtestStatus;
            //private string DrugtestRemarks;

            paramsToStore[76] = new SqlParameter("@CaseStatus", SqlDbType.VarChar);
            paramsToStore[76].Value = objEmployeeInfo.CaseStatus;
            paramsToStore[76].Size = 20;

            paramsToStore[77] = new SqlParameter("@AllocatedStatus", SqlDbType.VarChar);
            paramsToStore[77].Value = objEmployeeInfo.AllocatedStatus;
            paramsToStore[77].Size = 20;



            paramsToStore[78] = new SqlParameter("@datetoemphis1", SqlDbType.VarChar);
            paramsToStore[78].Value = objEmployeeInfo.datetoemphis1;
            paramsToStore[78].Size = 20;

            paramsToStore[79] = new SqlParameter("@datetoemphis2", SqlDbType.VarChar);
            paramsToStore[79].Value = objEmployeeInfo.datetoemphis2;
            paramsToStore[79].Size = 20;

            paramsToStore[80] = new SqlParameter("@ReportingLevel2emp1", SqlDbType.VarChar);
            paramsToStore[80].Value = objEmployeeInfo.ReportingLevel2emp1;

            paramsToStore[81] = new SqlParameter("@ReportingLevel2emp2", SqlDbType.VarChar);
            paramsToStore[81].Value = objEmployeeInfo.ReportingLevel2emp2;


            paramsToStore[82] = new SqlParameter("@EmploymentType", SqlDbType.VarChar);
            paramsToStore[82].Value = objEmployeeInfo.employmentType;


            paramsToStore[83] = new SqlParameter("@RejectedRemarks", SqlDbType.VarChar);
            paramsToStore[83].Value = objEmployeeInfo.RejectedRemarks;

            paramsToStore[84] = new SqlParameter("@ClientName", SqlDbType.VarChar);
            paramsToStore[84].Value = objEmployeeInfo.ClientName;
            //new fields

            paramsToStore[85] = new SqlParameter("@EmpHis3_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[85].Value = objEmployeeInfo.EmpHis3_CompnayNameandLocation;
            paramsToStore[85].Size = 50;

            paramsToStore[86] = new SqlParameter("@EmpHis3_LastPositionHeldnDepartmentName", SqlDbType.VarChar);
            paramsToStore[86].Value = objEmployeeInfo.EmpHis3_LastPositionHeldnDepartmentName;
            paramsToStore[86].Size = 50;

            paramsToStore[87] = new SqlParameter("@EmpHis3_Address", SqlDbType.VarChar);
            paramsToStore[87].Value = objEmployeeInfo.EmpHis3_Address;
            paramsToStore[87].Size = 500;

            paramsToStore[88] = new SqlParameter("@EmpHis3_EmployeeCode", SqlDbType.VarChar);
            paramsToStore[88].Value = objEmployeeInfo.EmpHis3_EmployeeCode;
            paramsToStore[88].Size = 50;

            paramsToStore[89] = new SqlParameter("@EmpHis3_PeriodofEmployment", SqlDbType.VarChar);
            paramsToStore[89].Value = objEmployeeInfo.EmpHis3_PeriodofEmployment;
            paramsToStore[89].Size = 50;

            paramsToStore[90] = new SqlParameter("@datetoempHis3", SqlDbType.VarChar);
            paramsToStore[90].Value = objEmployeeInfo.datetoempHis3;
            paramsToStore[90].Size = 50;

            paramsToStore[91] = new SqlParameter("@EmpHis3_PeriodofEmploymentRemark", SqlDbType.VarChar);
            paramsToStore[91].Value = objEmployeeInfo.EmpHis3_PeriodofEmploymentRemark;
            paramsToStore[91].Size = 50;

            paramsToStore[92] = new SqlParameter("@EmpHis3RLvl1_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[92].Value = objEmployeeInfo.EmpHis3RLvl1_NameDesignatinOfSupervisor;
            paramsToStore[92].Size = 50;

            paramsToStore[93] = new SqlParameter("@EmpHis3RLvl1_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[93].Value = objEmployeeInfo.EmpHis3RLvl1_TelepnoneNo;
            paramsToStore[93].Size = 50;


            paramsToStore[94] = new SqlParameter("@EmpHis3RLvl1_MobileNo", SqlDbType.VarChar);
            paramsToStore[94].Value = objEmployeeInfo.EmpHis3RLvl1_MobileNo;
            paramsToStore[94].Size = 50;

            paramsToStore[95] = new SqlParameter("@EmpHis3RLvl1_EmailId", SqlDbType.VarChar);
            paramsToStore[95].Value = objEmployeeInfo.EmpHis3RLvl1_EmailId;
            paramsToStore[95].Size = 50;

            paramsToStore[96] = new SqlParameter("@EmpHis3RLvl2_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[96].Value = objEmployeeInfo.EmpHis3RLvl2_NameDesignatinOfSupervisor;
            paramsToStore[96].Size = 50;

            paramsToStore[97] = new SqlParameter("@EmpHis3RLvl2_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[97].Value = objEmployeeInfo.EmpHis3RLvl2_TelepnoneNo;
            paramsToStore[97].Size = 50;

            paramsToStore[98] = new SqlParameter("@EmpHis3RLvl2_MobileNo", SqlDbType.VarChar);
            paramsToStore[98].Value = objEmployeeInfo.EmpHis3RLvl2_MobileNo;
            paramsToStore[98].Size = 50;

            paramsToStore[99] = new SqlParameter("@EmpHis3RLvl2_EmailId", SqlDbType.VarChar);
            paramsToStore[99].Value = objEmployeeInfo.EmpHis3RLvl2_EmailId;
            paramsToStore[99].Size = 50;

            paramsToStore[100] = new SqlParameter("@EmpHis3_TempPerma", SqlDbType.VarChar);
            paramsToStore[100].Value = objEmployeeInfo.EmpHis3_TempPerma;
            paramsToStore[100].Size = 50;

            paramsToStore[101] = new SqlParameter("@EmpHis3_AgencyDetails", SqlDbType.VarChar);
            paramsToStore[101].Value = objEmployeeInfo.EmpHis3_AgencyDetails;
            paramsToStore[101].Size = 50;

            paramsToStore[102] = new SqlParameter("@EmpHis3_RemunerationOrSalary", SqlDbType.VarChar);
            paramsToStore[102].Value = objEmployeeInfo.EmpHis3_RemunerationOrSalary;
            paramsToStore[102].Size = 50;

            paramsToStore[103] = new SqlParameter("@EmpHis3_ReasonOfLeaving", SqlDbType.VarChar);
            paramsToStore[103].Value = objEmployeeInfo.EmpHis3_ReasonOfLeaving;
            paramsToStore[103].Size = 50;

            paramsToStore[104] = new SqlParameter("@EmpHis3_referenceYN", SqlDbType.VarChar);
            paramsToStore[104].Value = objEmployeeInfo.EmpHis3_referenceYN;
            paramsToStore[104].Size = 50;

            paramsToStore[105] = new SqlParameter("@EmpHis3_IncaseOfGap", SqlDbType.VarChar);
            paramsToStore[105].Value = objEmployeeInfo.EmpHis3_IncaseOfGap;
            paramsToStore[105].Size = 50;


            paramsToStore[106] = new SqlParameter("@ExperienceInYears3", SqlDbType.VarChar);
            paramsToStore[106].Value = objEmployeeInfo.ExperienceInYears3;
            paramsToStore[106].Size = 50;


            paramsToStore[107] = new SqlParameter("@ReportingLevel2emp3", SqlDbType.VarChar);
            paramsToStore[107].Value = objEmployeeInfo.ReportingLevel2emp3;
            paramsToStore[107].Size = 50;


            //Company 4
            paramsToStore[108] = new SqlParameter("@EmpHis4_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[108].Value = objEmployeeInfo.EmpHis4_CompnayNameandLocation;
            paramsToStore[108].Size = 50;

            paramsToStore[109] = new SqlParameter("@EmpHis4_LastPositionHeldnDepartmentName", SqlDbType.VarChar);
            paramsToStore[109].Value = objEmployeeInfo.EmpHis4_LastPositionHeldnDepartmentName;
            paramsToStore[109].Size = 50;

            paramsToStore[110] = new SqlParameter("@EmpHis4_Address", SqlDbType.VarChar);
            paramsToStore[110].Value = objEmployeeInfo.EmpHis4_Address;
            paramsToStore[110].Size = 500;

            paramsToStore[111] = new SqlParameter("@EmpHis4_EmployeeCode", SqlDbType.VarChar);
            paramsToStore[111].Value = objEmployeeInfo.EmpHis4_EmployeeCode;
            paramsToStore[111].Size = 50;

            paramsToStore[112] = new SqlParameter("@EmpHis4_PeriodofEmployment", SqlDbType.VarChar);
            paramsToStore[112].Value = objEmployeeInfo.EmpHis4_PeriodofEmployment;
            paramsToStore[112].Size = 50;

            paramsToStore[113] = new SqlParameter("@datetoempHis4", SqlDbType.VarChar);
            paramsToStore[113].Value = objEmployeeInfo.datetoempHis4;
            paramsToStore[113].Size = 50;

            paramsToStore[114] = new SqlParameter("@EmpHis4_PeriodofEmploymentRemark", SqlDbType.VarChar);
            paramsToStore[114].Value = objEmployeeInfo.EmpHis4_PeriodofEmploymentRemark;
            paramsToStore[114].Size = 50;

            paramsToStore[115] = new SqlParameter("@EmpHis4RLvl1_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[115].Value = objEmployeeInfo.EmpHis4RLvl1_NameDesignatinOfSupervisor;
            paramsToStore[115].Size = 50;

            paramsToStore[116] = new SqlParameter("@EmpHis4RLvl1_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[116].Value = objEmployeeInfo.EmpHis4RLvl1_TelepnoneNo;
            paramsToStore[116].Size = 50;


            paramsToStore[117] = new SqlParameter("@EmpHis4RLvl1_MobileNo", SqlDbType.VarChar);
            paramsToStore[117].Value = objEmployeeInfo.EmpHis4RLvl1_MobileNo;
            paramsToStore[117].Size = 50;

            paramsToStore[118] = new SqlParameter("@EmpHis4RLvl1_EmailId", SqlDbType.VarChar);
            paramsToStore[118].Value = objEmployeeInfo.EmpHis4RLvl1_EmailId;
            paramsToStore[118].Size = 50;

            paramsToStore[119] = new SqlParameter("@EmpHis4RLvl2_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[119].Value = objEmployeeInfo.EmpHis4RLvl2_NameDesignatinOfSupervisor;
            paramsToStore[119].Size = 50;

            paramsToStore[120] = new SqlParameter("@EmpHis4RLvl2_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[120].Value = objEmployeeInfo.EmpHis4RLvl2_TelepnoneNo;
            paramsToStore[120].Size = 50;

            paramsToStore[121] = new SqlParameter("@EmpHis4RLvl2_MobileNo", SqlDbType.VarChar);
            paramsToStore[121].Value = objEmployeeInfo.EmpHis4RLvl2_MobileNo;
            paramsToStore[121].Size = 50;

            paramsToStore[122] = new SqlParameter("@EmpHis4RLvl2_EmailId", SqlDbType.VarChar);
            paramsToStore[122].Value = objEmployeeInfo.EmpHis4RLvl2_EmailId;
            paramsToStore[122].Size = 50;

            paramsToStore[123] = new SqlParameter("@EmpHis4_TempPerma", SqlDbType.VarChar);
            paramsToStore[123].Value = objEmployeeInfo.EmpHis4_TempPerma;
            paramsToStore[123].Size = 50;

            paramsToStore[124] = new SqlParameter("@EmpHis4_AgencyDetails", SqlDbType.VarChar);
            paramsToStore[124].Value = objEmployeeInfo.EmpHis4_AgencyDetails;
            paramsToStore[124].Size = 50;

            paramsToStore[125] = new SqlParameter("@EmpHis4_RemunerationOrSalary", SqlDbType.VarChar);
            paramsToStore[125].Value = objEmployeeInfo.EmpHis4_RemunerationOrSalary;
            paramsToStore[125].Size = 50;

            paramsToStore[126] = new SqlParameter("@EmpHis4_ReasonOfLeaving", SqlDbType.VarChar);
            paramsToStore[126].Value = objEmployeeInfo.EmpHis4_ReasonOfLeaving;
            paramsToStore[126].Size = 50;

            paramsToStore[127] = new SqlParameter("@EmpHis4_referenceYN", SqlDbType.VarChar);
            paramsToStore[127].Value = objEmployeeInfo.EmpHis4_referenceYN;
            paramsToStore[127].Size = 50;

            paramsToStore[128] = new SqlParameter("@EmpHis4_IncaseOfGap", SqlDbType.VarChar);
            paramsToStore[128].Value = objEmployeeInfo.EmpHis4_IncaseOfGap;
            paramsToStore[128].Size = 50;


            paramsToStore[129] = new SqlParameter("@ExperienceInYears4", SqlDbType.VarChar);
            paramsToStore[129].Value = objEmployeeInfo.ExperienceInYears4;
            paramsToStore[129].Size = 50;


            paramsToStore[130] = new SqlParameter("@ReportingLevel2emp4", SqlDbType.VarChar);
            paramsToStore[130].Value = objEmployeeInfo.ReportingLevel2emp4;
            paramsToStore[130].Size = 50;

            //Company 5

            paramsToStore[131] = new SqlParameter("@EmpHis5_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[131].Value = objEmployeeInfo.EmpHis5_CompnayNameandLocation;
            paramsToStore[131].Size = 50;

            paramsToStore[132] = new SqlParameter("@EmpHis5_LastPositionHeldnDepartmentName", SqlDbType.VarChar);
            paramsToStore[132].Value = objEmployeeInfo.EmpHis5_LastPositionHeldnDepartmentName;
            paramsToStore[132].Size = 50;

            paramsToStore[133] = new SqlParameter("@EmpHis5_Address", SqlDbType.VarChar);
            paramsToStore[133].Value = objEmployeeInfo.EmpHis5_Address;
            paramsToStore[133].Size = 500;

            paramsToStore[134] = new SqlParameter("@EmpHis5_EmployeeCode", SqlDbType.VarChar);
            paramsToStore[134].Value = objEmployeeInfo.EmpHis5_EmployeeCode;
            paramsToStore[134].Size = 50;

            paramsToStore[135] = new SqlParameter("@EmpHis5_PeriodofEmployment", SqlDbType.VarChar);
            paramsToStore[135].Value = objEmployeeInfo.EmpHis5_PeriodofEmployment;
            paramsToStore[135].Size = 50;

            paramsToStore[136] = new SqlParameter("@datetoempHis5", SqlDbType.VarChar);
            paramsToStore[136].Value = objEmployeeInfo.datetoempHis5;
            paramsToStore[136].Size = 50;

            paramsToStore[137] = new SqlParameter("@EmpHis5_PeriodofEmploymentRemark", SqlDbType.VarChar);
            paramsToStore[137].Value = objEmployeeInfo.EmpHis5_PeriodofEmploymentRemark;
            paramsToStore[137].Size = 50;

            paramsToStore[138] = new SqlParameter("@EmpHis5RLvl1_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[138].Value = objEmployeeInfo.EmpHis5RLvl1_NameDesignatinOfSupervisor;
            paramsToStore[138].Size = 50;

            paramsToStore[139] = new SqlParameter("@EmpHis5RLvl1_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[139].Value = objEmployeeInfo.EmpHis5RLvl1_TelepnoneNo;
            paramsToStore[139].Size = 50;


            paramsToStore[140] = new SqlParameter("@EmpHis5RLvl1_MobileNo", SqlDbType.VarChar);
            paramsToStore[140].Value = objEmployeeInfo.EmpHis5RLvl1_MobileNo;
            paramsToStore[140].Size = 50;

            paramsToStore[141] = new SqlParameter("@EmpHis5RLvl1_EmailId", SqlDbType.VarChar);
            paramsToStore[141].Value = objEmployeeInfo.EmpHis5RLvl1_EmailId;
            paramsToStore[141].Size = 50;

            paramsToStore[142] = new SqlParameter("@EmpHis5RLvl2_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[142].Value = objEmployeeInfo.EmpHis5RLvl2_NameDesignatinOfSupervisor;
            paramsToStore[142].Size = 50;

            paramsToStore[143] = new SqlParameter("@EmpHis5RLvl2_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[143].Value = objEmployeeInfo.EmpHis5RLvl2_TelepnoneNo;
            paramsToStore[143].Size = 50;

            paramsToStore[144] = new SqlParameter("@EmpHis5RLvl2_MobileNo", SqlDbType.VarChar);
            paramsToStore[144].Value = objEmployeeInfo.EmpHis5RLvl2_MobileNo;
            paramsToStore[144].Size = 50;

            paramsToStore[145] = new SqlParameter("@EmpHis5RLvl2_EmailId", SqlDbType.VarChar);
            paramsToStore[145].Value = objEmployeeInfo.EmpHis5RLvl2_EmailId;
            paramsToStore[145].Size = 50;

            paramsToStore[146] = new SqlParameter("@EmpHis5_TempPerma", SqlDbType.VarChar);
            paramsToStore[146].Value = objEmployeeInfo.EmpHis5_TempPerma;
            paramsToStore[146].Size = 50;

            paramsToStore[147] = new SqlParameter("@EmpHis5_AgencyDetails", SqlDbType.VarChar);
            paramsToStore[147].Value = objEmployeeInfo.EmpHis5_AgencyDetails;
            paramsToStore[147].Size = 50;

            paramsToStore[148] = new SqlParameter("@EmpHis5_RemunerationOrSalary", SqlDbType.VarChar);
            paramsToStore[148].Value = objEmployeeInfo.EmpHis5_RemunerationOrSalary;
            paramsToStore[148].Size = 50;

            paramsToStore[149] = new SqlParameter("@EmpHis5_ReasonOfLeaving", SqlDbType.VarChar);
            paramsToStore[149].Value = objEmployeeInfo.EmpHis5_ReasonOfLeaving;
            paramsToStore[149].Size = 50;

            paramsToStore[150] = new SqlParameter("@EmpHis5_referenceYN", SqlDbType.VarChar);
            paramsToStore[150].Value = objEmployeeInfo.EmpHis5_referenceYN;
            paramsToStore[150].Size = 50;

            paramsToStore[151] = new SqlParameter("@EmpHis5_IncaseOfGap", SqlDbType.VarChar);
            paramsToStore[151].Value = objEmployeeInfo.EmpHis5_IncaseOfGap;
            paramsToStore[151].Size = 50;


            paramsToStore[152] = new SqlParameter("@ExperienceInYears5", SqlDbType.VarChar);
            paramsToStore[152].Value = objEmployeeInfo.ExperienceInYears5;
            paramsToStore[152].Size = 50;


            paramsToStore[153] = new SqlParameter("@ReportingLevel2emp5", SqlDbType.VarChar);
            paramsToStore[153].Value = objEmployeeInfo.ReportingLevel2emp5;
            paramsToStore[153].Size = 50;

            paramsToStore[154] = new SqlParameter("@ExperienceInYears2", SqlDbType.VarChar);
            paramsToStore[154].Value = objEmployeeInfo.ExperienceInYears2;
            paramsToStore[154].Size = 50;


            paramsToStore[155] = new SqlParameter("@FresherOrExp", SqlDbType.VarChar);
            paramsToStore[155].Value = objEmployeeInfo.FresherOrExp;
            paramsToStore[155].Size = 50;

            paramsToStore[156] = new SqlParameter("@NoOfComp", SqlDbType.VarChar);
            paramsToStore[156].Value = objEmployeeInfo.NoOfComp;
            paramsToStore[156].Size = 50;

            paramsToStore[157] = new SqlParameter("@Edu2_CollegeName", SqlDbType.VarChar);
            paramsToStore[157].Value = objEmployeeInfo.Edu2_CollegeName;
            paramsToStore[157].Size = 250;

            paramsToStore[158] = new SqlParameter("@Edu2_UniversityName", SqlDbType.VarChar);
            paramsToStore[158].Value = objEmployeeInfo.Edu2_UniversityName;
            paramsToStore[158].Size = 150;

            paramsToStore[159] = new SqlParameter("@Edu2_Address", SqlDbType.VarChar);
            paramsToStore[159].Value = objEmployeeInfo.Edu2_Address;
            paramsToStore[159].Size = 500;

            paramsToStore[160] = new SqlParameter("@Edu2_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[160].Value = objEmployeeInfo.Edu2_EducationalQualification;
            paramsToStore[160].Size = 100;

            paramsToStore[161] = new SqlParameter("@Edu2_RollNo", SqlDbType.VarChar);
            paramsToStore[161].Value = objEmployeeInfo.Edu2_RollNo;
            paramsToStore[161].Size = 50;

            paramsToStore[162] = new SqlParameter("@YearOfPassing2", SqlDbType.VarChar);
            paramsToStore[162].Value = objEmployeeInfo.YearOfPassing2;
            paramsToStore[162].Size = 50;


            paramsToStore[163] = new SqlParameter("@Edu3_CollegeName", SqlDbType.VarChar);
            paramsToStore[163].Value = objEmployeeInfo.Edu3_CollegeName;
            paramsToStore[163].Size = 250;

            paramsToStore[164] = new SqlParameter("@Edu4_CollegeName", SqlDbType.VarChar);
            paramsToStore[164].Value = objEmployeeInfo.Edu4_CollegeName;
            paramsToStore[164].Size = 250;

            paramsToStore[165] = new SqlParameter("@Edu3_UniversityName", SqlDbType.VarChar);
            paramsToStore[165].Value = objEmployeeInfo.Edu3_UniversityName;
            paramsToStore[165].Size = 150;

            paramsToStore[166] = new SqlParameter("@Edu4_UniversityName", SqlDbType.VarChar);
            paramsToStore[166].Value = objEmployeeInfo.Edu4_UniversityName;
            paramsToStore[166].Size = 150;

            paramsToStore[167] = new SqlParameter("@Edu3_Address", SqlDbType.VarChar);
            paramsToStore[167].Value = objEmployeeInfo.Edu3_Address;
            paramsToStore[167].Size = 500;

            paramsToStore[168] = new SqlParameter("@Edu4_Address", SqlDbType.VarChar);
            paramsToStore[168].Value = objEmployeeInfo.Edu4_Address;
            paramsToStore[168].Size = 500;

            paramsToStore[169] = new SqlParameter("@Edu3_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[169].Value = objEmployeeInfo.Edu3_EducationalQualification;
            paramsToStore[169].Size = 100;

            paramsToStore[170] = new SqlParameter("@Edu4_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[170].Value = objEmployeeInfo.Edu4_EducationalQualification;
            paramsToStore[170].Size = 100;

            paramsToStore[171] = new SqlParameter("@Edu3_RollNo", SqlDbType.VarChar);
            paramsToStore[171].Value = objEmployeeInfo.Edu3_RollNo;
            paramsToStore[171].Size = 50;

            paramsToStore[172] = new SqlParameter("@Edu4_RollNo", SqlDbType.VarChar);
            paramsToStore[172].Value = objEmployeeInfo.Edu4_RollNo;
            paramsToStore[172].Size = 50;

            paramsToStore[173] = new SqlParameter("@YearOfPassing3", SqlDbType.VarChar);
            paramsToStore[173].Value = objEmployeeInfo.YearOfPassing3;
            paramsToStore[173].Size = 50;

            paramsToStore[174] = new SqlParameter("@YearOfPassing4", SqlDbType.VarChar);
            paramsToStore[174].Value = objEmployeeInfo.YearOfPassing4;
            paramsToStore[174].Size = 50;


            paramsToStore[175] = new SqlParameter("@EmpHis3_TelephoneNo", SqlDbType.VarChar);
            paramsToStore[175].Value = objEmployeeInfo.EmpHis3_TelephoneNo;
            paramsToStore[175].Size = 50;

            paramsToStore[176] = new SqlParameter("@EmpHis5_TelephoneNo", SqlDbType.VarChar);
            paramsToStore[176].Value = objEmployeeInfo.EmpHis5_TelephoneNo;
            paramsToStore[176].Size = 50;

            paramsToStore[177] = new SqlParameter("@EmpHis4_TelephoneNo", SqlDbType.VarChar);
            paramsToStore[177].Value = objEmployeeInfo.EmpHis4_TelephoneNo;
            paramsToStore[177].Size = 50;

            paramsToStore[178] = new SqlParameter("@EducationList", SqlDbType.VarChar);
            paramsToStore[178].Value = objEmployeeInfo.EducationList;
            paramsToStore[178].Size = 50;

            paramsToStore[179] = new SqlParameter("@UserName", SqlDbType.NVarChar);
            paramsToStore[179].Value = objEmployeeInfo.UserName;
            paramsToStore[179].Size = 300;


            paramsToStore[180] = new SqlParameter("@CaseSubmmissionDate", SqlDbType.VarChar);
            paramsToStore[180].Value = objEmployeeInfo.CaseSubmmissionDate;
            paramsToStore[180].Size = 300;



            paramsToStore[181] = new SqlParameter("@TATDate", SqlDbType.VarChar);
            paramsToStore[181].Value = objEmployeeInfo.TATDate;
            paramsToStore[181].Size = 50;

            //-----------------------------------------------------------------------------------------




            paramsToStore[182] = new SqlParameter("@txt_ResumeNo", SqlDbType.VarChar);
            paramsToStore[182].Value = objEmployeeInfo.txt_ResumeNo;
            paramsToStore[182].Size = 50;


            paramsToStore[183] = new SqlParameter("@txt_CaseReceivedBy", SqlDbType.VarChar);
            paramsToStore[183].Value = objEmployeeInfo.txt_CaseReceivedBy;
            paramsToStore[183].Size = 50;


            paramsToStore[184] = new SqlParameter("@txtPercentage", SqlDbType.VarChar);
            paramsToStore[184].Value = objEmployeeInfo.txtPercentage;
            paramsToStore[184].Size = 50;

            paramsToStore[185] = new SqlParameter("@txtEducation1State", SqlDbType.VarChar);
            paramsToStore[185].Value = objEmployeeInfo.txtEducation1State;
            paramsToStore[185].Size = 50;

            paramsToStore[186] = new SqlParameter("@txtEducation1City", SqlDbType.VarChar);
            paramsToStore[186].Value = objEmployeeInfo.txtEducation1City;
            paramsToStore[186].Size = 50;

            paramsToStore[187] = new SqlParameter("@txtEducation1PinCode", SqlDbType.VarChar);
            paramsToStore[187].Value = objEmployeeInfo.txtEducation1PinCode;
            paramsToStore[187].Size = 50;

            paramsToStore[188] = new SqlParameter("@txtEducation2State", SqlDbType.VarChar);
            paramsToStore[188].Value = objEmployeeInfo.txtEducation2State;
            paramsToStore[188].Size = 50;






            paramsToStore[189] = new SqlParameter("@txtEducation2City", SqlDbType.VarChar);
            paramsToStore[189].Value = objEmployeeInfo.txtEducation2City;
            paramsToStore[189].Size = 50;


            paramsToStore[190] = new SqlParameter("@txtEducation2PinCode", SqlDbType.VarChar);
            paramsToStore[190].Value = objEmployeeInfo.txtEducation2PinCode;
            paramsToStore[190].Size = 50;

            paramsToStore[191] = new SqlParameter("@txtEducation3State", SqlDbType.VarChar);
            paramsToStore[191].Value = objEmployeeInfo.txtEducation3State;
            paramsToStore[191].Size = 50;

            paramsToStore[192] = new SqlParameter("@txtEducation3City", SqlDbType.VarChar);
            paramsToStore[192].Value = objEmployeeInfo.txtEducation3City;
            paramsToStore[192].Size = 50;

            paramsToStore[193] = new SqlParameter("@txtEducation3PinCode", SqlDbType.VarChar);
            paramsToStore[193].Value = objEmployeeInfo.txtEducation3PinCode;
            paramsToStore[193].Size = 50;

            paramsToStore[194] = new SqlParameter("@txtEducation4State", SqlDbType.VarChar);
            paramsToStore[194].Value = objEmployeeInfo.txtEducation4State;
            paramsToStore[194].Size = 50;



            paramsToStore[195] = new SqlParameter("@txtEducation4City", SqlDbType.VarChar);
            paramsToStore[195].Value = objEmployeeInfo.txtEmployemenmt4City;
            paramsToStore[195].Size = 50;


            paramsToStore[196] = new SqlParameter("@txtEducation4PinCode", SqlDbType.VarChar);
            paramsToStore[196].Value = objEmployeeInfo.txtEducation4PinCode;
            paramsToStore[196].Size = 50;

            paramsToStore[197] = new SqlParameter("@txtEmployemenmt1State", SqlDbType.VarChar);
            paramsToStore[197].Value = objEmployeeInfo.txtEmployemenmt1State;
            paramsToStore[197].Size = 50;

            paramsToStore[198] = new SqlParameter("@txtEmployemenmt2State", SqlDbType.VarChar);
            paramsToStore[198].Value = objEmployeeInfo.txtEmployemenmt2State;
            paramsToStore[198].Size = 50;

            paramsToStore[199] = new SqlParameter("@txtEmployemenmt3State", SqlDbType.VarChar);
            paramsToStore[199].Value = objEmployeeInfo.txtEmployemenmt3State;
            paramsToStore[199].Size = 50;



            paramsToStore[200] = new SqlParameter("@txtEmployemenmt4State", SqlDbType.VarChar);
            paramsToStore[200].Value = objEmployeeInfo.txtEmployemenmt4State;
            paramsToStore[200].Size = 50;

            paramsToStore[201] = new SqlParameter("@txtEmployemenmt5State", SqlDbType.VarChar);
            paramsToStore[201].Value = objEmployeeInfo.txtEmployemenmt5State;
            paramsToStore[201].Size = 50;


            paramsToStore[202] = new SqlParameter("@txtEmployemenmt1City", SqlDbType.VarChar);
            paramsToStore[202].Value = objEmployeeInfo.txtEmployemenmt1City;
            paramsToStore[202].Size = 50;


            paramsToStore[203] = new SqlParameter("@txtEmployemenmt2City", SqlDbType.VarChar);
            paramsToStore[203].Value = objEmployeeInfo.txtEmployemenmt2City;
            paramsToStore[203].Size = 50;

            paramsToStore[204] = new SqlParameter("@txtEmployemenmt3City", SqlDbType.VarChar);
            paramsToStore[204].Value = objEmployeeInfo.txtEmployemenmt3City;
            paramsToStore[204].Size = 50;

            paramsToStore[205] = new SqlParameter("@txtEmployemenmt4City", SqlDbType.VarChar);
            paramsToStore[205].Value = objEmployeeInfo.txtEmployemenmt4City;
            paramsToStore[205].Size = 50;

            paramsToStore[206] = new SqlParameter("@txtEmployemenmt5City", SqlDbType.VarChar);
            paramsToStore[206].Value = objEmployeeInfo.txtEmployemenmt5City;
            paramsToStore[206].Size = 50;

            paramsToStore[207] = new SqlParameter("@txtEmployemenmt1PinCode", SqlDbType.VarChar);
            paramsToStore[207].Value = objEmployeeInfo.txtEmployemenmt1PinCode;
            paramsToStore[207].Size = 50;



            paramsToStore[208] = new SqlParameter("@txtEmployemenmt2PinCode", SqlDbType.VarChar);
            paramsToStore[208].Value = objEmployeeInfo.txtEmployemenmt2PinCode;
            paramsToStore[208].Size = 50;


            paramsToStore[209] = new SqlParameter("@txtEmployemenmt3PinCode", SqlDbType.VarChar);
            paramsToStore[209].Value = objEmployeeInfo.txtEmployemenmt3PinCode;
            paramsToStore[209].Size = 50;

            paramsToStore[210] = new SqlParameter("@txtEmployemenmt4PinCode", SqlDbType.VarChar);
            paramsToStore[210].Value = objEmployeeInfo.txtEmployemenmt4PinCode;
            paramsToStore[210].Size = 50;

            paramsToStore[211] = new SqlParameter("@txtEmployemenmt5PinCode", SqlDbType.VarChar);
            paramsToStore[211].Value = objEmployeeInfo.txtEmployemenmt5PinCode;
            paramsToStore[211].Size = 50;

            //---------------------------Start All Checks

            //[Address2City] [varchar](50) NULL,
            //[Address2State] [varchar](50) NULL,
            //[Address2PhoneNo1] [varchar](50) NULL,
            //[Address2PhoneNo2] [varchar](50) NULL,
            //[Address3CurrentAddress] [varchar](500) NULL,
            //[Address3City] [varchar](50) NULL,
            //[Address3State] [varchar](50) NULL,
            //[Address3PhoneNo1] [varchar](50) NULL,
            //[Address3PhoneNo2] [varchar](50) NULL,
            //[Address4CurrentAddress] [varchar](500) NULL,
            //[Address4City] [varchar](50) NULL,
            //[Address4State] [varchar](50) NULL,
            //[Address4PhoneNo1] [varchar](50) NULL,
            //[Address4PhoneNo2] [varchar](50) NULL,
            //[Address5CurrentAddress] [varchar](500) NULL,
            //[Address5City] [varchar](50) NULL,
            //[Address5State] [varchar](50) NULL,
            //[Address5PhoneNo1] [varchar](50) NULL,
            //[Address5PhoneNo2] [varchar](50) NULL,
            //[Address6CurrentAddress] [varchar](500) NULL,
            //[Address6City] [varchar](50) NULL,
            //[Address6State] [varchar](50) NULL,
            //[Address6PhoneNo1] [varchar](50) NULL,
            //[Address6PhoneNo2] [varchar](50) NULL,
            //[Address7CurrentAddress] [varchar](500) NULL,
            //[Address7City] [varchar](50) NULL,
            //[Address7State] [varchar](50) NULL,
            //[Address7PhoneNo1] [varchar](50) NULL,
            //[Address7PhoneNo2] [varchar](50) NULL,
            //[Criminal1Location] [varchar](50) NULL,
            //[Criminal2Location] [varchar](50) NULL,
            //[Criminal3Location] [varchar](50) NULL,
            //[Criminal4Location] [varchar](50) NULL,
            //[Criminal5Location] [varchar](50) NULL,
            //[Criminal6Location] [varchar](50) NULL,
            //[Criminal7Location] [varchar](50) NULL,
            //[Criminal8Location] [varchar](50) NULL,
            //[Education5CollegeName] [varchar](150) NULL,
            //[Education5CollegeAddress] [varchar](500) NULL,
            //[Education5UniversityName] [varchar](150) NULL,
            //[Education5UniversityAddress] [varchar](100) NULL,
            //[Education5EQ] [varchar](50) NULL,
            //[Education5YearofPassing] [varchar](50) NULL,
            //[Education5RollNo] [varchar](50) NULL,
            //[Education5joinfrom] [varchar](50) NULL,
            //[Education5jointo] [varchar](50) NULL,
            //[Education5State] [varchar](50) NULL,
            //[Education5City] [varchar](50) NULL,
            //[Education5PinCode] [varchar](50) NULL,
            //[Education6CollegeName] [varchar](150) NULL,
            //[Education6CollegeAddress] [varchar](500) NULL,
            //[Education6UniversityName] [varchar](150) NULL,
            //[Education6UniversityAddress] [varchar](100) NULL,
            //[Education6EQ] [varchar](50) NULL,
            //[Education6YearofPassing] [varchar](50) NULL,
            //[Education6RollNo] [varchar](50) NULL,
            //[Education6joinfrom] [varchar](50) NULL,
            //[Education6jointo] [varchar](50) NULL,
            //[Education6State] [varchar](50) NULL,
            //[Education6City] [varchar](50) NULL,
            //[Education6PinCode] [varchar](50) NULL,
            //[Education7CollegeName] [varchar](150) NULL,
            //[Education7CollegeAddress] [varchar](500) NULL,
            //[Education7UniversityName] [varchar](150) NULL,
            //[Education7UniversityAddress] [varchar](100) NULL,
            //[Education7EQ] [varchar](50) NULL,
            //[Education7YearofPassing] [varchar](50) NULL,
            //[Education7RollNo] [varchar](50) NULL,
            //[Education7joinfrom] [varchar](50) NULL,
            //[Education7jointo] [varchar](50) NULL,
            //[Education7State] [varchar](50) NULL,
            //[Education7City] [varchar](50) NULL,
            //[Education7PinCode] [varchar](50) NULL,
            //[Education8CollegeName] [varchar](150) NULL,
            //[Education8CollegeAddress] [nchar](500) NULL,
            //[Education8UniversityName] [varchar](150) NULL,
            //[Education8UniversityAddress] [varchar](50) NULL,
            //[Education8EQ] [varchar](50) NULL,
            //[Education8YearofPassing] [varchar](50) NULL,
            //[Education8RollNo] [varchar](50) NULL,
            //[Education8joinfrom] [varchar](50) NULL,
            //[Education8jointo] [varchar](50) NULL,
            //[Education8State] [varchar](50) NULL,
            //[Education8City] [varchar](50) NULL,
            //[Education8PinCode] [varchar](50) NULL,
            //[Employement6CompanyName] [varchar](150) NULL,
            //[Employement6CompanyLocation] [varchar](50) NULL,
            //[Employement6OfficeAddress] [varchar](150) NULL,
            //[Employement6Designation] [varchar](50) NULL,
            //[Employement6phone1] [varchar](50) NULL,
            //[Employement6phone2] [varchar](50) NULL,
            //[Employement6EmpCode] [varchar](50) NULL,
            //[Employement6DateFrom] [varchar](50) NULL,
            //[Employement6DateTo] [varchar](50) NULL,
            //[Employement6Salary] [varchar](50) NULL,
            //[Employement6State] [varchar](50) NULL,
            //[Employement6City] [varchar](50) NULL,
            //[Employement6PinCode] [varchar](50) NULL,
            //[Employement6Sdesig] [varchar](50) NULL,
            //[Employement6Semail] [varchar](50) NULL,
            //[Employement6Sphone1] [varchar](50) NULL,
            //[Emplyoement6Sphone2] [varchar](50) NULL,
            //[Employement6SMobile] [varchar](50) NULL,
            //[Employement6SResofliv] [varchar](50) NULL,
            //[Employement7CompanyName] [varchar](150) NULL,
            //[Employement7CompanyLocation] [varchar](50) NULL,
            //[Employement7OfficeAddress] [varchar](150) NULL,
            //[Employement7Designation] [varchar](50) NULL,
            //[Employement7phone1] [varchar](50) NULL,
            //[Employement7phone2] [varchar](50) NULL,
            //[Employement7EmpCode] [varchar](50) NULL,
            //[Employement7DateFrom] [varchar](50) NULL,
            //[Employement7DateTo] [varchar](50) NULL,
            //[Employement7Salary] [varchar](50) NULL,
            //[Employement7State] [varchar](50) NULL,
            //[Employement7City] [varchar](50) NULL,
            //[Employement7PinCode] [varchar](50) NULL,
            //[Emplyement7Sdesig] [varchar](50) NULL,
            //[Emplyement7Semail] [varchar](50) NULL,
            //[Emplyement7Sphone1] [varchar](50) NULL,
            //[Emplyement7Sphone2] [varchar](50) NULL,
            //[Emplyement7SMobile] [varchar](50) NULL,
            //[Emplyement7SResofliv] [varchar](50) NULL,
            //[Employement8CompanyName] [varchar](150) NULL,
            //[Employement8CompanyLocation] [varchar](50) NULL,
            //[Employement8OfficeAddress] [varchar](150) NULL,
            //[Employement8Designation] [varchar](50) NULL,
            //[Employement8phone1] [varchar](50) NULL,
            //[Employement8phone2] [varchar](50) NULL,
            //[Employement8EmpCode] [varchar](50) NULL,
            //[Employement8DateFrom] [varchar](50) NULL,
            //[Employement8DateTo] [varchar](50) NULL,
            //[Employement8Salary] [varchar](50) NULL,
            //[Employement8State] [varchar](50) NULL,
            //[Employement8City] [varchar](50) NULL,
            //[Employement8PinCode] [varchar](50) NULL,
            //[Emplyement8Sdesig] [varchar](50) NULL,
            //[Emplyement8Semail] [varchar](50) NULL,
            //[Emplyement8Sphone1] [varchar](50) NULL,
            //[Emplyement8Sphone2] [varchar](50) NULL,
            //[Emplyement8SMobile] [varchar](50) NULL,
            //[Emplyement8SResofliv] [varchar](50) NULL,
            //[ddlReference] [varchar](50) NULL,
            //[RefCheck1AppName] [varchar](50) NULL,
            //[Ref1DOV] [varchar](50) NULL,
            //[RefCheck1VerifierName] [varchar](50) NULL,
            //[Ref1Desi] [varchar](50) NULL,
            //[Ref1Company] [varchar](50) NULL,
            //[Ref1Email] [varchar](50) NULL,
            //[Ref1CN] [varchar](50) NULL,
            //[RefCheck2AppName] [varchar](50) NULL,
            //[Ref2DOV] [varchar](50) NULL,
            //[RefCheck2VerifierName] [varchar](50) NULL,
            //[Ref2Desi] [varchar](50) NULL,
            //[Ref2Company] [varchar](50) NULL,
            //[Ref2Email] [varchar](50) NULL,
            //[Ref2CN] [varchar](50) NULL,
            //[RefCheck3AppName] [varchar](50) NULL,
            //[Ref3DOV] [varchar](50) NULL,
            //[RefCheck3VerifierName] [varchar](50) NULL,
            //[Ref3Desi] [varchar](50) NULL,
            //[Ref3Company] [varchar](50) NULL,
            //[Ref3Email] [varchar](50) NULL,
            //[Ref3CN] [varchar](50) NULL,
            //[ddlDatabase] [varchar](50) NULL,
            //[DatabaseCheck] [varchar](50) NULL,
            //[DatabaseLocation] [varchar](50) NULL,
            //[ddlDrug] [varchar](50) NULL,
            //[DrugCheck] [varchar](50) NULL,
            //[DrugLocation] [varchar](50) NULL,
            //[ddlIndentity] [varchar](50) NULL,
            //[IdetityCheck] [varchar](50) NULL,
            //[IdentityLocation] [varchar](50) NULL,

            //[Address2CurrentAddress] [varchar](500) NULL,
            //[Address2City] [varchar](50) NULL,
            //[Address2State] [varchar](50) NULL,
            //[Address2PhoneNo1] [varchar](50) NULL,
            //[Address2PhoneNo2] [varchar](50) NULL,

            //Address 3
            paramsToStore[212] = new SqlParameter("@Address2CurrentAddress", SqlDbType.VarChar);
            paramsToStore[212].Value = objEmployeeInfo.txtAddress2CurrentAddress;
            paramsToStore[212].Size = 500;

            paramsToStore[213] = new SqlParameter("@Address2City", SqlDbType.VarChar);
            paramsToStore[213].Value = objEmployeeInfo.txtAddress2City;
            paramsToStore[213].Size = 50;

            paramsToStore[214] = new SqlParameter("@Address2State", SqlDbType.VarChar);
            paramsToStore[214].Value = objEmployeeInfo.txtAddress2State;
            paramsToStore[214].Size = 50;

            paramsToStore[215] = new SqlParameter("@Address2PhoneNo1", SqlDbType.VarChar);
            paramsToStore[215].Value = objEmployeeInfo.txtAddress2PhoneNo1;
            paramsToStore[215].Size = 50;

            paramsToStore[216] = new SqlParameter("@Address2PhoneNo2", SqlDbType.VarChar);
            paramsToStore[216].Value = objEmployeeInfo.txtAddress2PhoneNo2;
            paramsToStore[216].Size = 50;

            //Address 4
            paramsToStore[217] = new SqlParameter("@Address3CurrentAddress", SqlDbType.VarChar);
            paramsToStore[217].Value = objEmployeeInfo.txtAddress3CurrentAddress;
            paramsToStore[217].Size = 500;

            paramsToStore[218] = new SqlParameter("@Address3City", SqlDbType.VarChar);
            paramsToStore[218].Value = objEmployeeInfo.txtAddress3City;
            paramsToStore[218].Size = 50;

            paramsToStore[219] = new SqlParameter("@Address3State", SqlDbType.VarChar);
            paramsToStore[219].Value = objEmployeeInfo.txtAddress3State;
            paramsToStore[219].Size = 50;

            paramsToStore[220] = new SqlParameter("@Address3PhoneNo1", SqlDbType.VarChar);
            paramsToStore[220].Value = objEmployeeInfo.txtAddress3PhoneNo1;
            paramsToStore[220].Size = 50;

            paramsToStore[221] = new SqlParameter("@Address3PhoneNo2", SqlDbType.VarChar);
            paramsToStore[221].Value = objEmployeeInfo.txtAddress3PhoneNo2;
            paramsToStore[221].Size = 50;

            //Address 5

            paramsToStore[222] = new SqlParameter("@Address4CurrentAddress", SqlDbType.VarChar);
            paramsToStore[222].Value = objEmployeeInfo.txtAddress4CurrentAddress;
            paramsToStore[222].Size = 500;

            paramsToStore[223] = new SqlParameter("@Address4City", SqlDbType.VarChar);
            paramsToStore[223].Value = objEmployeeInfo.txtAddress4City;
            paramsToStore[223].Size = 50;

            paramsToStore[224] = new SqlParameter("@Address4State", SqlDbType.VarChar);
            paramsToStore[224].Value = objEmployeeInfo.txtAddress4State;
            paramsToStore[224].Size = 50;

            paramsToStore[225] = new SqlParameter("@Address4PhoneNo1", SqlDbType.VarChar);
            paramsToStore[225].Value = objEmployeeInfo.txtAddress4PhoneNo1;
            paramsToStore[225].Size = 50;

            paramsToStore[226] = new SqlParameter("@Address4PhoneNo2", SqlDbType.VarChar);
            paramsToStore[226].Value = objEmployeeInfo.txtAddress4PhoneNo2;
            paramsToStore[226].Size = 50;
            //Address 6

            paramsToStore[227] = new SqlParameter("@Address5CurrentAddress", SqlDbType.VarChar);
            paramsToStore[227].Value = objEmployeeInfo.txtAddress5CurrentAddress;
            paramsToStore[227].Size = 500;

            paramsToStore[228] = new SqlParameter("@Address5City", SqlDbType.VarChar);
            paramsToStore[228].Value = objEmployeeInfo.txtAddress5City;
            paramsToStore[228].Size = 50;

            paramsToStore[229] = new SqlParameter("@Address5State", SqlDbType.VarChar);
            paramsToStore[229].Value = objEmployeeInfo.txtAddress5State;
            paramsToStore[229].Size = 50;

            paramsToStore[230] = new SqlParameter("@Address5PhoneNo1", SqlDbType.VarChar);
            paramsToStore[230].Value = objEmployeeInfo.txtAddress5PhoneNo1;
            paramsToStore[230].Size = 50;

            paramsToStore[231] = new SqlParameter("@Address5PhoneNo2", SqlDbType.VarChar);
            paramsToStore[231].Value = objEmployeeInfo.txtAddress5PhoneNo2;
            paramsToStore[231].Size = 50;
            //Address 7

            paramsToStore[232] = new SqlParameter("@Address6CurrentAddress", SqlDbType.VarChar);
            paramsToStore[232].Value = objEmployeeInfo.txtAddress6CurrentAddress;
            paramsToStore[232].Size = 500;

            paramsToStore[233] = new SqlParameter("@Address6City", SqlDbType.VarChar);
            paramsToStore[233].Value = objEmployeeInfo.txtAddress6City;
            paramsToStore[233].Size = 50;

            paramsToStore[234] = new SqlParameter("@Address6State", SqlDbType.VarChar);
            paramsToStore[234].Value = objEmployeeInfo.txtAddress6State;
            paramsToStore[234].Size = 50;

            paramsToStore[235] = new SqlParameter("@Address6PhoneNo1", SqlDbType.VarChar);
            paramsToStore[235].Value = objEmployeeInfo.txtAddress6PhoneNo1;
            paramsToStore[235].Size = 50;

            paramsToStore[236] = new SqlParameter("@Address6PhoneNo2", SqlDbType.VarChar);
            paramsToStore[236].Value = objEmployeeInfo.txtAddress6PhoneNo2;
            paramsToStore[236].Size = 50;
            //Address 8

            paramsToStore[237] = new SqlParameter("@Address7CurrentAddress", SqlDbType.VarChar);
            paramsToStore[237].Value = objEmployeeInfo.txtAddress7CurrentAddress;
            paramsToStore[237].Size = 500;

            paramsToStore[238] = new SqlParameter("@Address7City", SqlDbType.VarChar);
            paramsToStore[238].Value = objEmployeeInfo.txtAddress7City;
            paramsToStore[238].Size = 50;

            paramsToStore[239] = new SqlParameter("@Address7State", SqlDbType.VarChar);
            paramsToStore[239].Value = objEmployeeInfo.txtAddress7State;
            paramsToStore[239].Size = 50;

            paramsToStore[240] = new SqlParameter("@Address7PhoneNo1", SqlDbType.VarChar);
            paramsToStore[240].Value = objEmployeeInfo.txtAddress7PhoneNo1;
            paramsToStore[240].Size = 50;

            paramsToStore[241] = new SqlParameter("@Address7PhoneNo2", SqlDbType.VarChar);
            paramsToStore[241].Value = objEmployeeInfo.txtAddress7PhoneNo2;
            paramsToStore[241].Size = 50;
            //Criminal Check

            //[Criminal1Location] [varchar](50) NULL,
            //[Criminal2Location] [varchar](50) NULL,
            //[Criminal3Location] [varchar](50) NULL,
            //[Criminal4Location] [varchar](50) NULL,
            //[Criminal5Location] [varchar](50) NULL,
            //[Criminal6Location] [varchar](50) NULL,
            //[Criminal7Location] [varchar](50) NULL,
            //[Criminal8Location] [varchar](50) NULL,

            paramsToStore[242] = new SqlParameter("@Criminal1Location", SqlDbType.VarChar);
            paramsToStore[242].Value = objEmployeeInfo.txtCriminal1Location;
            paramsToStore[242].Size = 50;

            paramsToStore[243] = new SqlParameter("@Criminal2Location", SqlDbType.VarChar);
            paramsToStore[243].Value = objEmployeeInfo.txtCriminal2Location;
            paramsToStore[243].Size = 50;

            paramsToStore[244] = new SqlParameter("@Criminal3Location", SqlDbType.VarChar);
            paramsToStore[244].Value = objEmployeeInfo.txtCriminal3Location;
            paramsToStore[244].Size = 50;

            paramsToStore[245] = new SqlParameter("@Criminal4Location", SqlDbType.VarChar);
            paramsToStore[245].Value = objEmployeeInfo.txtCriminal4Location;
            paramsToStore[245].Size = 50;

            paramsToStore[246] = new SqlParameter("@Criminal5Location", SqlDbType.VarChar);
            paramsToStore[246].Value = objEmployeeInfo.txtCriminal5Location;
            paramsToStore[246].Size = 50;

            paramsToStore[247] = new SqlParameter("@Criminal6Location", SqlDbType.VarChar);
            paramsToStore[247].Value = objEmployeeInfo.txtCriminal6Location;
            paramsToStore[247].Size = 50;

            paramsToStore[248] = new SqlParameter("@Criminal7Location", SqlDbType.VarChar);
            paramsToStore[248].Value = objEmployeeInfo.txtCriminal7Location;
            paramsToStore[248].Size = 50;

            paramsToStore[249] = new SqlParameter("@Criminal8Location", SqlDbType.VarChar);
            paramsToStore[249].Value = objEmployeeInfo.txtCriminal8Location;
            paramsToStore[249].Size = 50;


            //Education Check

            // [Education5CollegeName] [varchar](150) NULL,
            //[Education5CollegeAddress] [varchar](500) NULL,
            //[Education5UniversityName] [varchar](150) NULL,
            //[Education5UniversityAddress] [varchar](100) NULL,
            //[Education5EQ] [varchar](50) NULL,
            //[Education5YearofPassing] [varchar](50) NULL,
            //[Education5RollNo] [varchar](50) NULL,
            //[Education5joinfrom] [varchar](50) NULL,
            //[Education5jointo] [varchar](50) NULL,
            //[Education5State] [varchar](50) NULL,
            //[Education5City] [varchar](50) NULL,
            //[Education5PinCode] [varchar](50) NULL,
            //Education 5

            paramsToStore[250] = new SqlParameter("@Education5CollegeName", SqlDbType.VarChar);
            paramsToStore[250].Value = objEmployeeInfo.txtEducation5CollegeName;
            paramsToStore[250].Size = 250;

            paramsToStore[251] = new SqlParameter("@Education5CollegeAddress", SqlDbType.VarChar);
            paramsToStore[251].Value = objEmployeeInfo.txtEducation5CollegeAddress;
            paramsToStore[251].Size = 500;


            paramsToStore[252] = new SqlParameter("@Education5UniversityName", SqlDbType.VarChar);
            paramsToStore[252].Value = objEmployeeInfo.txtEducation5UniversityName;
            paramsToStore[252].Size = 150;


            paramsToStore[253] = new SqlParameter("@Education5UniversityAddress", SqlDbType.VarChar);
            paramsToStore[253].Value = objEmployeeInfo.txtEducation5UniversityAddress;
            paramsToStore[253].Size = 100;


            paramsToStore[254] = new SqlParameter("@Education5EQ", SqlDbType.VarChar);
            paramsToStore[254].Value = objEmployeeInfo.txtEducation5EQ;
            paramsToStore[254].Size = 50;

            paramsToStore[255] = new SqlParameter("@Education5YearofPassing", SqlDbType.VarChar);
            paramsToStore[255].Value = objEmployeeInfo.txtEducation5YearofPassing;
            paramsToStore[255].Size = 50;

            paramsToStore[256] = new SqlParameter("@Education5RollNo", SqlDbType.VarChar);
            paramsToStore[256].Value = objEmployeeInfo.txtEducation5RollNo;
            paramsToStore[256].Size = 50;

            paramsToStore[257] = new SqlParameter("@Education5joinfrom", SqlDbType.VarChar);
            paramsToStore[257].Value = objEmployeeInfo.txtEducation5joinfrom;
            paramsToStore[257].Size = 50;

            paramsToStore[258] = new SqlParameter("@Education5jointo", SqlDbType.VarChar);
            paramsToStore[258].Value = objEmployeeInfo.txtEducation5jointo;
            paramsToStore[258].Size = 50;

            paramsToStore[259] = new SqlParameter("@Education5State", SqlDbType.VarChar);
            paramsToStore[259].Value = objEmployeeInfo.txtEducation5State;
            paramsToStore[259].Size = 50;


            paramsToStore[260] = new SqlParameter("@Education5City", SqlDbType.VarChar);
            paramsToStore[260].Value = objEmployeeInfo.txtEducation5City;
            paramsToStore[260].Size = 50;

            paramsToStore[261] = new SqlParameter("@Education5PinCode", SqlDbType.VarChar);
            paramsToStore[261].Value = objEmployeeInfo.txtEducation5PinCode;
            paramsToStore[261].Size = 50;





            //Education 6 

            paramsToStore[262] = new SqlParameter("@Education6CollegeName", SqlDbType.VarChar);
            paramsToStore[262].Value = objEmployeeInfo.txtEducation6CollegeName;
            paramsToStore[262].Size = 250;

            paramsToStore[263] = new SqlParameter("@Education6CollegeAddress", SqlDbType.VarChar);
            paramsToStore[263].Value = objEmployeeInfo.txtEducation6CollegeAddress;
            paramsToStore[263].Size = 500;


            paramsToStore[264] = new SqlParameter("@Education6UniversityName", SqlDbType.VarChar);
            paramsToStore[264].Value = objEmployeeInfo.txtEducation6UniversityName;
            paramsToStore[264].Size = 150;


            paramsToStore[265] = new SqlParameter("@Education6UniversityAddress", SqlDbType.VarChar);
            paramsToStore[265].Value = objEmployeeInfo.txtEducation6UniversityAddress;
            paramsToStore[265].Size = 100;


            paramsToStore[266] = new SqlParameter("@Education6EQ", SqlDbType.VarChar);
            paramsToStore[266].Value = objEmployeeInfo.txtEducation6EQ;
            paramsToStore[266].Size = 50;

            paramsToStore[267] = new SqlParameter("@Education6YearofPassing", SqlDbType.VarChar);
            paramsToStore[267].Value = objEmployeeInfo.txtEducation6YearofPassing;
            paramsToStore[267].Size = 50;

            paramsToStore[268] = new SqlParameter("@Education6RollNo", SqlDbType.VarChar);
            paramsToStore[268].Value = objEmployeeInfo.txtEducation6RollNo;
            paramsToStore[268].Size = 50;

            paramsToStore[269] = new SqlParameter("@Education6joinfrom", SqlDbType.VarChar);
            paramsToStore[269].Value = objEmployeeInfo.txtEducation6joinfrom;
            paramsToStore[269].Size = 50;

            paramsToStore[270] = new SqlParameter("@Education6jointo", SqlDbType.VarChar);
            paramsToStore[270].Value = objEmployeeInfo.txtEducation6jointo;
            paramsToStore[270].Size = 50;

            paramsToStore[271] = new SqlParameter("@Education6State", SqlDbType.VarChar);
            paramsToStore[271].Value = objEmployeeInfo.txtEducation6State;
            paramsToStore[271].Size = 50;


            paramsToStore[272] = new SqlParameter("@Education6City", SqlDbType.VarChar);
            paramsToStore[272].Value = objEmployeeInfo.txtEducation6City;
            paramsToStore[272].Size = 50;

            paramsToStore[273] = new SqlParameter("@Education6PinCode", SqlDbType.VarChar);
            paramsToStore[273].Value = objEmployeeInfo.txtEducation6PinCode;
            paramsToStore[273].Size = 50;



            //Education 7 

            paramsToStore[274] = new SqlParameter("@Education7CollegeName", SqlDbType.VarChar);
            paramsToStore[274].Value = objEmployeeInfo.txtEducation7CollegeName;
            paramsToStore[274].Size = 250;

            paramsToStore[275] = new SqlParameter("@Education7CollegeAddress", SqlDbType.VarChar);
            paramsToStore[275].Value = objEmployeeInfo.txtEducation7CollegeAddress;
            paramsToStore[275].Size = 500;


            paramsToStore[276] = new SqlParameter("@Education7UniversityName", SqlDbType.VarChar);
            paramsToStore[276].Value = objEmployeeInfo.txtEducation7UniversityName;
            paramsToStore[276].Size = 150;


            paramsToStore[277] = new SqlParameter("@Education7UniversityAddress", SqlDbType.VarChar);
            paramsToStore[277].Value = objEmployeeInfo.txtEducation7UniversityAddress;
            paramsToStore[277].Size = 100;


            paramsToStore[278] = new SqlParameter("@Education7EQ", SqlDbType.VarChar);
            paramsToStore[278].Value = objEmployeeInfo.txtEducation7EQ;
            paramsToStore[278].Size = 50;

            paramsToStore[279] = new SqlParameter("@Education7YearofPassing", SqlDbType.VarChar);
            paramsToStore[279].Value = objEmployeeInfo.txtEducation7YearofPassing;
            paramsToStore[279].Size = 50;

            paramsToStore[280] = new SqlParameter("@Education7RollNo", SqlDbType.VarChar);
            paramsToStore[280].Value = objEmployeeInfo.txtEducation7RollNo;
            paramsToStore[280].Size = 50;

            paramsToStore[281] = new SqlParameter("@Education7joinfrom", SqlDbType.VarChar);
            paramsToStore[281].Value = objEmployeeInfo.txtEducation7joinfrom;
            paramsToStore[281].Size = 50;

            paramsToStore[282] = new SqlParameter("@Education7jointo", SqlDbType.VarChar);
            paramsToStore[282].Value = objEmployeeInfo.txtEducation7jointo;
            paramsToStore[282].Size = 50;

            paramsToStore[283] = new SqlParameter("@Education7State", SqlDbType.VarChar);
            paramsToStore[283].Value = objEmployeeInfo.txtEducation7State;
            paramsToStore[283].Size = 50;


            paramsToStore[284] = new SqlParameter("@Education7City", SqlDbType.VarChar);
            paramsToStore[284].Value = objEmployeeInfo.txtEducation7City;
            paramsToStore[284].Size = 50;

            paramsToStore[285] = new SqlParameter("@Education7PinCode", SqlDbType.VarChar);
            paramsToStore[285].Value = objEmployeeInfo.txtEducation7PinCode;
            paramsToStore[285].Size = 50;

            //Education 8 

            paramsToStore[286] = new SqlParameter("@Education8CollegeName", SqlDbType.VarChar);
            paramsToStore[286].Value = objEmployeeInfo.txtEducation8CollegeName;
            paramsToStore[286].Size = 250;

            paramsToStore[287] = new SqlParameter("@Education8CollegeAddress", SqlDbType.VarChar);
            paramsToStore[287].Value = objEmployeeInfo.txtEducation8CollegeAddress;
            paramsToStore[287].Size = 500;


            paramsToStore[288] = new SqlParameter("@Education8UniversityName", SqlDbType.VarChar);
            paramsToStore[288].Value = objEmployeeInfo.txtEducation8UniversityName;
            paramsToStore[288].Size = 150;


            paramsToStore[289] = new SqlParameter("@Education8UniversityAddress", SqlDbType.VarChar);
            paramsToStore[289].Value = objEmployeeInfo.txtEducation8UniversityAddress;
            paramsToStore[289].Size = 100;


            paramsToStore[290] = new SqlParameter("@Education8EQ", SqlDbType.VarChar);
            paramsToStore[290].Value = objEmployeeInfo.txtEducation8EQ;
            paramsToStore[290].Size = 50;

            paramsToStore[291] = new SqlParameter("@Education8YearofPassing", SqlDbType.VarChar);
            paramsToStore[291].Value = objEmployeeInfo.txtEducation8YearofPassing;
            paramsToStore[291].Size = 50;

            paramsToStore[292] = new SqlParameter("@Education8RollNo", SqlDbType.VarChar);
            paramsToStore[292].Value = objEmployeeInfo.txtEducation8RollNo;
            paramsToStore[292].Size = 50;

            paramsToStore[293] = new SqlParameter("@Education8joinfrom", SqlDbType.VarChar);
            paramsToStore[293].Value = objEmployeeInfo.txtEducation8joinfrom;
            paramsToStore[293].Size = 50;

            paramsToStore[294] = new SqlParameter("@Education8jointo", SqlDbType.VarChar);
            paramsToStore[294].Value = objEmployeeInfo.txtEducation8jointo;
            paramsToStore[294].Size = 50;

            paramsToStore[295] = new SqlParameter("@Education8State", SqlDbType.VarChar);
            paramsToStore[295].Value = objEmployeeInfo.txtEducation8State;
            paramsToStore[295].Size = 50;


            paramsToStore[296] = new SqlParameter("@Education8City", SqlDbType.VarChar);
            paramsToStore[296].Value = objEmployeeInfo.txtEducation8City;
            paramsToStore[296].Size = 50;

            paramsToStore[297] = new SqlParameter("@Education8PinCode", SqlDbType.VarChar);
            paramsToStore[297].Value = objEmployeeInfo.txtEducation8PinCode;
            paramsToStore[297].Size = 50;
            //Employemeny Check 

            //[Employement6CompanyName] [varchar](150) NULL,
            //[Employement6CompanyLocation] [varchar](50) NULL,
            //[Employement6OfficeAddress] [varchar](150) NULL,
            //[Employement6Designation] [varchar](50) NULL,
            //[Employement6phone1] [varchar](50) NULL,
            //[Employement6phone2] [varchar](50) NULL,
            //[Employement6EmpCode] [varchar](50) NULL,
            //[Employement6DateFrom] [varchar](50) NULL,
            //[Employement6DateTo] [varchar](50) NULL,
            //[Employement6Salary] [varchar](50) NULL,
            //[Employement6State] [varchar](50) NULL,
            //[Employement6City] [varchar](50) NULL,
            //[Employement6PinCode] [varchar](50) NULL,
            //[Employement6Sdesig] [varchar](50) NULL,
            //[Employement6Semail] [varchar](50) NULL,
            //[Employement6Sphone1] [varchar](50) NULL,
            //[Emplyoement6Sphone2] [varchar](50) NULL,
            //[Employement6SMobile] [varchar](50) NULL,
            //[Employement6SResofliv] [varchar](50) NULL,

            //Emplyement 6
            paramsToStore[298] = new SqlParameter("@Employement6CompanyName", SqlDbType.VarChar);
            paramsToStore[298].Value = objEmployeeInfo.txtEmployement6CompanyName;
            paramsToStore[298].Size = 150;

            paramsToStore[299] = new SqlParameter("@Employement6CompanyLocation", SqlDbType.VarChar);
            paramsToStore[299].Value = objEmployeeInfo.txtEmployement6CompanyLocation;
            paramsToStore[299].Size = 50;

            paramsToStore[300] = new SqlParameter("@Employement6OfficeAddress", SqlDbType.VarChar);
            paramsToStore[300].Value = objEmployeeInfo.txtEmployement6OfficeAddress;
            paramsToStore[300].Size = 150;

            paramsToStore[301] = new SqlParameter("@Employement6Designation", SqlDbType.VarChar);
            paramsToStore[301].Value = objEmployeeInfo.txtEmployement6Designation;
            paramsToStore[301].Size = 50;

            paramsToStore[302] = new SqlParameter("@Employement6phone1", SqlDbType.VarChar);
            paramsToStore[302].Value = objEmployeeInfo.txtEmployement6phone1;
            paramsToStore[302].Size = 50;


            paramsToStore[303] = new SqlParameter("@Employement6phone2", SqlDbType.VarChar);
            paramsToStore[303].Value = objEmployeeInfo.txtEmployement6phone2;
            paramsToStore[303].Size = 50;

            paramsToStore[304] = new SqlParameter("@Employement6EmpCode", SqlDbType.VarChar);
            paramsToStore[304].Value = objEmployeeInfo.txtEmployement6EmpCode;
            paramsToStore[304].Size = 50;


            paramsToStore[305] = new SqlParameter("@Employement6DateFrom", SqlDbType.VarChar);
            paramsToStore[305].Value = objEmployeeInfo.txtEmployement6DateFrom;
            paramsToStore[305].Size = 50;


            paramsToStore[306] = new SqlParameter("@Employement6DateTo", SqlDbType.VarChar);
            paramsToStore[306].Value = objEmployeeInfo.txtEmployement6DateTo;
            paramsToStore[306].Size = 50;


            paramsToStore[307] = new SqlParameter("@Employement6Salary", SqlDbType.VarChar);
            paramsToStore[307].Value = objEmployeeInfo.txtEmployement6Salary;
            paramsToStore[307].Size = 50;


            paramsToStore[308] = new SqlParameter("@Employement6State", SqlDbType.VarChar);
            paramsToStore[308].Value = objEmployeeInfo.txtEmployement6State;
            paramsToStore[308].Size = 50;


            paramsToStore[309] = new SqlParameter("@Employement6City", SqlDbType.VarChar);
            paramsToStore[309].Value = objEmployeeInfo.txtEmployement6City;
            paramsToStore[309].Size = 50;


            paramsToStore[310] = new SqlParameter("@Employement6PinCode", SqlDbType.VarChar);
            paramsToStore[310].Value = objEmployeeInfo.txtEmployement6PinCode;
            paramsToStore[310].Size = 50;


            paramsToStore[311] = new SqlParameter("@Employement6Sdesig", SqlDbType.VarChar);
            paramsToStore[311].Value = objEmployeeInfo.txtEmployement6Sdesig;
            paramsToStore[311].Size = 50;


            paramsToStore[312] = new SqlParameter("@Employement6Semail", SqlDbType.VarChar);
            paramsToStore[312].Value = objEmployeeInfo.txtEmployement6Semail;
            paramsToStore[312].Size = 50;


            paramsToStore[313] = new SqlParameter("@Employement6Sphone1", SqlDbType.VarChar);
            paramsToStore[313].Value = objEmployeeInfo.txtEmployement6Sphone1;
            paramsToStore[313].Size = 50;


            paramsToStore[314] = new SqlParameter("@Employement6Sphone2", SqlDbType.VarChar);
            paramsToStore[314].Value = objEmployeeInfo.txtEmployement6Sphone2;
            paramsToStore[314].Size = 50;

            paramsToStore[315] = new SqlParameter("@Employement6SMobile", SqlDbType.VarChar);
            paramsToStore[315].Value = objEmployeeInfo.txtEmployement6SMobile;
            paramsToStore[315].Size = 50;

            paramsToStore[316] = new SqlParameter("@Employement6SResofliv", SqlDbType.VarChar);
            paramsToStore[316].Value = objEmployeeInfo.txtEmployement6SResofliv;
            paramsToStore[316].Size = 50;


            //Emplyement 7
            paramsToStore[317] = new SqlParameter("@Employement7CompanyName", SqlDbType.VarChar);
            paramsToStore[317].Value = objEmployeeInfo.txtEmployement7CompanyName;
            paramsToStore[317].Size = 150;

            paramsToStore[318] = new SqlParameter("@Employement7CompanyLocation", SqlDbType.VarChar);
            paramsToStore[318].Value = objEmployeeInfo.txtEmployement7CompanyLocation;
            paramsToStore[318].Size = 50;

            paramsToStore[319] = new SqlParameter("@Employement7OfficeAddress", SqlDbType.VarChar);
            paramsToStore[319].Value = objEmployeeInfo.txtEmployement7OfficeAddress;
            paramsToStore[319].Size = 150;

            paramsToStore[320] = new SqlParameter("@Employement7Designation", SqlDbType.VarChar);
            paramsToStore[320].Value = objEmployeeInfo.txtEmployement7Designation;
            paramsToStore[320].Size = 50;

            paramsToStore[321] = new SqlParameter("@Employement7phone1", SqlDbType.VarChar);
            paramsToStore[321].Value = objEmployeeInfo.txtEmployement7phone1;
            paramsToStore[321].Size = 50;


            paramsToStore[322] = new SqlParameter("@Employement7phone2", SqlDbType.VarChar);
            paramsToStore[322].Value = objEmployeeInfo.txtEmployement7phone2;
            paramsToStore[322].Size = 50;


            paramsToStore[323] = new SqlParameter("@Employement7EmpCode", SqlDbType.VarChar);
            paramsToStore[323].Value = objEmployeeInfo.txtEmployement7EmpCode;
            paramsToStore[323].Size = 50;

            paramsToStore[324] = new SqlParameter("@Employement7DateFrom", SqlDbType.VarChar);
            paramsToStore[324].Value = objEmployeeInfo.txtEmployement7DateFrom;
            paramsToStore[324].Size = 50;


            paramsToStore[325] = new SqlParameter("@Employement7DateTo", SqlDbType.VarChar);
            paramsToStore[325].Value = objEmployeeInfo.txtEmployement7DateTo;
            paramsToStore[325].Size = 50;


            paramsToStore[326] = new SqlParameter("@Employement7Salary", SqlDbType.VarChar);
            paramsToStore[326].Value = objEmployeeInfo.txtEmployement7Salary;
            paramsToStore[326].Size = 50;


            paramsToStore[327] = new SqlParameter("@Employement7State", SqlDbType.VarChar);
            paramsToStore[327].Value = objEmployeeInfo.txtEmployement7State;
            paramsToStore[327].Size = 50;


            paramsToStore[328] = new SqlParameter("@Employement7City", SqlDbType.VarChar);
            paramsToStore[328].Value = objEmployeeInfo.txtEmployement7City;
            paramsToStore[328].Size = 50;


            paramsToStore[329] = new SqlParameter("@Employement7PinCode", SqlDbType.VarChar);
            paramsToStore[329].Value = objEmployeeInfo.txtEmployement7PinCode;
            paramsToStore[329].Size = 50;


            paramsToStore[330] = new SqlParameter("@Employement7Sdesig", SqlDbType.VarChar);
            paramsToStore[330].Value = objEmployeeInfo.txtEmployement7Sdesig;
            paramsToStore[330].Size = 50;


            paramsToStore[331] = new SqlParameter("@Employement7Semail", SqlDbType.VarChar);
            paramsToStore[331].Value = objEmployeeInfo.txtEmployement7Semail;
            paramsToStore[331].Size = 50;


            paramsToStore[332] = new SqlParameter("@Employement7Sphone1", SqlDbType.VarChar);
            paramsToStore[332].Value = objEmployeeInfo.txtEmployement7Sphone1;
            paramsToStore[332].Size = 50;


            paramsToStore[333] = new SqlParameter("@Employement7Sphone2", SqlDbType.VarChar);
            paramsToStore[333].Value = objEmployeeInfo.txtEmployement7Sphone2;
            paramsToStore[333].Size = 50;

            paramsToStore[334] = new SqlParameter("@Employement7SMobile", SqlDbType.VarChar);
            paramsToStore[334].Value = objEmployeeInfo.txtEmployement7SMobile;
            paramsToStore[334].Size = 50;

            paramsToStore[335] = new SqlParameter("@Employement7SResofliv", SqlDbType.VarChar);
            paramsToStore[335].Value = objEmployeeInfo.txtEmployement7SResofliv;
            paramsToStore[335].Size = 50;




            //Emplyement 8
            paramsToStore[336] = new SqlParameter("@Employement8CompanyName", SqlDbType.VarChar);
            paramsToStore[336].Value = objEmployeeInfo.txtEmployement8CompanyName;
            paramsToStore[336].Size = 150;

            paramsToStore[337] = new SqlParameter("@Employement8CompanyLocation", SqlDbType.VarChar);
            paramsToStore[337].Value = objEmployeeInfo.txtEmployement8CompanyLocation;
            paramsToStore[337].Size = 50;

            paramsToStore[338] = new SqlParameter("@Employement8OfficeAddress", SqlDbType.VarChar);
            paramsToStore[338].Value = objEmployeeInfo.txtEmployement8OfficeAddress;
            paramsToStore[338].Size = 150;

            paramsToStore[339] = new SqlParameter("@Employement8Designation", SqlDbType.VarChar);
            paramsToStore[339].Value = objEmployeeInfo.txtEmployement8Designation;
            paramsToStore[339].Size = 50;

            paramsToStore[340] = new SqlParameter("@Employement8phone1", SqlDbType.VarChar);
            paramsToStore[340].Value = objEmployeeInfo.txtEmployement8phone1;
            paramsToStore[340].Size = 50;


            paramsToStore[341] = new SqlParameter("@Employement8phone2", SqlDbType.VarChar);
            paramsToStore[341].Value = objEmployeeInfo.txtEmployement8phone2;
            paramsToStore[341].Size = 50;

            paramsToStore[342] = new SqlParameter("@Employement8EmpCode", SqlDbType.VarChar);
            paramsToStore[342].Value = objEmployeeInfo.txtEmployement8EmpCode;
            paramsToStore[342].Size = 50;



            paramsToStore[343] = new SqlParameter("@Employement8DateFrom", SqlDbType.VarChar);
            paramsToStore[343].Value = objEmployeeInfo.txtEmployement8DateFrom;
            paramsToStore[343].Size = 50;


            paramsToStore[344] = new SqlParameter("@Employement8DateTo", SqlDbType.VarChar);
            paramsToStore[344].Value = objEmployeeInfo.txtEmployement8DateTo;
            paramsToStore[344].Size = 50;


            paramsToStore[345] = new SqlParameter("@Employement8Salary", SqlDbType.VarChar);
            paramsToStore[345].Value = objEmployeeInfo.txtEmployement8Salary;
            paramsToStore[345].Size = 50;


            paramsToStore[346] = new SqlParameter("@Employement8State", SqlDbType.VarChar);
            paramsToStore[346].Value = objEmployeeInfo.txtEmployement8State;
            paramsToStore[346].Size = 50;


            paramsToStore[347] = new SqlParameter("@Employement8City", SqlDbType.VarChar);
            paramsToStore[347].Value = objEmployeeInfo.txtEmployement8City;
            paramsToStore[347].Size = 50;


            paramsToStore[348] = new SqlParameter("@Employement8PinCode", SqlDbType.VarChar);
            paramsToStore[348].Value = objEmployeeInfo.txtEmployement8PinCode;
            paramsToStore[348].Size = 50;


            paramsToStore[349] = new SqlParameter("@Employement8Sdesig", SqlDbType.VarChar);
            paramsToStore[349].Value = objEmployeeInfo.txtEmployement8Sdesig;
            paramsToStore[349].Size = 50;


            paramsToStore[350] = new SqlParameter("@Employement8Semail", SqlDbType.VarChar);
            paramsToStore[350].Value = objEmployeeInfo.txtEmployement8Semail;
            paramsToStore[350].Size = 50;


            paramsToStore[351] = new SqlParameter("@Employement8Sphone1", SqlDbType.VarChar);
            paramsToStore[351].Value = objEmployeeInfo.txtEmployement8Sphone1;
            paramsToStore[351].Size = 50;


            paramsToStore[352] = new SqlParameter("@Employement8Sphone2", SqlDbType.VarChar);
            paramsToStore[352].Value = objEmployeeInfo.txtEmployement8Sphone2;
            paramsToStore[352].Size = 50;

            paramsToStore[353] = new SqlParameter("@Employement8SMobile", SqlDbType.VarChar);
            paramsToStore[353].Value = objEmployeeInfo.txtEmployement8SMobile;
            paramsToStore[353].Size = 50;

            paramsToStore[354] = new SqlParameter("@Employement8SResofliv", SqlDbType.VarChar);
            paramsToStore[354].Value = objEmployeeInfo.txtEmployement8SResofliv;
            paramsToStore[354].Size = 50;


            //Reference Check


            //[ddlReference] [varchar](50) NULL,
            //[RefCheck1AppName] [varchar](50) NULL,
            //[Ref1DOV] [varchar](50) NULL,
            //[RefCheck1VerifierName] [varchar](50) NULL,
            //[Ref1Desi] [varchar](50) NULL,
            //[Ref1Company] [varchar](50) NULL,
            //[Ref1Email] [varchar](50) NULL,
            //[Ref1CN] [varchar](50) NULL,
            //[RefCheck2AppName] [varchar](50) NULL,
            //[Ref2DOV] [varchar](50) NULL,
            //[RefCheck2VerifierName] [varchar](50) NULL,
            //[Ref2Desi] [varchar](50) NULL,
            //[Ref2Company] [varchar](50) NULL,
            //[Ref2Email] [varchar](50) NULL,
            //[Ref2CN] [varchar](50) NULL,
            //[RefCheck3AppName] [varchar](50) NULL,
            //[Ref3DOV] [varchar](50) NULL,
            //[RefCheck3VerifierName] [varchar](50) NULL,
            //[Ref3Desi] [varchar](50) NULL,
            //[Ref3Company] [varchar](50) NULL,
            //[Ref3Email] [varchar](50) NULL,
            //[Ref3CN] [varchar](50) NULL,

            //Reference 1

            paramsToStore[355] = new SqlParameter("@ddlReference", SqlDbType.VarChar);
            paramsToStore[355].Value = objEmployeeInfo.ddlReference;
            paramsToStore[355].Size = 50;

            paramsToStore[356] = new SqlParameter("@RefCheck1AppName", SqlDbType.VarChar);
            paramsToStore[356].Value = objEmployeeInfo.txtRefCheck1AppName;
            paramsToStore[356].Size = 50;

            paramsToStore[357] = new SqlParameter("@Ref1DOV", SqlDbType.VarChar);
            paramsToStore[357].Value = objEmployeeInfo.txtRef1DOV;
            paramsToStore[357].Size = 50;

            paramsToStore[358] = new SqlParameter("@RefCheck1VerifierName", SqlDbType.VarChar);
            paramsToStore[358].Value = objEmployeeInfo.txtRefCheck1VerifierName;
            paramsToStore[358].Size = 50;

            paramsToStore[359] = new SqlParameter("@Ref1Desi", SqlDbType.VarChar);
            paramsToStore[359].Value = objEmployeeInfo.txtRef1Desi;
            paramsToStore[359].Size = 50;

            paramsToStore[360] = new SqlParameter("@Ref1Company", SqlDbType.VarChar);
            paramsToStore[360].Value = objEmployeeInfo.txtRef1Company;
            paramsToStore[360].Size = 50;


            paramsToStore[361] = new SqlParameter("@Ref1Email", SqlDbType.VarChar);
            paramsToStore[361].Value = objEmployeeInfo.txtRef1Email;
            paramsToStore[361].Size = 50;

            paramsToStore[362] = new SqlParameter("@Ref1CN", SqlDbType.VarChar);
            paramsToStore[362].Value = objEmployeeInfo.txtRef1CN;
            paramsToStore[362].Size = 50;


            //Reference 2



            paramsToStore[363] = new SqlParameter("@RefCheck2AppName", SqlDbType.VarChar);
            paramsToStore[363].Value = objEmployeeInfo.txtRefCheck2AppName;
            paramsToStore[363].Size = 50;

            paramsToStore[364] = new SqlParameter("@Ref2DOV", SqlDbType.VarChar);
            paramsToStore[364].Value = objEmployeeInfo.txtRef2DOV;
            paramsToStore[364].Size = 50;

            paramsToStore[365] = new SqlParameter("@RefCheck2VerifierName", SqlDbType.VarChar);
            paramsToStore[365].Value = objEmployeeInfo.txtRefCheck2VerifierName;
            paramsToStore[365].Size = 50;

            paramsToStore[366] = new SqlParameter("@Ref2Desi", SqlDbType.VarChar);
            paramsToStore[366].Value = objEmployeeInfo.txtRef2Desi;
            paramsToStore[366].Size = 50;

            paramsToStore[367] = new SqlParameter("@Ref2Company", SqlDbType.VarChar);
            paramsToStore[367].Value = objEmployeeInfo.txtRef2Company;
            paramsToStore[367].Size = 50;


            paramsToStore[368] = new SqlParameter("@Ref2Email", SqlDbType.VarChar);
            paramsToStore[368].Value = objEmployeeInfo.txtRef2Email;
            paramsToStore[368].Size = 50;

            paramsToStore[369] = new SqlParameter("@Ref2CN", SqlDbType.VarChar);
            paramsToStore[369].Value = objEmployeeInfo.txtRef2CN;
            paramsToStore[369].Size = 50;


            //Reference 3



            paramsToStore[370] = new SqlParameter("@RefCheck3AppName", SqlDbType.VarChar);
            paramsToStore[370].Value = objEmployeeInfo.txtRefCheck3AppName;
            paramsToStore[370].Size = 50;

            paramsToStore[371] = new SqlParameter("@Ref3DOV", SqlDbType.VarChar);
            paramsToStore[371].Value = objEmployeeInfo.txtRef3DOV;
            paramsToStore[371].Size = 50;

            paramsToStore[372] = new SqlParameter("@RefCheck3VerifierName", SqlDbType.VarChar);
            paramsToStore[372].Value = objEmployeeInfo.txtRefCheck3VerifierName;
            paramsToStore[372].Size = 50;

            paramsToStore[373] = new SqlParameter("@Ref3Desi", SqlDbType.VarChar);
            paramsToStore[373].Value = objEmployeeInfo.txtRef3Desi;
            paramsToStore[373].Size = 50;

            paramsToStore[374] = new SqlParameter("@Ref3Company", SqlDbType.VarChar);
            paramsToStore[374].Value = objEmployeeInfo.txtRef3Company;
            paramsToStore[374].Size = 50;


            paramsToStore[375] = new SqlParameter("@Ref3Email", SqlDbType.VarChar);
            paramsToStore[375].Value = objEmployeeInfo.txtRef3Email;
            paramsToStore[375].Size = 50;

            paramsToStore[376] = new SqlParameter("@Ref3CN", SqlDbType.VarChar);
            paramsToStore[376].Value = objEmployeeInfo.txtRef3CN;
            paramsToStore[376].Size = 50;

            //[ddlDatabase] [varchar](50) NULL,
            //[DatabaseCheck] [varchar](50) NULL,
            //[DatabaseLocation] [varchar](50) NULL,
            //[ddlDrug] [varchar](50) NULL,
            //[DrugCheck] [varchar](50) NULL,
            //[DrugLocation] [varchar](50) NULL,
            //[ddlIndentity] [varchar](50) NULL,
            //[IdetityCheck] [varchar](50) NULL,
            //[IdentityLocation] [varchar](50) NULL,

            paramsToStore[377] = new SqlParameter("@ddlDatabase", SqlDbType.VarChar);
            paramsToStore[377].Value = objEmployeeInfo.ddlDatabase;
            paramsToStore[377].Size = 50;

            paramsToStore[378] = new SqlParameter("@DatabaseCheck", SqlDbType.VarChar);
            paramsToStore[378].Value = objEmployeeInfo.txtDatabaseCheck;
            paramsToStore[378].Size = 50;

            paramsToStore[379] = new SqlParameter("@DatabaseLocation", SqlDbType.VarChar);
            paramsToStore[379].Value = objEmployeeInfo.txtDatabaseLocation;
            paramsToStore[379].Size = 50;

            paramsToStore[380] = new SqlParameter("@ddlDrug", SqlDbType.VarChar);
            paramsToStore[380].Value = objEmployeeInfo.ddlDrug;
            paramsToStore[380].Size = 50;

            paramsToStore[381] = new SqlParameter("@DrugCheck", SqlDbType.VarChar);
            paramsToStore[381].Value = objEmployeeInfo.txtDrugCheck;
            paramsToStore[381].Size = 50;

            paramsToStore[382] = new SqlParameter("@DrugLocation", SqlDbType.VarChar);
            paramsToStore[382].Value = objEmployeeInfo.txtDrugLocation;
            paramsToStore[382].Size = 50;


            paramsToStore[383] = new SqlParameter("@ddlIndentity", SqlDbType.VarChar);
            paramsToStore[383].Value = objEmployeeInfo.ddlIndentity;
            paramsToStore[383].Size = 50;


            paramsToStore[384] = new SqlParameter("@IdentityCheck", SqlDbType.VarChar);
            paramsToStore[384].Value = objEmployeeInfo.txtIdentityCheck;
            paramsToStore[384].Size = 50;

            paramsToStore[385] = new SqlParameter("@IdentityLocation", SqlDbType.VarChar);
            paramsToStore[385].Value = objEmployeeInfo.txtIdentityLocation;
            paramsToStore[385].Size = 50;

            paramsToStore[386] = new SqlParameter("@AddressCheck", SqlDbType.VarChar);
            paramsToStore[386].Value = objEmployeeInfo.AddressCheck;
            paramsToStore[386].Size = 50;

            paramsToStore[387] = new SqlParameter("@CriminalCheck", SqlDbType.VarChar);
            paramsToStore[387].Value = objEmployeeInfo.CriminalCheck;
            paramsToStore[387].Size = 50;





            //---------------------------End All Checks


            //-------------------------Start----------Criminal

            paramsToStore[388] = new SqlParameter("@Criminal1Address", SqlDbType.VarChar);
            paramsToStore[388].Value = objEmployeeInfo.Criminal1Address;
            paramsToStore[388].Size = 300;

            paramsToStore[389] = new SqlParameter("@Criminal2Address", SqlDbType.VarChar);
            paramsToStore[389].Value = objEmployeeInfo.Criminal2Address;
            paramsToStore[389].Size = 300;

            paramsToStore[390] = new SqlParameter("@Criminal3Address", SqlDbType.VarChar);
            paramsToStore[390].Value = objEmployeeInfo.Criminal3Address;
            paramsToStore[390].Size = 300;

            paramsToStore[391] = new SqlParameter("@Criminal4Address", SqlDbType.VarChar);
            paramsToStore[391].Value = objEmployeeInfo.Criminal4Address;
            paramsToStore[391].Size = 300;




            paramsToStore[392] = new SqlParameter("@Criminal5Address", SqlDbType.VarChar);
            paramsToStore[392].Value = objEmployeeInfo.Criminal5Address;
            paramsToStore[392].Size = 300;

            paramsToStore[393] = new SqlParameter("@Criminal6Address", SqlDbType.VarChar);
            paramsToStore[393].Value = objEmployeeInfo.Criminal6Address;
            paramsToStore[393].Size = 300;

            paramsToStore[394] = new SqlParameter("@Criminal7Address", SqlDbType.VarChar);
            paramsToStore[394].Value = objEmployeeInfo.Criminal7Address;
            paramsToStore[394].Size = 300;

            paramsToStore[395] = new SqlParameter("@Criminal8Address", SqlDbType.VarChar);
            paramsToStore[395].Value = objEmployeeInfo.Criminal8Address;
            paramsToStore[395].Size = 300;




            paramsToStore[396] = new SqlParameter("@Criminal1State", SqlDbType.VarChar);
            paramsToStore[396].Value = objEmployeeInfo.Criminal1State;
            paramsToStore[396].Size = 50;

            paramsToStore[397] = new SqlParameter("@Criminal2State", SqlDbType.VarChar);
            paramsToStore[397].Value = objEmployeeInfo.Criminal2State;
            paramsToStore[397].Size = 50;

            paramsToStore[398] = new SqlParameter("@Criminal3State", SqlDbType.VarChar);
            paramsToStore[398].Value = objEmployeeInfo.Criminal3State;
            paramsToStore[398].Size = 50;

            paramsToStore[399] = new SqlParameter("@Criminal4State", SqlDbType.VarChar);
            paramsToStore[399].Value = objEmployeeInfo.Criminal4State;
            paramsToStore[399].Size = 50;




            paramsToStore[400] = new SqlParameter("@Criminal5State", SqlDbType.VarChar);
            paramsToStore[400].Value = objEmployeeInfo.Criminal5State;
            paramsToStore[400].Size = 50;

            paramsToStore[401] = new SqlParameter("@Criminal6State", SqlDbType.VarChar);
            paramsToStore[401].Value = objEmployeeInfo.Criminal6State;
            paramsToStore[401].Size = 50;

            paramsToStore[402] = new SqlParameter("@Criminal7State", SqlDbType.VarChar);
            paramsToStore[402].Value = objEmployeeInfo.Criminal7State;
            paramsToStore[402].Size = 50;

            paramsToStore[403] = new SqlParameter("@Criminal8State", SqlDbType.VarChar);
            paramsToStore[403].Value = objEmployeeInfo.Criminal8State;
            paramsToStore[403].Size = 50;

            paramsToStore[404] = new SqlParameter("@CaseStatusKPMG", SqlDbType.VarChar);
            paramsToStore[404].Value = objEmployeeInfo.CaseStatusKPMG;
            paramsToStore[404].Size = 50;

            paramsToStore[405] = new SqlParameter("@Req_Edu1", SqlDbType.VarChar);
            paramsToStore[405].Value = objEmployeeInfo.strRequirement_edu1;
            paramsToStore[405].Size = 50;

            paramsToStore[406] = new SqlParameter("@Req_Edu2", SqlDbType.VarChar);
            paramsToStore[406].Value = objEmployeeInfo.strRequirement_edu2;
            paramsToStore[406].Size = 50;

            paramsToStore[407] = new SqlParameter("@Req_Edu3", SqlDbType.VarChar);
            paramsToStore[407].Value = objEmployeeInfo.strRequirement_edu3;
            paramsToStore[407].Size = 50;

            paramsToStore[408] = new SqlParameter("@Req_Edu4", SqlDbType.VarChar);
            paramsToStore[408].Value = objEmployeeInfo.strRequirement_edu4;
            paramsToStore[408].Size = 50;

            paramsToStore[409] = new SqlParameter("@category", SqlDbType.VarChar);
            paramsToStore[409].Value = objEmployeeInfo.strCategory;
            paramsToStore[409].Size = 50;

            paramsToStore[410] = new SqlParameter("@subCategory", SqlDbType.VarChar);
            paramsToStore[410].Value = objEmployeeInfo.strSubCategory;
            paramsToStore[410].Size = 50;


            paramsToStore[411] = new SqlParameter("@AddDateFrm1", SqlDbType.VarChar);
            paramsToStore[411].Value = objEmployeeInfo.strAddDateFrm1;
            paramsToStore[411].Size = 50;

            paramsToStore[412] = new SqlParameter("@AddDateFrm2", SqlDbType.VarChar);
            paramsToStore[412].Value = objEmployeeInfo.strAddDateFrm2;
            paramsToStore[412].Size = 50;

            paramsToStore[413] = new SqlParameter("@AddDateFrm3", SqlDbType.VarChar);
            paramsToStore[413].Value = objEmployeeInfo.strAddDateFrm3;
            paramsToStore[413].Size = 50;

            paramsToStore[414] = new SqlParameter("@AddDateFrm4", SqlDbType.VarChar);
            paramsToStore[414].Value = objEmployeeInfo.strAddDateFrm4;
            paramsToStore[414].Size = 50;

            paramsToStore[415] = new SqlParameter("@AddDateFrm5", SqlDbType.VarChar);
            paramsToStore[415].Value = objEmployeeInfo.strAddDateFrm5;
            paramsToStore[415].Size = 50;

            paramsToStore[416] = new SqlParameter("@AddDateFrm6", SqlDbType.VarChar);
            paramsToStore[416].Value = objEmployeeInfo.strAddDateFrm6;
            paramsToStore[416].Size = 50;

            paramsToStore[417] = new SqlParameter("@AddDateFrm7", SqlDbType.VarChar);
            paramsToStore[417].Value = objEmployeeInfo.strAddDateFrm7;
            paramsToStore[417].Size = 50;

            paramsToStore[418] = new SqlParameter("@AddDateFrm8", SqlDbType.VarChar);
            paramsToStore[418].Value = objEmployeeInfo.strAddDateFrm8;
            paramsToStore[418].Size = 50;

            paramsToStore[419] = new SqlParameter("@AddDateTo1", SqlDbType.VarChar);
            paramsToStore[419].Value = objEmployeeInfo.strAddDateTo1;
            paramsToStore[419].Size = 50;

            paramsToStore[420] = new SqlParameter("@AddDateTo2", SqlDbType.VarChar);
            paramsToStore[420].Value = objEmployeeInfo.strAddDateTo2;
            paramsToStore[420].Size = 50;

            paramsToStore[421] = new SqlParameter("@AddDateTo3", SqlDbType.VarChar);
            paramsToStore[421].Value = objEmployeeInfo.strAddDateTo3;
            paramsToStore[421].Size = 50;

            paramsToStore[422] = new SqlParameter("@AddDateTo4", SqlDbType.VarChar);
            paramsToStore[422].Value = objEmployeeInfo.strAddDateTo4;
            paramsToStore[422].Size = 50;

            paramsToStore[423] = new SqlParameter("@AddDateTo5", SqlDbType.VarChar);
            paramsToStore[423].Value = objEmployeeInfo.strAddDateTo5;
            paramsToStore[423].Size = 50;

            paramsToStore[424] = new SqlParameter("@AddDateTo6", SqlDbType.VarChar);
            paramsToStore[424].Value = objEmployeeInfo.strAddDateTo6;
            paramsToStore[424].Size = 50;

            paramsToStore[425] = new SqlParameter("@AddDateTo7", SqlDbType.VarChar);
            paramsToStore[425].Value = objEmployeeInfo.strAddDateTo7;
            paramsToStore[425].Size = 50;

            paramsToStore[426] = new SqlParameter("@AddDateTo8", SqlDbType.VarChar);
            paramsToStore[426].Value = objEmployeeInfo.strAddDateTo8;
            paramsToStore[426].Size = 50;

            paramsToStore[427] = new SqlParameter("@CriDateFrm1", SqlDbType.VarChar);
            paramsToStore[427].Value = objEmployeeInfo.strCriDateFrm1;
            paramsToStore[427].Size = 50;

            paramsToStore[428] = new SqlParameter("@CriDateFrm2", SqlDbType.VarChar);
            paramsToStore[428].Value = objEmployeeInfo.strCriDateFrm2;
            paramsToStore[428].Size = 50;

            paramsToStore[429] = new SqlParameter("@CriDateFrm3", SqlDbType.VarChar);
            paramsToStore[429].Value = objEmployeeInfo.strCriDateFrm3;
            paramsToStore[429].Size = 50;

            paramsToStore[430] = new SqlParameter("@CriDateFrm4", SqlDbType.VarChar);
            paramsToStore[430].Value = objEmployeeInfo.strCriDateFrm4;
            paramsToStore[430].Size = 50;

            paramsToStore[431] = new SqlParameter("@CriDateFrm5", SqlDbType.VarChar);
            paramsToStore[431].Value = objEmployeeInfo.strCriDateFrm5;
            paramsToStore[431].Size = 50;

            paramsToStore[432] = new SqlParameter("@CriDateFrm6", SqlDbType.VarChar);
            paramsToStore[432].Value = objEmployeeInfo.strCriDateFrm6;
            paramsToStore[432].Size = 50;

            paramsToStore[433] = new SqlParameter("@CriDateFrm7", SqlDbType.VarChar);
            paramsToStore[433].Value = objEmployeeInfo.strCriDateFrm7;
            paramsToStore[433].Size = 50;

            paramsToStore[434] = new SqlParameter("@CriDateFrm8", SqlDbType.VarChar);
            paramsToStore[434].Value = objEmployeeInfo.strCriDateFrm8;
            paramsToStore[434].Size = 50;

            paramsToStore[435] = new SqlParameter("@CriDateTo1", SqlDbType.VarChar);
            paramsToStore[435].Value = objEmployeeInfo.strCriDateTo1;
            paramsToStore[435].Size = 50;

            paramsToStore[436] = new SqlParameter("@CriDateTo2", SqlDbType.VarChar);
            paramsToStore[436].Value = objEmployeeInfo.strCriDateTo2;
            paramsToStore[436].Size = 50;

            paramsToStore[437] = new SqlParameter("@CriDateTo3", SqlDbType.VarChar);
            paramsToStore[437].Value = objEmployeeInfo.strCriDateTo3;
            paramsToStore[437].Size = 50;

            paramsToStore[438] = new SqlParameter("@CriDateTo4", SqlDbType.VarChar);
            paramsToStore[438].Value = objEmployeeInfo.strCriDateTo4;
            paramsToStore[438].Size = 50;

            paramsToStore[439] = new SqlParameter("@CriDateTo5", SqlDbType.VarChar);
            paramsToStore[439].Value = objEmployeeInfo.strCriDateTo5;
            paramsToStore[439].Size = 50;

            paramsToStore[440] = new SqlParameter("@CriDateTo6", SqlDbType.VarChar);
            paramsToStore[440].Value = objEmployeeInfo.strCriDateTo6;
            paramsToStore[440].Size = 50;

            paramsToStore[441] = new SqlParameter("@CriDateTo7", SqlDbType.VarChar);
            paramsToStore[441].Value = objEmployeeInfo.strCriDateTo7;
            paramsToStore[441].Size = 50;

            paramsToStore[442] = new SqlParameter("@CriDateTo8", SqlDbType.VarChar);
            paramsToStore[442].Value = objEmployeeInfo.strCriDateTo8;
            paramsToStore[442].Size = 50;

            paramsToStore[443] = new SqlParameter("@EduDateFrm1", SqlDbType.VarChar);
            paramsToStore[443].Value = objEmployeeInfo.strEduDateFrm1;
            paramsToStore[443].Size = 50;

            paramsToStore[444] = new SqlParameter("@EduDateFrm2", SqlDbType.VarChar);
            paramsToStore[444].Value = objEmployeeInfo.strEduDateFrm2;
            paramsToStore[444].Size = 50;

            paramsToStore[445] = new SqlParameter("@EduDateFrm3", SqlDbType.VarChar);
            paramsToStore[445].Value = objEmployeeInfo.strEduDateFrm3;
            paramsToStore[445].Size = 50;

         

            paramsToStore[446] = new SqlParameter("@EduDateFrm5", SqlDbType.VarChar);
            paramsToStore[446].Value = objEmployeeInfo.strEduDateFrm5;
            paramsToStore[446].Size = 50;

            paramsToStore[447] = new SqlParameter("@EduDateFrm6", SqlDbType.VarChar);
            paramsToStore[447].Value = objEmployeeInfo.strEduDateFrm6;
            paramsToStore[447].Size = 50;

            paramsToStore[448] = new SqlParameter("@EduDateFrm7", SqlDbType.VarChar);
            paramsToStore[448].Value = objEmployeeInfo.strEduDateFrm7;
            paramsToStore[448].Size = 50;

            paramsToStore[449] = new SqlParameter("@EduDateFrm8", SqlDbType.VarChar);
            paramsToStore[449].Value = objEmployeeInfo.strEduDateFrm8;
            paramsToStore[449].Size = 50;

            paramsToStore[450] = new SqlParameter("@EduDateTo1", SqlDbType.VarChar);
            paramsToStore[450].Value = objEmployeeInfo.strEduDateTo1;
            paramsToStore[450].Size = 50;

            paramsToStore[451] = new SqlParameter("@EduDateTo2", SqlDbType.VarChar);
            paramsToStore[451].Value = objEmployeeInfo.strEduDateTo2;
            paramsToStore[451].Size = 50;

            paramsToStore[452] = new SqlParameter("@EduDateTo3", SqlDbType.VarChar);
            paramsToStore[452].Value = objEmployeeInfo.strEduDateTo3;
            paramsToStore[452].Size = 50;

            paramsToStore[453] = new SqlParameter("@EduDateTo4", SqlDbType.VarChar);
            paramsToStore[453].Value = objEmployeeInfo.strEduDateTo4;
            paramsToStore[453].Size = 50;

            paramsToStore[454] = new SqlParameter("@EduDateTo5", SqlDbType.VarChar);
            paramsToStore[454].Value = objEmployeeInfo.strEduDateTo5;
            paramsToStore[454].Size = 50;

            paramsToStore[455] = new SqlParameter("@EduDateTo6", SqlDbType.VarChar);
            paramsToStore[455].Value = objEmployeeInfo.strEduDateTo6;
            paramsToStore[455].Size = 50;

            paramsToStore[456] = new SqlParameter("@EduDateTo7", SqlDbType.VarChar);
            paramsToStore[456].Value = objEmployeeInfo.strEduDateTo7;
            paramsToStore[456].Size = 50;

           

            

            paramsToStore[457] = new SqlParameter("@AddStatus1", SqlDbType.VarChar);
            paramsToStore[457].Value = objEmployeeInfo.strAddStatus1;
            paramsToStore[457].Size = 50;

            paramsToStore[458] = new SqlParameter("@AddStatus2", SqlDbType.VarChar);
            paramsToStore[458].Value = objEmployeeInfo.strAddStatus2;
            paramsToStore[458].Size = 50;

            paramsToStore[459] = new SqlParameter("@AddStatus3", SqlDbType.VarChar);
            paramsToStore[459].Value = objEmployeeInfo.strAddStatus3;
            paramsToStore[459].Size = 50;

            paramsToStore[460] = new SqlParameter("@AddStatus4", SqlDbType.VarChar);
            paramsToStore[460].Value = objEmployeeInfo.strAddStatus4;
            paramsToStore[460].Size = 50;

            paramsToStore[461] = new SqlParameter("@AddStatus5", SqlDbType.VarChar);
            paramsToStore[461].Value = objEmployeeInfo.strAddStatus5;
            paramsToStore[461].Size = 50;

            paramsToStore[462] = new SqlParameter("@AddStatus6", SqlDbType.VarChar);
            paramsToStore[462].Value = objEmployeeInfo.strAddStatus6;
            paramsToStore[462].Size = 50;

            paramsToStore[463] = new SqlParameter("@AddStatus7", SqlDbType.VarChar);
            paramsToStore[463].Value = objEmployeeInfo.strAddStatus7;
            paramsToStore[463].Size = 50;

            paramsToStore[464] = new SqlParameter("@AddStatus8", SqlDbType.VarChar);
            paramsToStore[464].Value = objEmployeeInfo.strAddStatus8;
            paramsToStore[464].Size = 50;

            paramsToStore[465] = new SqlParameter("@AddRemarks1", SqlDbType.VarChar);
            paramsToStore[465].Value = objEmployeeInfo.strAddRemarks1;
            paramsToStore[465].Size = 500;

            paramsToStore[466] = new SqlParameter("@AddRemarks2", SqlDbType.VarChar);
            paramsToStore[466].Value = objEmployeeInfo.strAddRemarks2;
            paramsToStore[466].Size = 500;

            paramsToStore[467] = new SqlParameter("@AddRemarks3", SqlDbType.VarChar);
            paramsToStore[467].Value = objEmployeeInfo.strAddRemarks3;
            paramsToStore[467].Size = 500;

            paramsToStore[468] = new SqlParameter("@AddRemarks4", SqlDbType.VarChar);
            paramsToStore[468].Value = objEmployeeInfo.strAddRemarks4;
            paramsToStore[468].Size = 500;

          

            paramsToStore[469] = new SqlParameter("@AddRemarks6", SqlDbType.VarChar);
            paramsToStore[469].Value = objEmployeeInfo.strAddRemarks6;
            paramsToStore[469].Size = 500;

            paramsToStore[470] = new SqlParameter("@AddRemarks7", SqlDbType.VarChar);
            paramsToStore[470].Value = objEmployeeInfo.strAddRemarks7;
            paramsToStore[470].Size = 500;

            paramsToStore[471] = new SqlParameter("@AddRemarks8", SqlDbType.VarChar);
            paramsToStore[471].Value = objEmployeeInfo.strAddRemarks8;
            paramsToStore[471].Size = 500;


            paramsToStore[472] = new SqlParameter("@CriStatus1", SqlDbType.VarChar);
            paramsToStore[472].Value = objEmployeeInfo.strCriStatus1;
            paramsToStore[472].Size = 50;

            paramsToStore[473] = new SqlParameter("@CriStatus2", SqlDbType.VarChar);
            paramsToStore[473].Value = objEmployeeInfo.strCriStatus2;
            paramsToStore[473].Size = 50;

            paramsToStore[474] = new SqlParameter("@CriStatus3", SqlDbType.VarChar);
            paramsToStore[474].Value = objEmployeeInfo.strCriStatus3;
            paramsToStore[474].Size = 50;

            paramsToStore[475] = new SqlParameter("@CriStatus4", SqlDbType.VarChar);
            paramsToStore[475].Value = objEmployeeInfo.strCriStatus4;
            paramsToStore[475].Size = 50;

            paramsToStore[476] = new SqlParameter("@CriStatus5", SqlDbType.VarChar);
            paramsToStore[476].Value = objEmployeeInfo.strCriStatus5;
            paramsToStore[476].Size = 50;

            paramsToStore[477] = new SqlParameter("@CriStatus6", SqlDbType.VarChar);
            paramsToStore[477].Value = objEmployeeInfo.strCriStatus6;
            paramsToStore[477].Size = 50;

            paramsToStore[478] = new SqlParameter("@CriStatus7", SqlDbType.VarChar);
            paramsToStore[478].Value = objEmployeeInfo.strCriStatus7;
            paramsToStore[478].Size = 50;

            paramsToStore[479] = new SqlParameter("@CriStatus8", SqlDbType.VarChar);
            paramsToStore[479].Value = objEmployeeInfo.strCriStatus8;
            paramsToStore[479].Size = 50;

            paramsToStore[480] = new SqlParameter("@CriRemarks1", SqlDbType.VarChar);
            paramsToStore[480].Value = objEmployeeInfo.strCriRemarks1;
            paramsToStore[480].Size = 500;

            paramsToStore[481] = new SqlParameter("@CriRemarks2", SqlDbType.VarChar);
            paramsToStore[481].Value = objEmployeeInfo.strCriRemarks2;
            paramsToStore[481].Size = 500;

            paramsToStore[482] = new SqlParameter("@CriRemarks3", SqlDbType.VarChar);
            paramsToStore[482].Value = objEmployeeInfo.strCriRemarks3;
            paramsToStore[482].Size = 500;

            paramsToStore[483] = new SqlParameter("@CriRemarks4", SqlDbType.VarChar);
            paramsToStore[483].Value = objEmployeeInfo.strCriRemarks4;
            paramsToStore[483].Size = 500;

            paramsToStore[484] = new SqlParameter("@CriRemarks5", SqlDbType.VarChar);
            paramsToStore[484].Value = objEmployeeInfo.strCriRemarks5;
            paramsToStore[484].Size = 500;

            paramsToStore[485] = new SqlParameter("@CriRemarks6", SqlDbType.VarChar);
            paramsToStore[485].Value = objEmployeeInfo.strCriRemarks6;
            paramsToStore[485].Size = 500;

            paramsToStore[486] = new SqlParameter("@CriRemarks7", SqlDbType.VarChar);
            paramsToStore[486].Value = objEmployeeInfo.strCriRemarks7;
            paramsToStore[486].Size = 500;

            paramsToStore[487] = new SqlParameter("@CriRemarks8", SqlDbType.VarChar);
            paramsToStore[487].Value = objEmployeeInfo.strCriRemarks8;
            paramsToStore[487].Size = 500;


            paramsToStore[488] = new SqlParameter("@EduStatus1", SqlDbType.VarChar);
            paramsToStore[488].Value = objEmployeeInfo.strEduStatus1;
            paramsToStore[488].Size = 50;

            paramsToStore[489] = new SqlParameter("@EduStatus2", SqlDbType.VarChar);
            paramsToStore[489].Value = objEmployeeInfo.strEduStatus2;
            paramsToStore[489].Size = 50;

            paramsToStore[490] = new SqlParameter("@EduStatus3", SqlDbType.VarChar);
            paramsToStore[490].Value = objEmployeeInfo.strEduStatus3;
            paramsToStore[490].Size = 50;

            paramsToStore[491] = new SqlParameter("@EduStatus4", SqlDbType.VarChar);
            paramsToStore[491].Value = objEmployeeInfo.strEduStatus4;
            paramsToStore[491].Size = 50;

            paramsToStore[492] = new SqlParameter("@EduStatus5", SqlDbType.VarChar);
            paramsToStore[492].Value = objEmployeeInfo.strEduStatus5;
            paramsToStore[492].Size = 50;

            paramsToStore[493] = new SqlParameter("@EduStatus6", SqlDbType.VarChar);
            paramsToStore[493].Value = objEmployeeInfo.strEduStatus6;
            paramsToStore[493].Size = 50;

            paramsToStore[494] = new SqlParameter("@EduStatus7", SqlDbType.VarChar);
            paramsToStore[494].Value = objEmployeeInfo.strEduStatus7;
            paramsToStore[494].Size = 50;

            paramsToStore[495] = new SqlParameter("@EduStatus8", SqlDbType.VarChar);
            paramsToStore[495].Value = objEmployeeInfo.strEduStatus8;
            paramsToStore[495].Size = 50;

            paramsToStore[496] = new SqlParameter("@EduRemarks1", SqlDbType.VarChar);
            paramsToStore[496].Value = objEmployeeInfo.strEduRemarks1;
            paramsToStore[496].Size = 500;

            paramsToStore[497] = new SqlParameter("@EduRemarks2", SqlDbType.VarChar);
            paramsToStore[497].Value = objEmployeeInfo.strEduRemarks2;
            paramsToStore[497].Size = 500;

            paramsToStore[498] = new SqlParameter("@EduRemarks3", SqlDbType.VarChar);
            paramsToStore[498].Value = objEmployeeInfo.strEduRemarks3;
            paramsToStore[498].Size = 500;

            paramsToStore[499] = new SqlParameter("@EduRemarks4", SqlDbType.VarChar);
            paramsToStore[499].Value = objEmployeeInfo.strEduRemarks4;
            paramsToStore[499].Size = 500;

           

            paramsToStore[500] = new SqlParameter("@EduRemarks6", SqlDbType.VarChar);
            paramsToStore[500].Value = objEmployeeInfo.strEduRemarks6;
            paramsToStore[500].Size = 500;

            paramsToStore[501] = new SqlParameter("@EduRemarks7", SqlDbType.VarChar);
            paramsToStore[501].Value = objEmployeeInfo.strEduRemarks7;
            paramsToStore[501].Size = 500;

            paramsToStore[502] = new SqlParameter("@EduRemarks8", SqlDbType.VarChar);
            paramsToStore[502].Value = objEmployeeInfo.strEduRemarks8;
            paramsToStore[502].Size = 500;


            paramsToStore[503] = new SqlParameter("@EmpStatus1", SqlDbType.VarChar);
            paramsToStore[503].Value = objEmployeeInfo.strEmpStatus1;
            paramsToStore[503].Size = 50;

            paramsToStore[504] = new SqlParameter("@EmpStatus2", SqlDbType.VarChar);
            paramsToStore[504].Value = objEmployeeInfo.strEmpStatus2;
            paramsToStore[504].Size = 50;

            paramsToStore[505] = new SqlParameter("@EmpStatus3", SqlDbType.VarChar);
            paramsToStore[505].Value = objEmployeeInfo.strEmpStatus3;
            paramsToStore[505].Size = 50;

            paramsToStore[506] = new SqlParameter("@EmpStatus4", SqlDbType.VarChar);
            paramsToStore[506].Value = objEmployeeInfo.strEmpStatus4;
            paramsToStore[506].Size = 50;

            paramsToStore[507] = new SqlParameter("@EmpStatus5", SqlDbType.VarChar);
            paramsToStore[507].Value = objEmployeeInfo.strEmpStatus5;
            paramsToStore[507].Size = 50;

            paramsToStore[508] = new SqlParameter("@EmpStatus6", SqlDbType.VarChar);
            paramsToStore[508].Value = objEmployeeInfo.strEmpStatus6;
            paramsToStore[508].Size = 50;

            paramsToStore[509] = new SqlParameter("@EmpStatus7", SqlDbType.VarChar);
            paramsToStore[509].Value = objEmployeeInfo.strEmpStatus7;
            paramsToStore[509].Size = 50;

            paramsToStore[510] = new SqlParameter("@EmpStatus8", SqlDbType.VarChar);
            paramsToStore[510].Value = objEmployeeInfo.strEmpStatus8;
            paramsToStore[510].Size = 50;

            paramsToStore[511] = new SqlParameter("@EmpRemarks1", SqlDbType.VarChar);
            paramsToStore[511].Value = objEmployeeInfo.strEmpRemarks1;
            paramsToStore[511].Size = 500;

            paramsToStore[512] = new SqlParameter("@EmpRemarks2", SqlDbType.VarChar);
            paramsToStore[512].Value = objEmployeeInfo.strEmpRemarks2;
            paramsToStore[512].Size = 500;

            paramsToStore[513] = new SqlParameter("@EmpRemarks3", SqlDbType.VarChar);
            paramsToStore[513].Value = objEmployeeInfo.strEmpRemarks3;
            paramsToStore[513].Size = 500;

            paramsToStore[514] = new SqlParameter("@EmpRemarks4", SqlDbType.VarChar);
            paramsToStore[514].Value = objEmployeeInfo.strEmpRemarks4;
            paramsToStore[514].Size = 500;

            paramsToStore[515] = new SqlParameter("@EmpRemarks5", SqlDbType.VarChar);
            paramsToStore[515].Value = objEmployeeInfo.strEmpRemarks5;
            paramsToStore[515].Size = 500;

            paramsToStore[516] = new SqlParameter("@EmpRemarks6", SqlDbType.VarChar);
            paramsToStore[516].Value = objEmployeeInfo.strEmpRemarks6;
            paramsToStore[516].Size = 500;

            paramsToStore[517] = new SqlParameter("@EmpRemarks7", SqlDbType.VarChar);
            paramsToStore[517].Value = objEmployeeInfo.strEmpRemarks7;
            paramsToStore[517].Size = 500;

            paramsToStore[518] = new SqlParameter("@EmpRemarks8", SqlDbType.VarChar);
            paramsToStore[518].Value = objEmployeeInfo.strEmpRemarks8;
            paramsToStore[518].Size = 500;

            paramsToStore[519] = new SqlParameter("@RefStatus1", SqlDbType.VarChar);
            paramsToStore[519].Value = objEmployeeInfo.strRefStatus1;
            paramsToStore[519].Size = 50;

            paramsToStore[520] = new SqlParameter("@RefStatus2", SqlDbType.VarChar);
            paramsToStore[520].Value = objEmployeeInfo.strRefStatus2;
            paramsToStore[520].Size = 50;

           

          
            paramsToStore[521] = new SqlParameter("@RefRemarks1", SqlDbType.VarChar);
            paramsToStore[521].Value = objEmployeeInfo.strRefRemarks1;
            paramsToStore[521].Size = 500;

            paramsToStore[522] = new SqlParameter("@RefRemarks2", SqlDbType.VarChar);
            paramsToStore[522].Value = objEmployeeInfo.strRefRemarks2;
            paramsToStore[522].Size = 500;

            paramsToStore[523] = new SqlParameter("@RefRemarks3", SqlDbType.VarChar);
            paramsToStore[523].Value = objEmployeeInfo.strRefRemarks3;
            paramsToStore[523].Size = 500;

            paramsToStore[524] = new SqlParameter("@DBStatus", SqlDbType.VarChar);
            paramsToStore[524].Value = objEmployeeInfo.strDBStatus;
            paramsToStore[524].Size = 50;


            paramsToStore[525] = new SqlParameter("@DBRemarks", SqlDbType.VarChar);
            paramsToStore[525].Value = objEmployeeInfo.strDBRemarks;
            paramsToStore[525].Size = 500;

            paramsToStore[526] = new SqlParameter("@DrugStatus", SqlDbType.VarChar);
            paramsToStore[526].Value = objEmployeeInfo.strDrugStatus;
            paramsToStore[526].Size = 50;


            paramsToStore[527] = new SqlParameter("@DrugRemarks", SqlDbType.VarChar);
            paramsToStore[527].Value = objEmployeeInfo.strDrugRemarks;
            paramsToStore[527].Size = 500;

            //

            paramsToStore[528] = new SqlParameter("@IDStatus1", SqlDbType.VarChar);
            paramsToStore[528].Value = objEmployeeInfo.strIDStatus1;
            paramsToStore[528].Size = 50;

            paramsToStore[529] = new SqlParameter("@IDStatus2", SqlDbType.VarChar);
            paramsToStore[529].Value = objEmployeeInfo.strIDStatus2;
            paramsToStore[529].Size = 50;

            paramsToStore[530] = new SqlParameter("@IDStatus3", SqlDbType.VarChar);
            paramsToStore[530].Value = objEmployeeInfo.strIDStatus3;
            paramsToStore[530].Size = 50;

            paramsToStore[531] = new SqlParameter("@IDStatus4", SqlDbType.VarChar);
            paramsToStore[531].Value = objEmployeeInfo.strIDStatus4;
            paramsToStore[531].Size = 50;



            paramsToStore[532] = new SqlParameter("@IDRemarks1", SqlDbType.VarChar);
            paramsToStore[532].Value = objEmployeeInfo.strIDRemarks1;
            paramsToStore[532].Size = 500;

            paramsToStore[533] = new SqlParameter("@IDRemarks2", SqlDbType.VarChar);
            paramsToStore[533].Value = objEmployeeInfo.strIDRemarks2;
            paramsToStore[533].Size = 500;

            paramsToStore[534] = new SqlParameter("@IDRemarks3", SqlDbType.VarChar);
            paramsToStore[534].Value = objEmployeeInfo.strIDRemarks3;
            paramsToStore[534].Size = 500;

            paramsToStore[535] = new SqlParameter("@IDRemarks4", SqlDbType.VarChar);
            paramsToStore[535].Value = objEmployeeInfo.strIDRemarks4;
            paramsToStore[535].Size = 500;

            paramsToStore[536] = new SqlParameter("@EduDateFrm4", SqlDbType.VarChar);
            paramsToStore[536].Value = objEmployeeInfo.strEduDateFrm4;
            paramsToStore[536].Size = 50;


            paramsToStore[537] = new SqlParameter("@EduDateTo8", SqlDbType.VarChar);
            paramsToStore[537].Value = objEmployeeInfo.strEduDateTo8;
            paramsToStore[537].Size = 50;


            paramsToStore[538] = new SqlParameter("@AddRemarks5", SqlDbType.VarChar);
            paramsToStore[538].Value = objEmployeeInfo.strAddRemarks5;
            paramsToStore[538].Size = 500;

            paramsToStore[539] = new SqlParameter("@EduRemarks5", SqlDbType.VarChar);
            paramsToStore[539].Value = objEmployeeInfo.strEduRemarks5;
            paramsToStore[539].Size = 500;

            paramsToStore[540] = new SqlParameter("@RefStatus3", SqlDbType.VarChar);
            paramsToStore[540].Value = objEmployeeInfo.strRefStatus3;
            paramsToStore[540].Size = 50;

            paramsToStore[541] = new SqlParameter("@IdentityCheck2", SqlDbType.VarChar);
            paramsToStore[541].Value = objEmployeeInfo.txtIdentityCheck2;
            paramsToStore[541].Size = 50;

            paramsToStore[542] = new SqlParameter("@IdentityLocation2", SqlDbType.VarChar);
            paramsToStore[542].Value = objEmployeeInfo.txtIdentityLocation2;
            paramsToStore[542].Size = 50;

            paramsToStore[543] = new SqlParameter("@IdentityState2", SqlDbType.VarChar);
            paramsToStore[543].Value = objEmployeeInfo.txtIdentityState2;
            paramsToStore[543].Size = 50;

            paramsToStore[544] = new SqlParameter("@IdentityCheck3", SqlDbType.VarChar);
            paramsToStore[544].Value = objEmployeeInfo.txtIdentityCheck3;
            paramsToStore[544].Size = 50;

            paramsToStore[545] = new SqlParameter("@IdentityLocation3", SqlDbType.VarChar);
            paramsToStore[545].Value = objEmployeeInfo.txtIdentityLocation3;
            paramsToStore[545].Size = 50;

            paramsToStore[546] = new SqlParameter("@IdentityState3", SqlDbType.VarChar);
            paramsToStore[546].Value = objEmployeeInfo.txtIdentityState3;
            paramsToStore[546].Size = 50;

            paramsToStore[547] = new SqlParameter("@IdentityCheck4", SqlDbType.VarChar);
            paramsToStore[547].Value = objEmployeeInfo.txtIdentityCheck4;
            paramsToStore[547].Size = 50;

            paramsToStore[548] = new SqlParameter("@IdentityLocation4", SqlDbType.VarChar);
            paramsToStore[548].Value = objEmployeeInfo.txtIdentityLocation4;
            paramsToStore[548].Size = 50;

            paramsToStore[549] = new SqlParameter("@IdentityState4", SqlDbType.VarChar);
            paramsToStore[549].Value = objEmployeeInfo.txtIdentityState4;
            paramsToStore[549].Size = 50;

            paramsToStore[550] = new SqlParameter("@TATstartDate", SqlDbType.VarChar);
            paramsToStore[550].Value = objEmployeeInfo.strTATStartDate;
            paramsToStore[550].Size = 50;

            paramsToStore[551] = new SqlParameter("@CourtCheck", SqlDbType.VarChar);
            paramsToStore[551].Value = objEmployeeInfo.strCourtCheck;
            paramsToStore[551].Size = 50;

            paramsToStore[552] = new SqlParameter("@CourtAddress", SqlDbType.VarChar);
            paramsToStore[552].Value = objEmployeeInfo.strCourtAddress;
            paramsToStore[552].Size = 50;

            paramsToStore[553] = new SqlParameter("@CourtAddLoc", SqlDbType.VarChar);
            paramsToStore[553].Value = objEmployeeInfo.strCourtAddLoc;
            paramsToStore[553].Size = 50;

            paramsToStore[554] = new SqlParameter("@CourtAddState", SqlDbType.VarChar);
            paramsToStore[554].Value = objEmployeeInfo.strCourtAddState;
            paramsToStore[554].Size = 50;

            paramsToStore[555] = new SqlParameter("@CourtAddStatus", SqlDbType.VarChar);
            paramsToStore[555].Value = objEmployeeInfo.strCourtAddStatus;
            paramsToStore[555].Size = 50;

            paramsToStore[556] = new SqlParameter("@CourtAddRemarks", SqlDbType.VarChar);
            paramsToStore[556].Value = objEmployeeInfo.strCourtAddRemarks;
            paramsToStore[556].Size = 50;



            //paramsToStore[409] = new SqlParameter("@Req_Edu5", SqlDbType.VarChar);
            //paramsToStore[409].Value = objEmployeeInfo.strRequirement_edu5;
            //paramsToStore[409].Size = 50;

            //paramsToStore[500] = new SqlParameter("@Req_Edu6", SqlDbType.VarChar);
            //paramsToStore[500].Value = objEmployeeInfo.strRequirement_edu6;
            //paramsToStore[500].Size = 50;

            //paramsToStore[501] = new SqlParameter("@Req_Edu7", SqlDbType.VarChar);
            //paramsToStore[501].Value = objEmployeeInfo.strRequirement_edu7;
            //paramsToStore[501].Size = 50;

            //paramsToStore[502] = new SqlParameter("@Req_Edu8", SqlDbType.VarChar);
            //paramsToStore[502].Value = objEmployeeInfo.strRequirement_edu8;
            //paramsToStore[502].Size = 50;



            //------------------------END ------------Criminal




            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "FillAllDDLfillGrid", paramsToStore));



        }


        public int updateVerificationDetails(EmployeeInfo objEmployeeInfo, string verid, string empid, string check)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[133];

            //Address

            //Address 1
            paramsToStore[0] = new SqlParameter("@Address1CurrentAddress", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.CurrentAddress;
            paramsToStore[0].Size = 500;

            //Address 2

            paramsToStore[1] = new SqlParameter("Address2CurrentAddress", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.PermanentAddress;
            paramsToStore[1].Size = 500;

            //Address 3
            paramsToStore[2] = new SqlParameter("@Address3CurrentAddress", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.txtAddress2CurrentAddress;
            paramsToStore[2].Size = 500;

            //Address 4
            paramsToStore[3] = new SqlParameter("@Address4CurrentAddress", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.txtAddress3CurrentAddress;
            paramsToStore[3].Size = 500;

            //Address 5

            paramsToStore[4] = new SqlParameter("@Address5CurrentAddress", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.txtAddress4CurrentAddress;
            paramsToStore[4].Size = 500;

            //Address 6

            paramsToStore[5] = new SqlParameter("@Address6CurrentAddress", SqlDbType.VarChar);
            paramsToStore[5].Value = objEmployeeInfo.txtAddress5CurrentAddress;
            paramsToStore[5].Size = 500;

            //Address 7

            paramsToStore[6] = new SqlParameter("@Address7CurrentAddress", SqlDbType.VarChar);
            paramsToStore[6].Value = objEmployeeInfo.txtAddress6CurrentAddress;
            paramsToStore[6].Size = 500;

            //Address 8

            paramsToStore[7] = new SqlParameter("@Address8CurrentAddress", SqlDbType.VarChar);
            paramsToStore[7].Value = objEmployeeInfo.txtAddress7CurrentAddress;
            paramsToStore[7].Size = 500;

            /////////////////////////////////////////////////// Criminal

            // Criminal 1

            paramsToStore[8] = new SqlParameter("@Criminal1Address", SqlDbType.VarChar);
            paramsToStore[8].Value = objEmployeeInfo.Criminal1Address;
            paramsToStore[8].Size = 300;

            // Criminal 2

            paramsToStore[9] = new SqlParameter("@Criminal2Address", SqlDbType.VarChar);
            paramsToStore[9].Value = objEmployeeInfo.Criminal2Address;
            paramsToStore[9].Size = 300;

            // Criminal 3

            paramsToStore[10] = new SqlParameter("@Criminal3Address", SqlDbType.VarChar);
            paramsToStore[10].Value = objEmployeeInfo.Criminal3Address;
            paramsToStore[10].Size = 300;

            // Criminal 4

            paramsToStore[11] = new SqlParameter("@Criminal4Address", SqlDbType.VarChar);
            paramsToStore[11].Value = objEmployeeInfo.Criminal4Address;
            paramsToStore[11].Size = 300;

            // Criminal 5

            paramsToStore[12] = new SqlParameter("@Criminal5Address", SqlDbType.VarChar);
            paramsToStore[12].Value = objEmployeeInfo.Criminal5Address;
            paramsToStore[12].Size = 300;

            // Criminal 6

            paramsToStore[13] = new SqlParameter("@Criminal6Address", SqlDbType.VarChar);
            paramsToStore[13].Value = objEmployeeInfo.Criminal6Address;
            paramsToStore[13].Size = 300;

            // Criminal 7

            paramsToStore[14] = new SqlParameter("@Criminal7Address", SqlDbType.VarChar);
            paramsToStore[14].Value = objEmployeeInfo.Criminal7Address;
            paramsToStore[14].Size = 300;

            // Criminal 8

            paramsToStore[15] = new SqlParameter("@Criminal8Address", SqlDbType.VarChar);
            paramsToStore[15].Value = objEmployeeInfo.Criminal8Address;
            paramsToStore[15].Size = 300;

            ///////////////////////////////////////////////////// EMPLOYMENT

            // Employment 1

            paramsToStore[16] = new SqlParameter("@EmpHis1_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[16].Value = objEmployeeInfo.EmpHis1_CompnayNameandLocation;
            paramsToStore[16].Size = 150;

            // Employment 2

            paramsToStore[17] = new SqlParameter("@EmpHis2_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[17].Value = objEmployeeInfo.EmpHis2_CompnayNameandLocation;
            paramsToStore[17].Size = 150;

            // Employment 3

            paramsToStore[18] = new SqlParameter("@EmpHis3_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[18].Value = objEmployeeInfo.EmpHis3_CompnayNameandLocation;
            paramsToStore[18].Size = 150;

            //Company 4
            paramsToStore[19] = new SqlParameter("@EmpHis4_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[19].Value = objEmployeeInfo.EmpHis4_CompnayNameandLocation;
            paramsToStore[19].Size = 150;


            //Company 5

            paramsToStore[20] = new SqlParameter("@EmpHis5_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[20].Value = objEmployeeInfo.EmpHis5_CompnayNameandLocation;
            paramsToStore[20].Size = 150;

            //Emplyement 6
            paramsToStore[21] = new SqlParameter("@Employement6CompanyName", SqlDbType.VarChar);
            paramsToStore[21].Value = objEmployeeInfo.txtEmployement6CompanyName;
            paramsToStore[21].Size = 150;

            //Emplyement 7
            paramsToStore[22] = new SqlParameter("@Employement7CompanyName", SqlDbType.VarChar);
            paramsToStore[22].Value = objEmployeeInfo.txtEmployement7CompanyName;
            paramsToStore[22].Size = 150;


            //Emplyement 8
            paramsToStore[23] = new SqlParameter("@Employement8CompanyName", SqlDbType.VarChar);
            paramsToStore[23].Value = objEmployeeInfo.txtEmployement8CompanyName;
            paramsToStore[23].Size = 150;

            //Reference Check

            //Reference 1

            paramsToStore[24] = new SqlParameter("@RefCheck1AppName", SqlDbType.VarChar);
            paramsToStore[24].Value = objEmployeeInfo.txtRefCheck1AppName;
            paramsToStore[24].Size = 50;

            //Reference 2

            paramsToStore[25] = new SqlParameter("@RefCheck2AppName", SqlDbType.VarChar);
            paramsToStore[25].Value = objEmployeeInfo.txtRefCheck2AppName;
            paramsToStore[25].Size = 50;

            //Reference 3

            paramsToStore[26] = new SqlParameter("@RefCheck3AppName", SqlDbType.VarChar);
            paramsToStore[26].Value = objEmployeeInfo.txtRefCheck3AppName;
            paramsToStore[26].Size = 50;

            ///////////////////////////////////// EDUCATION

            // Education 1

            paramsToStore[27] = new SqlParameter("@Edu1_UniversityName", SqlDbType.VarChar);
            paramsToStore[27].Value = objEmployeeInfo.Edu1_UniversityName;
            paramsToStore[27].Size = 150;

            paramsToStore[28] = new SqlParameter("@Edu1_CollegeName", SqlDbType.VarChar);
            paramsToStore[28].Value = objEmployeeInfo.Edu1_CollegeName;
            paramsToStore[28].Size = 250;

            paramsToStore[29] = new SqlParameter("@Edu1_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[29].Value = objEmployeeInfo.Edu1_EducationalQualification;
            paramsToStore[29].Size = 100;

            paramsToStore[30] = new SqlParameter("@Edu1_RollNo", SqlDbType.VarChar);
            paramsToStore[30].Value = objEmployeeInfo.Edu1_RollNo;
            paramsToStore[30].Size = 50;

            paramsToStore[31] = new SqlParameter("@Edu1_YearOfPassing", SqlDbType.VarChar);
            paramsToStore[31].Value = objEmployeeInfo.Edu1_YearOfPassing;
            paramsToStore[31].Size = 50;


            paramsToStore[32] = new SqlParameter("@txtEducation1State", SqlDbType.VarChar);
            paramsToStore[32].Value = objEmployeeInfo.txtEducation1State;
            paramsToStore[32].Size = 50;

            paramsToStore[33] = new SqlParameter("@Edu1_Address", SqlDbType.VarChar);
            paramsToStore[33].Value = objEmployeeInfo.Edu1_Address;
            paramsToStore[33].Size = 500;

            // Education 2

            paramsToStore[34] = new SqlParameter("@Edu2_CollegeName", SqlDbType.VarChar);
            paramsToStore[34].Value = objEmployeeInfo.Edu2_CollegeName;
            paramsToStore[34].Size = 250;

            paramsToStore[35] = new SqlParameter("@Edu2_UniversityName", SqlDbType.VarChar);
            paramsToStore[35].Value = objEmployeeInfo.Edu2_UniversityName;
            paramsToStore[35].Size = 150;

            paramsToStore[36] = new SqlParameter("@Edu2_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[36].Value = objEmployeeInfo.Edu2_EducationalQualification;
            paramsToStore[36].Size = 100;

            paramsToStore[37] = new SqlParameter("@Edu2_RollNo", SqlDbType.VarChar);
            paramsToStore[37].Value = objEmployeeInfo.Edu2_RollNo;
            paramsToStore[37].Size = 50;

            paramsToStore[38] = new SqlParameter("@YearOfPassing2", SqlDbType.VarChar);
            paramsToStore[38].Value = objEmployeeInfo.YearOfPassing2;
            paramsToStore[38].Size = 50;

            paramsToStore[39] = new SqlParameter("@txtEducation2State", SqlDbType.VarChar);
            paramsToStore[39].Value = objEmployeeInfo.txtEducation2State;
            paramsToStore[39].Size = 50;

            paramsToStore[40] = new SqlParameter("@Edu2_Address", SqlDbType.VarChar);
            paramsToStore[40].Value = objEmployeeInfo.Edu2_Address;
            paramsToStore[40].Size = 500;

            // Education 3


            paramsToStore[41] = new SqlParameter("@Edu3_CollegeName", SqlDbType.VarChar);
            paramsToStore[41].Value = objEmployeeInfo.Edu3_CollegeName;
            paramsToStore[41].Size = 250;

            paramsToStore[42] = new SqlParameter("@Edu3_UniversityName", SqlDbType.VarChar);
            paramsToStore[42].Value = objEmployeeInfo.Edu3_UniversityName;
            paramsToStore[42].Size = 150;

            paramsToStore[43] = new SqlParameter("@Edu3_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[43].Value = objEmployeeInfo.Edu3_EducationalQualification;
            paramsToStore[43].Size = 100;

            paramsToStore[44] = new SqlParameter("@Edu3_RollNo", SqlDbType.VarChar);
            paramsToStore[44].Value = objEmployeeInfo.Edu3_RollNo;
            paramsToStore[44].Size = 50;

            paramsToStore[45] = new SqlParameter("@YearOfPassing3", SqlDbType.VarChar);
            paramsToStore[45].Value = objEmployeeInfo.YearOfPassing3;
            paramsToStore[45].Size = 50;

            paramsToStore[46] = new SqlParameter("@Edu3_Address", SqlDbType.VarChar);
            paramsToStore[46].Value = objEmployeeInfo.Edu3_Address;
            paramsToStore[46].Size = 500;

            paramsToStore[47] = new SqlParameter("@txtEducation3State", SqlDbType.VarChar);
            paramsToStore[47].Value = objEmployeeInfo.txtEducation3State;
            paramsToStore[47].Size = 50;

            // education 4


            paramsToStore[48] = new SqlParameter("@Edu4_CollegeName", SqlDbType.VarChar);
            paramsToStore[48].Value = objEmployeeInfo.Edu4_CollegeName;
            paramsToStore[48].Size = 250;


            paramsToStore[49] = new SqlParameter("@Edu4_UniversityName", SqlDbType.VarChar);
            paramsToStore[49].Value = objEmployeeInfo.Edu4_UniversityName;
            paramsToStore[49].Size = 150;

            paramsToStore[50] = new SqlParameter("@Edu4_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[50].Value = objEmployeeInfo.Edu4_EducationalQualification;
            paramsToStore[50].Size = 100;

            paramsToStore[51] = new SqlParameter("@Edu4_RollNo", SqlDbType.VarChar);
            paramsToStore[51].Value = objEmployeeInfo.Edu4_RollNo;
            paramsToStore[51].Size = 50;

            paramsToStore[52] = new SqlParameter("@YearOfPassing4", SqlDbType.VarChar);
            paramsToStore[52].Value = objEmployeeInfo.YearOfPassing4;
            paramsToStore[52].Size = 50;

            paramsToStore[53] = new SqlParameter("@Edu4_Address", SqlDbType.VarChar);
            paramsToStore[53].Value = objEmployeeInfo.Edu4_Address;
            paramsToStore[53].Size = 500;

            paramsToStore[54] = new SqlParameter("@txtEducation4State", SqlDbType.VarChar);
            paramsToStore[54].Value = objEmployeeInfo.txtEducation4State;
            paramsToStore[54].Size = 50;

            //Education 5

            paramsToStore[55] = new SqlParameter("@Education5CollegeName", SqlDbType.VarChar);
            paramsToStore[55].Value = objEmployeeInfo.txtEducation5CollegeName;
            paramsToStore[55].Size = 250;

            paramsToStore[56] = new SqlParameter("@Education5UniversityName", SqlDbType.VarChar);
            paramsToStore[56].Value = objEmployeeInfo.txtEducation5UniversityName;
            paramsToStore[56].Size = 150;

            paramsToStore[57] = new SqlParameter("@Education5EQ", SqlDbType.VarChar);
            paramsToStore[57].Value = objEmployeeInfo.txtEducation5EQ;
            paramsToStore[57].Size = 50;

            paramsToStore[58] = new SqlParameter("@Education5YearofPassing", SqlDbType.VarChar);
            paramsToStore[58].Value = objEmployeeInfo.txtEducation5YearofPassing;
            paramsToStore[58].Size = 50;

            paramsToStore[59] = new SqlParameter("@Education5RollNo", SqlDbType.VarChar);
            paramsToStore[59].Value = objEmployeeInfo.txtEducation5RollNo;
            paramsToStore[59].Size = 50;

            paramsToStore[60] = new SqlParameter("@Education5State", SqlDbType.VarChar);
            paramsToStore[60].Value = objEmployeeInfo.txtEducation5State;
            paramsToStore[60].Size = 50;



            //Education 6 

            paramsToStore[61] = new SqlParameter("@Education6CollegeName", SqlDbType.VarChar);
            paramsToStore[61].Value = objEmployeeInfo.txtEducation6CollegeName;
            paramsToStore[61].Size = 250;

            paramsToStore[62] = new SqlParameter("@Education6UniversityName", SqlDbType.VarChar);
            paramsToStore[62].Value = objEmployeeInfo.txtEducation6UniversityName;
            paramsToStore[62].Size = 150;

            paramsToStore[63] = new SqlParameter("@Education6EQ", SqlDbType.VarChar);
            paramsToStore[63].Value = objEmployeeInfo.txtEducation6EQ;
            paramsToStore[63].Size = 50;

            paramsToStore[64] = new SqlParameter("@Education6YearofPassing", SqlDbType.VarChar);
            paramsToStore[64].Value = objEmployeeInfo.txtEducation6YearofPassing;
            paramsToStore[64].Size = 50;

            paramsToStore[65] = new SqlParameter("@Education6RollNo", SqlDbType.VarChar);
            paramsToStore[65].Value = objEmployeeInfo.txtEducation6RollNo;
            paramsToStore[65].Size = 50;

            paramsToStore[66] = new SqlParameter("@Education6State", SqlDbType.VarChar);
            paramsToStore[66].Value = objEmployeeInfo.txtEducation6State;
            paramsToStore[66].Size = 50;



            //Education 7 

            paramsToStore[67] = new SqlParameter("@Education7CollegeName", SqlDbType.VarChar);
            paramsToStore[67].Value = objEmployeeInfo.txtEducation7CollegeName;
            paramsToStore[67].Size = 250;

            paramsToStore[68] = new SqlParameter("@Education7UniversityName", SqlDbType.VarChar);
            paramsToStore[68].Value = objEmployeeInfo.txtEducation7UniversityName;
            paramsToStore[68].Size = 150;

            paramsToStore[69] = new SqlParameter("@Education7EQ", SqlDbType.VarChar);
            paramsToStore[69].Value = objEmployeeInfo.txtEducation7EQ;
            paramsToStore[69].Size = 50;

            paramsToStore[70] = new SqlParameter("@Education7YearofPassing", SqlDbType.VarChar);
            paramsToStore[70].Value = objEmployeeInfo.txtEducation7YearofPassing;
            paramsToStore[70].Size = 50;

            paramsToStore[71] = new SqlParameter("@Education7RollNo", SqlDbType.VarChar);
            paramsToStore[71].Value = objEmployeeInfo.txtEducation7RollNo;
            paramsToStore[71].Size = 50;

            paramsToStore[72] = new SqlParameter("@Education7State", SqlDbType.VarChar);
            paramsToStore[72].Value = objEmployeeInfo.txtEducation7State;
            paramsToStore[72].Size = 50;



            //Education 8 

            paramsToStore[73] = new SqlParameter("@Education8CollegeName", SqlDbType.VarChar);
            paramsToStore[73].Value = objEmployeeInfo.txtEducation8CollegeName;
            paramsToStore[73].Size = 250;

            paramsToStore[74] = new SqlParameter("@Education8UniversityName", SqlDbType.VarChar);
            paramsToStore[74].Value = objEmployeeInfo.txtEducation8UniversityName;
            paramsToStore[74].Size = 150;

            paramsToStore[75] = new SqlParameter("@Education8EQ", SqlDbType.VarChar);
            paramsToStore[75].Value = objEmployeeInfo.txtEducation8EQ;
            paramsToStore[75].Size = 50;

            paramsToStore[76] = new SqlParameter("@Education8YearofPassing", SqlDbType.VarChar);
            paramsToStore[76].Value = objEmployeeInfo.txtEducation8YearofPassing;
            paramsToStore[76].Size = 50;

            paramsToStore[77] = new SqlParameter("@Education8RollNo", SqlDbType.VarChar);
            paramsToStore[77].Value = objEmployeeInfo.txtEducation8RollNo;
            paramsToStore[77].Size = 50;

            paramsToStore[78] = new SqlParameter("@Education8State", SqlDbType.VarChar);
            paramsToStore[78].Value = objEmployeeInfo.txtEducation8State;
            paramsToStore[78].Size = 50;





            // DATABASE 

            paramsToStore[79] = new SqlParameter("@DatabaseCheck", SqlDbType.VarChar);
            paramsToStore[79].Value = objEmployeeInfo.txtDatabaseCheck;
            paramsToStore[79].Size = 50;

            //DRUG


            paramsToStore[80] = new SqlParameter("@DrugCheck", SqlDbType.VarChar);
            paramsToStore[80].Value = objEmployeeInfo.txtDrugCheck;
            paramsToStore[80].Size = 50;

            // IDENTITY

            // Identity 1

            paramsToStore[81] = new SqlParameter("@IdentityCheck1", SqlDbType.VarChar);
            paramsToStore[81].Value = objEmployeeInfo.txtIdentityCheck;
            paramsToStore[81].Size = 50;

            // Identity 2

            paramsToStore[82] = new SqlParameter("@IdentityCheck2", SqlDbType.VarChar);
            paramsToStore[82].Value = objEmployeeInfo.txtIdentityCheck2;
            paramsToStore[82].Size = 50;

            // Identity 3

            paramsToStore[83] = new SqlParameter("@IdentityCheck3", SqlDbType.VarChar);
            paramsToStore[83].Value = objEmployeeInfo.txtIdentityCheck3;
            paramsToStore[83].Size = 50;

            // Identity 4


            paramsToStore[84] = new SqlParameter("@IdentityCheck4", SqlDbType.VarChar);
            paramsToStore[84].Value = objEmployeeInfo.txtIdentityCheck4;
            paramsToStore[84].Size = 50;

            //---------------------------End All Checks


            // Requirement type of Education 1,2,3,4


            paramsToStore[85] = new SqlParameter("@Req_Edu1", SqlDbType.VarChar);
            paramsToStore[85].Value = objEmployeeInfo.strRequirement_edu1;
            paramsToStore[85].Size = 50;

            paramsToStore[86] = new SqlParameter("@Req_Edu2", SqlDbType.VarChar);
            paramsToStore[86].Value = objEmployeeInfo.strRequirement_edu2;
            paramsToStore[86].Size = 50;

            paramsToStore[87] = new SqlParameter("@Req_Edu3", SqlDbType.VarChar);
            paramsToStore[87].Value = objEmployeeInfo.strRequirement_edu3;
            paramsToStore[87].Size = 50;

            paramsToStore[88] = new SqlParameter("@Req_Edu4", SqlDbType.VarChar);
            paramsToStore[88].Value = objEmployeeInfo.strRequirement_edu4;
            paramsToStore[88].Size = 50;

            // Address 1,2,3,4,5,6,7,8

            paramsToStore[89] = new SqlParameter("@AddRemarks1", SqlDbType.VarChar);
            paramsToStore[89].Value = objEmployeeInfo.strAddRemarks1;
            paramsToStore[89].Size = 500;

            paramsToStore[90] = new SqlParameter("@AddRemarks2", SqlDbType.VarChar);
            paramsToStore[90].Value = objEmployeeInfo.strAddRemarks2;
            paramsToStore[90].Size = 500;

            paramsToStore[91] = new SqlParameter("@AddRemarks3", SqlDbType.VarChar);
            paramsToStore[91].Value = objEmployeeInfo.strAddRemarks3;
            paramsToStore[91].Size = 500;

            paramsToStore[92] = new SqlParameter("@AddRemarks4", SqlDbType.VarChar);
            paramsToStore[92].Value = objEmployeeInfo.strAddRemarks4;
            paramsToStore[92].Size = 500;

            paramsToStore[93] = new SqlParameter("@AddRemarks5", SqlDbType.VarChar);
            paramsToStore[93].Value = objEmployeeInfo.strAddRemarks5;
            paramsToStore[93].Size = 500;

            paramsToStore[94] = new SqlParameter("@AddRemarks6", SqlDbType.VarChar);
            paramsToStore[94].Value = objEmployeeInfo.strAddRemarks6;
            paramsToStore[94].Size = 500;

            paramsToStore[95] = new SqlParameter("@AddRemarks7", SqlDbType.VarChar);
            paramsToStore[95].Value = objEmployeeInfo.strAddRemarks7;
            paramsToStore[95].Size = 500;

            paramsToStore[96] = new SqlParameter("@AddRemarks8", SqlDbType.VarChar);
            paramsToStore[96].Value = objEmployeeInfo.strAddRemarks8;
            paramsToStore[96].Size = 500;

            // Criminal 1,2,3,4,5,6,7,8

            paramsToStore[97] = new SqlParameter("@CriRemarks1", SqlDbType.VarChar);
            paramsToStore[97].Value = objEmployeeInfo.strCriRemarks1;
            paramsToStore[97].Size = 500;

            paramsToStore[98] = new SqlParameter("@CriRemarks2", SqlDbType.VarChar);
            paramsToStore[98].Value = objEmployeeInfo.strCriRemarks2;
            paramsToStore[98].Size = 500;

            paramsToStore[99] = new SqlParameter("@CriRemarks3", SqlDbType.VarChar);
            paramsToStore[99].Value = objEmployeeInfo.strCriRemarks3;
            paramsToStore[99].Size = 500;

            paramsToStore[100] = new SqlParameter("@CriRemarks4", SqlDbType.VarChar);
            paramsToStore[100].Value = objEmployeeInfo.strCriRemarks4;
            paramsToStore[100].Size = 500;

            paramsToStore[101] = new SqlParameter("@CriRemarks5", SqlDbType.VarChar);
            paramsToStore[101].Value = objEmployeeInfo.strCriRemarks5;
            paramsToStore[101].Size = 500;

            paramsToStore[102] = new SqlParameter("@CriRemarks6", SqlDbType.VarChar);
            paramsToStore[102].Value = objEmployeeInfo.strCriRemarks6;
            paramsToStore[102].Size = 500;

            paramsToStore[103] = new SqlParameter("@CriRemarks7", SqlDbType.VarChar);
            paramsToStore[103].Value = objEmployeeInfo.strCriRemarks7;
            paramsToStore[103].Size = 500;

            paramsToStore[104] = new SqlParameter("@CriRemarks8", SqlDbType.VarChar);
            paramsToStore[104].Value = objEmployeeInfo.strCriRemarks8;
            paramsToStore[104].Size = 500;

            // Education 1,2,3,4,5,6,7,8

            paramsToStore[105] = new SqlParameter("@EduRemarks1", SqlDbType.VarChar);
            paramsToStore[105].Value = objEmployeeInfo.strEduRemarks1;
            paramsToStore[105].Size = 500;

            paramsToStore[106] = new SqlParameter("@EduRemarks2", SqlDbType.VarChar);
            paramsToStore[106].Value = objEmployeeInfo.strEduRemarks2;
            paramsToStore[106].Size = 500;

            paramsToStore[107] = new SqlParameter("@EduRemarks3", SqlDbType.VarChar);
            paramsToStore[107].Value = objEmployeeInfo.strEduRemarks3;
            paramsToStore[107].Size = 500;

            paramsToStore[108] = new SqlParameter("@EduRemarks4", SqlDbType.VarChar);
            paramsToStore[108].Value = objEmployeeInfo.strEduRemarks4;
            paramsToStore[108].Size = 500;

            paramsToStore[109] = new SqlParameter("@EduRemarks5", SqlDbType.VarChar);
            paramsToStore[109].Value = objEmployeeInfo.strEduRemarks5;
            paramsToStore[109].Size = 500;

            paramsToStore[110] = new SqlParameter("@EduRemarks6", SqlDbType.VarChar);
            paramsToStore[110].Value = objEmployeeInfo.strEduRemarks6;
            paramsToStore[110].Size = 500;

            paramsToStore[111] = new SqlParameter("@EduRemarks7", SqlDbType.VarChar);
            paramsToStore[111].Value = objEmployeeInfo.strEduRemarks7;
            paramsToStore[111].Size = 500;

            paramsToStore[112] = new SqlParameter("@EduRemarks8", SqlDbType.VarChar);
            paramsToStore[112].Value = objEmployeeInfo.strEduRemarks8;
            paramsToStore[112].Size = 500;

            // Employment 1,2,3,4,5,6,7,8

            paramsToStore[113] = new SqlParameter("@EmpRemarks1", SqlDbType.VarChar);
            paramsToStore[113].Value = objEmployeeInfo.strEmpRemarks1;
            paramsToStore[113].Size = 500;

            paramsToStore[114] = new SqlParameter("@EmpRemarks2", SqlDbType.VarChar);
            paramsToStore[114].Value = objEmployeeInfo.strEmpRemarks2;
            paramsToStore[114].Size = 500;

            paramsToStore[115] = new SqlParameter("@EmpRemarks3", SqlDbType.VarChar);
            paramsToStore[115].Value = objEmployeeInfo.strEmpRemarks3;
            paramsToStore[115].Size = 500;

            paramsToStore[116] = new SqlParameter("@EmpRemarks4", SqlDbType.VarChar);
            paramsToStore[116].Value = objEmployeeInfo.strEmpRemarks4;
            paramsToStore[116].Size = 500;

            paramsToStore[117] = new SqlParameter("@EmpRemarks5", SqlDbType.VarChar);
            paramsToStore[117].Value = objEmployeeInfo.strEmpRemarks5;
            paramsToStore[117].Size = 500;

            paramsToStore[118] = new SqlParameter("@EmpRemarks6", SqlDbType.VarChar);
            paramsToStore[118].Value = objEmployeeInfo.strEmpRemarks6;
            paramsToStore[118].Size = 500;

            paramsToStore[119] = new SqlParameter("@EmpRemarks7", SqlDbType.VarChar);
            paramsToStore[119].Value = objEmployeeInfo.strEmpRemarks7;
            paramsToStore[119].Size = 500;

            paramsToStore[120] = new SqlParameter("@EmpRemarks8", SqlDbType.VarChar);
            paramsToStore[120].Value = objEmployeeInfo.strEmpRemarks8;
            paramsToStore[120].Size = 500;



            // REf 1,2,3


            paramsToStore[121] = new SqlParameter("@RefRemarks1", SqlDbType.VarChar);
            paramsToStore[121].Value = objEmployeeInfo.strRefRemarks1;
            paramsToStore[121].Size = 500;

            paramsToStore[122] = new SqlParameter("@RefRemarks2", SqlDbType.VarChar);
            paramsToStore[122].Value = objEmployeeInfo.strRefRemarks2;
            paramsToStore[122].Size = 500;

            paramsToStore[123] = new SqlParameter("@RefRemarks3", SqlDbType.VarChar);
            paramsToStore[123].Value = objEmployeeInfo.strRefRemarks3;
            paramsToStore[123].Size = 500;

            //DB

            paramsToStore[124] = new SqlParameter("@DBRemarks", SqlDbType.VarChar);
            paramsToStore[124].Value = objEmployeeInfo.strDBRemarks;
            paramsToStore[124].Size = 500;

            // Drug

            paramsToStore[125] = new SqlParameter("@DrugRemarks", SqlDbType.VarChar);
            paramsToStore[125].Value = objEmployeeInfo.strDrugRemarks;
            paramsToStore[125].Size = 500;


            // Identity 1,2,3,4

            paramsToStore[126] = new SqlParameter("@IDRemarks1", SqlDbType.VarChar);
            paramsToStore[126].Value = objEmployeeInfo.strIDRemarks1;
            paramsToStore[126].Size = 500;

            paramsToStore[127] = new SqlParameter("@IDRemarks2", SqlDbType.VarChar);
            paramsToStore[127].Value = objEmployeeInfo.strIDRemarks2;
            paramsToStore[127].Size = 500;

            paramsToStore[128] = new SqlParameter("@IDRemarks3", SqlDbType.VarChar);
            paramsToStore[128].Value = objEmployeeInfo.strIDRemarks3;
            paramsToStore[128].Size = 500;

            paramsToStore[129] = new SqlParameter("@IDRemarks4", SqlDbType.VarChar);
            paramsToStore[129].Value = objEmployeeInfo.strIDRemarks4;
            paramsToStore[129].Size = 500;

            paramsToStore[130] = new SqlParameter("@EmpID", SqlDbType.VarChar);
            paramsToStore[130].Value = empid;

            paramsToStore[131] = new SqlParameter("@VerID", SqlDbType.VarChar);
            paramsToStore[131].Value = verid;

            paramsToStore[132] = new SqlParameter("@check", SqlDbType.VarChar);
            paramsToStore[132].Value = check;






            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UpdateVerificationDetails", paramsToStore));



        }


        public int saveUniversityCollegeInfo(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[18];
            // 213+173



            paramsToStore[0] = new SqlParameter("@UniName", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.strUniName;
            paramsToStore[0].Size = 150;

            paramsToStore[1] = new SqlParameter("@UniLocation", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.strUniLoc;
            paramsToStore[1].Size = 100;

            paramsToStore[2] = new SqlParameter("@UniConPerson", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.strUniConPer;
            paramsToStore[2].Size = 100;

            paramsToStore[3] = new SqlParameter("@UniDesignation", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.strUniDesig;
            paramsToStore[3].Size = 100;

            paramsToStore[4] = new SqlParameter("@UniConNo1", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.strUniNo1;
            paramsToStore[4].Size = 50;

            paramsToStore[5] = new SqlParameter("@UniConNo2", SqlDbType.VarChar);
            paramsToStore[5].Value = objEmployeeInfo.strUniNo2;
            paramsToStore[5].Size = 50;

            paramsToStore[6] = new SqlParameter("@UniConPerson1", SqlDbType.VarChar);
            paramsToStore[6].Value = objEmployeeInfo.strUniConPer1;
            paramsToStore[6].Size = 100;

            paramsToStore[7] = new SqlParameter("@UniDesignation1", SqlDbType.VarChar);
            paramsToStore[7].Value = objEmployeeInfo.strUniDesig1;
            paramsToStore[7].Size = 100;

            paramsToStore[8] = new SqlParameter("@UniConNo3", SqlDbType.VarChar);
            paramsToStore[8].Value = objEmployeeInfo.strUniNo3;
            paramsToStore[8].Size = 50;

            paramsToStore[9] = new SqlParameter("@UniConNo4", SqlDbType.VarChar);
            paramsToStore[9].Value = objEmployeeInfo.strUniNo4;
            paramsToStore[9].Size = 50;

            paramsToStore[10] = new SqlParameter("@UniDD", SqlDbType.VarChar);
            paramsToStore[10].Value = objEmployeeInfo.strUniDD;
            paramsToStore[10].Size = 50;

            paramsToStore[11] = new SqlParameter("@UniDDto", SqlDbType.VarChar);
            paramsToStore[11].Value = objEmployeeInfo.strUniDDto;
            paramsToStore[11].Size = 50;

            paramsToStore[12] = new SqlParameter("@UniDDAddress", SqlDbType.VarChar);
            paramsToStore[12].Value = objEmployeeInfo.strUniDDadd;
            paramsToStore[12].Size = 200;

            paramsToStore[13] = new SqlParameter("@UniTime", SqlDbType.VarChar);
            paramsToStore[13].Value = objEmployeeInfo.strUniTime;
            paramsToStore[13].Size = 50;

            paramsToStore[14] = new SqlParameter("@UniMail", SqlDbType.VarChar);
            paramsToStore[14].Value = objEmployeeInfo.strUniMail;
            paramsToStore[14].Size = 100;

            paramsToStore[15] = new SqlParameter("@UniWebsite", SqlDbType.VarChar);
            paramsToStore[15].Value = objEmployeeInfo.strUniWeb;
            paramsToStore[15].Size = 100;

            paramsToStore[16] = new SqlParameter("@UniRemarks", SqlDbType.VarChar);
            paramsToStore[16].Value = objEmployeeInfo.strUniRemark;
            paramsToStore[16].Size = 500;

            //paramsToStore[17] = new SqlParameter("@ColName", SqlDbType.VarChar);
            //paramsToStore[17].Value = objEmployeeInfo.strColName;
            //paramsToStore[17].Size = 150;

            //paramsToStore[18] = new SqlParameter("@ColLocation", SqlDbType.VarChar);
            //paramsToStore[18].Value = objEmployeeInfo.strColLoc;
            //paramsToStore[18].Size = 100;

            //paramsToStore[19] = new SqlParameter("@ColConPerson", SqlDbType.VarChar);
            //paramsToStore[19].Value = objEmployeeInfo.strColConPer;
            //paramsToStore[19].Size = 100;

            //paramsToStore[20] = new SqlParameter("@ColDesignation", SqlDbType.VarChar);
            //paramsToStore[20].Value = objEmployeeInfo.strColDesig;
            //paramsToStore[20].Size = 100;

            //paramsToStore[21] = new SqlParameter("@ColConNo1", SqlDbType.VarChar);
            //paramsToStore[21].Value = objEmployeeInfo.strColNo1;
            //paramsToStore[21].Size = 50;

            //paramsToStore[22] = new SqlParameter("@ColConNo2", SqlDbType.VarChar);
            //paramsToStore[22].Value = objEmployeeInfo.strColNo2;
            //paramsToStore[22].Size = 50;

            //paramsToStore[23] = new SqlParameter("@ColConPerson1", SqlDbType.VarChar);
            //paramsToStore[23].Value = objEmployeeInfo.strColConPer1;
            //paramsToStore[23].Size = 100;

            //paramsToStore[24] = new SqlParameter("@ColDesignation1", SqlDbType.VarChar);
            //paramsToStore[24].Value = objEmployeeInfo.strColDesig1;
            //paramsToStore[24].Size = 100;

            //paramsToStore[25] = new SqlParameter("@ColConNo3", SqlDbType.VarChar);
            //paramsToStore[25].Value = objEmployeeInfo.strColNo3;
            //paramsToStore[25].Size = 50;

            //paramsToStore[26] = new SqlParameter("@ColConNo4", SqlDbType.VarChar);
            //paramsToStore[26].Value = objEmployeeInfo.strColNo4;
            //paramsToStore[26].Size = 50;

            //paramsToStore[27] = new SqlParameter("@ColDD", SqlDbType.VarChar);
            //paramsToStore[27].Value = objEmployeeInfo.strColDD;
            //paramsToStore[27].Size = 50;

            //paramsToStore[28] = new SqlParameter("@ColDDto", SqlDbType.VarChar);
            //paramsToStore[28].Value = objEmployeeInfo.strColDDto;
            //paramsToStore[28].Size = 50;

            //paramsToStore[29] = new SqlParameter("@ColDDAddress", SqlDbType.VarChar);
            //paramsToStore[29].Value = objEmployeeInfo.strColDDadd;
            //paramsToStore[29].Size = 150;

            //paramsToStore[30] = new SqlParameter("@ColTime", SqlDbType.VarChar);
            //paramsToStore[30].Value = objEmployeeInfo.strColTime;
            //paramsToStore[30].Size = 50;

            //paramsToStore[31] = new SqlParameter("@ColMail", SqlDbType.VarChar);
            //paramsToStore[31].Value = objEmployeeInfo.strColMail;
            //paramsToStore[31].Size = 50;

            //paramsToStore[32] = new SqlParameter("@ColWebsite", SqlDbType.VarChar);
            //paramsToStore[32].Value = objEmployeeInfo.strColWeb;
            //paramsToStore[32].Size = 50;

            //paramsToStore[33] = new SqlParameter("@ColRemarks", SqlDbType.VarChar);
            //paramsToStore[33].Value = objEmployeeInfo.strColRemark;
            //paramsToStore[33].Size = 500;

            paramsToStore[17] = new SqlParameter("@telecaller", SqlDbType.VarChar);
            paramsToStore[17].Value = objEmployeeInfo.strUser;
            paramsToStore[17].Size = 50;





            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SaveUniversityCollegeInfo", paramsToStore));

        }


        public int addColg(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[36];
            // 213+173



            paramsToStore[0] = new SqlParameter("@UniName", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.strUniName;
            paramsToStore[0].Size = 150;

            paramsToStore[1] = new SqlParameter("@UniLocation", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.strUniLoc;
            paramsToStore[1].Size = 100;

            paramsToStore[2] = new SqlParameter("@UniConPerson", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.strUniConPer;
            paramsToStore[2].Size = 100;

            paramsToStore[3] = new SqlParameter("@UniDesignation", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.strUniDesig;
            paramsToStore[3].Size = 100;

            paramsToStore[4] = new SqlParameter("@UniConNo1", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.strUniNo1;
            paramsToStore[4].Size = 50;

            paramsToStore[5] = new SqlParameter("@UniConNo2", SqlDbType.VarChar);
            paramsToStore[5].Value = objEmployeeInfo.strUniNo2;
            paramsToStore[5].Size = 50;

            paramsToStore[6] = new SqlParameter("@UniConPerson1", SqlDbType.VarChar);
            paramsToStore[6].Value = objEmployeeInfo.strUniConPer1;
            paramsToStore[6].Size = 100;

            paramsToStore[7] = new SqlParameter("@UniDesignation1", SqlDbType.VarChar);
            paramsToStore[7].Value = objEmployeeInfo.strUniDesig1;
            paramsToStore[7].Size = 100;

            paramsToStore[8] = new SqlParameter("@UniConNo3", SqlDbType.VarChar);
            paramsToStore[8].Value = objEmployeeInfo.strUniNo3;
            paramsToStore[8].Size = 50;

            paramsToStore[9] = new SqlParameter("@UniConNo4", SqlDbType.VarChar);
            paramsToStore[9].Value = objEmployeeInfo.strUniNo4;
            paramsToStore[9].Size = 50;

            paramsToStore[10] = new SqlParameter("@UniDD", SqlDbType.VarChar);
            paramsToStore[10].Value = objEmployeeInfo.strUniDD;
            paramsToStore[10].Size = 50;

            paramsToStore[11] = new SqlParameter("@UniDDto", SqlDbType.VarChar);
            paramsToStore[11].Value = objEmployeeInfo.strUniDDto;
            paramsToStore[11].Size = 50;

            paramsToStore[12] = new SqlParameter("@UniDDAddress", SqlDbType.VarChar);
            paramsToStore[12].Value = objEmployeeInfo.strUniDDadd;
            paramsToStore[12].Size = 200;

            paramsToStore[13] = new SqlParameter("@UniTime", SqlDbType.VarChar);
            paramsToStore[13].Value = objEmployeeInfo.strUniTime;
            paramsToStore[13].Size = 50;

            paramsToStore[14] = new SqlParameter("@UniMail", SqlDbType.VarChar);
            paramsToStore[14].Value = objEmployeeInfo.strUniMail;
            paramsToStore[14].Size = 100;

            paramsToStore[15] = new SqlParameter("@UniWebsite", SqlDbType.VarChar);
            paramsToStore[15].Value = objEmployeeInfo.strUniWeb;
            paramsToStore[15].Size = 100;

            paramsToStore[16] = new SqlParameter("@UniRemarks", SqlDbType.VarChar);
            paramsToStore[16].Value = objEmployeeInfo.strUniRemark;
            paramsToStore[16].Size = 500;

            paramsToStore[17] = new SqlParameter("@ColName", SqlDbType.VarChar);
            paramsToStore[17].Value = objEmployeeInfo.strColName;
            paramsToStore[17].Size = 150;

            paramsToStore[18] = new SqlParameter("@ColLocation", SqlDbType.VarChar);
            paramsToStore[18].Value = objEmployeeInfo.strColLoc;
            paramsToStore[18].Size = 100;

            paramsToStore[19] = new SqlParameter("@ColConPerson", SqlDbType.VarChar);
            paramsToStore[19].Value = objEmployeeInfo.strColConPer;
            paramsToStore[19].Size = 100;

            paramsToStore[20] = new SqlParameter("@ColDesignation", SqlDbType.VarChar);
            paramsToStore[20].Value = objEmployeeInfo.strColDesig;
            paramsToStore[20].Size = 100;

            paramsToStore[21] = new SqlParameter("@ColConNo1", SqlDbType.VarChar);
            paramsToStore[21].Value = objEmployeeInfo.strColNo1;
            paramsToStore[21].Size = 50;

            paramsToStore[22] = new SqlParameter("@ColConNo2", SqlDbType.VarChar);
            paramsToStore[22].Value = objEmployeeInfo.strColNo2;
            paramsToStore[22].Size = 50;

            paramsToStore[23] = new SqlParameter("@ColConPerson1", SqlDbType.VarChar);
            paramsToStore[23].Value = objEmployeeInfo.strColConPer1;
            paramsToStore[23].Size = 100;

            paramsToStore[24] = new SqlParameter("@ColDesignation1", SqlDbType.VarChar);
            paramsToStore[24].Value = objEmployeeInfo.strColDesig1;
            paramsToStore[24].Size = 100;

            paramsToStore[25] = new SqlParameter("@ColConNo3", SqlDbType.VarChar);
            paramsToStore[25].Value = objEmployeeInfo.strColNo3;
            paramsToStore[25].Size = 50;

            paramsToStore[26] = new SqlParameter("@ColConNo4", SqlDbType.VarChar);
            paramsToStore[26].Value = objEmployeeInfo.strColNo4;
            paramsToStore[26].Size = 50;

            paramsToStore[27] = new SqlParameter("@ColDD", SqlDbType.VarChar);
            paramsToStore[27].Value = objEmployeeInfo.strColDD;
            paramsToStore[27].Size = 50;

            paramsToStore[28] = new SqlParameter("@ColDDto", SqlDbType.VarChar);
            paramsToStore[28].Value = objEmployeeInfo.strColDDto;
            paramsToStore[28].Size = 50;

            paramsToStore[29] = new SqlParameter("@ColDDAddress", SqlDbType.VarChar);
            paramsToStore[29].Value = objEmployeeInfo.strColDDadd;
            paramsToStore[29].Size = 150;

            paramsToStore[30] = new SqlParameter("@ColTime", SqlDbType.VarChar);
            paramsToStore[30].Value = objEmployeeInfo.strColTime;
            paramsToStore[30].Size = 50;

            paramsToStore[31] = new SqlParameter("@ColMail", SqlDbType.VarChar);
            paramsToStore[31].Value = objEmployeeInfo.strColMail;
            paramsToStore[31].Size = 50;

            paramsToStore[32] = new SqlParameter("@ColWebsite", SqlDbType.VarChar);
            paramsToStore[32].Value = objEmployeeInfo.strColWeb;
            paramsToStore[32].Size = 50;

            paramsToStore[33] = new SqlParameter("@ColRemarks", SqlDbType.VarChar);
            paramsToStore[33].Value = objEmployeeInfo.strColRemark;
            paramsToStore[33].Size = 500;

            paramsToStore[34] = new SqlParameter("@telecaller", SqlDbType.VarChar);
            paramsToStore[34].Value = objEmployeeInfo.strUser;
            paramsToStore[34].Size = 50;

            paramsToStore[35] = new SqlParameter("@CMode", SqlDbType.VarChar);
            paramsToStore[35].Value = objEmployeeInfo.strMode;






            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "addColg", paramsToStore));

        }

        public int editUniversity(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[17];
            // 213+173



            paramsToStore[0] = new SqlParameter("@UniName", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.strUniName;
            paramsToStore[0].Size = 150;

            paramsToStore[1] = new SqlParameter("@UniLocation", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.strUniLoc;
            paramsToStore[1].Size = 100;

            paramsToStore[2] = new SqlParameter("@UniConPerson", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.strUniConPer;
            paramsToStore[2].Size = 100;

            paramsToStore[3] = new SqlParameter("@UniDesignation", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.strUniDesig;
            paramsToStore[3].Size = 100;

            paramsToStore[4] = new SqlParameter("@UniConNo1", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.strUniNo1;
            paramsToStore[4].Size = 50;

            paramsToStore[5] = new SqlParameter("@UniConNo2", SqlDbType.VarChar);
            paramsToStore[5].Value = objEmployeeInfo.strUniNo2;
            paramsToStore[5].Size = 50;

            paramsToStore[6] = new SqlParameter("@UniConPerson1", SqlDbType.VarChar);
            paramsToStore[6].Value = objEmployeeInfo.strUniConPer1;
            paramsToStore[6].Size = 100;

            paramsToStore[7] = new SqlParameter("@UniDesignation1", SqlDbType.VarChar);
            paramsToStore[7].Value = objEmployeeInfo.strUniDesig1;
            paramsToStore[7].Size = 100;

            paramsToStore[8] = new SqlParameter("@UniConNo3", SqlDbType.VarChar);
            paramsToStore[8].Value = objEmployeeInfo.strUniNo3;
            paramsToStore[8].Size = 50;

            paramsToStore[9] = new SqlParameter("@UniConNo4", SqlDbType.VarChar);
            paramsToStore[9].Value = objEmployeeInfo.strUniNo4;
            paramsToStore[9].Size = 50;

            paramsToStore[10] = new SqlParameter("@UniDD", SqlDbType.VarChar);
            paramsToStore[10].Value = objEmployeeInfo.strUniDD;
            paramsToStore[10].Size = 50;

            paramsToStore[11] = new SqlParameter("@UniDDto", SqlDbType.VarChar);
            paramsToStore[11].Value = objEmployeeInfo.strUniDDto;
            paramsToStore[11].Size = 50;

            paramsToStore[12] = new SqlParameter("@UniDDAddress", SqlDbType.VarChar);
            paramsToStore[12].Value = objEmployeeInfo.strUniDDadd;
            paramsToStore[12].Size = 200;

            paramsToStore[13] = new SqlParameter("@UniTime", SqlDbType.VarChar);
            paramsToStore[13].Value = objEmployeeInfo.strUniTime;
            paramsToStore[13].Size = 50;

            paramsToStore[14] = new SqlParameter("@UniMail", SqlDbType.VarChar);
            paramsToStore[14].Value = objEmployeeInfo.strUniMail;
            paramsToStore[14].Size = 100;

            paramsToStore[15] = new SqlParameter("@UniWebsite", SqlDbType.VarChar);
            paramsToStore[15].Value = objEmployeeInfo.strUniWeb;
            paramsToStore[15].Size = 100;

            paramsToStore[16] = new SqlParameter("@UniRemarks", SqlDbType.VarChar);
            paramsToStore[16].Value = objEmployeeInfo.strUniRemark;
            paramsToStore[16].Size = 500;


            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "editUniversity", paramsToStore));

        }

        public int UniversityData(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[2];
            // 213+173



            paramsToStore[0] = new SqlParameter("@UniName", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.strUniName;
            paramsToStore[0].Size = 150;

            paramsToStore[1] = new SqlParameter("@UniLocation", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.strUniLoc;
            paramsToStore[1].Size = 100;

            //paramsToStore[2] = new SqlParameter("@teleCaller", SqlDbType.VarChar);
            //paramsToStore[2].Value = objEmployeeInfo.SUser;
            //paramsToStore[2].Size = 50;





            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UniversityData", paramsToStore));

        }

        public int saveDDDetails(EmployeeInfo objEmployeeInfo, string ID)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[19];
            // 213+173



            paramsToStore[0] = new SqlParameter("@ddreqDate ", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.strDReqDate;
            paramsToStore[0].Size = 50;

            paramsToStore[1] = new SqlParameter("@reqCaller", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.strReqCaller;
            paramsToStore[1].Size = 50;

            paramsToStore[2] = new SqlParameter("@ddDate", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.strDDate;
            paramsToStore[2].Size = 50;

            paramsToStore[3] = new SqlParameter("@ddNumber", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.strDNumber;
            paramsToStore[3].Size = 50;

            paramsToStore[4] = new SqlParameter("@amount", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.strDAmount;
            paramsToStore[4].Size = 50;

            paramsToStore[5] = new SqlParameter("@sentto", SqlDbType.VarChar);
            paramsToStore[5].Value = objEmployeeInfo.strDSentTo;
            paramsToStore[5].Size = 50;

            paramsToStore[6] = new SqlParameter("@address", SqlDbType.VarChar);
            paramsToStore[6].Value = objEmployeeInfo.strDAdr;
            paramsToStore[6].Size = 200;

            paramsToStore[7] = new SqlParameter("@madeAt", SqlDbType.VarChar);
            paramsToStore[7].Value = objEmployeeInfo.strDMadeAt;
            paramsToStore[7].Size = 50;

            paramsToStore[8] = new SqlParameter("@courrierDate", SqlDbType.VarChar);
            paramsToStore[8].Value = objEmployeeInfo.strCDate;
            paramsToStore[8].Size = 50;

            paramsToStore[9] = new SqlParameter("@pod", SqlDbType.VarChar);
            paramsToStore[9].Value = objEmployeeInfo.strCPOD;
            paramsToStore[9].Size = 50;

            paramsToStore[10] = new SqlParameter("@csp", SqlDbType.VarChar);
            paramsToStore[10].Value = objEmployeeInfo.strCCSP;
            paramsToStore[10].Size = 100;

            paramsToStore[11] = new SqlParameter("@CsentTo", SqlDbType.VarChar);
            paramsToStore[11].Value = objEmployeeInfo.strCSentTo;
            paramsToStore[11].Size = 150;

            paramsToStore[12] = new SqlParameter("@street1", SqlDbType.VarChar);
            paramsToStore[12].Value = objEmployeeInfo.strCStreet1;
            paramsToStore[12].Size = 50;

            paramsToStore[13] = new SqlParameter("@street2", SqlDbType.VarChar);
            paramsToStore[13].Value = objEmployeeInfo.strCStreet2;
            paramsToStore[13].Size = 50;

            paramsToStore[14] = new SqlParameter("@state", SqlDbType.VarChar);
            paramsToStore[14].Value = objEmployeeInfo.strCState;
            paramsToStore[14].Size = 50;

            paramsToStore[15] = new SqlParameter("@city", SqlDbType.VarChar);
            paramsToStore[15].Value = objEmployeeInfo.strCCity;
            paramsToStore[15].Size = 50;

            paramsToStore[16] = new SqlParameter("@zip", SqlDbType.VarChar);
            paramsToStore[16].Value = objEmployeeInfo.strCZip;
            paramsToStore[16].Size = 50;

            paramsToStore[17] = new SqlParameter("@contact", SqlDbType.VarChar);
            paramsToStore[17].Value = objEmployeeInfo.strCContact;
            paramsToStore[17].Size = 50;

            paramsToStore[17] = new SqlParameter("@contact", SqlDbType.VarChar);
            paramsToStore[17].Value = objEmployeeInfo.strCContact;
            paramsToStore[17].Size = 50;


            paramsToStore[18] = new SqlParameter("@refId", SqlDbType.Int);
            paramsToStore[18].Value = ID;




            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "saveDDDetails", paramsToStore));

        }

        //SHIV

        public int KPMGUploadexcel(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[26];
            // 213+173




            paramsToStore[0] = new SqlParameter("@Edu1_UniversityName", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.Edu1_UniversityName;
            paramsToStore[0].Size = 500;


            paramsToStore[1] = new SqlParameter("@Edu1_RollNo", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.Edu1_RollNo;
            paramsToStore[1].Size = 50;





            paramsToStore[2] = new SqlParameter("@Edu1_CollegeName", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.Edu1_CollegeName;
            paramsToStore[2].Size = 500;



            paramsToStore[3] = new SqlParameter("@EmpHis3_AgencyDetails", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.EmpHis3_AgencyDetails;
            paramsToStore[3].Size = 50;



            paramsToStore[4] = new SqlParameter("@FirstName", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.FirstName;
            paramsToStore[4].Size = 150;



            paramsToStore[5] = new SqlParameter("@COE", SqlDbType.VarChar);
            paramsToStore[5].Value = objEmployeeInfo.COE;
            paramsToStore[5].Size = 50;





            paramsToStore[6] = new SqlParameter("@Edu1_YearOfPassing", SqlDbType.VarChar);
            paramsToStore[6].Value = objEmployeeInfo.Edu1_YearOfPassing;
            paramsToStore[6].Size = 50;



            paramsToStore[7] = new SqlParameter("@EmployeeID", SqlDbType.VarChar);
            paramsToStore[7].Value = objEmployeeInfo.EmployeeID;
            paramsToStore[7].Size = 20;








            //paramsToStore[8] = new SqlParameter("@EmpHis3_AgencyDetails", SqlDbType.VarChar);
            //paramsToStore[8].Value = objEmployeeInfo.EmpHis3_AgencyDetails;
            //paramsToStore[8].Size = 50;



            paramsToStore[8] = new SqlParameter("@SNo", SqlDbType.VarChar);
            paramsToStore[8].Value = objEmployeeInfo.SNo;
            paramsToStore[8].Size = 50;

            paramsToStore[9] = new SqlParameter("@Vender", SqlDbType.VarChar);
            paramsToStore[9].Value = objEmployeeInfo.Vender;
            paramsToStore[9].Size = 50;


            paramsToStore[10] = new SqlParameter("@Monthy", SqlDbType.VarChar);
            paramsToStore[10].Value = objEmployeeInfo.Month;
            paramsToStore[10].Size = 50;


            paramsToStore[11] = new SqlParameter("@DCSV", SqlDbType.VarChar);

            paramsToStore[11].Value = objEmployeeInfo.DCSV;
            paramsToStore[11].Size = 50;


            paramsToStore[12] = new SqlParameter("@DDV", SqlDbType.VarChar);
            paramsToStore[12].Value = objEmployeeInfo.DDV;
            paramsToStore[12].Size = 50;


            paramsToStore[13] = new SqlParameter("@DVR", SqlDbType.VarChar);
            paramsToStore[13].Value = objEmployeeInfo.DVR;
            paramsToStore[13].Size = 50;


            paramsToStore[14] = new SqlParameter("@DVU", SqlDbType.VarChar);
            paramsToStore[14].Value = objEmployeeInfo.DVU;
            paramsToStore[14].Size = 50;

            paramsToStore[15] = new SqlParameter("@Mode", SqlDbType.VarChar);
            paramsToStore[15].Value = objEmployeeInfo.Mode;
            paramsToStore[15].Size = 50;

            paramsToStore[16] = new SqlParameter("@EmpIdProvidedByClient", SqlDbType.VarChar);
            paramsToStore[16].Value = objEmployeeInfo.EmpIdProvidedByClient;
            paramsToStore[16].Size = 50;

            paramsToStore[17] = new SqlParameter("@Edu1_Address", SqlDbType.VarChar);
            paramsToStore[17].Value = objEmployeeInfo.Edu1_Address;
            paramsToStore[17].Size = 500;

            paramsToStore[18] = new SqlParameter("@Edu1_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[18].Value = objEmployeeInfo.Edu1_EducationalQualification;
            paramsToStore[18].Size = 150;

            paramsToStore[19] = new SqlParameter("@CaseReceivingDate", SqlDbType.VarChar);
            paramsToStore[19].Value = objEmployeeInfo.DateofJoining;
            paramsToStore[19].Size = 50;

            paramsToStore[20] = new SqlParameter("@ClientName", SqlDbType.VarChar);
            paramsToStore[20].Value = objEmployeeInfo.ClientName;
            paramsToStore[20].Size = 50;

            paramsToStore[21] = new SqlParameter("@Manager", SqlDbType.VarChar);
            paramsToStore[21].Value = objEmployeeInfo.MiddleName;
            paramsToStore[21].Size = 50;

            paramsToStore[22] = new SqlParameter("@CaseSubmissionDate", SqlDbType.VarChar);
            paramsToStore[22].Value = objEmployeeInfo.CaseSubmmissionDate;
            paramsToStore[22].Size = 50;

            paramsToStore[23] = new SqlParameter("@Education1State", SqlDbType.VarChar);
            paramsToStore[23].Value = objEmployeeInfo.Education1State;
            paramsToStore[23].Size = 50;

            paramsToStore[24] = new SqlParameter("@EmpHis1_IncaseOfGap", SqlDbType.VarChar);
            paramsToStore[24].Value = objEmployeeInfo.EmpHis1_IncaseOfGap;
            paramsToStore[24].Size = 50;

            paramsToStore[25] = new SqlParameter("@requirement", SqlDbType.VarChar);
            paramsToStore[25].Value = objEmployeeInfo.strRequirement_edu1;
            paramsToStore[25].Size = 50;









            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "KPMGexcelUpload", paramsToStore));



        }
        public int WIPROUploadexcel(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[41];
            // 213+173




            paramsToStore[0] = new SqlParameter("@Edu1_UniversityName", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.Edu1_UniversityName;
            paramsToStore[0].Size = 500;


            paramsToStore[1] = new SqlParameter("@Edu1_RollNo", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.Edu1_RollNo;
            paramsToStore[1].Size = 50;



            paramsToStore[2] = new SqlParameter("@Edu1_CollegeName", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.Edu1_CollegeName;
            paramsToStore[2].Size = 500;



            paramsToStore[3] = new SqlParameter("@TATDate", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.TATDate;
            paramsToStore[3].Size = 50;



            paramsToStore[4] = new SqlParameter("@FirstName", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.FirstName;
            paramsToStore[4].Size = 150;



            paramsToStore[5] = new SqlParameter("@COE", SqlDbType.VarChar);
            paramsToStore[5].Value = objEmployeeInfo.COE;
            paramsToStore[5].Size = 50;





            paramsToStore[6] = new SqlParameter("@Edu1_YearOfPassing", SqlDbType.VarChar);
            paramsToStore[6].Value = objEmployeeInfo.Edu1_YearOfPassing;
            paramsToStore[6].Size = 50;



            paramsToStore[7] = new SqlParameter("@EmployeeID", SqlDbType.VarChar);
            paramsToStore[7].Value = objEmployeeInfo.EmployeeID;
            paramsToStore[7].Size = 20;








            //paramsToStore[8] = new SqlParameter("@EmpHis3_AgencyDetails", SqlDbType.VarChar);
            //paramsToStore[8].Value = objEmployeeInfo.EmpHis3_AgencyDetails;
            //paramsToStore[8].Size = 50;



            paramsToStore[8] = new SqlParameter("@SNo", SqlDbType.VarChar);
            paramsToStore[8].Value = objEmployeeInfo.SNo;
            paramsToStore[8].Size = 50;

            paramsToStore[9] = new SqlParameter("@Within_TATOut", SqlDbType.VarChar);
            paramsToStore[9].Value = objEmployeeInfo.Within_TATOut;
            paramsToStore[9].Size = 50;


            paramsToStore[10] = new SqlParameter("@Monthy", SqlDbType.VarChar);
            paramsToStore[10].Value = objEmployeeInfo.Month;
            paramsToStore[10].Size = 50;


            paramsToStore[11] = new SqlParameter("@Online_Offline", SqlDbType.VarChar);
            paramsToStore[11].Value = objEmployeeInfo.Online_Offline;
            paramsToStore[11].Size = 50;


            paramsToStore[12] = new SqlParameter("@Reallocation", SqlDbType.VarChar);
            paramsToStore[12].Value = objEmployeeInfo.Reallocation;
            paramsToStore[12].Size = 50;


            paramsToStore[13] = new SqlParameter("@EmpIdProvidedByClient", SqlDbType.VarChar);
            paramsToStore[13].Value = objEmployeeInfo.EmpIdProvidedByClient;
            paramsToStore[13].Size = 50;


            paramsToStore[14] = new SqlParameter("@Specialization", SqlDbType.VarChar);
            paramsToStore[14].Value = objEmployeeInfo.Specialization;
            paramsToStore[14].Size = 50;

            paramsToStore[15] = new SqlParameter("@Mode", SqlDbType.VarChar);
            paramsToStore[15].Value = objEmployeeInfo.Mode;
            paramsToStore[15].Size = 50;

            paramsToStore[16] = new SqlParameter("@GraduatedYearMonth", SqlDbType.VarChar);
            paramsToStore[16].Value = objEmployeeInfo.GraduatedYearMonth;
            paramsToStore[16].Size = 50;

            paramsToStore[17] = new SqlParameter("@Edu1_Address", SqlDbType.VarChar);
            paramsToStore[17].Value = objEmployeeInfo.Edu1_Address;
            paramsToStore[17].Size = 500;

            paramsToStore[18] = new SqlParameter("@Edu1_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[18].Value = objEmployeeInfo.Edu1_EducationalQualification;
            paramsToStore[18].Size = 150;

            paramsToStore[19] = new SqlParameter("@CaseReceivingDate", SqlDbType.VarChar);
            paramsToStore[19].Value = objEmployeeInfo.DateofJoining;
            paramsToStore[19].Size = 50;

            paramsToStore[20] = new SqlParameter("@ClientName", SqlDbType.VarChar);
            paramsToStore[20].Value = objEmployeeInfo.ClientName;
            paramsToStore[20].Size = 50;

            paramsToStore[21] = new SqlParameter("@Manager", SqlDbType.VarChar);
            paramsToStore[21].Value = objEmployeeInfo.MiddleName;
            paramsToStore[21].Size = 50;

            paramsToStore[22] = new SqlParameter("@CaseSubmissionDate", SqlDbType.VarChar);
            paramsToStore[22].Value = objEmployeeInfo.CaseSubmmissionDate;
            paramsToStore[22].Size = 50;

            paramsToStore[23] = new SqlParameter("@Percentage", SqlDbType.VarChar);
            paramsToStore[23].Value = objEmployeeInfo.Percentage;
            paramsToStore[23].Size = 50;

            paramsToStore[24] = new SqlParameter("@Education1City", SqlDbType.VarChar);
            paramsToStore[24].Value = objEmployeeInfo.Education1City;
            paramsToStore[24].Size = 50;


            paramsToStore[25] = new SqlParameter("@Education1PinCode", SqlDbType.VarChar);
            paramsToStore[25].Value = objEmployeeInfo.Education1PinCode;
            paramsToStore[25].Size = 50;

            paramsToStore[26] = new SqlParameter("@Education1State", SqlDbType.VarChar);
            paramsToStore[26].Value = objEmployeeInfo.Education1State;
            paramsToStore[26].Size = 50;

            paramsToStore[27] = new SqlParameter("@RevertRecd", SqlDbType.VarChar);
            paramsToStore[27].Value = objEmployeeInfo.RevertRecd;
            paramsToStore[27].Size = 50;

            paramsToStore[28] = new SqlParameter("@StampedVerbal", SqlDbType.VarChar);
            paramsToStore[28].Value = objEmployeeInfo.StampedVerbal;
            paramsToStore[28].Size = 50;

            paramsToStore[29] = new SqlParameter("@DateofExport", SqlDbType.VarChar);
            paramsToStore[29].Value = objEmployeeInfo.DateofExport;
            paramsToStore[29].Size = 50;

            paramsToStore[30] = new SqlParameter("@FinalStatus", SqlDbType.VarChar);
            paramsToStore[30].Value = objEmployeeInfo.FinalStatus;
            paramsToStore[30].Size = 50;

            paramsToStore[31] = new SqlParameter("@ColorofReport", SqlDbType.VarChar);
            paramsToStore[31].Value = objEmployeeInfo.ColorofReport;
            paramsToStore[31].Size = 50;

            paramsToStore[32] = new SqlParameter("@Price", SqlDbType.VarChar);
            paramsToStore[32].Value = objEmployeeInfo.price;
            paramsToStore[32].Size = 50;

            paramsToStore[33] = new SqlParameter("@NoofDaysDelay", SqlDbType.VarChar);
            paramsToStore[33].Value = objEmployeeInfo.NoofDaysDelay;
            paramsToStore[33].Size = 50;

            paramsToStore[34] = new SqlParameter("@DDAmount", SqlDbType.VarChar);
            paramsToStore[34].Value = objEmployeeInfo.DDAmount;
            paramsToStore[34].Size = 50;

            paramsToStore[35] = new SqlParameter("@DDDate", SqlDbType.VarChar);
            paramsToStore[35].Value = objEmployeeInfo.DDDate;
            paramsToStore[35].Size = 50;

            paramsToStore[36] = new SqlParameter("@Requestedby", SqlDbType.VarChar);
            paramsToStore[36].Value = objEmployeeInfo.Requestedby;
            paramsToStore[36].Size = 50;

            paramsToStore[37] = new SqlParameter("@DateofCompeletion", SqlDbType.VarChar);
            paramsToStore[37].Value = objEmployeeInfo.DateofCompeletion;
            paramsToStore[37].Size = 50;

            paramsToStore[38] = new SqlParameter("@Remarks", SqlDbType.VarChar);
            paramsToStore[38].Value = objEmployeeInfo.Remarks;
            paramsToStore[38].Size = 50;


            paramsToStore[39] = new SqlParameter("@ClientRefNo", SqlDbType.VarChar);
            paramsToStore[39].Value = objEmployeeInfo.ClientRefNo;
            paramsToStore[39].Size = 50;


            paramsToStore[40] = new SqlParameter("@Edu1_Address2", SqlDbType.VarChar);
            paramsToStore[40].Value = objEmployeeInfo.Edu1_Address2;
            paramsToStore[40].Size = 50;




            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "WIPROEduexcelUpload", paramsToStore));



        }

        public int WIPROCityUploadexcel(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[52];
            // 213+173




            paramsToStore[0] = new SqlParameter("@SNo", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.SNo;
            paramsToStore[0].Size = 50;


            paramsToStore[1] = new SqlParameter("@CaseReceivingDate", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.DateofJoining;
            paramsToStore[1].Size = 50;



            paramsToStore[2] = new SqlParameter("@MonthInitiation", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.MonthInitiation;
            paramsToStore[2].Size = 50;



            paramsToStore[3] = new SqlParameter("@DateofAllocation", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.DateofAllocation;
            paramsToStore[3].Size = 50;



            paramsToStore[4] = new SqlParameter("@TATDate", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.TATDate;
            paramsToStore[4].Size = 150;



            paramsToStore[5] = new SqlParameter("@TAT2Date", SqlDbType.VarChar);
            paramsToStore[5].Value = objEmployeeInfo.TAT2;
            paramsToStore[5].Size = 50;


            paramsToStore[6] = new SqlParameter("@Within_TATOut", SqlDbType.VarChar);
            paramsToStore[6].Value = objEmployeeInfo.Within_TATOut;
            paramsToStore[6].Size = 50;



            paramsToStore[7] = new SqlParameter("@CaseStatus1", SqlDbType.VarChar);
            paramsToStore[7].Value = objEmployeeInfo.CaseStatus1;
            paramsToStore[7].Size = 50;








            //paramsToStore[8] = new SqlParameter("@EmpHis3_AgencyDetails", SqlDbType.VarChar);
            //paramsToStore[8].Value = objEmployeeInfo.EmpHis3_AgencyDetails;
            //paramsToStore[8].Size = 50;



            paramsToStore[8] = new SqlParameter("@ImpInfo", SqlDbType.VarChar);
            paramsToStore[8].Value = objEmployeeInfo.ImpInfo;
            paramsToStore[8].Size = 50;

            paramsToStore[9] = new SqlParameter("@ReinitiateCaseStatus", SqlDbType.VarChar);
            paramsToStore[9].Value = objEmployeeInfo.ReinitiateCaseStatus;
            paramsToStore[9].Size = 50;


            paramsToStore[10] = new SqlParameter("@ReinitiateChecks", SqlDbType.VarChar);
            paramsToStore[10].Value = objEmployeeInfo.ReinitiateChecks;
            paramsToStore[10].Size = 50;


            paramsToStore[11] = new SqlParameter("@ClientRefNo", SqlDbType.VarChar);
            paramsToStore[11].Value = objEmployeeInfo.ClientRefNo;
            paramsToStore[11].Size = 150;


            paramsToStore[12] = new SqlParameter("@ClientName", SqlDbType.VarChar);
            paramsToStore[12].Value = objEmployeeInfo.ClientName;
            paramsToStore[12].Size = 50;


            paramsToStore[13] = new SqlParameter("@Online_Offline", SqlDbType.VarChar);
            paramsToStore[13].Value = objEmployeeInfo.Online_Offline;
            paramsToStore[13].Size = 50;


            paramsToStore[14] = new SqlParameter("@EmpIdProvidedByClient", SqlDbType.VarChar);
            paramsToStore[14].Value = objEmployeeInfo.EmpIdProvidedByClient;
            paramsToStore[14].Size = 50;

            paramsToStore[15] = new SqlParameter("@Mode", SqlDbType.VarChar);
            paramsToStore[15].Value = objEmployeeInfo.Mode;
            paramsToStore[15].Size = 50;

            paramsToStore[16] = new SqlParameter("@FirstName", SqlDbType.VarChar);
            paramsToStore[16].Value = objEmployeeInfo.FirstName;
            paramsToStore[16].Size = 50;

            paramsToStore[17] = new SqlParameter("@FatherName", SqlDbType.VarChar);
            paramsToStore[17].Value = objEmployeeInfo.FatherName;
            paramsToStore[17].Size = 150;

            paramsToStore[18] = new SqlParameter("@CheksID", SqlDbType.VarChar);
            paramsToStore[18].Value = objEmployeeInfo.CheksID;
            paramsToStore[18].Size = 150;

            paramsToStore[19] = new SqlParameter("@TypeofCheck", SqlDbType.VarChar);
            paramsToStore[19].Value = objEmployeeInfo.TypeofCheck;
            paramsToStore[19].Size = 50;

            paramsToStore[20] = new SqlParameter("@Add_Emp_Deg_Idtity", SqlDbType.VarChar);
            paramsToStore[20].Value = objEmployeeInfo.Add_Emp_Deg_Idtity;
            paramsToStore[20].Size = 250;

            paramsToStore[21] = new SqlParameter("@Manager", SqlDbType.VarChar);
            paramsToStore[21].Value = objEmployeeInfo.MiddleName;
            paramsToStore[21].Size = 50;

            paramsToStore[22] = new SqlParameter("@CollegeName_Lastposheld", SqlDbType.VarChar);
            paramsToStore[22].Value = objEmployeeInfo.CollegeName_Lastposheld;
            paramsToStore[22].Size = 150;

            paramsToStore[23] = new SqlParameter("@CollegeLocation", SqlDbType.VarChar);
            paramsToStore[23].Value = objEmployeeInfo.CollegeLocation;
            paramsToStore[23].Size = 250;

            paramsToStore[24] = new SqlParameter("@UniversityName_SupervisorName", SqlDbType.VarChar);
            paramsToStore[24].Value = objEmployeeInfo.UniversityName_SupervisorName;
            paramsToStore[24].Size = 250;


            paramsToStore[25] = new SqlParameter("@YearofPassing_Emp_Duration_DOB", SqlDbType.VarChar);
            paramsToStore[25].Value = objEmployeeInfo.YearofPassing_Emp_Duration_DOB;
            paramsToStore[25].Size = 50;

            paramsToStore[26] = new SqlParameter("@RollNo_RegNo_Empcode", SqlDbType.VarChar);
            paramsToStore[26].Value = objEmployeeInfo.RollNo_RegNo_Empcode;
            paramsToStore[26].Size = 50;

            paramsToStore[27] = new SqlParameter("@Location", SqlDbType.VarChar);
            paramsToStore[27].Value = objEmployeeInfo.Location;
            paramsToStore[27].Size = 150;

            paramsToStore[28] = new SqlParameter("@State", SqlDbType.VarChar);
            paramsToStore[28].Value = objEmployeeInfo.State;
            paramsToStore[28].Size = 50;

            paramsToStore[29] = new SqlParameter("@RevertRecd", SqlDbType.VarChar);
            paramsToStore[29].Value = objEmployeeInfo.RevertRecd;
            paramsToStore[29].Size = 50;

            paramsToStore[30] = new SqlParameter("@Stamp_Verbal", SqlDbType.VarChar);
            paramsToStore[30].Value = objEmployeeInfo.Stamp_Verbal;
            paramsToStore[30].Size = 50;

            paramsToStore[31] = new SqlParameter("@Status", SqlDbType.VarChar);
            paramsToStore[31].Value = objEmployeeInfo.Status;
            paramsToStore[31].Size = 50;

            paramsToStore[32] = new SqlParameter("@Team", SqlDbType.VarChar);
            paramsToStore[32].Value = objEmployeeInfo.Team;
            paramsToStore[32].Size = 50;

            paramsToStore[33] = new SqlParameter("@MonthPrice", SqlDbType.VarChar);
            paramsToStore[33].Value = objEmployeeInfo.MonthPrice;
            paramsToStore[33].Size = 50;

            paramsToStore[34] = new SqlParameter("@Price", SqlDbType.VarChar);
            paramsToStore[34].Value = objEmployeeInfo.Price;
            paramsToStore[34].Size = 50;

            paramsToStore[35] = new SqlParameter("@Months", SqlDbType.VarChar);
            paramsToStore[35].Value = objEmployeeInfo.Months;
            paramsToStore[35].Size = 50;

            paramsToStore[36] = new SqlParameter("@EducationRemarks", SqlDbType.VarChar);
            paramsToStore[36].Value = objEmployeeInfo.EducationRemarks;
            paramsToStore[36].Size = 150;

            paramsToStore[37] = new SqlParameter("@Remarks", SqlDbType.VarChar);
            paramsToStore[37].Value = objEmployeeInfo.Remarks;
            paramsToStore[37].Size = 250;

            paramsToStore[38] = new SqlParameter("@CaseStatus2", SqlDbType.VarChar);
            paramsToStore[38].Value = objEmployeeInfo.CaseStatus2;
            paramsToStore[38].Size = 50;


            paramsToStore[39] = new SqlParameter("@DateofExport", SqlDbType.VarChar);
            paramsToStore[39].Value = objEmployeeInfo.DateofExport;
            paramsToStore[39].Size = 50;


            paramsToStore[40] = new SqlParameter("@ColorofReport", SqlDbType.VarChar);
            paramsToStore[40].Value = objEmployeeInfo.ColorofReport;
            paramsToStore[40].Size = 50;

            paramsToStore[41] = new SqlParameter("@NameofVeri_Desg", SqlDbType.VarChar);
            paramsToStore[41].Value = objEmployeeInfo.NameofVeri_Desg;
            paramsToStore[41].Size = 50;

            paramsToStore[42] = new SqlParameter("@VerifiedLocation", SqlDbType.VarChar);
            paramsToStore[42].Value = objEmployeeInfo.VerifiedLocation;
            paramsToStore[42].Size = 50;

            paramsToStore[43] = new SqlParameter("@ReasonforRed_Orange", SqlDbType.VarChar);
            paramsToStore[43].Value = objEmployeeInfo.ReasonforRed_Orange;
            paramsToStore[43].Size = 150;

            paramsToStore[44] = new SqlParameter("@InsufficiencyLevel", SqlDbType.VarChar);
            paramsToStore[44].Value = objEmployeeInfo.InsufficiencyLevel;
            paramsToStore[44].Size = 50;

            paramsToStore[45] = new SqlParameter("@ReasonforInsufficiency", SqlDbType.VarChar);
            paramsToStore[45].Value = objEmployeeInfo.ReasonforInsufficiency;
            paramsToStore[45].Size = 50;

            paramsToStore[46] = new SqlParameter("@Anand", SqlDbType.VarChar);
            paramsToStore[46].Value = objEmployeeInfo.Anand;
            paramsToStore[46].Size = 50;

            paramsToStore[47] = new SqlParameter("@Sandeep", SqlDbType.VarChar);
            paramsToStore[47].Value = objEmployeeInfo.Sandeep;
            paramsToStore[47].Size = 50;

            paramsToStore[48] = new SqlParameter("@DDDate", SqlDbType.VarChar);
            paramsToStore[48].Value = objEmployeeInfo.DDDate;
            paramsToStore[48].Size = 50;

            paramsToStore[49] = new SqlParameter("@AmountofDD", SqlDbType.VarChar);
            paramsToStore[49].Value = objEmployeeInfo.AmountofDD;
            paramsToStore[49].Size = 50;

            paramsToStore[50] = new SqlParameter("@DDRequestedby", SqlDbType.VarChar);
            paramsToStore[50].Value = objEmployeeInfo.DDRequestedby;
            paramsToStore[50].Size = 50;

            paramsToStore[51] = new SqlParameter("@InterimReports", SqlDbType.VarChar);
            paramsToStore[51].Value = objEmployeeInfo.InterimReports;
            paramsToStore[51].Size = 50;

            //paramsToStore[52] = new SqlParameter("@CaseStatus", SqlDbType.VarChar);
            //paramsToStore[52].Value = objEmployeeInfo.CaseStatus;
            //paramsToStore[52].Size = 5;





            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "WIPROCityexcelUpload", paramsToStore));



        }
        public DataSet SelectAddViewData(int EmployeeID)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SelectaddViewData",
                  SQLDataAccess.CreateParameter("@EmployeeID", SqlDbType.Int, EmployeeID, ParameterDirection.Input, 4, false)


                );
            return dsServiceType;
        }


        public int saveEmployeeInfoKPMG(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[29];
            // 213+173

            paramsToStore[0] = new SqlParameter("@TAT2Date", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.TAT2;
            paramsToStore[0].Size = 50;



            paramsToStore[1] = new SqlParameter("@DateofJoining", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.DateofJoining;
            paramsToStore[1].Size = 50;



            paramsToStore[2] = new SqlParameter("@Edu1_UniversityName", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.Edu1_UniversityName;
            paramsToStore[2].Size = 150;




            paramsToStore[3] = new SqlParameter("@FatherName", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.FatherName;
            paramsToStore[3].Size = 150;



            paramsToStore[4] = new SqlParameter("@DOB", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.DOB;
            paramsToStore[4].Size = 50;


            paramsToStore[5] = new SqlParameter("@Edu1_RollNo", SqlDbType.VarChar);
            paramsToStore[5].Value = objEmployeeInfo.Edu1_RollNo;
            paramsToStore[5].Size = 50;



            paramsToStore[6] = new SqlParameter("@MiddleName", SqlDbType.VarChar);
            paramsToStore[6].Value = objEmployeeInfo.MiddleName;
            paramsToStore[6].Size = 50;

            paramsToStore[7] = new SqlParameter("@Edu1_CollegeName", SqlDbType.VarChar);
            paramsToStore[7].Value = objEmployeeInfo.Edu1_CollegeName;
            paramsToStore[7].Size = 50;



            paramsToStore[8] = new SqlParameter("@FirstName", SqlDbType.VarChar);
            paramsToStore[8].Value = objEmployeeInfo.FirstName;
            paramsToStore[8].Size = 150;


            paramsToStore[9] = new SqlParameter("@COE", SqlDbType.VarChar);
            paramsToStore[9].Value = objEmployeeInfo.COE;
            paramsToStore[9].Size = 50;

            paramsToStore[10] = new SqlParameter("@Mobile", SqlDbType.VarChar);
            paramsToStore[10].Value = objEmployeeInfo.Mobile;
            paramsToStore[10].Size = 50;



            paramsToStore[11] = new SqlParameter("@Band", SqlDbType.VarChar);
            paramsToStore[11].Value = objEmployeeInfo.Band;
            paramsToStore[11].Size = 50;

            paramsToStore[12] = new SqlParameter("@EmpIdProvidedByClient", SqlDbType.VarChar);
            paramsToStore[12].Value = objEmployeeInfo.EmpIdProvidedByClient;
            paramsToStore[12].Size = 50;

            paramsToStore[13] = new SqlParameter("@PlaceofBirth", SqlDbType.VarChar);
            paramsToStore[13].Value = objEmployeeInfo.PlaceofBirth;
            paramsToStore[13].Size = 150;

            paramsToStore[14] = new SqlParameter("@Surname", SqlDbType.VarChar);
            paramsToStore[14].Value = objEmployeeInfo.Surname;
            paramsToStore[14].Size = 50;

            paramsToStore[15] = new SqlParameter("@Edu1_YearOfPassing", SqlDbType.VarChar);
            paramsToStore[15].Value = objEmployeeInfo.Edu1_YearOfPassing;
            paramsToStore[15].Size = 50;

            paramsToStore[16] = new SqlParameter("@Mode", SqlDbType.VarChar);

            paramsToStore[16].Value = objEmployeeInfo.Mode;
            paramsToStore[16].Size = 20;

            paramsToStore[17] = new SqlParameter("@EmployeeID", SqlDbType.VarChar);
            paramsToStore[17].Value = objEmployeeInfo.EmployeeID;
            paramsToStore[17].Size = 20;

            paramsToStore[18] = new SqlParameter("@ClientName", SqlDbType.VarChar);
            paramsToStore[18].Value = objEmployeeInfo.ClientName;
            paramsToStore[18].Size = 50;

            paramsToStore[19] = new SqlParameter("@EmpHis3_AgencyDetails", SqlDbType.VarChar);
            paramsToStore[19].Value = objEmployeeInfo.EmpHis3_AgencyDetails;
            paramsToStore[19].Size = 50;

            //paramsToStore[20] = new SqlParameter("@NoOfComp", SqlDbType.VarChar);
            //paramsToStore[20].Value = objEmployeeInfo.NoOfComp;
            //paramsToStore[20].Size = 50;

            paramsToStore[20] = new SqlParameter("@CaseStatusKPMG", SqlDbType.VarChar);
            paramsToStore[20].Value = objEmployeeInfo.CaseStatusKPMG;
            paramsToStore[20].Size = 50;


            //paramsToStore[22] = new SqlParameter("@PlaceofBirth", SqlDbType.VarChar);
            //paramsToStore[22].Value = objEmployeeInfo.PlaceofBirth;
            //paramsToStore[22].Size = 150;

            paramsToStore[21] = new SqlParameter("@TATDate", SqlDbType.VarChar);
            paramsToStore[21].Value = objEmployeeInfo.TATDate;
            paramsToStore[21].Size = 50;

            //paramsToStore[23] = new SqlParameter("@COE", SqlDbType.VarChar);
            //paramsToStore[23].Value = objEmployeeInfo.COE;
            //paramsToStore[23].Size = 50;

            paramsToStore[22] = new SqlParameter("@ExperienceInYears", SqlDbType.VarChar);
            paramsToStore[22].Value = objEmployeeInfo.ExperienceInYears;
            paramsToStore[22].Size = 50;

            paramsToStore[23] = new SqlParameter("@Edu1_Address", SqlDbType.VarChar);
            paramsToStore[23].Value = objEmployeeInfo.Edu1_Address;
            paramsToStore[23].Size = 500;


            paramsToStore[24] = new SqlParameter("@Edu1_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[24].Value = objEmployeeInfo.Edu1_EducationalQualification;
            paramsToStore[24].Size = 150;

            paramsToStore[25] = new SqlParameter("@EmpHis1_IncaseOfGap", SqlDbType.VarChar);
            paramsToStore[25].Value = objEmployeeInfo.EmpHis1_IncaseOfGap;
            paramsToStore[25].Size = 50;

            paramsToStore[26] = new SqlParameter("@EducationList", SqlDbType.VarChar);
            paramsToStore[26].Value = objEmployeeInfo.EducationList;
            paramsToStore[26].Size = 50;


            paramsToStore[27] = new SqlParameter("@Education1State", SqlDbType.VarChar);
            paramsToStore[27].Value = objEmployeeInfo.Education1State;
            paramsToStore[27].Size = 50;

            paramsToStore[28] = new SqlParameter("@requirement", SqlDbType.VarChar);
            paramsToStore[28].Value = objEmployeeInfo.strRequirement_edu1;
            paramsToStore[28].Size = 50;



            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SaveEmployeeInfoKPMG", paramsToStore));



        }
        public int saveEmployeeInfoWIPROEdu(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[28];
            // 213+173

            paramsToStore[0] = new SqlParameter("@TAT2Date", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.TAT2;
            paramsToStore[0].Size = 50;



            paramsToStore[1] = new SqlParameter("@DateofJoining", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.DateofJoining;
            paramsToStore[1].Size = 50;



            paramsToStore[2] = new SqlParameter("@Edu1_UniversityName", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.Edu1_UniversityName;
            paramsToStore[2].Size = 150;




            paramsToStore[3] = new SqlParameter("@FatherName", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.FatherName;
            paramsToStore[3].Size = 150;



            paramsToStore[4] = new SqlParameter("@DOB", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.DOB;
            paramsToStore[4].Size = 50;


            paramsToStore[5] = new SqlParameter("@Edu1_RollNo", SqlDbType.VarChar);
            paramsToStore[5].Value = objEmployeeInfo.Edu1_RollNo;
            paramsToStore[5].Size = 50;



            paramsToStore[6] = new SqlParameter("@MiddleName", SqlDbType.VarChar);
            paramsToStore[6].Value = objEmployeeInfo.MiddleName;
            paramsToStore[6].Size = 50;

            paramsToStore[7] = new SqlParameter("@Edu1_CollegeName", SqlDbType.VarChar);
            paramsToStore[7].Value = objEmployeeInfo.Edu1_CollegeName;
            paramsToStore[7].Size = 50;



            paramsToStore[8] = new SqlParameter("@FirstName", SqlDbType.VarChar);
            paramsToStore[8].Value = objEmployeeInfo.FirstName;
            paramsToStore[8].Size = 150;


            paramsToStore[9] = new SqlParameter("@COE", SqlDbType.VarChar);
            paramsToStore[9].Value = objEmployeeInfo.COE;
            paramsToStore[9].Size = 50;

            paramsToStore[10] = new SqlParameter("@Mobile", SqlDbType.VarChar);
            paramsToStore[10].Value = objEmployeeInfo.Mobile;
            paramsToStore[10].Size = 50;



            paramsToStore[11] = new SqlParameter("@Band", SqlDbType.VarChar);
            paramsToStore[11].Value = objEmployeeInfo.Band;
            paramsToStore[11].Size = 50;

            paramsToStore[12] = new SqlParameter("@EmpIdProvidedByClient", SqlDbType.VarChar);
            paramsToStore[12].Value = objEmployeeInfo.EmpIdProvidedByClient;
            paramsToStore[12].Size = 50;

            paramsToStore[13] = new SqlParameter("@PlaceofBirth", SqlDbType.VarChar);
            paramsToStore[13].Value = objEmployeeInfo.PlaceofBirth;
            paramsToStore[13].Size = 150;

            paramsToStore[14] = new SqlParameter("@Surname", SqlDbType.VarChar);
            paramsToStore[14].Value = objEmployeeInfo.Surname;
            paramsToStore[14].Size = 50;

            paramsToStore[15] = new SqlParameter("@Edu1_YearOfPassing", SqlDbType.VarChar);
            paramsToStore[15].Value = objEmployeeInfo.Edu1_YearOfPassing;
            paramsToStore[15].Size = 50;

            paramsToStore[16] = new SqlParameter("@Mode", SqlDbType.VarChar);

            paramsToStore[16].Value = objEmployeeInfo.Mode;
            paramsToStore[16].Size = 20;

            paramsToStore[17] = new SqlParameter("@EmployeeID", SqlDbType.VarChar);
            paramsToStore[17].Value = objEmployeeInfo.EmployeeID;
            paramsToStore[17].Size = 20;

            paramsToStore[18] = new SqlParameter("@ClientName", SqlDbType.VarChar);
            paramsToStore[18].Value = objEmployeeInfo.ClientName;
            paramsToStore[18].Size = 50;

            paramsToStore[19] = new SqlParameter("@EmpHis3_AgencyDetails", SqlDbType.VarChar);
            paramsToStore[19].Value = objEmployeeInfo.EmpHis3_AgencyDetails;
            paramsToStore[19].Size = 50;

            //paramsToStore[20] = new SqlParameter("@NoOfComp", SqlDbType.VarChar);
            //paramsToStore[20].Value = objEmployeeInfo.NoOfComp;
            //paramsToStore[20].Size = 50;

            paramsToStore[20] = new SqlParameter("@CaseStatusWIPROEdu", SqlDbType.VarChar);
            paramsToStore[20].Value = objEmployeeInfo.CaseStatusWIPROEdu;
            paramsToStore[20].Size = 50;


            //paramsToStore[22] = new SqlParameter("@PlaceofBirth", SqlDbType.VarChar);
            //paramsToStore[22].Value = objEmployeeInfo.PlaceofBirth;
            //paramsToStore[22].Size = 150;

            paramsToStore[21] = new SqlParameter("@TATDate", SqlDbType.VarChar);
            paramsToStore[21].Value = objEmployeeInfo.TATDate;
            paramsToStore[21].Size = 50;

            //paramsToStore[23] = new SqlParameter("@COE", SqlDbType.VarChar);
            //paramsToStore[23].Value = objEmployeeInfo.COE;
            //paramsToStore[23].Size = 50;

            paramsToStore[22] = new SqlParameter("@ExperienceInYears", SqlDbType.VarChar);
            paramsToStore[22].Value = objEmployeeInfo.ExperienceInYears;
            paramsToStore[22].Size = 50;

            paramsToStore[23] = new SqlParameter("@Edu1_Address", SqlDbType.VarChar);
            paramsToStore[23].Value = objEmployeeInfo.Edu1_Address;
            paramsToStore[23].Size = 500;


            paramsToStore[24] = new SqlParameter("@Edu1_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[24].Value = objEmployeeInfo.Edu1_EducationalQualification;
            paramsToStore[24].Size = 150;

            paramsToStore[25] = new SqlParameter("@EmpHis1_IncaseOfGap", SqlDbType.VarChar);
            paramsToStore[25].Value = objEmployeeInfo.EmpHis1_IncaseOfGap;
            paramsToStore[25].Size = 50;

            paramsToStore[26] = new SqlParameter("@EducationList", SqlDbType.VarChar);
            paramsToStore[26].Value = objEmployeeInfo.EducationList;
            paramsToStore[26].Size = 50;


            paramsToStore[27] = new SqlParameter("@txtEducation1State", SqlDbType.VarChar);
            paramsToStore[27].Value = objEmployeeInfo.txtEducation1State;
            paramsToStore[27].Size = 50;


            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SaveEmployeeInfoWIPROEDU", paramsToStore));



        }

        public int saveEmployeeInfoWIPROCITY(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[28];
            // 213+173

            paramsToStore[0] = new SqlParameter("@TAT2Date", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.TAT2;
            paramsToStore[0].Size = 50;



            paramsToStore[1] = new SqlParameter("@DateofJoining", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.DateofJoining;
            paramsToStore[1].Size = 50;



            paramsToStore[2] = new SqlParameter("@Edu1_UniversityName", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.Edu1_UniversityName;
            paramsToStore[2].Size = 150;




            paramsToStore[3] = new SqlParameter("@FatherName", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.FatherName;
            paramsToStore[3].Size = 150;



            paramsToStore[4] = new SqlParameter("@DOB", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.DOB;
            paramsToStore[4].Size = 50;


            paramsToStore[5] = new SqlParameter("@Edu1_RollNo", SqlDbType.VarChar);
            paramsToStore[5].Value = objEmployeeInfo.Edu1_RollNo;
            paramsToStore[5].Size = 50;



            paramsToStore[6] = new SqlParameter("@MiddleName", SqlDbType.VarChar);
            paramsToStore[6].Value = objEmployeeInfo.MiddleName;
            paramsToStore[6].Size = 50;

            paramsToStore[7] = new SqlParameter("@Edu1_CollegeName", SqlDbType.VarChar);
            paramsToStore[7].Value = objEmployeeInfo.Edu1_CollegeName;
            paramsToStore[7].Size = 50;



            paramsToStore[8] = new SqlParameter("@FirstName", SqlDbType.VarChar);
            paramsToStore[8].Value = objEmployeeInfo.FirstName;
            paramsToStore[8].Size = 150;


            paramsToStore[9] = new SqlParameter("@COE", SqlDbType.VarChar);
            paramsToStore[9].Value = objEmployeeInfo.COE;
            paramsToStore[9].Size = 50;

            paramsToStore[10] = new SqlParameter("@Mobile", SqlDbType.VarChar);
            paramsToStore[10].Value = objEmployeeInfo.Mobile;
            paramsToStore[10].Size = 50;



            paramsToStore[11] = new SqlParameter("@Band", SqlDbType.VarChar);
            paramsToStore[11].Value = objEmployeeInfo.Band;
            paramsToStore[11].Size = 50;

            paramsToStore[12] = new SqlParameter("@EmpIdProvidedByClient", SqlDbType.VarChar);
            paramsToStore[12].Value = objEmployeeInfo.EmpIdProvidedByClient;
            paramsToStore[12].Size = 50;

            paramsToStore[13] = new SqlParameter("@PlaceofBirth", SqlDbType.VarChar);
            paramsToStore[13].Value = objEmployeeInfo.PlaceofBirth;
            paramsToStore[13].Size = 150;

            paramsToStore[14] = new SqlParameter("@Surname", SqlDbType.VarChar);
            paramsToStore[14].Value = objEmployeeInfo.Surname;
            paramsToStore[14].Size = 50;

            paramsToStore[15] = new SqlParameter("@Edu1_YearOfPassing", SqlDbType.VarChar);
            paramsToStore[15].Value = objEmployeeInfo.Edu1_YearOfPassing;
            paramsToStore[15].Size = 50;

            paramsToStore[16] = new SqlParameter("@Mode", SqlDbType.VarChar);

            paramsToStore[16].Value = objEmployeeInfo.Mode;
            paramsToStore[16].Size = 20;

            paramsToStore[17] = new SqlParameter("@EmployeeID", SqlDbType.VarChar);
            paramsToStore[17].Value = objEmployeeInfo.EmployeeID;
            paramsToStore[17].Size = 20;

            paramsToStore[18] = new SqlParameter("@ClientName", SqlDbType.VarChar);
            paramsToStore[18].Value = objEmployeeInfo.ClientName;
            paramsToStore[18].Size = 50;

            paramsToStore[19] = new SqlParameter("@EmpHis3_AgencyDetails", SqlDbType.VarChar);
            paramsToStore[19].Value = objEmployeeInfo.EmpHis3_AgencyDetails;
            paramsToStore[19].Size = 50;

            //paramsToStore[20] = new SqlParameter("@NoOfComp", SqlDbType.VarChar);
            //paramsToStore[20].Value = objEmployeeInfo.NoOfComp;
            //paramsToStore[20].Size = 50;

            paramsToStore[20] = new SqlParameter("@Casestatuswiprocity", SqlDbType.VarChar);
            paramsToStore[20].Value = objEmployeeInfo.Casestatuswiprocity;
            paramsToStore[20].Size = 50;


            //paramsToStore[22] = new SqlParameter("@PlaceofBirth", SqlDbType.VarChar);
            //paramsToStore[22].Value = objEmployeeInfo.PlaceofBirth;
            //paramsToStore[22].Size = 150;

            paramsToStore[21] = new SqlParameter("@TATDate", SqlDbType.VarChar);
            paramsToStore[21].Value = objEmployeeInfo.TATDate;
            paramsToStore[21].Size = 50;

            //paramsToStore[23] = new SqlParameter("@COE", SqlDbType.VarChar);
            //paramsToStore[23].Value = objEmployeeInfo.COE;
            //paramsToStore[23].Size = 50;

            paramsToStore[22] = new SqlParameter("@ExperienceInYears", SqlDbType.VarChar);
            paramsToStore[22].Value = objEmployeeInfo.ExperienceInYears;
            paramsToStore[22].Size = 50;

            paramsToStore[23] = new SqlParameter("@Edu1_Address", SqlDbType.VarChar);
            paramsToStore[23].Value = objEmployeeInfo.Edu1_Address;
            paramsToStore[23].Size = 500;


            paramsToStore[24] = new SqlParameter("@Edu1_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[24].Value = objEmployeeInfo.Edu1_EducationalQualification;
            paramsToStore[24].Size = 150;

            paramsToStore[25] = new SqlParameter("@EmpHis1_IncaseOfGap", SqlDbType.VarChar);
            paramsToStore[25].Value = objEmployeeInfo.EmpHis1_IncaseOfGap;
            paramsToStore[25].Size = 50;

            paramsToStore[26] = new SqlParameter("@EducationList", SqlDbType.VarChar);
            paramsToStore[26].Value = objEmployeeInfo.EducationList;
            paramsToStore[26].Size = 50;


            paramsToStore[27] = new SqlParameter("@txtEducation1State", SqlDbType.VarChar);
            paramsToStore[27].Value = objEmployeeInfo.txtEducation1State;
            paramsToStore[27].Size = 50;


            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SaveEmployeeInfoWIPROCITY", paramsToStore));



        }


        public DataSet SelectViewData(int EmployeeID)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "selectviewdata",
                  SQLDataAccess.CreateParameter("@EmployeeID", SqlDbType.Int, EmployeeID, ParameterDirection.Input, 4, false)


                );
            return dsServiceType;
        }

        public DataSet EmploymentViewData(int EmployeeID)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "EmploymentViewData",
                  SQLDataAccess.CreateParameter("@EmployeeID", SqlDbType.Int, EmployeeID, ParameterDirection.Input, 4, false)


                );
            return dsServiceType;
        }

        public DataSet DDViewData(int EmployeeID)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DDViewData",
                  SQLDataAccess.CreateParameter("@EmpID", SqlDbType.Int, EmployeeID, ParameterDirection.Input, 4, false)


                );
            return dsServiceType;
        }

        public DataSet UniversityViewData(string universityName)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UniversityViewData",
                  SQLDataAccess.CreateParameter("@uniName", SqlDbType.VarChar, universityName, ParameterDirection.Input, 150, false)


                );
            return dsServiceType;
        }

        public DataSet showUniversityData(string universityName)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "showUniversityData",
                  SQLDataAccess.CreateParameter("@uniName", SqlDbType.VarChar, universityName, ParameterDirection.Input, 150, false)


                );
            return dsServiceType;
        }

        public DataSet showDDData(int refId)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "showDDData",
                  SQLDataAccess.CreateParameter("@refid", SqlDbType.Int, refId, ParameterDirection.Input, 150, false)


                );
            return dsServiceType;
        }

        public DataSet showData(string universityName, string collegeName)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "showData",
                  SQLDataAccess.CreateParameter("@uniName", SqlDbType.VarChar, universityName, ParameterDirection.Input, 150, false),
                  SQLDataAccess.CreateParameter("@colName", SqlDbType.VarChar, collegeName, ParameterDirection.Input, 150, false)

                );
            return dsServiceType;
        }

        public DataSet ShowGrid(string universityName)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ShowGrid",
                  SQLDataAccess.CreateParameter("@uniName", SqlDbType.VarChar, universityName, ParameterDirection.Input, 150, false)


                );
            return dsServiceType;
        }

        public DataSet CollegeView(string collegeName)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "collegeNewView",
                  SQLDataAccess.CreateParameter("@colName", SqlDbType.VarChar, collegeName, ParameterDirection.Input, 150, false)


                );
            return dsServiceType;
        }

        public DataSet CollegeDataView(string universityName)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "CollegeDataView",
                  SQLDataAccess.CreateParameter("@uniName", SqlDbType.VarChar, universityName, ParameterDirection.Input, 150, false)


                );
            return dsServiceType;
        }


        public DataSet TruncateKPMGExcel()
        {
            DataSet band5;
            band5 = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "TruncateKPMGExcel");
            return band5;
        }
        public DataSet TruncateWIPROExcel()
        {
            DataSet band5;
            band5 = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "TruncateWIPROExcel");
            return band5;
        }
        public DataSet TruncateWIPROEduExcel()
        {
            DataSet band5;
            band5 = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "TruncateWIPROEduExcel");
            return band5;
        }
        public DataSet TruncateWIPROCityExcel()
        {
            DataSet band5;
            band5 = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "TruncateWIPROCityExcel");
            return band5;
        }





        public int doublecheck(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[7];
            // 213+173


            paramsToStore[4] = new SqlParameter("@DateofJoining", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.DateofJoining;
            paramsToStore[4].Size = 50;


            paramsToStore[1] = new SqlParameter("@FatherName", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.FatherName;
            paramsToStore[1].Size = 150;



            paramsToStore[5] = new SqlParameter("@DOB", SqlDbType.VarChar);
            paramsToStore[5].Value = objEmployeeInfo.DOB;
            paramsToStore[5].Size = 50;

            paramsToStore[6] = new SqlParameter("@Mobile", SqlDbType.VarChar);
            paramsToStore[6].Value = objEmployeeInfo.Mobile;
            paramsToStore[6].Size = 50;

            paramsToStore[0] = new SqlParameter("@FirstName", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.FirstName;
            paramsToStore[0].Size = 150;



            paramsToStore[2] = new SqlParameter("@ClientName", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.ClientName;




            paramsToStore[3] = new SqlParameter("@txt_ResumeNo", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.txt_ResumeNo;
            paramsToStore[3].Size = 50;





            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "doublecheck", paramsToStore));



        }

        public int dataexist(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[3];

            paramsToStore[0] = new SqlParameter("@UniName", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.strUniName;
            paramsToStore[0].Size = 150;

            paramsToStore[1] = new SqlParameter("@ColName", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.strColName;
            paramsToStore[1].Size = 150;

            paramsToStore[2] = new SqlParameter("@ColLocation", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.strColLoc;
            paramsToStore[2].Size = 100;


            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "dataexist", paramsToStore));



        }

        public int DDexist(string refid)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[1];

            paramsToStore[0] = new SqlParameter("@refId", SqlDbType.Int);
            paramsToStore[0].Value = refid;


            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "DDexist", paramsToStore));



        }

        public int UniExist(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[2];

            paramsToStore[0] = new SqlParameter("@UniName", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.strUniName;
            paramsToStore[0].Size = 200;

            paramsToStore[1] = new SqlParameter("@UniLocation", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.strUniLoc;
            paramsToStore[1].Size = 100;




            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "UniExist", paramsToStore));



        }

        public int saveEmploymentDetails(EmployeeInfo objEmployeeInfo,int cmpID, int empID, string check)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[115];
            // 213+173


            paramsToStore[97] = new SqlParameter("empID", empID);
         paramsToStore[0] = new SqlParameter("@cmpid ", cmpID);
         paramsToStore[1] = new SqlParameter("@organ1 ", strOrganisation1);
         paramsToStore[2] = new SqlParameter("@empdates1 ", strEmpDates1);
         paramsToStore[3] = new SqlParameter("@desig1 ", strDesignation1);
         paramsToStore[4] = new SqlParameter("@employeeid1 ", strEmpID1);
         paramsToStore[5] = new SqlParameter("@salary1", strSalary1);
         paramsToStore[6] = new SqlParameter("@mgr1 ", strMGR1);
         paramsToStore[7] = new SqlParameter("@leaving1 ", strLeaving1);
         paramsToStore[8] = new SqlParameter("@exit1 ", strExit1);
         paramsToStore[9] = new SqlParameter("@issue1 ", strIssue1);
         paramsToStore[10] = new SqlParameter("@dicip1 ", strDisciplinary1);
         paramsToStore[11] = new SqlParameter("@rehire1 ", strReHire1);
         paramsToStore[12] = new SqlParameter("@behaviour1 ", strBehaviour1);
         paramsToStore[13] = new SqlParameter("@organ2 ", strOrganisation2);
         paramsToStore[14] = new SqlParameter("@empdates2 ", strEmpDates2);
         paramsToStore[15] = new SqlParameter("@desig2 ", strDesignation2);
         paramsToStore[16] = new SqlParameter("@employeeid2 ", strEmpID2);
         paramsToStore[17] = new SqlParameter("@salary2 ", strSalary2);
         paramsToStore[18] = new SqlParameter("@mgr2 ", strMGR2);
         paramsToStore[19] = new SqlParameter("@leaving2 ", strLeaving2);
         paramsToStore[20] = new SqlParameter("@exit2 ", strExit2);
         paramsToStore[21] = new SqlParameter("@issue2 ", strIssue2);
         paramsToStore[22] = new SqlParameter("@dicip2 ", strDisciplinary2);
         paramsToStore[23] = new SqlParameter("@rehire2 ", strReHire2);
         paramsToStore[24] = new SqlParameter("@behaviour2 ", strBehaviour2);
         paramsToStore[25] = new SqlParameter("@organ3 ", strOrganisation3);
         paramsToStore[26] = new SqlParameter("@empdates3 ", strEmpDates3);
         paramsToStore[27] = new SqlParameter("@desig3 ", strDesignation3);
         paramsToStore[28] = new SqlParameter("@employeeid3 ", strEmpID3);
         paramsToStore[29] = new SqlParameter("@salary3 ", strSalary3);
         paramsToStore[30] = new SqlParameter("@mgr3 ", strMGR3);
         paramsToStore[31] = new SqlParameter("@leaving3 ", strLeaving3);
         paramsToStore[32] = new SqlParameter("@exit3 ", strExit3);
         paramsToStore[33] = new SqlParameter("@issue3 ", strIssue3);
         paramsToStore[34] = new SqlParameter("@dicip3 ", strDisciplinary3);
         paramsToStore[35] = new SqlParameter("@rehire3 ", strReHire3);
         paramsToStore[36] = new SqlParameter("@behaviour3 ", strBehaviour3);
         paramsToStore[37] = new SqlParameter("@organ4 ", strOrganisation4);
         paramsToStore[38] = new SqlParameter("@empdates4 ", strEmpDates4);
         paramsToStore[39] = new SqlParameter("@desig4 ", strDesignation4);
         paramsToStore[40] = new SqlParameter("@employeeid4 ", strEmpID4);
         paramsToStore[41] = new SqlParameter("@salary4 ", strSalary4);
         paramsToStore[42] = new SqlParameter("@mgr4 ", strMGR4);
         paramsToStore[43] = new SqlParameter("@leaving4 ", strLeaving4);
         paramsToStore[44] = new SqlParameter("@exit4 ", strExit4);
         paramsToStore[45] = new SqlParameter("@issue4 ", strIssue4);
         paramsToStore[46] = new SqlParameter("@dicip4 ", strDisciplinary4);
         paramsToStore[47] = new SqlParameter("@rehire4 ", strReHire4);
         paramsToStore[48] = new SqlParameter("@behaviour4 ", strBehaviour4);
         paramsToStore[49] = new SqlParameter("@organ5 ", strOrganisation5);
         paramsToStore[50] = new SqlParameter("@empdates5 ", strEmpDates5);
         paramsToStore[51] = new SqlParameter("@desig5 ", strDesignation5);
         paramsToStore[52] = new SqlParameter("@employeeid5 ", strEmpID5);
         paramsToStore[53] = new SqlParameter("@salary5 ", strSalary5);
         paramsToStore[54] = new SqlParameter("@mgr5 ", strMGR5);
         paramsToStore[55] = new SqlParameter("@leaving5 ", strLeaving5);
         paramsToStore[56] = new SqlParameter("@exit5 ", strExit5);
         paramsToStore[57] = new SqlParameter("@issue5 ", strIssue5);
         paramsToStore[58] = new SqlParameter("@dicip5 ", strDisciplinary5);
         paramsToStore[59] = new SqlParameter("@rehire5 ", strReHire5);
         paramsToStore[60] = new SqlParameter("@behaviour5 ", strBehaviour5);
         paramsToStore[61] = new SqlParameter("@organ6 ", strOrganisation6);
         paramsToStore[62] = new SqlParameter("@empdates6 ", strEmpDates6);
         paramsToStore[63] = new SqlParameter("@desig6 ", strDesignation6);
         paramsToStore[64] = new SqlParameter("@employeeid6 ", strEmpID6);
         paramsToStore[65] = new SqlParameter("@salary6 ", strSalary6);
         paramsToStore[66] = new SqlParameter("@mgr6 ", strMGR6);
         paramsToStore[67] = new SqlParameter("@leaving6 ", strLeaving6);
         paramsToStore[68] = new SqlParameter("@exit6 ", strExit6);
         paramsToStore[69] = new SqlParameter("@issue6 ", strIssue6);
         paramsToStore[70] = new SqlParameter("@dicip6 ", strDisciplinary6);
         paramsToStore[71] = new SqlParameter("@rehire6 ", strReHire6);
         paramsToStore[72] = new SqlParameter("@behaviour6 ", strBehaviour6);
         paramsToStore[73] = new SqlParameter("@organ7 ", strOrganisation7);
         paramsToStore[74] = new SqlParameter("@empdates7 ", strEmpDates7);
         paramsToStore[75] = new SqlParameter("@desig7 ", strDesignation7);
         paramsToStore[76] = new SqlParameter("@employeeid7 ", strEmpID7);
         paramsToStore[77] = new SqlParameter("@salary7 ", strSalary7);
         paramsToStore[78] = new SqlParameter("@mgr7 ", strMGR7);
         paramsToStore[79] = new SqlParameter("@leaving7 ", strLeaving7);
         paramsToStore[80] = new SqlParameter("@exit7 ", strExit7);
         paramsToStore[81] = new SqlParameter("@issue7 ", strIssue7);
         paramsToStore[82] = new SqlParameter("@dicip7 ", strDisciplinary7);
         paramsToStore[83] = new SqlParameter("@rehire7 ", strReHire7);
         paramsToStore[84] = new SqlParameter("@behaviour7 ", strBehaviour7);
         paramsToStore[85] = new SqlParameter("@organ8 ", strOrganisation8);
         paramsToStore[86] = new SqlParameter("@empdates8 ", strEmpDates8);
         paramsToStore[87] = new SqlParameter("@desig8 ", strDesignation8);
         paramsToStore[88] = new SqlParameter("@employeeid8 ", strEmpID8);
         paramsToStore[89] = new SqlParameter("@salary8 ", strSalary8);
         paramsToStore[90] = new SqlParameter("@mgr8 ", strMGR8);
         paramsToStore[91] = new SqlParameter("@leaving8 ", strLeaving8);
         paramsToStore[92] = new SqlParameter("@exit8 ", strExit8);
         paramsToStore[93] = new SqlParameter("@issue8 ", strIssue8);
         paramsToStore[94] = new SqlParameter("@dicip8 ", strDisciplinary8);
         paramsToStore[95] = new SqlParameter("@rehire8 ", strReHire8);
         paramsToStore[96] = new SqlParameter("@behaviour8 ", strBehaviour8);

         paramsToStore[98] = new SqlParameter("@organR1", strOrganisationR1);
         paramsToStore[99] = new SqlParameter("@refname1", strRefName1);
         paramsToStore[100] = new SqlParameter("@desigR1", strDesignationR1);
         paramsToStore[101] = new SqlParameter("@contact1", strContact1);
         paramsToStore[102] = new SqlParameter("@mail1", strMail1);
         paramsToStore[103] = new SqlParameter("@organR2", strOrganisationR2);
         paramsToStore[104] = new SqlParameter("@refname2", strRefName2);
         paramsToStore[105] = new SqlParameter("@desigR2", strDesignationR2);
         paramsToStore[106] = new SqlParameter("@contact2", strContact2);
         paramsToStore[107] = new SqlParameter("@mail2", strMail2);
         paramsToStore[108] = new SqlParameter("@organR3", strOrganisationR3);
         paramsToStore[109] = new SqlParameter("@refname3", strRefName3);
         paramsToStore[110] = new SqlParameter("@desigR3", strDesignationR3);
         paramsToStore[111] = new SqlParameter("@contact3", strContact3);
         paramsToStore[112] = new SqlParameter("@mail3", strMail3);

         paramsToStore[113] = new SqlParameter("@check", check);
         paramsToStore[114] = new SqlParameter("@Mode", Mode);




         return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "saveEmploymentDetails", paramsToStore));

        }

        public DataSet SelectEmploymentData(int EmployeeID)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SelectEmploymentData",
                  SQLDataAccess.CreateParameter("@EmployeeID", SqlDbType.Int, EmployeeID, ParameterDirection.Input, 4, false)


                );
            return dsServiceType;
        }


        public DataSet SelectEducationData(int EduID)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SelectEducationData",
                  SQLDataAccess.CreateParameter("@eduID", SqlDbType.Int, EduID, ParameterDirection.Input, 4, false)


                );
            return dsServiceType;
        }



        public int PriceClientdoublecheck(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[2];

            paramsToStore[0] = new SqlParameter("@ClientName", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.ClientName;
            paramsToStore[0].Size = 100;

            paramsToStore[1] = new SqlParameter("@Catagory", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.Catagory;
            paramsToStore[1].Size = 50;


            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "PriceClientdoublecheck", paramsToStore));





        }



        public int PriceForm(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[19];


            paramsToStore[0] = new SqlParameter("@ClientName", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.ClientName;
            paramsToStore[0].Size = 100;

            paramsToStore[1] = new SqlParameter("@TATDate", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.TATDate;
            paramsToStore[1].Size = 50;

            paramsToStore[2] = new SqlParameter("@Catagory", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.PriceEntryCatagory;
            paramsToStore[2].Size = 50;

            paramsToStore[3] = new SqlParameter("@BillingType", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.BillingType;
            paramsToStore[3].Size = 50;

            paramsToStore[4] = new SqlParameter("@EduRate", SqlDbType.Int);
            paramsToStore[4].Value = objEmployeeInfo.EduRate;


            paramsToStore[5] = new SqlParameter("@EmpRate", SqlDbType.Int);
            paramsToStore[5].Value = objEmployeeInfo.EmpRate;


            paramsToStore[6] = new SqlParameter("@AddRate", SqlDbType.Int);
            paramsToStore[6].Value = objEmployeeInfo.AddRate;


            paramsToStore[7] = new SqlParameter("@CriRate", SqlDbType.Int);
            paramsToStore[7].Value = objEmployeeInfo.CriRate;


            paramsToStore[8] = new SqlParameter("@RefRate", SqlDbType.Int);
            paramsToStore[8].Value = objEmployeeInfo.RefRate;


            paramsToStore[9] = new SqlParameter("@IdRate", SqlDbType.Int);
            paramsToStore[9].Value = objEmployeeInfo.IdRate;
            paramsToStore[9].Size = 500;

            paramsToStore[10] = new SqlParameter("@DBRate", SqlDbType.Int);
            paramsToStore[10].Value = objEmployeeInfo.DBRate;
            paramsToStore[10].Size = 50;

            paramsToStore[11] = new SqlParameter("@CourtRate", SqlDbType.Int);
            paramsToStore[11].Value = objEmployeeInfo.CourtRate;

            paramsToStore[12] = new SqlParameter("@Drugpanel5", SqlDbType.Int);
            paramsToStore[12].Value = objEmployeeInfo.Drugpanel5;

            paramsToStore[13] = new SqlParameter("@Remarks", SqlDbType.VarChar);
            paramsToStore[13].Value = objEmployeeInfo.PriceEntryFormRemarks;
            paramsToStore[13].Size = 100;


            paramsToStore[14] = new SqlParameter("@FixedAmount", SqlDbType.VarChar);
            paramsToStore[14].Value = objEmployeeInfo.FixedAmount;
            paramsToStore[14].Size = 100;


            paramsToStore[15] = new SqlParameter("@Drugpanel9", SqlDbType.Int);
            paramsToStore[15].Value = objEmployeeInfo.Drugpanel9;
            paramsToStore[15].Size = 100;

            paramsToStore[16] = new SqlParameter("@Drugpanel10", SqlDbType.Int);
            paramsToStore[16].Value = objEmployeeInfo.Drugpanel10;
            paramsToStore[16].Size = 100;

            paramsToStore[17] = new SqlParameter("@Drugpanel5withalcohol", SqlDbType.Int);
            paramsToStore[17].Value = objEmployeeInfo.Drugpanel5withalcohol;
            paramsToStore[17].Size = 100;

            paramsToStore[18] = new SqlParameter("@Drugpanelspecial", SqlDbType.Int);
            paramsToStore[18].Value = objEmployeeInfo.Drugpanelspecial;
            paramsToStore[18].Size = 100;



            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "PriceForm", paramsToStore));



        }


        public DataSet SelectAddCriData(int AddID)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SelectAddCriData",
                  SQLDataAccess.CreateParameter("@AddID", SqlDbType.Int, AddID, ParameterDirection.Input, 4, false)


                );
            return dsServiceType;
        }

        public DataSet CaseViewData(int EmployeeID)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "CaseViewData",
                  SQLDataAccess.CreateParameter("@EmployeeID", SqlDbType.Int, EmployeeID, ParameterDirection.Input, 4, false)


                );
            return dsServiceType;
        }

        public DataSet ShowChecksDetails(int EmployeeID)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "ShowChecksDetails",
                  SQLDataAccess.CreateParameter("@EmpID", SqlDbType.Int, EmployeeID, ParameterDirection.Input, 4, false)


                );
            return dsServiceType;
        }

        public DataSet SelectDrugViewData(int EmployeeID)
        {
            DataSet dsServiceType;
            dsServiceType = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "SelectDrugViewData",
                  SQLDataAccess.CreateParameter("@EmployeeID", SqlDbType.Int, EmployeeID, ParameterDirection.Input, 4, false)


                );
            return dsServiceType;
        }

        public DataSet showfile(EmployeeInfo objEmployeeInfo)
        {
            DataSet dr;

            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "showuploadfile",
                 SQLDataAccess.CreateParameter("@FirstName", SqlDbType.VarChar, FirstName, ParameterDirection.Input, 50, false),
                  SQLDataAccess.CreateParameter("@MiddleName", SqlDbType.VarChar, MiddleName, ParameterDirection.Input, 50, false),
                       SQLDataAccess.CreateParameter("@Surname", SqlDbType.VarChar, Surname, ParameterDirection.Input, 50, false),
                            SQLDataAccess.CreateParameter("@FatherName", SqlDbType.VarChar, FatherName, ParameterDirection.Input, 100, false),
                                 SQLDataAccess.CreateParameter("@Mobile", SqlDbType.VarChar, Mobile, ParameterDirection.Input, 50, false)





                );
            return dr;





        }

        public DataSet deleteupload(EmployeeInfo objEmployeeInfo)
        {
            DataSet dr;

            dr = SQLDataAccess.ExecuteDataset(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "deleteupload",
                 SQLDataAccess.CreateParameter("@FirstName", SqlDbType.VarChar, FirstName, ParameterDirection.Input, 50, false),
                  SQLDataAccess.CreateParameter("@MiddleName", SqlDbType.VarChar, MiddleName, ParameterDirection.Input, 50, false),
                       SQLDataAccess.CreateParameter("@Surname", SqlDbType.VarChar, Surname, ParameterDirection.Input, 50, false),
                            SQLDataAccess.CreateParameter("@FatherName", SqlDbType.VarChar, FatherName, ParameterDirection.Input, 100, false),
                                 SQLDataAccess.CreateParameter("@Mobile", SqlDbType.VarChar, Mobile, ParameterDirection.Input, 50, false),
                                    SQLDataAccess.CreateParameter("@Key", SqlDbType.VarChar, key, ParameterDirection.Input, 100, false)






                );
            return dr;





        }

        public int checkDuplicateEntry(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[5];
          


            paramsToStore[0] = new SqlParameter("@FirstName", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.FirstName;
            paramsToStore[0].Size = 150;

            paramsToStore[1] = new SqlParameter("@LastName", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.Surname;
            paramsToStore[1].Size = 150;

            paramsToStore[2] = new SqlParameter("@FatherName", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.FatherName;
            paramsToStore[2].Size = 150;

            paramsToStore[3] = new SqlParameter("@DOB", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.DOB;
            paramsToStore[3].Size = 50;

            paramsToStore[4] = new SqlParameter("@Mobile", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.Mobile;
            paramsToStore[4].Size = 50;



            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "checkDuplicateEntry", paramsToStore));



        }

        public int saveEmployeeInfoClient(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[551];


            paramsToStore[0] = new SqlParameter("@CurrentAddress", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.CurrentAddress;
            paramsToStore[0].Size = 500;

            paramsToStore[1] = new SqlParameter("@EmpHis1_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.EmpHis1_CompnayNameandLocation;
            paramsToStore[1].Size = 150;

            paramsToStore[2] = new SqlParameter("@EmpHis2_EmployeeCode", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.EmpHis2_EmployeeCode;
            paramsToStore[2].Size = 50;

            paramsToStore[3] = new SqlParameter("@EmpHis1RLvl2_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.EmpHis1RLvl2_TelepnoneNo;
            paramsToStore[3].Size = 50;

            paramsToStore[4] = new SqlParameter("@EmpHis2RLvl2_MobileNo", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.EmpHis2RLvl2_MobileNo;
            paramsToStore[4].Size = 50;

            paramsToStore[5] = new SqlParameter("@Per_LivingSince", SqlDbType.VarChar);
            paramsToStore[5].Value = objEmployeeInfo.Per_LivingSince;
            paramsToStore[5].Size = 100;

            paramsToStore[6] = new SqlParameter("@EmpHis1_EmployeeCode", SqlDbType.VarChar);
            paramsToStore[6].Value = objEmployeeInfo.EmpHis1_EmployeeCode;
            paramsToStore[6].Size = 50;

            paramsToStore[7] = new SqlParameter("@TAT2Date", SqlDbType.VarChar);
            paramsToStore[7].Value = objEmployeeInfo.TAT2;
            paramsToStore[7].Size = 50;

            paramsToStore[8] = new SqlParameter("@EmpHis2RLvl1_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[8].Value = objEmployeeInfo.EmpHis2RLvl1_TelepnoneNo;
            paramsToStore[8].Size = 50;

            paramsToStore[9] = new SqlParameter("@Edu1_Address", SqlDbType.VarChar);
            paramsToStore[9].Value = objEmployeeInfo.Edu1_Address;
            paramsToStore[9].Size = 500;

            paramsToStore[10] = new SqlParameter("@DateofJoining", SqlDbType.VarChar);
            paramsToStore[10].Value = objEmployeeInfo.DateofJoining;
            paramsToStore[10].Size = 50;

            paramsToStore[11] = new SqlParameter("@EmpHis1_TelephoneNo", SqlDbType.VarChar);
            paramsToStore[11].Value = objEmployeeInfo.EmpHis1_TelephoneNo;
            paramsToStore[11].Size = 50;

            paramsToStore[12] = new SqlParameter("@EmpHis2RLvl2_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[12].Value = objEmployeeInfo.EmpHis2RLvl2_TelepnoneNo;
            paramsToStore[12].Size = 50;

            paramsToStore[13] = new SqlParameter("@EmpHis2_IncaseOfGap", SqlDbType.VarChar);
            paramsToStore[13].Value = objEmployeeInfo.EmpHis2_IncaseOfGap;
            paramsToStore[13].Size = 50;

            paramsToStore[14] = new SqlParameter("@EmpHis2RLvl1_EmailId", SqlDbType.VarChar);
            paramsToStore[14].Value = objEmployeeInfo.EmpHis2RLvl1_EmailId;
            paramsToStore[14].Size = 150;

            paramsToStore[15] = new SqlParameter("@Edu1_UniversityName", SqlDbType.VarChar);
            paramsToStore[15].Value = objEmployeeInfo.Edu1_UniversityName;
            paramsToStore[15].Size = 150;

            paramsToStore[16] = new SqlParameter("@Per_Landmark", SqlDbType.VarChar);
            paramsToStore[16].Value = objEmployeeInfo.Per_Landmark;
            paramsToStore[16].Size = 50;

            paramsToStore[17] = new SqlParameter("@EmpHis2_AgencyDetails", SqlDbType.VarChar);
            paramsToStore[17].Value = objEmployeeInfo.EmpHis2_AgencyDetails;
            paramsToStore[17].Size = 50;

            paramsToStore[18] = new SqlParameter("@EmpHis1_referenceYN", SqlDbType.VarChar);
            paramsToStore[18].Value = objEmployeeInfo.EmpHis1_referenceYN;
            paramsToStore[18].Size = 50;

            paramsToStore[19] = new SqlParameter("@Per_PostOffice", SqlDbType.VarChar);
            paramsToStore[19].Value = objEmployeeInfo.Per_PostOffice;
            paramsToStore[19].Size = 50;

            paramsToStore[20] = new SqlParameter("@FatherName", SqlDbType.VarChar);
            paramsToStore[20].Value = objEmployeeInfo.FatherName;
            paramsToStore[20].Size = 150;

            paramsToStore[21] = new SqlParameter("@EmpHis1_LastPositionHeldnDepartmentName", SqlDbType.VarChar);
            paramsToStore[21].Value = objEmployeeInfo.EmpHis1_LastPositionHeldnDepartmentName;
            paramsToStore[21].Size = 150;

            paramsToStore[22] = new SqlParameter("@EmpHis2_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[22].Value = objEmployeeInfo.EmpHis2_CompnayNameandLocation;
            paramsToStore[22].Size = 150;

            paramsToStore[23] = new SqlParameter("@EmpHis1_PeriodofEmployment", SqlDbType.VarChar);
            paramsToStore[23].Value = objEmployeeInfo.EmpHis1_PeriodofEmployment;
            paramsToStore[23].Size = 50;

            paramsToStore[24] = new SqlParameter("@DOB", SqlDbType.VarChar);
            paramsToStore[24].Value = objEmployeeInfo.DOB;
            paramsToStore[24].Size = 50;

            paramsToStore[25] = new SqlParameter("@EmpHis2_referenceYN", SqlDbType.VarChar);
            paramsToStore[25].Value = objEmployeeInfo.EmpHis2_referenceYN;
            paramsToStore[25].Size = 50;

            paramsToStore[26] = new SqlParameter("@Edu1_RollNo", SqlDbType.VarChar);
            paramsToStore[26].Value = objEmployeeInfo.Edu1_RollNo;
            paramsToStore[26].Size = 50;

            paramsToStore[27] = new SqlParameter("@EmpHis1RLvl1_MobileNo", SqlDbType.VarChar);
            paramsToStore[27].Value = objEmployeeInfo.EmpHis1RLvl1_MobileNo;
            paramsToStore[27].Size = 50;

            paramsToStore[28] = new SqlParameter("@EmpHis1_TempPerma", SqlDbType.VarChar);
            paramsToStore[28].Value = objEmployeeInfo.EmpHis1_TempPerma;
            paramsToStore[28].Size = 50;

            paramsToStore[29] = new SqlParameter("@EmpHis2_Address", SqlDbType.VarChar);
            paramsToStore[29].Value = objEmployeeInfo.EmpHis2_Address;
            paramsToStore[29].Size = 500;

            paramsToStore[30] = new SqlParameter("@EmpHis1_PeriodofEmploymentRemark", SqlDbType.VarChar);
            paramsToStore[30].Value = objEmployeeInfo.EmpHis1_PeriodofEmploymentRemark;
            paramsToStore[30].Size = 50;

            paramsToStore[31] = new SqlParameter("@EmpHis1_IncaseOfGap", SqlDbType.VarChar);
            paramsToStore[31].Value = objEmployeeInfo.EmpHis1_IncaseOfGap;
            paramsToStore[31].Size = 50;

            paramsToStore[32] = new SqlParameter("@EmpHis2_TempPerma", SqlDbType.VarChar);
            paramsToStore[32].Value = objEmployeeInfo.EmpHis2_TempPerma;
            paramsToStore[32].Size = 50;

            paramsToStore[33] = new SqlParameter("@EmpHis1RLvl2_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[33].Value = objEmployeeInfo.EmpHis1RLvl2_NameDesignatinOfSupervisor;
            paramsToStore[33].Size = 150;

            paramsToStore[34] = new SqlParameter("@EmpHis2RLvl1_MobileNo", SqlDbType.VarChar);
            paramsToStore[34].Value = objEmployeeInfo.EmpHis2RLvl1_MobileNo;
            paramsToStore[34].Size = 50;

            paramsToStore[35] = new SqlParameter("@MiddleName", SqlDbType.VarChar);
            paramsToStore[35].Value = objEmployeeInfo.MiddleName;
            paramsToStore[35].Size = 50;

            paramsToStore[36] = new SqlParameter("@Edu1_CollegeName", SqlDbType.VarChar);
            paramsToStore[36].Value = objEmployeeInfo.Edu1_CollegeName;
            paramsToStore[36].Size = 250;

            paramsToStore[37] = new SqlParameter("@EmpHis2RLvl2_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[37].Value = objEmployeeInfo.EmpHis2RLvl2_NameDesignatinOfSupervisor;
            paramsToStore[37].Size = 50;

            paramsToStore[38] = new SqlParameter("@EmpHis1_AgencyDetails", SqlDbType.VarChar);
            paramsToStore[38].Value = objEmployeeInfo.EmpHis1_AgencyDetails;
            paramsToStore[38].Size = 50;

            paramsToStore[39] = new SqlParameter("@EmpHis2RLvl1_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[39].Value = objEmployeeInfo.EmpHis2RLvl1_NameDesignatinOfSupervisor;
            paramsToStore[39].Size = 150;

            paramsToStore[40] = new SqlParameter("@FirstName", SqlDbType.VarChar);
            paramsToStore[40].Value = objEmployeeInfo.FirstName;
            paramsToStore[40].Size = 150;

            paramsToStore[41] = new SqlParameter("@Per_AddressPhoneNo", SqlDbType.VarChar);
            paramsToStore[41].Value = objEmployeeInfo.Per_AddressPhoneNo;
            paramsToStore[41].Size = 50;

            paramsToStore[42] = new SqlParameter("@EmpHis2_PeriodofEmployment", SqlDbType.VarChar);
            paramsToStore[42].Value = objEmployeeInfo.EmpHis2_PeriodofEmployment;
            paramsToStore[42].Size = 50;

            paramsToStore[43] = new SqlParameter("@EmpHis2RLvl2_EmailId", SqlDbType.VarChar);
            paramsToStore[43].Value = objEmployeeInfo.EmpHis2RLvl2_EmailId;
            paramsToStore[43].Size = 50;

            paramsToStore[44] = new SqlParameter("@COE", SqlDbType.VarChar);
            paramsToStore[44].Value = objEmployeeInfo.COE;
            paramsToStore[44].Size = 50;

            paramsToStore[45] = new SqlParameter("@Mobile", SqlDbType.VarChar);
            paramsToStore[45].Value = objEmployeeInfo.Mobile;
            paramsToStore[45].Size = 50;

            paramsToStore[46] = new SqlParameter("@Per_City", SqlDbType.VarChar);
            paramsToStore[46].Value = objEmployeeInfo.Per_City;
            paramsToStore[46].Size = 50;

            paramsToStore[47] = new SqlParameter("@Curr_PhoneNo", SqlDbType.VarChar);
            paramsToStore[47].Value = objEmployeeInfo.Curr_PhoneNo;
            paramsToStore[47].Size = 50;

            paramsToStore[48] = new SqlParameter("@EmpHis2_LastPositionHeldnDepartmentName", SqlDbType.VarChar);
            paramsToStore[48].Value = objEmployeeInfo.EmpHis2_LastPositionHeldnDepartmentName;
            paramsToStore[48].Size = 150;

            paramsToStore[49] = new SqlParameter("@EmpHis1_Address", SqlDbType.VarChar);
            paramsToStore[49].Value = objEmployeeInfo.EmpHis1_Address;
            paramsToStore[49].Size = 500;

            paramsToStore[50] = new SqlParameter("@Edu1_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[50].Value = objEmployeeInfo.Edu1_EducationalQualification;
            paramsToStore[50].Size = 100;

            paramsToStore[51] = new SqlParameter("@EmpHis1RLvl1_EmailId", SqlDbType.VarChar);
            paramsToStore[51].Value = objEmployeeInfo.EmpHis1RLvl1_EmailId;
            paramsToStore[51].Size = 150;

            paramsToStore[52] = new SqlParameter("@InDate", SqlDbType.VarChar);
            paramsToStore[52].Value = objEmployeeInfo.InDate;
            paramsToStore[52].Size = 50;

            paramsToStore[53] = new SqlParameter("@Per_PoliceStation", SqlDbType.VarChar);
            paramsToStore[53].Value = objEmployeeInfo.Per_PoliceStation;
            paramsToStore[53].Size = 50;

            paramsToStore[54] = new SqlParameter("@EmpHis2_TelephoneNo", SqlDbType.VarChar);
            paramsToStore[54].Value = objEmployeeInfo.EmpHis2_TelephoneNo;
            paramsToStore[54].Size = 50;

            paramsToStore[55] = new SqlParameter("@EmpHis1_ReasonOfLeaving", SqlDbType.VarChar);
            paramsToStore[55].Value = objEmployeeInfo.EmpHis1_ReasonOfLeaving;
            paramsToStore[55].Size = 50;

            paramsToStore[56] = new SqlParameter("@EmpHis1_RemunerationOrSalary", SqlDbType.VarChar);
            paramsToStore[56].Value = objEmployeeInfo.EmpHis1_RemunerationOrSalary;
            paramsToStore[56].Size = 50;

            paramsToStore[57] = new SqlParameter("@EnteredByLoginIdType", SqlDbType.VarChar);
            paramsToStore[57].Value = objEmployeeInfo.EnteredByLoginIdType;
            paramsToStore[57].Size = 50;

            paramsToStore[58] = new SqlParameter("@Band", SqlDbType.VarChar);
            paramsToStore[58].Value = objEmployeeInfo.Band;
            paramsToStore[58].Size = 50;

            paramsToStore[59] = new SqlParameter("@EmpHis2_ReasonOfLeaving", SqlDbType.VarChar);
            paramsToStore[59].Value = objEmployeeInfo.EmpHis2_ReasonOfLeaving;
            paramsToStore[59].Size = 50;

            paramsToStore[60] = new SqlParameter("@Per_State", SqlDbType.VarChar);
            paramsToStore[60].Value = objEmployeeInfo.Per_State;
            paramsToStore[60].Size = 50;

            paramsToStore[61] = new SqlParameter("@EmpIdProvidedByClient", SqlDbType.VarChar);
            paramsToStore[61].Value = objEmployeeInfo.EmpIdProvidedByClient;
            paramsToStore[61].Size = 50;

            paramsToStore[62] = new SqlParameter("@PlaceofBirth", SqlDbType.VarChar);
            paramsToStore[62].Value = objEmployeeInfo.PlaceofBirth;
            paramsToStore[62].Size = 150;

            paramsToStore[63] = new SqlParameter("@Surname", SqlDbType.VarChar);
            paramsToStore[63].Value = objEmployeeInfo.Surname;
            paramsToStore[63].Size = 50;

            paramsToStore[64] = new SqlParameter("@ExperienceInYears", SqlDbType.VarChar);
            paramsToStore[64].Value = objEmployeeInfo.ExperienceInYears;
            paramsToStore[64].Size = 50;

            paramsToStore[65] = new SqlParameter("@PermanentAddress", SqlDbType.VarChar);
            paramsToStore[65].Value = objEmployeeInfo.PermanentAddress;
            paramsToStore[65].Size = 500;

            paramsToStore[66] = new SqlParameter("@Curr_City", SqlDbType.VarChar);
            paramsToStore[66].Value = objEmployeeInfo.Curr_City;
            paramsToStore[66].Size = 50;

            paramsToStore[67] = new SqlParameter("@EmpHis2_RemunerationOrSalary", SqlDbType.VarChar);
            paramsToStore[67].Value = objEmployeeInfo.EmpHis2_RemunerationOrSalary;
            paramsToStore[67].Size = 50;

            //paramsToStore[68] = new SqlParameter("@EmployeeID", SqlDbType.VarChar);
            //paramsToStore[68].Value = objEmployeeInfo.EmployeeID;
            //paramsToStore[68].Size = 50;

            paramsToStore[68] = new SqlParameter("@Curr_State", SqlDbType.VarChar);
            paramsToStore[68].Value = objEmployeeInfo.Curr_State;
            paramsToStore[68].Size = 50;

            paramsToStore[69] = new SqlParameter("@EmpHis1RLvl1_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[69].Value = objEmployeeInfo.EmpHis1RLvl1_TelepnoneNo;
            paramsToStore[69].Size = 50;

            paramsToStore[70] = new SqlParameter("@EmpHis1RLvl2_EmailId", SqlDbType.VarChar);
            paramsToStore[70].Value = objEmployeeInfo.EmpHis1RLvl2_EmailId;
            paramsToStore[70].Size = 50;

            //paramsToStore[72] = new SqlParameter("@EmpHis2_PeriodofEmploymentRemark", SqlDbType.VarChar);
            //paramsToStore[72].Value = objEmployeeInfo.EmpHis2_PeriodofEmploymentRemark;
            //paramsToStore[72].Size = 50;

            paramsToStore[71] = new SqlParameter("@EmpHis2_PeriodofEmploymentRemark", SqlDbType.VarChar);
            paramsToStore[71].Value = objEmployeeInfo.EmpHis2_PeriodofEmploymentRemark;
            paramsToStore[71].Size = 50;

            paramsToStore[72] = new SqlParameter("@EmpHis1RLvl1_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[72].Value = objEmployeeInfo.EmpHis1RLvl1_NameDesignatinOfSupervisor;
            paramsToStore[72].Size = 150;

            paramsToStore[73] = new SqlParameter("@Edu1_YearOfPassing", SqlDbType.VarChar);
            paramsToStore[73].Value = objEmployeeInfo.Edu1_YearOfPassing;
            paramsToStore[73].Size = 50;

            paramsToStore[74] = new SqlParameter("@Mode", SqlDbType.VarChar);

            paramsToStore[74].Value = objEmployeeInfo.Mode;
            paramsToStore[74].Size = 20;

            paramsToStore[75] = new SqlParameter("@EmployeeID", SqlDbType.VarChar);
            paramsToStore[75].Value = objEmployeeInfo.EmployeeID;
            paramsToStore[75].Size = 20;
            //private int strEmployeeId;
            //private string CaseStatus;
            //private string AllocatedStatus;
            //private string AddressStatus;
            //private string AddressRemarks;
            //private string EducationStatus;
            //private string EducationRemarks;
            //private string EmploymentStatus;
            //private string EmploymentRemarks;
            //private string CriminalStatus;
            //private string CriminalRemarks;
            //private string ReferenceStatus;

            //private string ReferenceRemarks;
            //private string DrugtestStatus;
            //private string DrugtestRemarks;

            paramsToStore[76] = new SqlParameter("@CaseStatus", SqlDbType.VarChar);
            paramsToStore[76].Value = objEmployeeInfo.CaseStatus;
            paramsToStore[76].Size = 20;

            paramsToStore[77] = new SqlParameter("@AllocatedStatus", SqlDbType.VarChar);
            paramsToStore[77].Value = objEmployeeInfo.AllocatedStatus;
            paramsToStore[77].Size = 20;



            paramsToStore[78] = new SqlParameter("@datetoemphis1", SqlDbType.VarChar);
            paramsToStore[78].Value = objEmployeeInfo.datetoemphis1;
            paramsToStore[78].Size = 20;

            paramsToStore[79] = new SqlParameter("@datetoemphis2", SqlDbType.VarChar);
            paramsToStore[79].Value = objEmployeeInfo.datetoemphis2;
            paramsToStore[79].Size = 20;

            paramsToStore[80] = new SqlParameter("@ReportingLevel2emp1", SqlDbType.VarChar);
            paramsToStore[80].Value = objEmployeeInfo.ReportingLevel2emp1;

            paramsToStore[81] = new SqlParameter("@ReportingLevel2emp2", SqlDbType.VarChar);
            paramsToStore[81].Value = objEmployeeInfo.ReportingLevel2emp2;


            paramsToStore[82] = new SqlParameter("@EmploymentType", SqlDbType.VarChar);
            paramsToStore[82].Value = objEmployeeInfo.employmentType;


            paramsToStore[83] = new SqlParameter("@RejectedRemarks", SqlDbType.VarChar);
            paramsToStore[83].Value = objEmployeeInfo.RejectedRemarks;

            paramsToStore[84] = new SqlParameter("@ClientName", SqlDbType.VarChar);
            paramsToStore[84].Value = objEmployeeInfo.ClientName;
            //new fields

            paramsToStore[85] = new SqlParameter("@EmpHis3_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[85].Value = objEmployeeInfo.EmpHis3_CompnayNameandLocation;
            paramsToStore[85].Size = 50;

            paramsToStore[86] = new SqlParameter("@EmpHis3_LastPositionHeldnDepartmentName", SqlDbType.VarChar);
            paramsToStore[86].Value = objEmployeeInfo.EmpHis3_LastPositionHeldnDepartmentName;
            paramsToStore[86].Size = 50;

            paramsToStore[87] = new SqlParameter("@EmpHis3_Address", SqlDbType.VarChar);
            paramsToStore[87].Value = objEmployeeInfo.EmpHis3_Address;
            paramsToStore[87].Size = 500;

            paramsToStore[88] = new SqlParameter("@EmpHis3_EmployeeCode", SqlDbType.VarChar);
            paramsToStore[88].Value = objEmployeeInfo.EmpHis3_EmployeeCode;
            paramsToStore[88].Size = 50;

            paramsToStore[89] = new SqlParameter("@EmpHis3_PeriodofEmployment", SqlDbType.VarChar);
            paramsToStore[89].Value = objEmployeeInfo.EmpHis3_PeriodofEmployment;
            paramsToStore[89].Size = 50;

            paramsToStore[90] = new SqlParameter("@datetoempHis3", SqlDbType.VarChar);
            paramsToStore[90].Value = objEmployeeInfo.datetoempHis3;
            paramsToStore[90].Size = 50;

            paramsToStore[91] = new SqlParameter("@EmpHis3_PeriodofEmploymentRemark", SqlDbType.VarChar);
            paramsToStore[91].Value = objEmployeeInfo.EmpHis3_PeriodofEmploymentRemark;
            paramsToStore[91].Size = 50;

            paramsToStore[92] = new SqlParameter("@EmpHis3RLvl1_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[92].Value = objEmployeeInfo.EmpHis3RLvl1_NameDesignatinOfSupervisor;
            paramsToStore[92].Size = 50;

            paramsToStore[93] = new SqlParameter("@EmpHis3RLvl1_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[93].Value = objEmployeeInfo.EmpHis3RLvl1_TelepnoneNo;
            paramsToStore[93].Size = 50;


            paramsToStore[94] = new SqlParameter("@EmpHis3RLvl1_MobileNo", SqlDbType.VarChar);
            paramsToStore[94].Value = objEmployeeInfo.EmpHis3RLvl1_MobileNo;
            paramsToStore[94].Size = 50;

            paramsToStore[95] = new SqlParameter("@EmpHis3RLvl1_EmailId", SqlDbType.VarChar);
            paramsToStore[95].Value = objEmployeeInfo.EmpHis3RLvl1_EmailId;
            paramsToStore[95].Size = 50;

            paramsToStore[96] = new SqlParameter("@EmpHis3RLvl2_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[96].Value = objEmployeeInfo.EmpHis3RLvl2_NameDesignatinOfSupervisor;
            paramsToStore[96].Size = 50;

            paramsToStore[97] = new SqlParameter("@EmpHis3RLvl2_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[97].Value = objEmployeeInfo.EmpHis3RLvl2_TelepnoneNo;
            paramsToStore[97].Size = 50;

            paramsToStore[98] = new SqlParameter("@EmpHis3RLvl2_MobileNo", SqlDbType.VarChar);
            paramsToStore[98].Value = objEmployeeInfo.EmpHis3RLvl2_MobileNo;
            paramsToStore[98].Size = 50;

            paramsToStore[99] = new SqlParameter("@EmpHis3RLvl2_EmailId", SqlDbType.VarChar);
            paramsToStore[99].Value = objEmployeeInfo.EmpHis3RLvl2_EmailId;
            paramsToStore[99].Size = 50;

            paramsToStore[100] = new SqlParameter("@EmpHis3_TempPerma", SqlDbType.VarChar);
            paramsToStore[100].Value = objEmployeeInfo.EmpHis3_TempPerma;
            paramsToStore[100].Size = 50;

            paramsToStore[101] = new SqlParameter("@EmpHis3_AgencyDetails", SqlDbType.VarChar);
            paramsToStore[101].Value = objEmployeeInfo.EmpHis3_AgencyDetails;
            paramsToStore[101].Size = 50;

            paramsToStore[102] = new SqlParameter("@EmpHis3_RemunerationOrSalary", SqlDbType.VarChar);
            paramsToStore[102].Value = objEmployeeInfo.EmpHis3_RemunerationOrSalary;
            paramsToStore[102].Size = 50;

            paramsToStore[103] = new SqlParameter("@EmpHis3_ReasonOfLeaving", SqlDbType.VarChar);
            paramsToStore[103].Value = objEmployeeInfo.EmpHis3_ReasonOfLeaving;
            paramsToStore[103].Size = 50;

            paramsToStore[104] = new SqlParameter("@EmpHis3_referenceYN", SqlDbType.VarChar);
            paramsToStore[104].Value = objEmployeeInfo.EmpHis3_referenceYN;
            paramsToStore[104].Size = 50;

            paramsToStore[105] = new SqlParameter("@EmpHis3_IncaseOfGap", SqlDbType.VarChar);
            paramsToStore[105].Value = objEmployeeInfo.EmpHis3_IncaseOfGap;
            paramsToStore[105].Size = 50;


            paramsToStore[106] = new SqlParameter("@ExperienceInYears3", SqlDbType.VarChar);
            paramsToStore[106].Value = objEmployeeInfo.ExperienceInYears3;
            paramsToStore[106].Size = 50;


            paramsToStore[107] = new SqlParameter("@ReportingLevel2emp3", SqlDbType.VarChar);
            paramsToStore[107].Value = objEmployeeInfo.ReportingLevel2emp3;
            paramsToStore[107].Size = 50;


            //Company 4
            paramsToStore[108] = new SqlParameter("@EmpHis4_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[108].Value = objEmployeeInfo.EmpHis4_CompnayNameandLocation;
            paramsToStore[108].Size = 50;

            paramsToStore[109] = new SqlParameter("@EmpHis4_LastPositionHeldnDepartmentName", SqlDbType.VarChar);
            paramsToStore[109].Value = objEmployeeInfo.EmpHis4_LastPositionHeldnDepartmentName;
            paramsToStore[109].Size = 50;

            paramsToStore[110] = new SqlParameter("@EmpHis4_Address", SqlDbType.VarChar);
            paramsToStore[110].Value = objEmployeeInfo.EmpHis4_Address;
            paramsToStore[110].Size = 500;

            paramsToStore[111] = new SqlParameter("@EmpHis4_EmployeeCode", SqlDbType.VarChar);
            paramsToStore[111].Value = objEmployeeInfo.EmpHis4_EmployeeCode;
            paramsToStore[111].Size = 50;

            paramsToStore[112] = new SqlParameter("@EmpHis4_PeriodofEmployment", SqlDbType.VarChar);
            paramsToStore[112].Value = objEmployeeInfo.EmpHis4_PeriodofEmployment;
            paramsToStore[112].Size = 50;

            paramsToStore[113] = new SqlParameter("@datetoempHis4", SqlDbType.VarChar);
            paramsToStore[113].Value = objEmployeeInfo.datetoempHis4;
            paramsToStore[113].Size = 50;

            paramsToStore[114] = new SqlParameter("@EmpHis4_PeriodofEmploymentRemark", SqlDbType.VarChar);
            paramsToStore[114].Value = objEmployeeInfo.EmpHis4_PeriodofEmploymentRemark;
            paramsToStore[114].Size = 50;

            paramsToStore[115] = new SqlParameter("@EmpHis4RLvl1_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[115].Value = objEmployeeInfo.EmpHis4RLvl1_NameDesignatinOfSupervisor;
            paramsToStore[115].Size = 50;

            paramsToStore[116] = new SqlParameter("@EmpHis4RLvl1_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[116].Value = objEmployeeInfo.EmpHis4RLvl1_TelepnoneNo;
            paramsToStore[116].Size = 50;


            paramsToStore[117] = new SqlParameter("@EmpHis4RLvl1_MobileNo", SqlDbType.VarChar);
            paramsToStore[117].Value = objEmployeeInfo.EmpHis4RLvl1_MobileNo;
            paramsToStore[117].Size = 50;

            paramsToStore[118] = new SqlParameter("@EmpHis4RLvl1_EmailId", SqlDbType.VarChar);
            paramsToStore[118].Value = objEmployeeInfo.EmpHis4RLvl1_EmailId;
            paramsToStore[118].Size = 50;

            paramsToStore[119] = new SqlParameter("@EmpHis4RLvl2_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[119].Value = objEmployeeInfo.EmpHis4RLvl2_NameDesignatinOfSupervisor;
            paramsToStore[119].Size = 50;

            paramsToStore[120] = new SqlParameter("@EmpHis4RLvl2_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[120].Value = objEmployeeInfo.EmpHis4RLvl2_TelepnoneNo;
            paramsToStore[120].Size = 50;

            paramsToStore[121] = new SqlParameter("@EmpHis4RLvl2_MobileNo", SqlDbType.VarChar);
            paramsToStore[121].Value = objEmployeeInfo.EmpHis4RLvl2_MobileNo;
            paramsToStore[121].Size = 50;

            paramsToStore[122] = new SqlParameter("@EmpHis4RLvl2_EmailId", SqlDbType.VarChar);
            paramsToStore[122].Value = objEmployeeInfo.EmpHis4RLvl2_EmailId;
            paramsToStore[122].Size = 50;

            paramsToStore[123] = new SqlParameter("@EmpHis4_TempPerma", SqlDbType.VarChar);
            paramsToStore[123].Value = objEmployeeInfo.EmpHis4_TempPerma;
            paramsToStore[123].Size = 50;

            paramsToStore[124] = new SqlParameter("@EmpHis4_AgencyDetails", SqlDbType.VarChar);
            paramsToStore[124].Value = objEmployeeInfo.EmpHis4_AgencyDetails;
            paramsToStore[124].Size = 50;

            paramsToStore[125] = new SqlParameter("@EmpHis4_RemunerationOrSalary", SqlDbType.VarChar);
            paramsToStore[125].Value = objEmployeeInfo.EmpHis4_RemunerationOrSalary;
            paramsToStore[125].Size = 50;

            paramsToStore[126] = new SqlParameter("@EmpHis4_ReasonOfLeaving", SqlDbType.VarChar);
            paramsToStore[126].Value = objEmployeeInfo.EmpHis4_ReasonOfLeaving;
            paramsToStore[126].Size = 50;

            paramsToStore[127] = new SqlParameter("@EmpHis4_referenceYN", SqlDbType.VarChar);
            paramsToStore[127].Value = objEmployeeInfo.EmpHis4_referenceYN;
            paramsToStore[127].Size = 50;

            paramsToStore[128] = new SqlParameter("@EmpHis4_IncaseOfGap", SqlDbType.VarChar);
            paramsToStore[128].Value = objEmployeeInfo.EmpHis4_IncaseOfGap;
            paramsToStore[128].Size = 50;


            paramsToStore[129] = new SqlParameter("@ExperienceInYears4", SqlDbType.VarChar);
            paramsToStore[129].Value = objEmployeeInfo.ExperienceInYears4;
            paramsToStore[129].Size = 50;


            paramsToStore[130] = new SqlParameter("@ReportingLevel2emp4", SqlDbType.VarChar);
            paramsToStore[130].Value = objEmployeeInfo.ReportingLevel2emp4;
            paramsToStore[130].Size = 50;

            //Company 5

            paramsToStore[131] = new SqlParameter("@EmpHis5_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[131].Value = objEmployeeInfo.EmpHis5_CompnayNameandLocation;
            paramsToStore[131].Size = 50;

            paramsToStore[132] = new SqlParameter("@EmpHis5_LastPositionHeldnDepartmentName", SqlDbType.VarChar);
            paramsToStore[132].Value = objEmployeeInfo.EmpHis5_LastPositionHeldnDepartmentName;
            paramsToStore[132].Size = 50;

            paramsToStore[133] = new SqlParameter("@EmpHis5_Address", SqlDbType.VarChar);
            paramsToStore[133].Value = objEmployeeInfo.EmpHis5_Address;
            paramsToStore[133].Size = 500;

            paramsToStore[134] = new SqlParameter("@EmpHis5_EmployeeCode", SqlDbType.VarChar);
            paramsToStore[134].Value = objEmployeeInfo.EmpHis5_EmployeeCode;
            paramsToStore[134].Size = 50;

            paramsToStore[135] = new SqlParameter("@EmpHis5_PeriodofEmployment", SqlDbType.VarChar);
            paramsToStore[135].Value = objEmployeeInfo.EmpHis5_PeriodofEmployment;
            paramsToStore[135].Size = 50;

            paramsToStore[136] = new SqlParameter("@datetoempHis5", SqlDbType.VarChar);
            paramsToStore[136].Value = objEmployeeInfo.datetoempHis5;
            paramsToStore[136].Size = 50;

            paramsToStore[137] = new SqlParameter("@EmpHis5_PeriodofEmploymentRemark", SqlDbType.VarChar);
            paramsToStore[137].Value = objEmployeeInfo.EmpHis5_PeriodofEmploymentRemark;
            paramsToStore[137].Size = 50;

            paramsToStore[138] = new SqlParameter("@EmpHis5RLvl1_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[138].Value = objEmployeeInfo.EmpHis5RLvl1_NameDesignatinOfSupervisor;
            paramsToStore[138].Size = 50;

            paramsToStore[139] = new SqlParameter("@EmpHis5RLvl1_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[139].Value = objEmployeeInfo.EmpHis5RLvl1_TelepnoneNo;
            paramsToStore[139].Size = 50;


            paramsToStore[140] = new SqlParameter("@EmpHis5RLvl1_MobileNo", SqlDbType.VarChar);
            paramsToStore[140].Value = objEmployeeInfo.EmpHis5RLvl1_MobileNo;
            paramsToStore[140].Size = 50;

            paramsToStore[141] = new SqlParameter("@EmpHis5RLvl1_EmailId", SqlDbType.VarChar);
            paramsToStore[141].Value = objEmployeeInfo.EmpHis5RLvl1_EmailId;
            paramsToStore[141].Size = 50;

            paramsToStore[142] = new SqlParameter("@EmpHis5RLvl2_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[142].Value = objEmployeeInfo.EmpHis5RLvl2_NameDesignatinOfSupervisor;
            paramsToStore[142].Size = 50;

            paramsToStore[143] = new SqlParameter("@EmpHis5RLvl2_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[143].Value = objEmployeeInfo.EmpHis5RLvl2_TelepnoneNo;
            paramsToStore[143].Size = 50;

            paramsToStore[144] = new SqlParameter("@EmpHis5RLvl2_MobileNo", SqlDbType.VarChar);
            paramsToStore[144].Value = objEmployeeInfo.EmpHis5RLvl2_MobileNo;
            paramsToStore[144].Size = 50;

            paramsToStore[145] = new SqlParameter("@EmpHis5RLvl2_EmailId", SqlDbType.VarChar);
            paramsToStore[145].Value = objEmployeeInfo.EmpHis5RLvl2_EmailId;
            paramsToStore[145].Size = 50;

            paramsToStore[146] = new SqlParameter("@EmpHis5_TempPerma", SqlDbType.VarChar);
            paramsToStore[146].Value = objEmployeeInfo.EmpHis5_TempPerma;
            paramsToStore[146].Size = 50;

            paramsToStore[147] = new SqlParameter("@EmpHis5_AgencyDetails", SqlDbType.VarChar);
            paramsToStore[147].Value = objEmployeeInfo.EmpHis5_AgencyDetails;
            paramsToStore[147].Size = 50;

            paramsToStore[148] = new SqlParameter("@EmpHis5_RemunerationOrSalary", SqlDbType.VarChar);
            paramsToStore[148].Value = objEmployeeInfo.EmpHis5_RemunerationOrSalary;
            paramsToStore[148].Size = 50;

            paramsToStore[149] = new SqlParameter("@EmpHis5_ReasonOfLeaving", SqlDbType.VarChar);
            paramsToStore[149].Value = objEmployeeInfo.EmpHis5_ReasonOfLeaving;
            paramsToStore[149].Size = 50;

            paramsToStore[150] = new SqlParameter("@EmpHis5_referenceYN", SqlDbType.VarChar);
            paramsToStore[150].Value = objEmployeeInfo.EmpHis5_referenceYN;
            paramsToStore[150].Size = 50;

            paramsToStore[151] = new SqlParameter("@EmpHis5_IncaseOfGap", SqlDbType.VarChar);
            paramsToStore[151].Value = objEmployeeInfo.EmpHis5_IncaseOfGap;
            paramsToStore[151].Size = 50;


            paramsToStore[152] = new SqlParameter("@ExperienceInYears5", SqlDbType.VarChar);
            paramsToStore[152].Value = objEmployeeInfo.ExperienceInYears5;
            paramsToStore[152].Size = 50;


            paramsToStore[153] = new SqlParameter("@ReportingLevel2emp5", SqlDbType.VarChar);
            paramsToStore[153].Value = objEmployeeInfo.ReportingLevel2emp5;
            paramsToStore[153].Size = 50;

            paramsToStore[154] = new SqlParameter("@ExperienceInYears2", SqlDbType.VarChar);
            paramsToStore[154].Value = objEmployeeInfo.ExperienceInYears2;
            paramsToStore[154].Size = 50;


            paramsToStore[155] = new SqlParameter("@FresherOrExp", SqlDbType.VarChar);
            paramsToStore[155].Value = objEmployeeInfo.FresherOrExp;
            paramsToStore[155].Size = 50;

            paramsToStore[156] = new SqlParameter("@NoOfComp", SqlDbType.VarChar);
            paramsToStore[156].Value = objEmployeeInfo.NoOfComp;
            paramsToStore[156].Size = 50;

            paramsToStore[157] = new SqlParameter("@Edu2_CollegeName", SqlDbType.VarChar);
            paramsToStore[157].Value = objEmployeeInfo.Edu2_CollegeName;
            paramsToStore[157].Size = 250;

            paramsToStore[158] = new SqlParameter("@Edu2_UniversityName", SqlDbType.VarChar);
            paramsToStore[158].Value = objEmployeeInfo.Edu2_UniversityName;
            paramsToStore[158].Size = 150;

            paramsToStore[159] = new SqlParameter("@Edu2_Address", SqlDbType.VarChar);
            paramsToStore[159].Value = objEmployeeInfo.Edu2_Address;
            paramsToStore[159].Size = 500;

            paramsToStore[160] = new SqlParameter("@Edu2_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[160].Value = objEmployeeInfo.Edu2_EducationalQualification;
            paramsToStore[160].Size = 100;

            paramsToStore[161] = new SqlParameter("@Edu2_RollNo", SqlDbType.VarChar);
            paramsToStore[161].Value = objEmployeeInfo.Edu2_RollNo;
            paramsToStore[161].Size = 50;

            paramsToStore[162] = new SqlParameter("@YearOfPassing2", SqlDbType.VarChar);
            paramsToStore[162].Value = objEmployeeInfo.YearOfPassing2;
            paramsToStore[162].Size = 50;


            paramsToStore[163] = new SqlParameter("@Edu3_CollegeName", SqlDbType.VarChar);
            paramsToStore[163].Value = objEmployeeInfo.Edu3_CollegeName;
            paramsToStore[163].Size = 250;

            paramsToStore[164] = new SqlParameter("@Edu4_CollegeName", SqlDbType.VarChar);
            paramsToStore[164].Value = objEmployeeInfo.Edu4_CollegeName;
            paramsToStore[164].Size = 250;

            paramsToStore[165] = new SqlParameter("@Edu3_UniversityName", SqlDbType.VarChar);
            paramsToStore[165].Value = objEmployeeInfo.Edu3_UniversityName;
            paramsToStore[165].Size = 150;

            paramsToStore[166] = new SqlParameter("@Edu4_UniversityName", SqlDbType.VarChar);
            paramsToStore[166].Value = objEmployeeInfo.Edu4_UniversityName;
            paramsToStore[166].Size = 150;

            paramsToStore[167] = new SqlParameter("@Edu3_Address", SqlDbType.VarChar);
            paramsToStore[167].Value = objEmployeeInfo.Edu3_Address;
            paramsToStore[167].Size = 500;

            paramsToStore[168] = new SqlParameter("@Edu4_Address", SqlDbType.VarChar);
            paramsToStore[168].Value = objEmployeeInfo.Edu4_Address;
            paramsToStore[168].Size = 500;

            paramsToStore[169] = new SqlParameter("@Edu3_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[169].Value = objEmployeeInfo.Edu3_EducationalQualification;
            paramsToStore[169].Size = 100;

            paramsToStore[170] = new SqlParameter("@Edu4_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[170].Value = objEmployeeInfo.Edu4_EducationalQualification;
            paramsToStore[170].Size = 100;

            paramsToStore[171] = new SqlParameter("@Edu3_RollNo", SqlDbType.VarChar);
            paramsToStore[171].Value = objEmployeeInfo.Edu3_RollNo;
            paramsToStore[171].Size = 50;

            paramsToStore[172] = new SqlParameter("@Edu4_RollNo", SqlDbType.VarChar);
            paramsToStore[172].Value = objEmployeeInfo.Edu4_RollNo;
            paramsToStore[172].Size = 50;

            paramsToStore[173] = new SqlParameter("@YearOfPassing3", SqlDbType.VarChar);
            paramsToStore[173].Value = objEmployeeInfo.YearOfPassing3;
            paramsToStore[173].Size = 50;

            paramsToStore[174] = new SqlParameter("@YearOfPassing4", SqlDbType.VarChar);
            paramsToStore[174].Value = objEmployeeInfo.YearOfPassing4;
            paramsToStore[174].Size = 50;


            paramsToStore[175] = new SqlParameter("@EmpHis3_TelephoneNo", SqlDbType.VarChar);
            paramsToStore[175].Value = objEmployeeInfo.EmpHis3_TelephoneNo;
            paramsToStore[175].Size = 50;

            paramsToStore[176] = new SqlParameter("@EmpHis5_TelephoneNo", SqlDbType.VarChar);
            paramsToStore[176].Value = objEmployeeInfo.EmpHis5_TelephoneNo;
            paramsToStore[176].Size = 50;

            paramsToStore[177] = new SqlParameter("@EmpHis4_TelephoneNo", SqlDbType.VarChar);
            paramsToStore[177].Value = objEmployeeInfo.EmpHis4_TelephoneNo;
            paramsToStore[177].Size = 50;

            paramsToStore[178] = new SqlParameter("@EducationList", SqlDbType.VarChar);
            paramsToStore[178].Value = objEmployeeInfo.EducationList;
            paramsToStore[178].Size = 50;

            paramsToStore[179] = new SqlParameter("@UserName", SqlDbType.NVarChar);
            paramsToStore[179].Value = objEmployeeInfo.UserName;
            paramsToStore[179].Size = 300;


            paramsToStore[180] = new SqlParameter("@CaseSubmmissionDate", SqlDbType.VarChar);
            paramsToStore[180].Value = objEmployeeInfo.CaseSubmmissionDate;
            paramsToStore[180].Size = 300;



            paramsToStore[181] = new SqlParameter("@TATDate", SqlDbType.VarChar);
            paramsToStore[181].Value = objEmployeeInfo.TATDate;
            paramsToStore[181].Size = 50;

            //-----------------------------------------------------------------------------------------




            paramsToStore[182] = new SqlParameter("@txt_ResumeNo", SqlDbType.VarChar);
            paramsToStore[182].Value = objEmployeeInfo.txt_ResumeNo;
            paramsToStore[182].Size = 50;


            paramsToStore[183] = new SqlParameter("@txt_CaseReceivedBy", SqlDbType.VarChar);
            paramsToStore[183].Value = objEmployeeInfo.txt_CaseReceivedBy;
            paramsToStore[183].Size = 50;


            paramsToStore[184] = new SqlParameter("@txtPercentage", SqlDbType.VarChar);
            paramsToStore[184].Value = objEmployeeInfo.txtPercentage;
            paramsToStore[184].Size = 50;

            paramsToStore[185] = new SqlParameter("@txtEducation1State", SqlDbType.VarChar);
            paramsToStore[185].Value = objEmployeeInfo.txtEducation1State;
            paramsToStore[185].Size = 50;

            paramsToStore[186] = new SqlParameter("@txtEducation1City", SqlDbType.VarChar);
            paramsToStore[186].Value = objEmployeeInfo.txtEducation1City;
            paramsToStore[186].Size = 50;

            paramsToStore[187] = new SqlParameter("@txtEducation1PinCode", SqlDbType.VarChar);
            paramsToStore[187].Value = objEmployeeInfo.txtEducation1PinCode;
            paramsToStore[187].Size = 50;

            paramsToStore[188] = new SqlParameter("@txtEducation2State", SqlDbType.VarChar);
            paramsToStore[188].Value = objEmployeeInfo.txtEducation2State;
            paramsToStore[188].Size = 50;






            paramsToStore[189] = new SqlParameter("@txtEducation2City", SqlDbType.VarChar);
            paramsToStore[189].Value = objEmployeeInfo.txtEducation2City;
            paramsToStore[189].Size = 50;


            paramsToStore[190] = new SqlParameter("@txtEducation2PinCode", SqlDbType.VarChar);
            paramsToStore[190].Value = objEmployeeInfo.txtEducation2PinCode;
            paramsToStore[190].Size = 50;

            paramsToStore[191] = new SqlParameter("@txtEducation3State", SqlDbType.VarChar);
            paramsToStore[191].Value = objEmployeeInfo.txtEducation3State;
            paramsToStore[191].Size = 50;

            paramsToStore[192] = new SqlParameter("@txtEducation3City", SqlDbType.VarChar);
            paramsToStore[192].Value = objEmployeeInfo.txtEducation3City;
            paramsToStore[192].Size = 50;

            paramsToStore[193] = new SqlParameter("@txtEducation3PinCode", SqlDbType.VarChar);
            paramsToStore[193].Value = objEmployeeInfo.txtEducation3PinCode;
            paramsToStore[193].Size = 50;

            paramsToStore[194] = new SqlParameter("@txtEducation4State", SqlDbType.VarChar);
            paramsToStore[194].Value = objEmployeeInfo.txtEducation4State;
            paramsToStore[194].Size = 50;



            paramsToStore[195] = new SqlParameter("@txtEducation4City", SqlDbType.VarChar);
            paramsToStore[195].Value = objEmployeeInfo.txtEmployemenmt4City;
            paramsToStore[195].Size = 50;


            paramsToStore[196] = new SqlParameter("@txtEducation4PinCode", SqlDbType.VarChar);
            paramsToStore[196].Value = objEmployeeInfo.txtEducation4PinCode;
            paramsToStore[196].Size = 50;

            paramsToStore[197] = new SqlParameter("@txtEmployemenmt1State", SqlDbType.VarChar);
            paramsToStore[197].Value = objEmployeeInfo.txtEmployemenmt1State;
            paramsToStore[197].Size = 50;

            paramsToStore[198] = new SqlParameter("@txtEmployemenmt2State", SqlDbType.VarChar);
            paramsToStore[198].Value = objEmployeeInfo.txtEmployemenmt2State;
            paramsToStore[198].Size = 50;

            paramsToStore[199] = new SqlParameter("@txtEmployemenmt3State", SqlDbType.VarChar);
            paramsToStore[199].Value = objEmployeeInfo.txtEmployemenmt3State;
            paramsToStore[199].Size = 50;



            paramsToStore[200] = new SqlParameter("@txtEmployemenmt4State", SqlDbType.VarChar);
            paramsToStore[200].Value = objEmployeeInfo.txtEmployemenmt4State;
            paramsToStore[200].Size = 50;

            paramsToStore[201] = new SqlParameter("@txtEmployemenmt5State", SqlDbType.VarChar);
            paramsToStore[201].Value = objEmployeeInfo.txtEmployemenmt5State;
            paramsToStore[201].Size = 50;


            paramsToStore[202] = new SqlParameter("@txtEmployemenmt1City", SqlDbType.VarChar);
            paramsToStore[202].Value = objEmployeeInfo.txtEmployemenmt1City;
            paramsToStore[202].Size = 50;


            paramsToStore[203] = new SqlParameter("@txtEmployemenmt2City", SqlDbType.VarChar);
            paramsToStore[203].Value = objEmployeeInfo.txtEmployemenmt2City;
            paramsToStore[203].Size = 50;

            paramsToStore[204] = new SqlParameter("@txtEmployemenmt3City", SqlDbType.VarChar);
            paramsToStore[204].Value = objEmployeeInfo.txtEmployemenmt3City;
            paramsToStore[204].Size = 50;

            paramsToStore[205] = new SqlParameter("@txtEmployemenmt4City", SqlDbType.VarChar);
            paramsToStore[205].Value = objEmployeeInfo.txtEmployemenmt4City;
            paramsToStore[205].Size = 50;

            paramsToStore[206] = new SqlParameter("@txtEmployemenmt5City", SqlDbType.VarChar);
            paramsToStore[206].Value = objEmployeeInfo.txtEmployemenmt5City;
            paramsToStore[206].Size = 50;

            paramsToStore[207] = new SqlParameter("@txtEmployemenmt1PinCode", SqlDbType.VarChar);
            paramsToStore[207].Value = objEmployeeInfo.txtEmployemenmt1PinCode;
            paramsToStore[207].Size = 50;



            paramsToStore[208] = new SqlParameter("@txtEmployemenmt2PinCode", SqlDbType.VarChar);
            paramsToStore[208].Value = objEmployeeInfo.txtEmployemenmt2PinCode;
            paramsToStore[208].Size = 50;


            paramsToStore[209] = new SqlParameter("@txtEmployemenmt3PinCode", SqlDbType.VarChar);
            paramsToStore[209].Value = objEmployeeInfo.txtEmployemenmt3PinCode;
            paramsToStore[209].Size = 50;

            paramsToStore[210] = new SqlParameter("@txtEmployemenmt4PinCode", SqlDbType.VarChar);
            paramsToStore[210].Value = objEmployeeInfo.txtEmployemenmt4PinCode;
            paramsToStore[210].Size = 50;

            paramsToStore[211] = new SqlParameter("@txtEmployemenmt5PinCode", SqlDbType.VarChar);
            paramsToStore[211].Value = objEmployeeInfo.txtEmployemenmt5PinCode;
            paramsToStore[211].Size = 50;

            //---------------------------Start All Checks

            //[Address2City] [varchar](50) NULL,
            //[Address2State] [varchar](50) NULL,
            //[Address2PhoneNo1] [varchar](50) NULL,
            //[Address2PhoneNo2] [varchar](50) NULL,
            //[Address3CurrentAddress] [varchar](500) NULL,
            //[Address3City] [varchar](50) NULL,
            //[Address3State] [varchar](50) NULL,
            //[Address3PhoneNo1] [varchar](50) NULL,
            //[Address3PhoneNo2] [varchar](50) NULL,
            //[Address4CurrentAddress] [varchar](500) NULL,
            //[Address4City] [varchar](50) NULL,
            //[Address4State] [varchar](50) NULL,
            //[Address4PhoneNo1] [varchar](50) NULL,
            //[Address4PhoneNo2] [varchar](50) NULL,
            //[Address5CurrentAddress] [varchar](500) NULL,
            //[Address5City] [varchar](50) NULL,
            //[Address5State] [varchar](50) NULL,
            //[Address5PhoneNo1] [varchar](50) NULL,
            //[Address5PhoneNo2] [varchar](50) NULL,
            //[Address6CurrentAddress] [varchar](500) NULL,
            //[Address6City] [varchar](50) NULL,
            //[Address6State] [varchar](50) NULL,
            //[Address6PhoneNo1] [varchar](50) NULL,
            //[Address6PhoneNo2] [varchar](50) NULL,
            //[Address7CurrentAddress] [varchar](500) NULL,
            //[Address7City] [varchar](50) NULL,
            //[Address7State] [varchar](50) NULL,
            //[Address7PhoneNo1] [varchar](50) NULL,
            //[Address7PhoneNo2] [varchar](50) NULL,
            //[Criminal1Location] [varchar](50) NULL,
            //[Criminal2Location] [varchar](50) NULL,
            //[Criminal3Location] [varchar](50) NULL,
            //[Criminal4Location] [varchar](50) NULL,
            //[Criminal5Location] [varchar](50) NULL,
            //[Criminal6Location] [varchar](50) NULL,
            //[Criminal7Location] [varchar](50) NULL,
            //[Criminal8Location] [varchar](50) NULL,
            //[Education5CollegeName] [varchar](150) NULL,
            //[Education5CollegeAddress] [varchar](500) NULL,
            //[Education5UniversityName] [varchar](150) NULL,
            //[Education5UniversityAddress] [varchar](100) NULL,
            //[Education5EQ] [varchar](50) NULL,
            //[Education5YearofPassing] [varchar](50) NULL,
            //[Education5RollNo] [varchar](50) NULL,
            //[Education5joinfrom] [varchar](50) NULL,
            //[Education5jointo] [varchar](50) NULL,
            //[Education5State] [varchar](50) NULL,
            //[Education5City] [varchar](50) NULL,
            //[Education5PinCode] [varchar](50) NULL,
            //[Education6CollegeName] [varchar](150) NULL,
            //[Education6CollegeAddress] [varchar](500) NULL,
            //[Education6UniversityName] [varchar](150) NULL,
            //[Education6UniversityAddress] [varchar](100) NULL,
            //[Education6EQ] [varchar](50) NULL,
            //[Education6YearofPassing] [varchar](50) NULL,
            //[Education6RollNo] [varchar](50) NULL,
            //[Education6joinfrom] [varchar](50) NULL,
            //[Education6jointo] [varchar](50) NULL,
            //[Education6State] [varchar](50) NULL,
            //[Education6City] [varchar](50) NULL,
            //[Education6PinCode] [varchar](50) NULL,
            //[Education7CollegeName] [varchar](150) NULL,
            //[Education7CollegeAddress] [varchar](500) NULL,
            //[Education7UniversityName] [varchar](150) NULL,
            //[Education7UniversityAddress] [varchar](100) NULL,
            //[Education7EQ] [varchar](50) NULL,
            //[Education7YearofPassing] [varchar](50) NULL,
            //[Education7RollNo] [varchar](50) NULL,
            //[Education7joinfrom] [varchar](50) NULL,
            //[Education7jointo] [varchar](50) NULL,
            //[Education7State] [varchar](50) NULL,
            //[Education7City] [varchar](50) NULL,
            //[Education7PinCode] [varchar](50) NULL,
            //[Education8CollegeName] [varchar](150) NULL,
            //[Education8CollegeAddress] [nchar](500) NULL,
            //[Education8UniversityName] [varchar](150) NULL,
            //[Education8UniversityAddress] [varchar](50) NULL,
            //[Education8EQ] [varchar](50) NULL,
            //[Education8YearofPassing] [varchar](50) NULL,
            //[Education8RollNo] [varchar](50) NULL,
            //[Education8joinfrom] [varchar](50) NULL,
            //[Education8jointo] [varchar](50) NULL,
            //[Education8State] [varchar](50) NULL,
            //[Education8City] [varchar](50) NULL,
            //[Education8PinCode] [varchar](50) NULL,
            //[Employement6CompanyName] [varchar](150) NULL,
            //[Employement6CompanyLocation] [varchar](50) NULL,
            //[Employement6OfficeAddress] [varchar](150) NULL,
            //[Employement6Designation] [varchar](50) NULL,
            //[Employement6phone1] [varchar](50) NULL,
            //[Employement6phone2] [varchar](50) NULL,
            //[Employement6EmpCode] [varchar](50) NULL,
            //[Employement6DateFrom] [varchar](50) NULL,
            //[Employement6DateTo] [varchar](50) NULL,
            //[Employement6Salary] [varchar](50) NULL,
            //[Employement6State] [varchar](50) NULL,
            //[Employement6City] [varchar](50) NULL,
            //[Employement6PinCode] [varchar](50) NULL,
            //[Employement6Sdesig] [varchar](50) NULL,
            //[Employement6Semail] [varchar](50) NULL,
            //[Employement6Sphone1] [varchar](50) NULL,
            //[Emplyoement6Sphone2] [varchar](50) NULL,
            //[Employement6SMobile] [varchar](50) NULL,
            //[Employement6SResofliv] [varchar](50) NULL,
            //[Employement7CompanyName] [varchar](150) NULL,
            //[Employement7CompanyLocation] [varchar](50) NULL,
            //[Employement7OfficeAddress] [varchar](150) NULL,
            //[Employement7Designation] [varchar](50) NULL,
            //[Employement7phone1] [varchar](50) NULL,
            //[Employement7phone2] [varchar](50) NULL,
            //[Employement7EmpCode] [varchar](50) NULL,
            //[Employement7DateFrom] [varchar](50) NULL,
            //[Employement7DateTo] [varchar](50) NULL,
            //[Employement7Salary] [varchar](50) NULL,
            //[Employement7State] [varchar](50) NULL,
            //[Employement7City] [varchar](50) NULL,
            //[Employement7PinCode] [varchar](50) NULL,
            //[Emplyement7Sdesig] [varchar](50) NULL,
            //[Emplyement7Semail] [varchar](50) NULL,
            //[Emplyement7Sphone1] [varchar](50) NULL,
            //[Emplyement7Sphone2] [varchar](50) NULL,
            //[Emplyement7SMobile] [varchar](50) NULL,
            //[Emplyement7SResofliv] [varchar](50) NULL,
            //[Employement8CompanyName] [varchar](150) NULL,
            //[Employement8CompanyLocation] [varchar](50) NULL,
            //[Employement8OfficeAddress] [varchar](150) NULL,
            //[Employement8Designation] [varchar](50) NULL,
            //[Employement8phone1] [varchar](50) NULL,
            //[Employement8phone2] [varchar](50) NULL,
            //[Employement8EmpCode] [varchar](50) NULL,
            //[Employement8DateFrom] [varchar](50) NULL,
            //[Employement8DateTo] [varchar](50) NULL,
            //[Employement8Salary] [varchar](50) NULL,
            //[Employement8State] [varchar](50) NULL,
            //[Employement8City] [varchar](50) NULL,
            //[Employement8PinCode] [varchar](50) NULL,
            //[Emplyement8Sdesig] [varchar](50) NULL,
            //[Emplyement8Semail] [varchar](50) NULL,
            //[Emplyement8Sphone1] [varchar](50) NULL,
            //[Emplyement8Sphone2] [varchar](50) NULL,
            //[Emplyement8SMobile] [varchar](50) NULL,
            //[Emplyement8SResofliv] [varchar](50) NULL,
            //[ddlReference] [varchar](50) NULL,
            //[RefCheck1AppName] [varchar](50) NULL,
            //[Ref1DOV] [varchar](50) NULL,
            //[RefCheck1VerifierName] [varchar](50) NULL,
            //[Ref1Desi] [varchar](50) NULL,
            //[Ref1Company] [varchar](50) NULL,
            //[Ref1Email] [varchar](50) NULL,
            //[Ref1CN] [varchar](50) NULL,
            //[RefCheck2AppName] [varchar](50) NULL,
            //[Ref2DOV] [varchar](50) NULL,
            //[RefCheck2VerifierName] [varchar](50) NULL,
            //[Ref2Desi] [varchar](50) NULL,
            //[Ref2Company] [varchar](50) NULL,
            //[Ref2Email] [varchar](50) NULL,
            //[Ref2CN] [varchar](50) NULL,
            //[RefCheck3AppName] [varchar](50) NULL,
            //[Ref3DOV] [varchar](50) NULL,
            //[RefCheck3VerifierName] [varchar](50) NULL,
            //[Ref3Desi] [varchar](50) NULL,
            //[Ref3Company] [varchar](50) NULL,
            //[Ref3Email] [varchar](50) NULL,
            //[Ref3CN] [varchar](50) NULL,
            //[ddlDatabase] [varchar](50) NULL,
            //[DatabaseCheck] [varchar](50) NULL,
            //[DatabaseLocation] [varchar](50) NULL,
            //[ddlDrug] [varchar](50) NULL,
            //[DrugCheck] [varchar](50) NULL,
            //[DrugLocation] [varchar](50) NULL,
            //[ddlIndentity] [varchar](50) NULL,
            //[IdetityCheck] [varchar](50) NULL,
            //[IdentityLocation] [varchar](50) NULL,

            //[Address2CurrentAddress] [varchar](500) NULL,
            //[Address2City] [varchar](50) NULL,
            //[Address2State] [varchar](50) NULL,
            //[Address2PhoneNo1] [varchar](50) NULL,
            //[Address2PhoneNo2] [varchar](50) NULL,

            //Address 3
            paramsToStore[212] = new SqlParameter("@Address2CurrentAddress", SqlDbType.VarChar);
            paramsToStore[212].Value = objEmployeeInfo.txtAddress2CurrentAddress;
            paramsToStore[212].Size = 500;

            paramsToStore[213] = new SqlParameter("@Address2City", SqlDbType.VarChar);
            paramsToStore[213].Value = objEmployeeInfo.txtAddress2City;
            paramsToStore[213].Size = 50;

            paramsToStore[214] = new SqlParameter("@Address2State", SqlDbType.VarChar);
            paramsToStore[214].Value = objEmployeeInfo.txtAddress2State;
            paramsToStore[214].Size = 50;

            paramsToStore[215] = new SqlParameter("@Address2PhoneNo1", SqlDbType.VarChar);
            paramsToStore[215].Value = objEmployeeInfo.txtAddress2PhoneNo1;
            paramsToStore[215].Size = 50;

            paramsToStore[216] = new SqlParameter("@Address2PhoneNo2", SqlDbType.VarChar);
            paramsToStore[216].Value = objEmployeeInfo.txtAddress2PhoneNo2;
            paramsToStore[216].Size = 50;

            //Address 4
            paramsToStore[217] = new SqlParameter("@Address3CurrentAddress", SqlDbType.VarChar);
            paramsToStore[217].Value = objEmployeeInfo.txtAddress3CurrentAddress;
            paramsToStore[217].Size = 500;

            paramsToStore[218] = new SqlParameter("@Address3City", SqlDbType.VarChar);
            paramsToStore[218].Value = objEmployeeInfo.txtAddress3City;
            paramsToStore[218].Size = 50;

            paramsToStore[219] = new SqlParameter("@Address3State", SqlDbType.VarChar);
            paramsToStore[219].Value = objEmployeeInfo.txtAddress3State;
            paramsToStore[219].Size = 50;

            paramsToStore[220] = new SqlParameter("@Address3PhoneNo1", SqlDbType.VarChar);
            paramsToStore[220].Value = objEmployeeInfo.txtAddress3PhoneNo1;
            paramsToStore[220].Size = 50;

            paramsToStore[221] = new SqlParameter("@Address3PhoneNo2", SqlDbType.VarChar);
            paramsToStore[221].Value = objEmployeeInfo.txtAddress3PhoneNo2;
            paramsToStore[221].Size = 50;

            //Address 5

            paramsToStore[222] = new SqlParameter("@Address4CurrentAddress", SqlDbType.VarChar);
            paramsToStore[222].Value = objEmployeeInfo.txtAddress4CurrentAddress;
            paramsToStore[222].Size = 500;

            paramsToStore[223] = new SqlParameter("@Address4City", SqlDbType.VarChar);
            paramsToStore[223].Value = objEmployeeInfo.txtAddress4City;
            paramsToStore[223].Size = 50;

            paramsToStore[224] = new SqlParameter("@Address4State", SqlDbType.VarChar);
            paramsToStore[224].Value = objEmployeeInfo.txtAddress4State;
            paramsToStore[224].Size = 50;

            paramsToStore[225] = new SqlParameter("@Address4PhoneNo1", SqlDbType.VarChar);
            paramsToStore[225].Value = objEmployeeInfo.txtAddress4PhoneNo1;
            paramsToStore[225].Size = 50;

            paramsToStore[226] = new SqlParameter("@Address4PhoneNo2", SqlDbType.VarChar);
            paramsToStore[226].Value = objEmployeeInfo.txtAddress4PhoneNo2;
            paramsToStore[226].Size = 50;
            //Address 6

            paramsToStore[227] = new SqlParameter("@Address5CurrentAddress", SqlDbType.VarChar);
            paramsToStore[227].Value = objEmployeeInfo.txtAddress5CurrentAddress;
            paramsToStore[227].Size = 500;

            paramsToStore[228] = new SqlParameter("@Address5City", SqlDbType.VarChar);
            paramsToStore[228].Value = objEmployeeInfo.txtAddress5City;
            paramsToStore[228].Size = 50;

            paramsToStore[229] = new SqlParameter("@Address5State", SqlDbType.VarChar);
            paramsToStore[229].Value = objEmployeeInfo.txtAddress5State;
            paramsToStore[229].Size = 50;

            paramsToStore[230] = new SqlParameter("@Address5PhoneNo1", SqlDbType.VarChar);
            paramsToStore[230].Value = objEmployeeInfo.txtAddress5PhoneNo1;
            paramsToStore[230].Size = 50;

            paramsToStore[231] = new SqlParameter("@Address5PhoneNo2", SqlDbType.VarChar);
            paramsToStore[231].Value = objEmployeeInfo.txtAddress5PhoneNo2;
            paramsToStore[231].Size = 50;
            //Address 7

            paramsToStore[232] = new SqlParameter("@Address6CurrentAddress", SqlDbType.VarChar);
            paramsToStore[232].Value = objEmployeeInfo.txtAddress6CurrentAddress;
            paramsToStore[232].Size = 500;

            paramsToStore[233] = new SqlParameter("@Address6City", SqlDbType.VarChar);
            paramsToStore[233].Value = objEmployeeInfo.txtAddress6City;
            paramsToStore[233].Size = 50;

            paramsToStore[234] = new SqlParameter("@Address6State", SqlDbType.VarChar);
            paramsToStore[234].Value = objEmployeeInfo.txtAddress6State;
            paramsToStore[234].Size = 50;

            paramsToStore[235] = new SqlParameter("@Address6PhoneNo1", SqlDbType.VarChar);
            paramsToStore[235].Value = objEmployeeInfo.txtAddress6PhoneNo1;
            paramsToStore[235].Size = 50;

            paramsToStore[236] = new SqlParameter("@Address6PhoneNo2", SqlDbType.VarChar);
            paramsToStore[236].Value = objEmployeeInfo.txtAddress6PhoneNo2;
            paramsToStore[236].Size = 50;
            //Address 8

            paramsToStore[237] = new SqlParameter("@Address7CurrentAddress", SqlDbType.VarChar);
            paramsToStore[237].Value = objEmployeeInfo.txtAddress7CurrentAddress;
            paramsToStore[237].Size = 500;

            paramsToStore[238] = new SqlParameter("@Address7City", SqlDbType.VarChar);
            paramsToStore[238].Value = objEmployeeInfo.txtAddress7City;
            paramsToStore[238].Size = 50;

            paramsToStore[239] = new SqlParameter("@Address7State", SqlDbType.VarChar);
            paramsToStore[239].Value = objEmployeeInfo.txtAddress7State;
            paramsToStore[239].Size = 50;

            paramsToStore[240] = new SqlParameter("@Address7PhoneNo1", SqlDbType.VarChar);
            paramsToStore[240].Value = objEmployeeInfo.txtAddress7PhoneNo1;
            paramsToStore[240].Size = 50;

            paramsToStore[241] = new SqlParameter("@Address7PhoneNo2", SqlDbType.VarChar);
            paramsToStore[241].Value = objEmployeeInfo.txtAddress7PhoneNo2;
            paramsToStore[241].Size = 50;
            //Criminal Check

            //[Criminal1Location] [varchar](50) NULL,
            //[Criminal2Location] [varchar](50) NULL,
            //[Criminal3Location] [varchar](50) NULL,
            //[Criminal4Location] [varchar](50) NULL,
            //[Criminal5Location] [varchar](50) NULL,
            //[Criminal6Location] [varchar](50) NULL,
            //[Criminal7Location] [varchar](50) NULL,
            //[Criminal8Location] [varchar](50) NULL,

            paramsToStore[242] = new SqlParameter("@Criminal1Location", SqlDbType.VarChar);
            paramsToStore[242].Value = objEmployeeInfo.txtCriminal1Location;
            paramsToStore[242].Size = 50;

            paramsToStore[243] = new SqlParameter("@Criminal2Location", SqlDbType.VarChar);
            paramsToStore[243].Value = objEmployeeInfo.txtCriminal2Location;
            paramsToStore[243].Size = 50;

            paramsToStore[244] = new SqlParameter("@Criminal3Location", SqlDbType.VarChar);
            paramsToStore[244].Value = objEmployeeInfo.txtCriminal3Location;
            paramsToStore[244].Size = 50;

            paramsToStore[245] = new SqlParameter("@Criminal4Location", SqlDbType.VarChar);
            paramsToStore[245].Value = objEmployeeInfo.txtCriminal4Location;
            paramsToStore[245].Size = 50;

            paramsToStore[246] = new SqlParameter("@Criminal5Location", SqlDbType.VarChar);
            paramsToStore[246].Value = objEmployeeInfo.txtCriminal5Location;
            paramsToStore[246].Size = 50;

            paramsToStore[247] = new SqlParameter("@Criminal6Location", SqlDbType.VarChar);
            paramsToStore[247].Value = objEmployeeInfo.txtCriminal6Location;
            paramsToStore[247].Size = 50;

            paramsToStore[248] = new SqlParameter("@Criminal7Location", SqlDbType.VarChar);
            paramsToStore[248].Value = objEmployeeInfo.txtCriminal7Location;
            paramsToStore[248].Size = 50;

            paramsToStore[249] = new SqlParameter("@Criminal8Location", SqlDbType.VarChar);
            paramsToStore[249].Value = objEmployeeInfo.txtCriminal8Location;
            paramsToStore[249].Size = 50;


            //Education Check

            // [Education5CollegeName] [varchar](150) NULL,
            //[Education5CollegeAddress] [varchar](500) NULL,
            //[Education5UniversityName] [varchar](150) NULL,
            //[Education5UniversityAddress] [varchar](100) NULL,
            //[Education5EQ] [varchar](50) NULL,
            //[Education5YearofPassing] [varchar](50) NULL,
            //[Education5RollNo] [varchar](50) NULL,
            //[Education5joinfrom] [varchar](50) NULL,
            //[Education5jointo] [varchar](50) NULL,
            //[Education5State] [varchar](50) NULL,
            //[Education5City] [varchar](50) NULL,
            //[Education5PinCode] [varchar](50) NULL,
            //Education 5

            paramsToStore[250] = new SqlParameter("@Education5CollegeName", SqlDbType.VarChar);
            paramsToStore[250].Value = objEmployeeInfo.txtEducation5CollegeName;
            paramsToStore[250].Size = 250;

            paramsToStore[251] = new SqlParameter("@Education5CollegeAddress", SqlDbType.VarChar);
            paramsToStore[251].Value = objEmployeeInfo.txtEducation5CollegeAddress;
            paramsToStore[251].Size = 500;


            paramsToStore[252] = new SqlParameter("@Education5UniversityName", SqlDbType.VarChar);
            paramsToStore[252].Value = objEmployeeInfo.txtEducation5UniversityName;
            paramsToStore[252].Size = 150;


            paramsToStore[253] = new SqlParameter("@Education5UniversityAddress", SqlDbType.VarChar);
            paramsToStore[253].Value = objEmployeeInfo.txtEducation5UniversityAddress;
            paramsToStore[253].Size = 100;


            paramsToStore[254] = new SqlParameter("@Education5EQ", SqlDbType.VarChar);
            paramsToStore[254].Value = objEmployeeInfo.txtEducation5EQ;
            paramsToStore[254].Size = 50;

            paramsToStore[255] = new SqlParameter("@Education5YearofPassing", SqlDbType.VarChar);
            paramsToStore[255].Value = objEmployeeInfo.txtEducation5YearofPassing;
            paramsToStore[255].Size = 50;

            paramsToStore[256] = new SqlParameter("@Education5RollNo", SqlDbType.VarChar);
            paramsToStore[256].Value = objEmployeeInfo.txtEducation5RollNo;
            paramsToStore[256].Size = 50;

            paramsToStore[257] = new SqlParameter("@Education5joinfrom", SqlDbType.VarChar);
            paramsToStore[257].Value = objEmployeeInfo.txtEducation5joinfrom;
            paramsToStore[257].Size = 50;

            paramsToStore[258] = new SqlParameter("@Education5jointo", SqlDbType.VarChar);
            paramsToStore[258].Value = objEmployeeInfo.txtEducation5jointo;
            paramsToStore[258].Size = 50;

            paramsToStore[259] = new SqlParameter("@Education5State", SqlDbType.VarChar);
            paramsToStore[259].Value = objEmployeeInfo.txtEducation5State;
            paramsToStore[259].Size = 50;


            paramsToStore[260] = new SqlParameter("@Education5City", SqlDbType.VarChar);
            paramsToStore[260].Value = objEmployeeInfo.txtEducation5City;
            paramsToStore[260].Size = 50;

            paramsToStore[261] = new SqlParameter("@Education5PinCode", SqlDbType.VarChar);
            paramsToStore[261].Value = objEmployeeInfo.txtEducation5PinCode;
            paramsToStore[261].Size = 50;





            //Education 6 

            paramsToStore[262] = new SqlParameter("@Education6CollegeName", SqlDbType.VarChar);
            paramsToStore[262].Value = objEmployeeInfo.txtEducation6CollegeName;
            paramsToStore[262].Size = 250;

            paramsToStore[263] = new SqlParameter("@Education6CollegeAddress", SqlDbType.VarChar);
            paramsToStore[263].Value = objEmployeeInfo.txtEducation6CollegeAddress;
            paramsToStore[263].Size = 500;


            paramsToStore[264] = new SqlParameter("@Education6UniversityName", SqlDbType.VarChar);
            paramsToStore[264].Value = objEmployeeInfo.txtEducation6UniversityName;
            paramsToStore[264].Size = 150;


            paramsToStore[265] = new SqlParameter("@Education6UniversityAddress", SqlDbType.VarChar);
            paramsToStore[265].Value = objEmployeeInfo.txtEducation6UniversityAddress;
            paramsToStore[265].Size = 100;


            paramsToStore[266] = new SqlParameter("@Education6EQ", SqlDbType.VarChar);
            paramsToStore[266].Value = objEmployeeInfo.txtEducation6EQ;
            paramsToStore[266].Size = 50;

            paramsToStore[267] = new SqlParameter("@Education6YearofPassing", SqlDbType.VarChar);
            paramsToStore[267].Value = objEmployeeInfo.txtEducation6YearofPassing;
            paramsToStore[267].Size = 50;

            paramsToStore[268] = new SqlParameter("@Education6RollNo", SqlDbType.VarChar);
            paramsToStore[268].Value = objEmployeeInfo.txtEducation6RollNo;
            paramsToStore[268].Size = 50;

            paramsToStore[269] = new SqlParameter("@Education6joinfrom", SqlDbType.VarChar);
            paramsToStore[269].Value = objEmployeeInfo.txtEducation6joinfrom;
            paramsToStore[269].Size = 50;

            paramsToStore[270] = new SqlParameter("@Education6jointo", SqlDbType.VarChar);
            paramsToStore[270].Value = objEmployeeInfo.txtEducation6jointo;
            paramsToStore[270].Size = 50;

            paramsToStore[271] = new SqlParameter("@Education6State", SqlDbType.VarChar);
            paramsToStore[271].Value = objEmployeeInfo.txtEducation6State;
            paramsToStore[271].Size = 50;


            paramsToStore[272] = new SqlParameter("@Education6City", SqlDbType.VarChar);
            paramsToStore[272].Value = objEmployeeInfo.txtEducation6City;
            paramsToStore[272].Size = 50;

            paramsToStore[273] = new SqlParameter("@Education6PinCode", SqlDbType.VarChar);
            paramsToStore[273].Value = objEmployeeInfo.txtEducation6PinCode;
            paramsToStore[273].Size = 50;



            //Education 7 

            paramsToStore[274] = new SqlParameter("@Education7CollegeName", SqlDbType.VarChar);
            paramsToStore[274].Value = objEmployeeInfo.txtEducation7CollegeName;
            paramsToStore[274].Size = 250;

            paramsToStore[275] = new SqlParameter("@Education7CollegeAddress", SqlDbType.VarChar);
            paramsToStore[275].Value = objEmployeeInfo.txtEducation7CollegeAddress;
            paramsToStore[275].Size = 500;


            paramsToStore[276] = new SqlParameter("@Education7UniversityName", SqlDbType.VarChar);
            paramsToStore[276].Value = objEmployeeInfo.txtEducation7UniversityName;
            paramsToStore[276].Size = 150;


            paramsToStore[277] = new SqlParameter("@Education7UniversityAddress", SqlDbType.VarChar);
            paramsToStore[277].Value = objEmployeeInfo.txtEducation7UniversityAddress;
            paramsToStore[277].Size = 100;


            paramsToStore[278] = new SqlParameter("@Education7EQ", SqlDbType.VarChar);
            paramsToStore[278].Value = objEmployeeInfo.txtEducation7EQ;
            paramsToStore[278].Size = 50;

            paramsToStore[279] = new SqlParameter("@Education7YearofPassing", SqlDbType.VarChar);
            paramsToStore[279].Value = objEmployeeInfo.txtEducation7YearofPassing;
            paramsToStore[279].Size = 50;

            paramsToStore[280] = new SqlParameter("@Education7RollNo", SqlDbType.VarChar);
            paramsToStore[280].Value = objEmployeeInfo.txtEducation7RollNo;
            paramsToStore[280].Size = 50;

            paramsToStore[281] = new SqlParameter("@Education7joinfrom", SqlDbType.VarChar);
            paramsToStore[281].Value = objEmployeeInfo.txtEducation7joinfrom;
            paramsToStore[281].Size = 50;

            paramsToStore[282] = new SqlParameter("@Education7jointo", SqlDbType.VarChar);
            paramsToStore[282].Value = objEmployeeInfo.txtEducation7jointo;
            paramsToStore[282].Size = 50;

            paramsToStore[283] = new SqlParameter("@Education7State", SqlDbType.VarChar);
            paramsToStore[283].Value = objEmployeeInfo.txtEducation7State;
            paramsToStore[283].Size = 50;


            paramsToStore[284] = new SqlParameter("@Education7City", SqlDbType.VarChar);
            paramsToStore[284].Value = objEmployeeInfo.txtEducation7City;
            paramsToStore[284].Size = 50;

            paramsToStore[285] = new SqlParameter("@Education7PinCode", SqlDbType.VarChar);
            paramsToStore[285].Value = objEmployeeInfo.txtEducation7PinCode;
            paramsToStore[285].Size = 50;

            //Education 8 

            paramsToStore[286] = new SqlParameter("@Education8CollegeName", SqlDbType.VarChar);
            paramsToStore[286].Value = objEmployeeInfo.txtEducation8CollegeName;
            paramsToStore[286].Size = 250;

            paramsToStore[287] = new SqlParameter("@Education8CollegeAddress", SqlDbType.VarChar);
            paramsToStore[287].Value = objEmployeeInfo.txtEducation8CollegeAddress;
            paramsToStore[287].Size = 500;


            paramsToStore[288] = new SqlParameter("@Education8UniversityName", SqlDbType.VarChar);
            paramsToStore[288].Value = objEmployeeInfo.txtEducation8UniversityName;
            paramsToStore[288].Size = 150;


            paramsToStore[289] = new SqlParameter("@Education8UniversityAddress", SqlDbType.VarChar);
            paramsToStore[289].Value = objEmployeeInfo.txtEducation8UniversityAddress;
            paramsToStore[289].Size = 100;


            paramsToStore[290] = new SqlParameter("@Education8EQ", SqlDbType.VarChar);
            paramsToStore[290].Value = objEmployeeInfo.txtEducation8EQ;
            paramsToStore[290].Size = 50;

            paramsToStore[291] = new SqlParameter("@Education8YearofPassing", SqlDbType.VarChar);
            paramsToStore[291].Value = objEmployeeInfo.txtEducation8YearofPassing;
            paramsToStore[291].Size = 50;

            paramsToStore[292] = new SqlParameter("@Education8RollNo", SqlDbType.VarChar);
            paramsToStore[292].Value = objEmployeeInfo.txtEducation8RollNo;
            paramsToStore[292].Size = 50;

            paramsToStore[293] = new SqlParameter("@Education8joinfrom", SqlDbType.VarChar);
            paramsToStore[293].Value = objEmployeeInfo.txtEducation8joinfrom;
            paramsToStore[293].Size = 50;

            paramsToStore[294] = new SqlParameter("@Education8jointo", SqlDbType.VarChar);
            paramsToStore[294].Value = objEmployeeInfo.txtEducation8jointo;
            paramsToStore[294].Size = 50;

            paramsToStore[295] = new SqlParameter("@Education8State", SqlDbType.VarChar);
            paramsToStore[295].Value = objEmployeeInfo.txtEducation8State;
            paramsToStore[295].Size = 50;


            paramsToStore[296] = new SqlParameter("@Education8City", SqlDbType.VarChar);
            paramsToStore[296].Value = objEmployeeInfo.txtEducation8City;
            paramsToStore[296].Size = 50;

            paramsToStore[297] = new SqlParameter("@Education8PinCode", SqlDbType.VarChar);
            paramsToStore[297].Value = objEmployeeInfo.txtEducation8PinCode;
            paramsToStore[297].Size = 50;
            //Employemeny Check 

            //[Employement6CompanyName] [varchar](150) NULL,
            //[Employement6CompanyLocation] [varchar](50) NULL,
            //[Employement6OfficeAddress] [varchar](150) NULL,
            //[Employement6Designation] [varchar](50) NULL,
            //[Employement6phone1] [varchar](50) NULL,
            //[Employement6phone2] [varchar](50) NULL,
            //[Employement6EmpCode] [varchar](50) NULL,
            //[Employement6DateFrom] [varchar](50) NULL,
            //[Employement6DateTo] [varchar](50) NULL,
            //[Employement6Salary] [varchar](50) NULL,
            //[Employement6State] [varchar](50) NULL,
            //[Employement6City] [varchar](50) NULL,
            //[Employement6PinCode] [varchar](50) NULL,
            //[Employement6Sdesig] [varchar](50) NULL,
            //[Employement6Semail] [varchar](50) NULL,
            //[Employement6Sphone1] [varchar](50) NULL,
            //[Emplyoement6Sphone2] [varchar](50) NULL,
            //[Employement6SMobile] [varchar](50) NULL,
            //[Employement6SResofliv] [varchar](50) NULL,

            //Emplyement 6
            paramsToStore[298] = new SqlParameter("@Employement6CompanyName", SqlDbType.VarChar);
            paramsToStore[298].Value = objEmployeeInfo.txtEmployement6CompanyName;
            paramsToStore[298].Size = 150;

            paramsToStore[299] = new SqlParameter("@Employement6CompanyLocation", SqlDbType.VarChar);
            paramsToStore[299].Value = objEmployeeInfo.txtEmployement6CompanyLocation;
            paramsToStore[299].Size = 50;

            paramsToStore[300] = new SqlParameter("@Employement6OfficeAddress", SqlDbType.VarChar);
            paramsToStore[300].Value = objEmployeeInfo.txtEmployement6OfficeAddress;
            paramsToStore[300].Size = 150;

            paramsToStore[301] = new SqlParameter("@Employement6Designation", SqlDbType.VarChar);
            paramsToStore[301].Value = objEmployeeInfo.txtEmployement6Designation;
            paramsToStore[301].Size = 50;

            paramsToStore[302] = new SqlParameter("@Employement6phone1", SqlDbType.VarChar);
            paramsToStore[302].Value = objEmployeeInfo.txtEmployement6phone1;
            paramsToStore[302].Size = 50;


            paramsToStore[303] = new SqlParameter("@Employement6phone2", SqlDbType.VarChar);
            paramsToStore[303].Value = objEmployeeInfo.txtEmployement6phone2;
            paramsToStore[303].Size = 50;

            paramsToStore[304] = new SqlParameter("@Employement6EmpCode", SqlDbType.VarChar);
            paramsToStore[304].Value = objEmployeeInfo.txtEmployement6EmpCode;
            paramsToStore[304].Size = 50;


            paramsToStore[305] = new SqlParameter("@Employement6DateFrom", SqlDbType.VarChar);
            paramsToStore[305].Value = objEmployeeInfo.txtEmployement6DateFrom;
            paramsToStore[305].Size = 50;


            paramsToStore[306] = new SqlParameter("@Employement6DateTo", SqlDbType.VarChar);
            paramsToStore[306].Value = objEmployeeInfo.txtEmployement6DateTo;
            paramsToStore[306].Size = 50;


            paramsToStore[307] = new SqlParameter("@Employement6Salary", SqlDbType.VarChar);
            paramsToStore[307].Value = objEmployeeInfo.txtEmployement6Salary;
            paramsToStore[307].Size = 50;


            paramsToStore[308] = new SqlParameter("@Employement6State", SqlDbType.VarChar);
            paramsToStore[308].Value = objEmployeeInfo.txtEmployement6State;
            paramsToStore[308].Size = 50;


            paramsToStore[309] = new SqlParameter("@Employement6City", SqlDbType.VarChar);
            paramsToStore[309].Value = objEmployeeInfo.txtEmployement6City;
            paramsToStore[309].Size = 50;


            paramsToStore[310] = new SqlParameter("@Employement6PinCode", SqlDbType.VarChar);
            paramsToStore[310].Value = objEmployeeInfo.txtEmployement6PinCode;
            paramsToStore[310].Size = 50;


            paramsToStore[311] = new SqlParameter("@Employement6Sdesig", SqlDbType.VarChar);
            paramsToStore[311].Value = objEmployeeInfo.txtEmployement6Sdesig;
            paramsToStore[311].Size = 50;


            paramsToStore[312] = new SqlParameter("@Employement6Semail", SqlDbType.VarChar);
            paramsToStore[312].Value = objEmployeeInfo.txtEmployement6Semail;
            paramsToStore[312].Size = 50;


            paramsToStore[313] = new SqlParameter("@Employement6Sphone1", SqlDbType.VarChar);
            paramsToStore[313].Value = objEmployeeInfo.txtEmployement6Sphone1;
            paramsToStore[313].Size = 50;


            paramsToStore[314] = new SqlParameter("@Employement6Sphone2", SqlDbType.VarChar);
            paramsToStore[314].Value = objEmployeeInfo.txtEmployement6Sphone2;
            paramsToStore[314].Size = 50;

            paramsToStore[315] = new SqlParameter("@Employement6SMobile", SqlDbType.VarChar);
            paramsToStore[315].Value = objEmployeeInfo.txtEmployement6SMobile;
            paramsToStore[315].Size = 50;

            paramsToStore[316] = new SqlParameter("@Employement6SResofliv", SqlDbType.VarChar);
            paramsToStore[316].Value = objEmployeeInfo.txtEmployement6SResofliv;
            paramsToStore[316].Size = 50;


            //Emplyement 7
            paramsToStore[317] = new SqlParameter("@Employement7CompanyName", SqlDbType.VarChar);
            paramsToStore[317].Value = objEmployeeInfo.txtEmployement7CompanyName;
            paramsToStore[317].Size = 150;

            paramsToStore[318] = new SqlParameter("@Employement7CompanyLocation", SqlDbType.VarChar);
            paramsToStore[318].Value = objEmployeeInfo.txtEmployement7CompanyLocation;
            paramsToStore[318].Size = 50;

            paramsToStore[319] = new SqlParameter("@Employement7OfficeAddress", SqlDbType.VarChar);
            paramsToStore[319].Value = objEmployeeInfo.txtEmployement7OfficeAddress;
            paramsToStore[319].Size = 150;

            paramsToStore[320] = new SqlParameter("@Employement7Designation", SqlDbType.VarChar);
            paramsToStore[320].Value = objEmployeeInfo.txtEmployement7Designation;
            paramsToStore[320].Size = 50;

            paramsToStore[321] = new SqlParameter("@Employement7phone1", SqlDbType.VarChar);
            paramsToStore[321].Value = objEmployeeInfo.txtEmployement7phone1;
            paramsToStore[321].Size = 50;


            paramsToStore[322] = new SqlParameter("@Employement7phone2", SqlDbType.VarChar);
            paramsToStore[322].Value = objEmployeeInfo.txtEmployement7phone2;
            paramsToStore[322].Size = 50;


            paramsToStore[323] = new SqlParameter("@Employement7EmpCode", SqlDbType.VarChar);
            paramsToStore[323].Value = objEmployeeInfo.txtEmployement7EmpCode;
            paramsToStore[323].Size = 50;

            paramsToStore[324] = new SqlParameter("@Employement7DateFrom", SqlDbType.VarChar);
            paramsToStore[324].Value = objEmployeeInfo.txtEmployement7DateFrom;
            paramsToStore[324].Size = 50;


            paramsToStore[325] = new SqlParameter("@Employement7DateTo", SqlDbType.VarChar);
            paramsToStore[325].Value = objEmployeeInfo.txtEmployement7DateTo;
            paramsToStore[325].Size = 50;


            paramsToStore[326] = new SqlParameter("@Employement7Salary", SqlDbType.VarChar);
            paramsToStore[326].Value = objEmployeeInfo.txtEmployement7Salary;
            paramsToStore[326].Size = 50;


            paramsToStore[327] = new SqlParameter("@Employement7State", SqlDbType.VarChar);
            paramsToStore[327].Value = objEmployeeInfo.txtEmployement7State;
            paramsToStore[327].Size = 50;


            paramsToStore[328] = new SqlParameter("@Employement7City", SqlDbType.VarChar);
            paramsToStore[328].Value = objEmployeeInfo.txtEmployement7City;
            paramsToStore[328].Size = 50;


            paramsToStore[329] = new SqlParameter("@Employement7PinCode", SqlDbType.VarChar);
            paramsToStore[329].Value = objEmployeeInfo.txtEmployement7PinCode;
            paramsToStore[329].Size = 50;


            paramsToStore[330] = new SqlParameter("@Employement7Sdesig", SqlDbType.VarChar);
            paramsToStore[330].Value = objEmployeeInfo.txtEmployement7Sdesig;
            paramsToStore[330].Size = 50;


            paramsToStore[331] = new SqlParameter("@Employement7Semail", SqlDbType.VarChar);
            paramsToStore[331].Value = objEmployeeInfo.txtEmployement7Semail;
            paramsToStore[331].Size = 50;


            paramsToStore[332] = new SqlParameter("@Employement7Sphone1", SqlDbType.VarChar);
            paramsToStore[332].Value = objEmployeeInfo.txtEmployement7Sphone1;
            paramsToStore[332].Size = 50;


            paramsToStore[333] = new SqlParameter("@Employement7Sphone2", SqlDbType.VarChar);
            paramsToStore[333].Value = objEmployeeInfo.txtEmployement7Sphone2;
            paramsToStore[333].Size = 50;

            paramsToStore[334] = new SqlParameter("@Employement7SMobile", SqlDbType.VarChar);
            paramsToStore[334].Value = objEmployeeInfo.txtEmployement7SMobile;
            paramsToStore[334].Size = 50;

            paramsToStore[335] = new SqlParameter("@Employement7SResofliv", SqlDbType.VarChar);
            paramsToStore[335].Value = objEmployeeInfo.txtEmployement7SResofliv;
            paramsToStore[335].Size = 50;




            //Emplyement 8
            paramsToStore[336] = new SqlParameter("@Employement8CompanyName", SqlDbType.VarChar);
            paramsToStore[336].Value = objEmployeeInfo.txtEmployement8CompanyName;
            paramsToStore[336].Size = 150;

            paramsToStore[337] = new SqlParameter("@Employement8CompanyLocation", SqlDbType.VarChar);
            paramsToStore[337].Value = objEmployeeInfo.txtEmployement8CompanyLocation;
            paramsToStore[337].Size = 50;

            paramsToStore[338] = new SqlParameter("@Employement8OfficeAddress", SqlDbType.VarChar);
            paramsToStore[338].Value = objEmployeeInfo.txtEmployement8OfficeAddress;
            paramsToStore[338].Size = 150;

            paramsToStore[339] = new SqlParameter("@Employement8Designation", SqlDbType.VarChar);
            paramsToStore[339].Value = objEmployeeInfo.txtEmployement8Designation;
            paramsToStore[339].Size = 50;

            paramsToStore[340] = new SqlParameter("@Employement8phone1", SqlDbType.VarChar);
            paramsToStore[340].Value = objEmployeeInfo.txtEmployement8phone1;
            paramsToStore[340].Size = 50;


            paramsToStore[341] = new SqlParameter("@Employement8phone2", SqlDbType.VarChar);
            paramsToStore[341].Value = objEmployeeInfo.txtEmployement8phone2;
            paramsToStore[341].Size = 50;

            paramsToStore[342] = new SqlParameter("@Employement8EmpCode", SqlDbType.VarChar);
            paramsToStore[342].Value = objEmployeeInfo.txtEmployement8EmpCode;
            paramsToStore[342].Size = 50;



            paramsToStore[343] = new SqlParameter("@Employement8DateFrom", SqlDbType.VarChar);
            paramsToStore[343].Value = objEmployeeInfo.txtEmployement8DateFrom;
            paramsToStore[343].Size = 50;


            paramsToStore[344] = new SqlParameter("@Employement8DateTo", SqlDbType.VarChar);
            paramsToStore[344].Value = objEmployeeInfo.txtEmployement8DateTo;
            paramsToStore[344].Size = 50;


            paramsToStore[345] = new SqlParameter("@Employement8Salary", SqlDbType.VarChar);
            paramsToStore[345].Value = objEmployeeInfo.txtEmployement8Salary;
            paramsToStore[345].Size = 50;


            paramsToStore[346] = new SqlParameter("@Employement8State", SqlDbType.VarChar);
            paramsToStore[346].Value = objEmployeeInfo.txtEmployement8State;
            paramsToStore[346].Size = 50;


            paramsToStore[347] = new SqlParameter("@Employement8City", SqlDbType.VarChar);
            paramsToStore[347].Value = objEmployeeInfo.txtEmployement8City;
            paramsToStore[347].Size = 50;


            paramsToStore[348] = new SqlParameter("@Employement8PinCode", SqlDbType.VarChar);
            paramsToStore[348].Value = objEmployeeInfo.txtEmployement8PinCode;
            paramsToStore[348].Size = 50;


            paramsToStore[349] = new SqlParameter("@Employement8Sdesig", SqlDbType.VarChar);
            paramsToStore[349].Value = objEmployeeInfo.txtEmployement8Sdesig;
            paramsToStore[349].Size = 50;


            paramsToStore[350] = new SqlParameter("@Employement8Semail", SqlDbType.VarChar);
            paramsToStore[350].Value = objEmployeeInfo.txtEmployement8Semail;
            paramsToStore[350].Size = 50;


            paramsToStore[351] = new SqlParameter("@Employement8Sphone1", SqlDbType.VarChar);
            paramsToStore[351].Value = objEmployeeInfo.txtEmployement8Sphone1;
            paramsToStore[351].Size = 50;


            paramsToStore[352] = new SqlParameter("@Employement8Sphone2", SqlDbType.VarChar);
            paramsToStore[352].Value = objEmployeeInfo.txtEmployement8Sphone2;
            paramsToStore[352].Size = 50;

            paramsToStore[353] = new SqlParameter("@Employement8SMobile", SqlDbType.VarChar);
            paramsToStore[353].Value = objEmployeeInfo.txtEmployement8SMobile;
            paramsToStore[353].Size = 50;

            paramsToStore[354] = new SqlParameter("@Employement8SResofliv", SqlDbType.VarChar);
            paramsToStore[354].Value = objEmployeeInfo.txtEmployement8SResofliv;
            paramsToStore[354].Size = 50;


            //Reference Check


            //[ddlReference] [varchar](50) NULL,
            //[RefCheck1AppName] [varchar](50) NULL,
            //[Ref1DOV] [varchar](50) NULL,
            //[RefCheck1VerifierName] [varchar](50) NULL,
            //[Ref1Desi] [varchar](50) NULL,
            //[Ref1Company] [varchar](50) NULL,
            //[Ref1Email] [varchar](50) NULL,
            //[Ref1CN] [varchar](50) NULL,
            //[RefCheck2AppName] [varchar](50) NULL,
            //[Ref2DOV] [varchar](50) NULL,
            //[RefCheck2VerifierName] [varchar](50) NULL,
            //[Ref2Desi] [varchar](50) NULL,
            //[Ref2Company] [varchar](50) NULL,
            //[Ref2Email] [varchar](50) NULL,
            //[Ref2CN] [varchar](50) NULL,
            //[RefCheck3AppName] [varchar](50) NULL,
            //[Ref3DOV] [varchar](50) NULL,
            //[RefCheck3VerifierName] [varchar](50) NULL,
            //[Ref3Desi] [varchar](50) NULL,
            //[Ref3Company] [varchar](50) NULL,
            //[Ref3Email] [varchar](50) NULL,
            //[Ref3CN] [varchar](50) NULL,

            //Reference 1

            paramsToStore[355] = new SqlParameter("@ddlReference", SqlDbType.VarChar);
            paramsToStore[355].Value = objEmployeeInfo.ddlReference;
            paramsToStore[355].Size = 50;

            paramsToStore[356] = new SqlParameter("@RefCheck1AppName", SqlDbType.VarChar);
            paramsToStore[356].Value = objEmployeeInfo.txtRefCheck1AppName;
            paramsToStore[356].Size = 50;

            paramsToStore[357] = new SqlParameter("@Ref1DOV", SqlDbType.VarChar);
            paramsToStore[357].Value = objEmployeeInfo.txtRef1DOV;
            paramsToStore[357].Size = 50;

            paramsToStore[358] = new SqlParameter("@RefCheck1VerifierName", SqlDbType.VarChar);
            paramsToStore[358].Value = objEmployeeInfo.txtRefCheck1VerifierName;
            paramsToStore[358].Size = 50;

            paramsToStore[359] = new SqlParameter("@Ref1Desi", SqlDbType.VarChar);
            paramsToStore[359].Value = objEmployeeInfo.txtRef1Desi;
            paramsToStore[359].Size = 50;

            paramsToStore[360] = new SqlParameter("@Ref1Company", SqlDbType.VarChar);
            paramsToStore[360].Value = objEmployeeInfo.txtRef1Company;
            paramsToStore[360].Size = 50;


            paramsToStore[361] = new SqlParameter("@Ref1Email", SqlDbType.VarChar);
            paramsToStore[361].Value = objEmployeeInfo.txtRef1Email;
            paramsToStore[361].Size = 50;

            paramsToStore[362] = new SqlParameter("@Ref1CN", SqlDbType.VarChar);
            paramsToStore[362].Value = objEmployeeInfo.txtRef1CN;
            paramsToStore[362].Size = 50;


            //Reference 2



            paramsToStore[363] = new SqlParameter("@RefCheck2AppName", SqlDbType.VarChar);
            paramsToStore[363].Value = objEmployeeInfo.txtRefCheck2AppName;
            paramsToStore[363].Size = 50;

            paramsToStore[364] = new SqlParameter("@Ref2DOV", SqlDbType.VarChar);
            paramsToStore[364].Value = objEmployeeInfo.txtRef2DOV;
            paramsToStore[364].Size = 50;

            paramsToStore[365] = new SqlParameter("@RefCheck2VerifierName", SqlDbType.VarChar);
            paramsToStore[365].Value = objEmployeeInfo.txtRefCheck2VerifierName;
            paramsToStore[365].Size = 50;

            paramsToStore[366] = new SqlParameter("@Ref2Desi", SqlDbType.VarChar);
            paramsToStore[366].Value = objEmployeeInfo.txtRef2Desi;
            paramsToStore[366].Size = 50;

            paramsToStore[367] = new SqlParameter("@Ref2Company", SqlDbType.VarChar);
            paramsToStore[367].Value = objEmployeeInfo.txtRef2Company;
            paramsToStore[367].Size = 50;


            paramsToStore[368] = new SqlParameter("@Ref2Email", SqlDbType.VarChar);
            paramsToStore[368].Value = objEmployeeInfo.txtRef2Email;
            paramsToStore[368].Size = 50;

            paramsToStore[369] = new SqlParameter("@Ref2CN", SqlDbType.VarChar);
            paramsToStore[369].Value = objEmployeeInfo.txtRef2CN;
            paramsToStore[369].Size = 50;


            //Reference 3



            paramsToStore[370] = new SqlParameter("@RefCheck3AppName", SqlDbType.VarChar);
            paramsToStore[370].Value = objEmployeeInfo.txtRefCheck3AppName;
            paramsToStore[370].Size = 50;

            paramsToStore[371] = new SqlParameter("@Ref3DOV", SqlDbType.VarChar);
            paramsToStore[371].Value = objEmployeeInfo.txtRef3DOV;
            paramsToStore[371].Size = 50;

            paramsToStore[372] = new SqlParameter("@RefCheck3VerifierName", SqlDbType.VarChar);
            paramsToStore[372].Value = objEmployeeInfo.txtRefCheck3VerifierName;
            paramsToStore[372].Size = 50;

            paramsToStore[373] = new SqlParameter("@Ref3Desi", SqlDbType.VarChar);
            paramsToStore[373].Value = objEmployeeInfo.txtRef3Desi;
            paramsToStore[373].Size = 50;

            paramsToStore[374] = new SqlParameter("@Ref3Company", SqlDbType.VarChar);
            paramsToStore[374].Value = objEmployeeInfo.txtRef3Company;
            paramsToStore[374].Size = 50;


            paramsToStore[375] = new SqlParameter("@Ref3Email", SqlDbType.VarChar);
            paramsToStore[375].Value = objEmployeeInfo.txtRef3Email;
            paramsToStore[375].Size = 50;

            paramsToStore[376] = new SqlParameter("@Ref3CN", SqlDbType.VarChar);
            paramsToStore[376].Value = objEmployeeInfo.txtRef3CN;
            paramsToStore[376].Size = 50;

            //[ddlDatabase] [varchar](50) NULL,
            //[DatabaseCheck] [varchar](50) NULL,
            //[DatabaseLocation] [varchar](50) NULL,
            //[ddlDrug] [varchar](50) NULL,
            //[DrugCheck] [varchar](50) NULL,
            //[DrugLocation] [varchar](50) NULL,
            //[ddlIndentity] [varchar](50) NULL,
            //[IdetityCheck] [varchar](50) NULL,
            //[IdentityLocation] [varchar](50) NULL,

            paramsToStore[377] = new SqlParameter("@ddlDatabase", SqlDbType.VarChar);
            paramsToStore[377].Value = objEmployeeInfo.ddlDatabase;
            paramsToStore[377].Size = 50;

            paramsToStore[378] = new SqlParameter("@DatabaseCheck", SqlDbType.VarChar);
            paramsToStore[378].Value = objEmployeeInfo.txtDatabaseCheck;
            paramsToStore[378].Size = 50;

            paramsToStore[379] = new SqlParameter("@DatabaseLocation", SqlDbType.VarChar);
            paramsToStore[379].Value = objEmployeeInfo.txtDatabaseLocation;
            paramsToStore[379].Size = 50;

            paramsToStore[380] = new SqlParameter("@ddlDrug", SqlDbType.VarChar);
            paramsToStore[380].Value = objEmployeeInfo.ddlDrug;
            paramsToStore[380].Size = 50;

            paramsToStore[381] = new SqlParameter("@DrugCheck", SqlDbType.VarChar);
            paramsToStore[381].Value = objEmployeeInfo.txtDrugCheck;
            paramsToStore[381].Size = 50;

            paramsToStore[382] = new SqlParameter("@DrugLocation", SqlDbType.VarChar);
            paramsToStore[382].Value = objEmployeeInfo.txtDrugLocation;
            paramsToStore[382].Size = 50;


            paramsToStore[383] = new SqlParameter("@ddlIndentity", SqlDbType.VarChar);
            paramsToStore[383].Value = objEmployeeInfo.ddlIndentity;
            paramsToStore[383].Size = 50;


            paramsToStore[384] = new SqlParameter("@IdentityCheck", SqlDbType.VarChar);
            paramsToStore[384].Value = objEmployeeInfo.txtIdentityCheck;
            paramsToStore[384].Size = 50;

            paramsToStore[385] = new SqlParameter("@IdentityLocation", SqlDbType.VarChar);
            paramsToStore[385].Value = objEmployeeInfo.txtIdentityLocation;
            paramsToStore[385].Size = 50;

            paramsToStore[386] = new SqlParameter("@AddressCheck", SqlDbType.VarChar);
            paramsToStore[386].Value = objEmployeeInfo.AddressCheck;
            paramsToStore[386].Size = 50;

            paramsToStore[387] = new SqlParameter("@CriminalCheck", SqlDbType.VarChar);
            paramsToStore[387].Value = objEmployeeInfo.CriminalCheck;
            paramsToStore[387].Size = 50;





            //---------------------------End All Checks


            //-------------------------Start----------Criminal

            paramsToStore[388] = new SqlParameter("@Criminal1Address", SqlDbType.VarChar);
            paramsToStore[388].Value = objEmployeeInfo.Criminal1Address;
            paramsToStore[388].Size = 300;

            paramsToStore[389] = new SqlParameter("@Criminal2Address", SqlDbType.VarChar);
            paramsToStore[389].Value = objEmployeeInfo.Criminal2Address;
            paramsToStore[389].Size = 300;

            paramsToStore[390] = new SqlParameter("@Criminal3Address", SqlDbType.VarChar);
            paramsToStore[390].Value = objEmployeeInfo.Criminal3Address;
            paramsToStore[390].Size = 300;

            paramsToStore[391] = new SqlParameter("@Criminal4Address", SqlDbType.VarChar);
            paramsToStore[391].Value = objEmployeeInfo.Criminal4Address;
            paramsToStore[391].Size = 300;




            paramsToStore[392] = new SqlParameter("@Criminal5Address", SqlDbType.VarChar);
            paramsToStore[392].Value = objEmployeeInfo.Criminal5Address;
            paramsToStore[392].Size = 300;

            paramsToStore[393] = new SqlParameter("@Criminal6Address", SqlDbType.VarChar);
            paramsToStore[393].Value = objEmployeeInfo.Criminal6Address;
            paramsToStore[393].Size = 300;

            paramsToStore[394] = new SqlParameter("@Criminal7Address", SqlDbType.VarChar);
            paramsToStore[394].Value = objEmployeeInfo.Criminal7Address;
            paramsToStore[394].Size = 300;

            paramsToStore[395] = new SqlParameter("@Criminal8Address", SqlDbType.VarChar);
            paramsToStore[395].Value = objEmployeeInfo.Criminal8Address;
            paramsToStore[395].Size = 300;




            paramsToStore[396] = new SqlParameter("@Criminal1State", SqlDbType.VarChar);
            paramsToStore[396].Value = objEmployeeInfo.Criminal1State;
            paramsToStore[396].Size = 50;

            paramsToStore[397] = new SqlParameter("@Criminal2State", SqlDbType.VarChar);
            paramsToStore[397].Value = objEmployeeInfo.Criminal2State;
            paramsToStore[397].Size = 50;

            paramsToStore[398] = new SqlParameter("@Criminal3State", SqlDbType.VarChar);
            paramsToStore[398].Value = objEmployeeInfo.Criminal3State;
            paramsToStore[398].Size = 50;

            paramsToStore[399] = new SqlParameter("@Criminal4State", SqlDbType.VarChar);
            paramsToStore[399].Value = objEmployeeInfo.Criminal4State;
            paramsToStore[399].Size = 50;




            paramsToStore[400] = new SqlParameter("@Criminal5State", SqlDbType.VarChar);
            paramsToStore[400].Value = objEmployeeInfo.Criminal5State;
            paramsToStore[400].Size = 50;

            paramsToStore[401] = new SqlParameter("@Criminal6State", SqlDbType.VarChar);
            paramsToStore[401].Value = objEmployeeInfo.Criminal6State;
            paramsToStore[401].Size = 50;

            paramsToStore[402] = new SqlParameter("@Criminal7State", SqlDbType.VarChar);
            paramsToStore[402].Value = objEmployeeInfo.Criminal7State;
            paramsToStore[402].Size = 50;

            paramsToStore[403] = new SqlParameter("@Criminal8State", SqlDbType.VarChar);
            paramsToStore[403].Value = objEmployeeInfo.Criminal8State;
            paramsToStore[403].Size = 50;

            paramsToStore[404] = new SqlParameter("@CaseStatusKPMG", SqlDbType.VarChar);
            paramsToStore[404].Value = objEmployeeInfo.CaseStatusKPMG;
            paramsToStore[404].Size = 50;

            paramsToStore[405] = new SqlParameter("@Req_Edu1", SqlDbType.VarChar);
            paramsToStore[405].Value = objEmployeeInfo.strRequirement_edu1;
            paramsToStore[405].Size = 50;

            paramsToStore[406] = new SqlParameter("@Req_Edu2", SqlDbType.VarChar);
            paramsToStore[406].Value = objEmployeeInfo.strRequirement_edu2;
            paramsToStore[406].Size = 50;

            paramsToStore[407] = new SqlParameter("@Req_Edu3", SqlDbType.VarChar);
            paramsToStore[407].Value = objEmployeeInfo.strRequirement_edu3;
            paramsToStore[407].Size = 50;

            paramsToStore[408] = new SqlParameter("@Req_Edu4", SqlDbType.VarChar);
            paramsToStore[408].Value = objEmployeeInfo.strRequirement_edu4;
            paramsToStore[408].Size = 50;

            paramsToStore[409] = new SqlParameter("@category", SqlDbType.VarChar);
            paramsToStore[409].Value = objEmployeeInfo.strCategory;
            paramsToStore[409].Size = 50;

            paramsToStore[410] = new SqlParameter("@subCategory", SqlDbType.VarChar);
            paramsToStore[410].Value = objEmployeeInfo.strSubCategory;
            paramsToStore[410].Size = 50;


            paramsToStore[411] = new SqlParameter("@AddDateFrm1", SqlDbType.VarChar);
            paramsToStore[411].Value = objEmployeeInfo.strAddDateFrm1;
            paramsToStore[411].Size = 50;

            paramsToStore[412] = new SqlParameter("@AddDateFrm2", SqlDbType.VarChar);
            paramsToStore[412].Value = objEmployeeInfo.strAddDateFrm2;
            paramsToStore[412].Size = 50;

            paramsToStore[413] = new SqlParameter("@AddDateFrm3", SqlDbType.VarChar);
            paramsToStore[413].Value = objEmployeeInfo.strAddDateFrm3;
            paramsToStore[413].Size = 50;

            paramsToStore[414] = new SqlParameter("@AddDateFrm4", SqlDbType.VarChar);
            paramsToStore[414].Value = objEmployeeInfo.strAddDateFrm4;
            paramsToStore[414].Size = 50;

            paramsToStore[415] = new SqlParameter("@AddDateFrm5", SqlDbType.VarChar);
            paramsToStore[415].Value = objEmployeeInfo.strAddDateFrm5;
            paramsToStore[415].Size = 50;

            paramsToStore[416] = new SqlParameter("@AddDateFrm6", SqlDbType.VarChar);
            paramsToStore[416].Value = objEmployeeInfo.strAddDateFrm6;
            paramsToStore[416].Size = 50;

            paramsToStore[417] = new SqlParameter("@AddDateFrm7", SqlDbType.VarChar);
            paramsToStore[417].Value = objEmployeeInfo.strAddDateFrm7;
            paramsToStore[417].Size = 50;

            paramsToStore[418] = new SqlParameter("@AddDateFrm8", SqlDbType.VarChar);
            paramsToStore[418].Value = objEmployeeInfo.strAddDateFrm8;
            paramsToStore[418].Size = 50;

            paramsToStore[419] = new SqlParameter("@AddDateTo1", SqlDbType.VarChar);
            paramsToStore[419].Value = objEmployeeInfo.strAddDateTo1;
            paramsToStore[419].Size = 50;

            paramsToStore[420] = new SqlParameter("@AddDateTo2", SqlDbType.VarChar);
            paramsToStore[420].Value = objEmployeeInfo.strAddDateTo2;
            paramsToStore[420].Size = 50;

            paramsToStore[421] = new SqlParameter("@AddDateTo3", SqlDbType.VarChar);
            paramsToStore[421].Value = objEmployeeInfo.strAddDateTo3;
            paramsToStore[421].Size = 50;

            paramsToStore[422] = new SqlParameter("@AddDateTo4", SqlDbType.VarChar);
            paramsToStore[422].Value = objEmployeeInfo.strAddDateTo4;
            paramsToStore[422].Size = 50;

            paramsToStore[423] = new SqlParameter("@AddDateTo5", SqlDbType.VarChar);
            paramsToStore[423].Value = objEmployeeInfo.strAddDateTo5;
            paramsToStore[423].Size = 50;

            paramsToStore[424] = new SqlParameter("@AddDateTo6", SqlDbType.VarChar);
            paramsToStore[424].Value = objEmployeeInfo.strAddDateTo6;
            paramsToStore[424].Size = 50;

            paramsToStore[425] = new SqlParameter("@AddDateTo7", SqlDbType.VarChar);
            paramsToStore[425].Value = objEmployeeInfo.strAddDateTo7;
            paramsToStore[425].Size = 50;

            paramsToStore[426] = new SqlParameter("@AddDateTo8", SqlDbType.VarChar);
            paramsToStore[426].Value = objEmployeeInfo.strAddDateTo8;
            paramsToStore[426].Size = 50;

            paramsToStore[427] = new SqlParameter("@CriDateFrm1", SqlDbType.VarChar);
            paramsToStore[427].Value = objEmployeeInfo.strCriDateFrm1;
            paramsToStore[427].Size = 50;

            paramsToStore[428] = new SqlParameter("@CriDateFrm2", SqlDbType.VarChar);
            paramsToStore[428].Value = objEmployeeInfo.strCriDateFrm2;
            paramsToStore[428].Size = 50;

            paramsToStore[429] = new SqlParameter("@CriDateFrm3", SqlDbType.VarChar);
            paramsToStore[429].Value = objEmployeeInfo.strCriDateFrm3;
            paramsToStore[429].Size = 50;

            paramsToStore[430] = new SqlParameter("@CriDateFrm4", SqlDbType.VarChar);
            paramsToStore[430].Value = objEmployeeInfo.strCriDateFrm4;
            paramsToStore[430].Size = 50;

            paramsToStore[431] = new SqlParameter("@CriDateFrm5", SqlDbType.VarChar);
            paramsToStore[431].Value = objEmployeeInfo.strCriDateFrm5;
            paramsToStore[431].Size = 50;

            paramsToStore[432] = new SqlParameter("@CriDateFrm6", SqlDbType.VarChar);
            paramsToStore[432].Value = objEmployeeInfo.strCriDateFrm6;
            paramsToStore[432].Size = 50;

            paramsToStore[433] = new SqlParameter("@CriDateFrm7", SqlDbType.VarChar);
            paramsToStore[433].Value = objEmployeeInfo.strCriDateFrm7;
            paramsToStore[433].Size = 50;

            paramsToStore[434] = new SqlParameter("@CriDateFrm8", SqlDbType.VarChar);
            paramsToStore[434].Value = objEmployeeInfo.strCriDateFrm8;
            paramsToStore[434].Size = 50;

            paramsToStore[435] = new SqlParameter("@CriDateTo1", SqlDbType.VarChar);
            paramsToStore[435].Value = objEmployeeInfo.strCriDateTo1;
            paramsToStore[435].Size = 50;

            paramsToStore[436] = new SqlParameter("@CriDateTo2", SqlDbType.VarChar);
            paramsToStore[436].Value = objEmployeeInfo.strCriDateTo2;
            paramsToStore[436].Size = 50;

            paramsToStore[437] = new SqlParameter("@CriDateTo3", SqlDbType.VarChar);
            paramsToStore[437].Value = objEmployeeInfo.strCriDateTo3;
            paramsToStore[437].Size = 50;

            paramsToStore[438] = new SqlParameter("@CriDateTo4", SqlDbType.VarChar);
            paramsToStore[438].Value = objEmployeeInfo.strCriDateTo4;
            paramsToStore[438].Size = 50;

            paramsToStore[439] = new SqlParameter("@CriDateTo5", SqlDbType.VarChar);
            paramsToStore[439].Value = objEmployeeInfo.strCriDateTo5;
            paramsToStore[439].Size = 50;

            paramsToStore[440] = new SqlParameter("@CriDateTo6", SqlDbType.VarChar);
            paramsToStore[440].Value = objEmployeeInfo.strCriDateTo6;
            paramsToStore[440].Size = 50;

            paramsToStore[441] = new SqlParameter("@CriDateTo7", SqlDbType.VarChar);
            paramsToStore[441].Value = objEmployeeInfo.strCriDateTo7;
            paramsToStore[441].Size = 50;

            paramsToStore[442] = new SqlParameter("@CriDateTo8", SqlDbType.VarChar);
            paramsToStore[442].Value = objEmployeeInfo.strCriDateTo8;
            paramsToStore[442].Size = 50;

            paramsToStore[443] = new SqlParameter("@EduDateFrm1", SqlDbType.VarChar);
            paramsToStore[443].Value = objEmployeeInfo.strEduDateFrm1;
            paramsToStore[443].Size = 50;

            paramsToStore[444] = new SqlParameter("@EduDateFrm2", SqlDbType.VarChar);
            paramsToStore[444].Value = objEmployeeInfo.strEduDateFrm2;
            paramsToStore[444].Size = 50;

            paramsToStore[445] = new SqlParameter("@EduDateFrm3", SqlDbType.VarChar);
            paramsToStore[445].Value = objEmployeeInfo.strEduDateFrm3;
            paramsToStore[445].Size = 50;



            paramsToStore[446] = new SqlParameter("@EduDateFrm5", SqlDbType.VarChar);
            paramsToStore[446].Value = objEmployeeInfo.strEduDateFrm5;
            paramsToStore[446].Size = 50;

            paramsToStore[447] = new SqlParameter("@EduDateFrm6", SqlDbType.VarChar);
            paramsToStore[447].Value = objEmployeeInfo.strEduDateFrm6;
            paramsToStore[447].Size = 50;

            paramsToStore[448] = new SqlParameter("@EduDateFrm7", SqlDbType.VarChar);
            paramsToStore[448].Value = objEmployeeInfo.strEduDateFrm7;
            paramsToStore[448].Size = 50;

            paramsToStore[449] = new SqlParameter("@EduDateFrm8", SqlDbType.VarChar);
            paramsToStore[449].Value = objEmployeeInfo.strEduDateFrm8;
            paramsToStore[449].Size = 50;

            paramsToStore[450] = new SqlParameter("@EduDateTo1", SqlDbType.VarChar);
            paramsToStore[450].Value = objEmployeeInfo.strEduDateTo1;
            paramsToStore[450].Size = 50;

            paramsToStore[451] = new SqlParameter("@EduDateTo2", SqlDbType.VarChar);
            paramsToStore[451].Value = objEmployeeInfo.strEduDateTo2;
            paramsToStore[451].Size = 50;

            paramsToStore[452] = new SqlParameter("@EduDateTo3", SqlDbType.VarChar);
            paramsToStore[452].Value = objEmployeeInfo.strEduDateTo3;
            paramsToStore[452].Size = 50;

            paramsToStore[453] = new SqlParameter("@EduDateTo4", SqlDbType.VarChar);
            paramsToStore[453].Value = objEmployeeInfo.strEduDateTo4;
            paramsToStore[453].Size = 50;

            paramsToStore[454] = new SqlParameter("@EduDateTo5", SqlDbType.VarChar);
            paramsToStore[454].Value = objEmployeeInfo.strEduDateTo5;
            paramsToStore[454].Size = 50;

            paramsToStore[455] = new SqlParameter("@EduDateTo6", SqlDbType.VarChar);
            paramsToStore[455].Value = objEmployeeInfo.strEduDateTo6;
            paramsToStore[455].Size = 50;

            paramsToStore[456] = new SqlParameter("@EduDateTo7", SqlDbType.VarChar);
            paramsToStore[456].Value = objEmployeeInfo.strEduDateTo7;
            paramsToStore[456].Size = 50;





            paramsToStore[457] = new SqlParameter("@AddStatus1", SqlDbType.VarChar);
            paramsToStore[457].Value = objEmployeeInfo.strAddStatus1;
            paramsToStore[457].Size = 50;

            paramsToStore[458] = new SqlParameter("@AddStatus2", SqlDbType.VarChar);
            paramsToStore[458].Value = objEmployeeInfo.strAddStatus2;
            paramsToStore[458].Size = 50;

            paramsToStore[459] = new SqlParameter("@AddStatus3", SqlDbType.VarChar);
            paramsToStore[459].Value = objEmployeeInfo.strAddStatus3;
            paramsToStore[459].Size = 50;

            paramsToStore[460] = new SqlParameter("@AddStatus4", SqlDbType.VarChar);
            paramsToStore[460].Value = objEmployeeInfo.strAddStatus4;
            paramsToStore[460].Size = 50;

            paramsToStore[461] = new SqlParameter("@AddStatus5", SqlDbType.VarChar);
            paramsToStore[461].Value = objEmployeeInfo.strAddStatus5;
            paramsToStore[461].Size = 50;

            paramsToStore[462] = new SqlParameter("@AddStatus6", SqlDbType.VarChar);
            paramsToStore[462].Value = objEmployeeInfo.strAddStatus6;
            paramsToStore[462].Size = 50;

            paramsToStore[463] = new SqlParameter("@AddStatus7", SqlDbType.VarChar);
            paramsToStore[463].Value = objEmployeeInfo.strAddStatus7;
            paramsToStore[463].Size = 50;

            paramsToStore[464] = new SqlParameter("@AddStatus8", SqlDbType.VarChar);
            paramsToStore[464].Value = objEmployeeInfo.strAddStatus8;
            paramsToStore[464].Size = 50;

            paramsToStore[465] = new SqlParameter("@AddRemarks1", SqlDbType.VarChar);
            paramsToStore[465].Value = objEmployeeInfo.strAddRemarks1;
            paramsToStore[465].Size = 500;

            paramsToStore[466] = new SqlParameter("@AddRemarks2", SqlDbType.VarChar);
            paramsToStore[466].Value = objEmployeeInfo.strAddRemarks2;
            paramsToStore[466].Size = 500;

            paramsToStore[467] = new SqlParameter("@AddRemarks3", SqlDbType.VarChar);
            paramsToStore[467].Value = objEmployeeInfo.strAddRemarks3;
            paramsToStore[467].Size = 500;

            paramsToStore[468] = new SqlParameter("@AddRemarks4", SqlDbType.VarChar);
            paramsToStore[468].Value = objEmployeeInfo.strAddRemarks4;
            paramsToStore[468].Size = 500;



            paramsToStore[469] = new SqlParameter("@AddRemarks6", SqlDbType.VarChar);
            paramsToStore[469].Value = objEmployeeInfo.strAddRemarks6;
            paramsToStore[469].Size = 500;

            paramsToStore[470] = new SqlParameter("@AddRemarks7", SqlDbType.VarChar);
            paramsToStore[470].Value = objEmployeeInfo.strAddRemarks7;
            paramsToStore[470].Size = 500;

            paramsToStore[471] = new SqlParameter("@AddRemarks8", SqlDbType.VarChar);
            paramsToStore[471].Value = objEmployeeInfo.strAddRemarks8;
            paramsToStore[471].Size = 500;


            paramsToStore[472] = new SqlParameter("@CriStatus1", SqlDbType.VarChar);
            paramsToStore[472].Value = objEmployeeInfo.strCriStatus1;
            paramsToStore[472].Size = 50;

            paramsToStore[473] = new SqlParameter("@CriStatus2", SqlDbType.VarChar);
            paramsToStore[473].Value = objEmployeeInfo.strCriStatus2;
            paramsToStore[473].Size = 50;

            paramsToStore[474] = new SqlParameter("@CriStatus3", SqlDbType.VarChar);
            paramsToStore[474].Value = objEmployeeInfo.strCriStatus3;
            paramsToStore[474].Size = 50;

            paramsToStore[475] = new SqlParameter("@CriStatus4", SqlDbType.VarChar);
            paramsToStore[475].Value = objEmployeeInfo.strCriStatus4;
            paramsToStore[475].Size = 50;

            paramsToStore[476] = new SqlParameter("@CriStatus5", SqlDbType.VarChar);
            paramsToStore[476].Value = objEmployeeInfo.strCriStatus5;
            paramsToStore[476].Size = 50;

            paramsToStore[477] = new SqlParameter("@CriStatus6", SqlDbType.VarChar);
            paramsToStore[477].Value = objEmployeeInfo.strCriStatus6;
            paramsToStore[477].Size = 50;

            paramsToStore[478] = new SqlParameter("@CriStatus7", SqlDbType.VarChar);
            paramsToStore[478].Value = objEmployeeInfo.strCriStatus7;
            paramsToStore[478].Size = 50;

            paramsToStore[479] = new SqlParameter("@CriStatus8", SqlDbType.VarChar);
            paramsToStore[479].Value = objEmployeeInfo.strCriStatus8;
            paramsToStore[479].Size = 50;

            paramsToStore[480] = new SqlParameter("@CriRemarks1", SqlDbType.VarChar);
            paramsToStore[480].Value = objEmployeeInfo.strCriRemarks1;
            paramsToStore[480].Size = 500;

            paramsToStore[481] = new SqlParameter("@CriRemarks2", SqlDbType.VarChar);
            paramsToStore[481].Value = objEmployeeInfo.strCriRemarks2;
            paramsToStore[481].Size = 500;

            paramsToStore[482] = new SqlParameter("@CriRemarks3", SqlDbType.VarChar);
            paramsToStore[482].Value = objEmployeeInfo.strCriRemarks3;
            paramsToStore[482].Size = 500;

            paramsToStore[483] = new SqlParameter("@CriRemarks4", SqlDbType.VarChar);
            paramsToStore[483].Value = objEmployeeInfo.strCriRemarks4;
            paramsToStore[483].Size = 500;

            paramsToStore[484] = new SqlParameter("@CriRemarks5", SqlDbType.VarChar);
            paramsToStore[484].Value = objEmployeeInfo.strCriRemarks5;
            paramsToStore[484].Size = 500;

            paramsToStore[485] = new SqlParameter("@CriRemarks6", SqlDbType.VarChar);
            paramsToStore[485].Value = objEmployeeInfo.strCriRemarks6;
            paramsToStore[485].Size = 500;

            paramsToStore[486] = new SqlParameter("@CriRemarks7", SqlDbType.VarChar);
            paramsToStore[486].Value = objEmployeeInfo.strCriRemarks7;
            paramsToStore[486].Size = 500;

            paramsToStore[487] = new SqlParameter("@CriRemarks8", SqlDbType.VarChar);
            paramsToStore[487].Value = objEmployeeInfo.strCriRemarks8;
            paramsToStore[487].Size = 500;


            paramsToStore[488] = new SqlParameter("@EduStatus1", SqlDbType.VarChar);
            paramsToStore[488].Value = objEmployeeInfo.strEduStatus1;
            paramsToStore[488].Size = 50;

            paramsToStore[489] = new SqlParameter("@EduStatus2", SqlDbType.VarChar);
            paramsToStore[489].Value = objEmployeeInfo.strEduStatus2;
            paramsToStore[489].Size = 50;

            paramsToStore[490] = new SqlParameter("@EduStatus3", SqlDbType.VarChar);
            paramsToStore[490].Value = objEmployeeInfo.strEduStatus3;
            paramsToStore[490].Size = 50;

            paramsToStore[491] = new SqlParameter("@EduStatus4", SqlDbType.VarChar);
            paramsToStore[491].Value = objEmployeeInfo.strEduStatus4;
            paramsToStore[491].Size = 50;

            paramsToStore[492] = new SqlParameter("@EduStatus5", SqlDbType.VarChar);
            paramsToStore[492].Value = objEmployeeInfo.strEduStatus5;
            paramsToStore[492].Size = 50;

            paramsToStore[493] = new SqlParameter("@EduStatus6", SqlDbType.VarChar);
            paramsToStore[493].Value = objEmployeeInfo.strEduStatus6;
            paramsToStore[493].Size = 50;

            paramsToStore[494] = new SqlParameter("@EduStatus7", SqlDbType.VarChar);
            paramsToStore[494].Value = objEmployeeInfo.strEduStatus7;
            paramsToStore[494].Size = 50;

            paramsToStore[495] = new SqlParameter("@EduStatus8", SqlDbType.VarChar);
            paramsToStore[495].Value = objEmployeeInfo.strEduStatus8;
            paramsToStore[495].Size = 50;

            paramsToStore[496] = new SqlParameter("@EduRemarks1", SqlDbType.VarChar);
            paramsToStore[496].Value = objEmployeeInfo.strEduRemarks1;
            paramsToStore[496].Size = 500;

            paramsToStore[497] = new SqlParameter("@EduRemarks2", SqlDbType.VarChar);
            paramsToStore[497].Value = objEmployeeInfo.strEduRemarks2;
            paramsToStore[497].Size = 500;

            paramsToStore[498] = new SqlParameter("@EduRemarks3", SqlDbType.VarChar);
            paramsToStore[498].Value = objEmployeeInfo.strEduRemarks3;
            paramsToStore[498].Size = 500;

            paramsToStore[499] = new SqlParameter("@EduRemarks4", SqlDbType.VarChar);
            paramsToStore[499].Value = objEmployeeInfo.strEduRemarks4;
            paramsToStore[499].Size = 500;



            paramsToStore[500] = new SqlParameter("@EduRemarks6", SqlDbType.VarChar);
            paramsToStore[500].Value = objEmployeeInfo.strEduRemarks6;
            paramsToStore[500].Size = 500;

            paramsToStore[501] = new SqlParameter("@EduRemarks7", SqlDbType.VarChar);
            paramsToStore[501].Value = objEmployeeInfo.strEduRemarks7;
            paramsToStore[501].Size = 500;

            paramsToStore[502] = new SqlParameter("@EduRemarks8", SqlDbType.VarChar);
            paramsToStore[502].Value = objEmployeeInfo.strEduRemarks8;
            paramsToStore[502].Size = 500;


            paramsToStore[503] = new SqlParameter("@EmpStatus1", SqlDbType.VarChar);
            paramsToStore[503].Value = objEmployeeInfo.strEmpStatus1;
            paramsToStore[503].Size = 50;

            paramsToStore[504] = new SqlParameter("@EmpStatus2", SqlDbType.VarChar);
            paramsToStore[504].Value = objEmployeeInfo.strEmpStatus2;
            paramsToStore[504].Size = 50;

            paramsToStore[505] = new SqlParameter("@EmpStatus3", SqlDbType.VarChar);
            paramsToStore[505].Value = objEmployeeInfo.strEmpStatus3;
            paramsToStore[505].Size = 50;

            paramsToStore[506] = new SqlParameter("@EmpStatus4", SqlDbType.VarChar);
            paramsToStore[506].Value = objEmployeeInfo.strEmpStatus4;
            paramsToStore[506].Size = 50;

            paramsToStore[507] = new SqlParameter("@EmpStatus5", SqlDbType.VarChar);
            paramsToStore[507].Value = objEmployeeInfo.strEmpStatus5;
            paramsToStore[507].Size = 50;

            paramsToStore[508] = new SqlParameter("@EmpStatus6", SqlDbType.VarChar);
            paramsToStore[508].Value = objEmployeeInfo.strEmpStatus6;
            paramsToStore[508].Size = 50;

            paramsToStore[509] = new SqlParameter("@EmpStatus7", SqlDbType.VarChar);
            paramsToStore[509].Value = objEmployeeInfo.strEmpStatus7;
            paramsToStore[509].Size = 50;

            paramsToStore[510] = new SqlParameter("@EmpStatus8", SqlDbType.VarChar);
            paramsToStore[510].Value = objEmployeeInfo.strEmpStatus8;
            paramsToStore[510].Size = 50;

            paramsToStore[511] = new SqlParameter("@EmpRemarks1", SqlDbType.VarChar);
            paramsToStore[511].Value = objEmployeeInfo.strEmpRemarks1;
            paramsToStore[511].Size = 500;

            paramsToStore[512] = new SqlParameter("@EmpRemarks2", SqlDbType.VarChar);
            paramsToStore[512].Value = objEmployeeInfo.strEmpRemarks2;
            paramsToStore[512].Size = 500;

            paramsToStore[513] = new SqlParameter("@EmpRemarks3", SqlDbType.VarChar);
            paramsToStore[513].Value = objEmployeeInfo.strEmpRemarks3;
            paramsToStore[513].Size = 500;

            paramsToStore[514] = new SqlParameter("@EmpRemarks4", SqlDbType.VarChar);
            paramsToStore[514].Value = objEmployeeInfo.strEmpRemarks4;
            paramsToStore[514].Size = 500;

            paramsToStore[515] = new SqlParameter("@EmpRemarks5", SqlDbType.VarChar);
            paramsToStore[515].Value = objEmployeeInfo.strEmpRemarks5;
            paramsToStore[515].Size = 500;

            paramsToStore[516] = new SqlParameter("@EmpRemarks6", SqlDbType.VarChar);
            paramsToStore[516].Value = objEmployeeInfo.strEmpRemarks6;
            paramsToStore[516].Size = 500;

            paramsToStore[517] = new SqlParameter("@EmpRemarks7", SqlDbType.VarChar);
            paramsToStore[517].Value = objEmployeeInfo.strEmpRemarks7;
            paramsToStore[517].Size = 500;

            paramsToStore[518] = new SqlParameter("@EmpRemarks8", SqlDbType.VarChar);
            paramsToStore[518].Value = objEmployeeInfo.strEmpRemarks8;
            paramsToStore[518].Size = 500;

            paramsToStore[519] = new SqlParameter("@RefStatus1", SqlDbType.VarChar);
            paramsToStore[519].Value = objEmployeeInfo.strRefStatus1;
            paramsToStore[519].Size = 50;

            paramsToStore[520] = new SqlParameter("@RefStatus2", SqlDbType.VarChar);
            paramsToStore[520].Value = objEmployeeInfo.strRefStatus2;
            paramsToStore[520].Size = 50;




            paramsToStore[521] = new SqlParameter("@RefRemarks1", SqlDbType.VarChar);
            paramsToStore[521].Value = objEmployeeInfo.strRefRemarks1;
            paramsToStore[521].Size = 500;

            paramsToStore[522] = new SqlParameter("@RefRemarks2", SqlDbType.VarChar);
            paramsToStore[522].Value = objEmployeeInfo.strRefRemarks2;
            paramsToStore[522].Size = 500;

            paramsToStore[523] = new SqlParameter("@RefRemarks3", SqlDbType.VarChar);
            paramsToStore[523].Value = objEmployeeInfo.strRefRemarks3;
            paramsToStore[523].Size = 500;

            paramsToStore[524] = new SqlParameter("@DBStatus", SqlDbType.VarChar);
            paramsToStore[524].Value = objEmployeeInfo.strDBStatus;
            paramsToStore[524].Size = 50;


            paramsToStore[525] = new SqlParameter("@DBRemarks", SqlDbType.VarChar);
            paramsToStore[525].Value = objEmployeeInfo.strDBRemarks;
            paramsToStore[525].Size = 500;

            paramsToStore[526] = new SqlParameter("@DrugStatus", SqlDbType.VarChar);
            paramsToStore[526].Value = objEmployeeInfo.strDrugStatus;
            paramsToStore[526].Size = 50;


            paramsToStore[527] = new SqlParameter("@DrugRemarks", SqlDbType.VarChar);
            paramsToStore[527].Value = objEmployeeInfo.strDrugRemarks;
            paramsToStore[527].Size = 500;

            //

            paramsToStore[528] = new SqlParameter("@IDStatus1", SqlDbType.VarChar);
            paramsToStore[528].Value = objEmployeeInfo.strIDStatus1;
            paramsToStore[528].Size = 50;

            paramsToStore[529] = new SqlParameter("@IDStatus2", SqlDbType.VarChar);
            paramsToStore[529].Value = objEmployeeInfo.strIDStatus2;
            paramsToStore[529].Size = 50;

            paramsToStore[530] = new SqlParameter("@IDStatus3", SqlDbType.VarChar);
            paramsToStore[530].Value = objEmployeeInfo.strIDStatus3;
            paramsToStore[530].Size = 50;

            paramsToStore[531] = new SqlParameter("@IDStatus4", SqlDbType.VarChar);
            paramsToStore[531].Value = objEmployeeInfo.strIDStatus4;
            paramsToStore[531].Size = 50;



            paramsToStore[532] = new SqlParameter("@IDRemarks1", SqlDbType.VarChar);
            paramsToStore[532].Value = objEmployeeInfo.strIDRemarks1;
            paramsToStore[532].Size = 500;

            paramsToStore[533] = new SqlParameter("@IDRemarks2", SqlDbType.VarChar);
            paramsToStore[533].Value = objEmployeeInfo.strIDRemarks2;
            paramsToStore[533].Size = 500;

            paramsToStore[534] = new SqlParameter("@IDRemarks3", SqlDbType.VarChar);
            paramsToStore[534].Value = objEmployeeInfo.strIDRemarks3;
            paramsToStore[534].Size = 500;

            paramsToStore[535] = new SqlParameter("@IDRemarks4", SqlDbType.VarChar);
            paramsToStore[535].Value = objEmployeeInfo.strIDRemarks4;
            paramsToStore[535].Size = 500;

            paramsToStore[536] = new SqlParameter("@EduDateFrm4", SqlDbType.VarChar);
            paramsToStore[536].Value = objEmployeeInfo.strEduDateFrm4;
            paramsToStore[536].Size = 50;


            paramsToStore[537] = new SqlParameter("@EduDateTo8", SqlDbType.VarChar);
            paramsToStore[537].Value = objEmployeeInfo.strEduDateTo8;
            paramsToStore[537].Size = 50;


            paramsToStore[538] = new SqlParameter("@AddRemarks5", SqlDbType.VarChar);
            paramsToStore[538].Value = objEmployeeInfo.strAddRemarks5;
            paramsToStore[538].Size = 500;

            paramsToStore[539] = new SqlParameter("@EduRemarks5", SqlDbType.VarChar);
            paramsToStore[539].Value = objEmployeeInfo.strEduRemarks5;
            paramsToStore[539].Size = 500;

            paramsToStore[540] = new SqlParameter("@RefStatus3", SqlDbType.VarChar);
            paramsToStore[540].Value = objEmployeeInfo.strRefStatus3;
            paramsToStore[540].Size = 50;

            paramsToStore[541] = new SqlParameter("@IdentityCheck2", SqlDbType.VarChar);
            paramsToStore[541].Value = objEmployeeInfo.txtIdentityCheck2;
            paramsToStore[541].Size = 50;

            paramsToStore[542] = new SqlParameter("@IdentityLocation2", SqlDbType.VarChar);
            paramsToStore[542].Value = objEmployeeInfo.txtIdentityLocation2;
            paramsToStore[542].Size = 50;

            paramsToStore[543] = new SqlParameter("@IdentityState2", SqlDbType.VarChar);
            paramsToStore[543].Value = objEmployeeInfo.txtIdentityState2;
            paramsToStore[543].Size = 50;

            paramsToStore[544] = new SqlParameter("@IdentityCheck3", SqlDbType.VarChar);
            paramsToStore[544].Value = objEmployeeInfo.txtIdentityCheck3;
            paramsToStore[544].Size = 50;

            paramsToStore[545] = new SqlParameter("@IdentityLocation3", SqlDbType.VarChar);
            paramsToStore[545].Value = objEmployeeInfo.txtIdentityLocation3;
            paramsToStore[545].Size = 50;

            paramsToStore[546] = new SqlParameter("@IdentityState3", SqlDbType.VarChar);
            paramsToStore[546].Value = objEmployeeInfo.txtIdentityState3;
            paramsToStore[546].Size = 50;

            paramsToStore[547] = new SqlParameter("@IdentityCheck4", SqlDbType.VarChar);
            paramsToStore[547].Value = objEmployeeInfo.txtIdentityCheck4;
            paramsToStore[547].Size = 50;

            paramsToStore[548] = new SqlParameter("@IdentityLocation4", SqlDbType.VarChar);
            paramsToStore[548].Value = objEmployeeInfo.txtIdentityLocation4;
            paramsToStore[548].Size = 50;

            paramsToStore[549] = new SqlParameter("@IdentityState4", SqlDbType.VarChar);
            paramsToStore[549].Value = objEmployeeInfo.txtIdentityState4;
            paramsToStore[549].Size = 50;

            paramsToStore[550] = new SqlParameter("@TATstartDate", SqlDbType.VarChar);
            paramsToStore[550].Value = objEmployeeInfo.strTATStartDate;
            paramsToStore[550].Size = 50;


            //paramsToStore[409] = new SqlParameter("@Req_Edu5", SqlDbType.VarChar);
            //paramsToStore[409].Value = objEmployeeInfo.strRequirement_edu5;
            //paramsToStore[409].Size = 50;

            //paramsToStore[500] = new SqlParameter("@Req_Edu6", SqlDbType.VarChar);
            //paramsToStore[500].Value = objEmployeeInfo.strRequirement_edu6;
            //paramsToStore[500].Size = 50;

            //paramsToStore[501] = new SqlParameter("@Req_Edu7", SqlDbType.VarChar);
            //paramsToStore[501].Value = objEmployeeInfo.strRequirement_edu7;
            //paramsToStore[501].Size = 50;

            //paramsToStore[502] = new SqlParameter("@Req_Edu8", SqlDbType.VarChar);
            //paramsToStore[502].Value = objEmployeeInfo.strRequirement_edu8;
            //paramsToStore[502].Size = 50;



            //------------------------END ------------Criminal




            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "saveEmployeeInfo", paramsToStore));



        }

        public int saveCandidateDetails(EmployeeInfo objEmployeeInfo)
        {

            int i;
            SqlParameter[] paramsToStore = new SqlParameter[59];


            paramsToStore[0] = new SqlParameter("@COE", SqlDbType.VarChar);
            paramsToStore[0].Value = objEmployeeInfo.COE;
            paramsToStore[0].Size = 50;

            paramsToStore[1] = new SqlParameter("@subCategory", SqlDbType.VarChar);
            paramsToStore[1].Value = objEmployeeInfo.strSubCategory;
            paramsToStore[1].Size = 50;

            paramsToStore[58] = new SqlParameter("@EmpIdProvidedByClient", SqlDbType.VarChar);
            paramsToStore[58].Value = objEmployeeInfo.EmpIdProvidedByClient;
            paramsToStore[58].Size = 50;

            paramsToStore[2] = new SqlParameter("@FatherName", SqlDbType.VarChar);
            paramsToStore[2].Value = objEmployeeInfo.FatherName;
            paramsToStore[2].Size = 150;

            paramsToStore[3] = new SqlParameter("@DOB", SqlDbType.VarChar);
            paramsToStore[3].Value = objEmployeeInfo.DOB;
            paramsToStore[3].Size = 50;

            paramsToStore[4] = new SqlParameter("@MiddleName", SqlDbType.VarChar);
            paramsToStore[4].Value = objEmployeeInfo.MiddleName;
            paramsToStore[4].Size = 50;

            paramsToStore[5] = new SqlParameter("@FirstName", SqlDbType.VarChar);
            paramsToStore[5].Value = objEmployeeInfo.FirstName;
            paramsToStore[5].Size = 150;

            paramsToStore[6] = new SqlParameter("@Surname", SqlDbType.VarChar);
            paramsToStore[6].Value = objEmployeeInfo.Surname;
            paramsToStore[6].Size = 50;

            paramsToStore[7] = new SqlParameter("@Mobile", SqlDbType.VarChar);
            paramsToStore[7].Value = objEmployeeInfo.Mobile;
            paramsToStore[7].Size = 50;

            /////////////// Address

            paramsToStore[8] = new SqlParameter("@AddressCheck", SqlDbType.VarChar);
            paramsToStore[8].Value = objEmployeeInfo.AddressCheck;
            paramsToStore[8].Size = 50;

            paramsToStore[9] = new SqlParameter("@Address1CurrentAddress", SqlDbType.VarChar);
            paramsToStore[9].Value = objEmployeeInfo.CurrentAddress;
            paramsToStore[9].Size = 500;

            paramsToStore[10] = new SqlParameter("@Curr_State", SqlDbType.VarChar);
            paramsToStore[10].Value = objEmployeeInfo.Curr_State;
            paramsToStore[10].Size = 50;

            paramsToStore[11] = new SqlParameter("@Curr_City", SqlDbType.VarChar);
            paramsToStore[11].Value = objEmployeeInfo.Curr_City;
            paramsToStore[11].Size = 50;

            paramsToStore[12] = new SqlParameter("@Curr_PhoneNo", SqlDbType.VarChar);
            paramsToStore[12].Value = objEmployeeInfo.Curr_PhoneNo;
            paramsToStore[12].Size = 50;

            paramsToStore[13] = new SqlParameter("@AddDateFrm1", SqlDbType.VarChar);
            paramsToStore[13].Value = objEmployeeInfo.strAddDateFrm1;
            paramsToStore[13].Size = 50;

            paramsToStore[14] = new SqlParameter("@AddDateTo1", SqlDbType.VarChar);
            paramsToStore[14].Value = objEmployeeInfo.strAddDateTo1;
            paramsToStore[14].Size = 50;

            paramsToStore[57] = new SqlParameter("@AddLandMark", SqlDbType.VarChar);
            paramsToStore[57].Value = objEmployeeInfo.strPer_Landmark;
            paramsToStore[57].Size = 100;


            /////////////////////////////////////////////////// Criminal

            // Criminal 1
            paramsToStore[15] = new SqlParameter("@CriminalCheck", SqlDbType.VarChar);
            paramsToStore[15].Value = objEmployeeInfo.CriminalCheck;
            paramsToStore[15].Size = 50;

            paramsToStore[16] = new SqlParameter("@Criminal1Address", SqlDbType.VarChar);
            paramsToStore[16].Value = objEmployeeInfo.Criminal1Address;
            paramsToStore[16].Size = 300;

            paramsToStore[17] = new SqlParameter("@Criminal1Location", SqlDbType.VarChar);
            paramsToStore[17].Value = objEmployeeInfo.txtCriminal1Location;
            paramsToStore[17].Size = 50;

            paramsToStore[18] = new SqlParameter("@Criminal1State", SqlDbType.VarChar);
            paramsToStore[18].Value = objEmployeeInfo.Criminal1State;
            paramsToStore[18].Size = 50;

            paramsToStore[19] = new SqlParameter("@CriDateFrm1", SqlDbType.VarChar);
            paramsToStore[19].Value = objEmployeeInfo.strCriDateFrm1;
            paramsToStore[19].Size = 50;

            paramsToStore[20] = new SqlParameter("@CriDateTo1", SqlDbType.VarChar);
            paramsToStore[20].Value = objEmployeeInfo.strCriDateTo1;
            paramsToStore[20].Size = 50;




            ///////////////////////////////////////////////////// EMPLOYMENT

            paramsToStore[21] = new SqlParameter("@NoOfComp", SqlDbType.VarChar);
            paramsToStore[21].Value = objEmployeeInfo.NoOfComp;
            paramsToStore[21].Size = 50;

            // Employment 1

            paramsToStore[22] = new SqlParameter("@EmpHis1_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[22].Value = objEmployeeInfo.EmpHis1_CompnayNameandLocation;
            paramsToStore[22].Size = 150;

            paramsToStore[23] = new SqlParameter("@txtEmployemenmt1City", SqlDbType.VarChar);
            paramsToStore[23].Value = objEmployeeInfo.txtEmployemenmt1City;
            paramsToStore[23].Size = 50;

            paramsToStore[24] = new SqlParameter("@txtEmployemenmt1State", SqlDbType.VarChar);
            paramsToStore[24].Value = objEmployeeInfo.txtEmployemenmt1State;
            paramsToStore[24].Size = 50;

            paramsToStore[25] = new SqlParameter("@EmpHis1_PeriodofEmployment", SqlDbType.VarChar);
            paramsToStore[25].Value = objEmployeeInfo.EmpHis1_PeriodofEmployment;
            paramsToStore[25].Size = 50;

            paramsToStore[26] = new SqlParameter("@datetoemphis1", SqlDbType.VarChar);
            paramsToStore[26].Value = objEmployeeInfo.datetoemphis1;
            paramsToStore[26].Size = 20;

            paramsToStore[27] = new SqlParameter("@EmpHis1_LastPositionHeldnDepartmentName", SqlDbType.VarChar);
            paramsToStore[27].Value = objEmployeeInfo.EmpHis1_LastPositionHeldnDepartmentName;
            paramsToStore[27].Size = 150;

            paramsToStore[28] = new SqlParameter("@EmpHis1_EmployeeCode", SqlDbType.VarChar);
            paramsToStore[28].Value = objEmployeeInfo.EmpHis1_EmployeeCode;
            paramsToStore[28].Size = 50;

            paramsToStore[29] = new SqlParameter("@EmpHis1_RemunerationOrSalary", SqlDbType.VarChar);
            paramsToStore[29].Value = objEmployeeInfo.EmpHis1_RemunerationOrSalary;
            paramsToStore[29].Size = 50;

            paramsToStore[30] = new SqlParameter("@EmpHis1RLvl1_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[30].Value = objEmployeeInfo.EmpHis1RLvl1_NameDesignatinOfSupervisor;
            paramsToStore[30].Size = 150;

            paramsToStore[31] = new SqlParameter("@EmpHis1RLvl2_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[31].Value = objEmployeeInfo.EmpHis1RLvl2_TelepnoneNo;
            paramsToStore[31].Size = 50;

            paramsToStore[32] = new SqlParameter("@EmpHis1_ReasonOfLeaving", SqlDbType.VarChar);
            paramsToStore[32].Value = objEmployeeInfo.EmpHis1_ReasonOfLeaving;
            paramsToStore[32].Size = 50;

            paramsToStore[33] = new SqlParameter("@EmpHis1RLvl1_EmailId", SqlDbType.VarChar);
            paramsToStore[33].Value = objEmployeeInfo.EmpHis1RLvl1_EmailId;
            paramsToStore[33].Size = 150;

            paramsToStore[34] = new SqlParameter("@EmpHis1RLvl1_MobileNo", SqlDbType.VarChar);
            paramsToStore[34].Value = objEmployeeInfo.EmpHis1RLvl1_MobileNo;
            paramsToStore[34].Size = 50;


            // Employment 2

            paramsToStore[35] = new SqlParameter("@EmpHis2_CompnayNameandLocation", SqlDbType.VarChar);
            paramsToStore[35].Value = objEmployeeInfo.EmpHis2_CompnayNameandLocation;
            paramsToStore[35].Size = 150;

            paramsToStore[36] = new SqlParameter("@txtEmployemenmt2City", SqlDbType.VarChar);
            paramsToStore[36].Value = objEmployeeInfo.txtEmployemenmt2City;
            paramsToStore[36].Size = 50;

            paramsToStore[37] = new SqlParameter("@txtEmployemenmt2State", SqlDbType.VarChar);
            paramsToStore[37].Value = objEmployeeInfo.txtEmployemenmt2State;
            paramsToStore[37].Size = 50;

            paramsToStore[38] = new SqlParameter("@EmpHis2_PeriodofEmployment", SqlDbType.VarChar);
            paramsToStore[38].Value = objEmployeeInfo.EmpHis2_PeriodofEmployment;
            paramsToStore[38].Size = 50;

            paramsToStore[39] = new SqlParameter("@datetoemphis2", SqlDbType.VarChar);
            paramsToStore[39].Value = objEmployeeInfo.datetoemphis2;
            paramsToStore[39].Size = 20;

            paramsToStore[40] = new SqlParameter("@EmpHis2_LastPositionHeldnDepartmentName", SqlDbType.VarChar);
            paramsToStore[40].Value = objEmployeeInfo.EmpHis2_LastPositionHeldnDepartmentName;
            paramsToStore[40].Size = 150;

            paramsToStore[41] = new SqlParameter("@EmpHis2_EmployeeCode", SqlDbType.VarChar);
            paramsToStore[41].Value = objEmployeeInfo.EmpHis2_EmployeeCode;
            paramsToStore[41].Size = 50;

            paramsToStore[42] = new SqlParameter("@EmpHis2_RemunerationOrSalary", SqlDbType.VarChar);
            paramsToStore[42].Value = objEmployeeInfo.EmpHis2_RemunerationOrSalary;
            paramsToStore[42].Size = 50;

            paramsToStore[43] = new SqlParameter("@EmpHis2RLvl1_NameDesignatinOfSupervisor", SqlDbType.VarChar);
            paramsToStore[43].Value = objEmployeeInfo.EmpHis2RLvl1_NameDesignatinOfSupervisor;
            paramsToStore[43].Size = 150;



            paramsToStore[44] = new SqlParameter("@EmpHis2RLvl2_TelepnoneNo", SqlDbType.VarChar);
            paramsToStore[44].Value = objEmployeeInfo.EmpHis2RLvl2_TelepnoneNo;
            paramsToStore[44].Size = 50;

            paramsToStore[45] = new SqlParameter("@EmpHis2_ReasonOfLeaving", SqlDbType.VarChar);
            paramsToStore[45].Value = objEmployeeInfo.EmpHis2_ReasonOfLeaving;
            paramsToStore[45].Size = 50;

            paramsToStore[46] = new SqlParameter("@EmpHis2RLvl1_EmailId", SqlDbType.VarChar);
            paramsToStore[46].Value = objEmployeeInfo.EmpHis2RLvl1_EmailId;
            paramsToStore[46].Size = 150;

            paramsToStore[47] = new SqlParameter("@EmpHis2RLvl1_MobileNo", SqlDbType.VarChar);
            paramsToStore[47].Value = objEmployeeInfo.EmpHis2RLvl1_MobileNo;
            paramsToStore[47].Size = 50;


            ///////////////////////////////////// EDUCATION

            // Education 1

            paramsToStore[48] = new SqlParameter("@EducationList", SqlDbType.VarChar);
            paramsToStore[48].Value = objEmployeeInfo.EducationList;
            paramsToStore[48].Size = 50;

            paramsToStore[49] = new SqlParameter("@Edu1_CollegeName", SqlDbType.VarChar);
            paramsToStore[49].Value = objEmployeeInfo.Edu1_CollegeName;
            paramsToStore[49].Size = 250;

            paramsToStore[50] = new SqlParameter("@Edu1_Address", SqlDbType.VarChar);
            paramsToStore[50].Value = objEmployeeInfo.Edu1_Address;
            paramsToStore[50].Size = 500;

            paramsToStore[51] = new SqlParameter("@Edu1_UniversityName", SqlDbType.VarChar);
            paramsToStore[51].Value = objEmployeeInfo.Edu1_UniversityName;
            paramsToStore[51].Size = 150;

            paramsToStore[52] = new SqlParameter("@EmpHis1_IncaseOfGap", SqlDbType.VarChar);
            paramsToStore[52].Value = objEmployeeInfo.EmpHis1_IncaseOfGap;
            paramsToStore[52].Size = 50;

            paramsToStore[53] = new SqlParameter("@Edu1_EducationalQualification", SqlDbType.VarChar);
            paramsToStore[53].Value = objEmployeeInfo.Edu1_EducationalQualification;
            paramsToStore[53].Size = 100;

            paramsToStore[54] = new SqlParameter("@Edu1_RollNo", SqlDbType.VarChar);
            paramsToStore[54].Value = objEmployeeInfo.Edu1_RollNo;
            paramsToStore[54].Size = 50;

            paramsToStore[55] = new SqlParameter("@Edu1_YearOfPassing", SqlDbType.VarChar);
            paramsToStore[55].Value = objEmployeeInfo.Edu1_YearOfPassing;
            paramsToStore[55].Size = 50;

            paramsToStore[56] = new SqlParameter("@txtEducation1State", SqlDbType.VarChar);
            paramsToStore[56].Value = objEmployeeInfo.txtEducation1State;
            paramsToStore[56].Size = 50;









            return i = Convert.ToInt32(SQLDataAccess.ExecuteScalar(SQLDataAccess.ConnectionString, CommandType.StoredProcedure, "saveCandidateDetails", paramsToStore));



        }



    }




}
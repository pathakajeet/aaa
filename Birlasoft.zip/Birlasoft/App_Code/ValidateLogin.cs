﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Globalization;
using DataAccess;
using EmployeeInfonamespace;
using SendMails;
using IISERVZCLASS;
using classgen1;
using Casestatus;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Net;

/// <summary>
/// Summary description for ValidateLogin
/// </summary>
public class ValidateLogin
{

    private string cnn;
    public ValidateLogin()
    {
        cnn = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
    }




    /// <summary>
    /// 
    /// </summary>
    /// <returns>
    ///  userID,userName,usertype from LoginUsers
    /// </returns>
    public DataTable ValidateUserLogin(String UserName, String Password)
    {
        SqlConnection sqlcon = new SqlConnection(cnn);
        SqlDataAdapter sda = new SqlDataAdapter();
        DataTable dt = new DataTable();
        try
        {
            sqlcon.Open();
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = sqlcon;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ValidateLogin";
                cmd.Parameters.AddWithValue("@userName", UserName);
                cmd.Parameters.AddWithValue("@Password", Password);
                sda.SelectCommand = cmd;
                sda.Fill(dt);
                sqlcon.Close();
            }



        }
        catch (SqlException se)
        {
            //DBErLog.DbServLog(se, se.ToString());
        }
        finally
        {
            sqlcon.Close();
        }
        return dt;



    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="UserName"></param>
    /// <param name="Password"></param>
    /// <returns>
    /// SNo,CandidateName,MiddleName,LastName,UserType,password,refid,ClosedStatus,MobileNo,
    /// dateofjoining,placeofjoining,DateofBirth,FatherName,ActiveStatus,category
    /// </returns>
    public DataTable ValidateCandidateLogin(String UserName, String Password)
    {
        SqlConnection sqlcon = new SqlConnection(cnn);
        SqlDataAdapter sda = new SqlDataAdapter();
        DataTable dt = new DataTable();
        try
        {
            sqlcon.Open();
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = sqlcon;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ValidateCandidateLogin";
                cmd.Parameters.AddWithValue("@userName", UserName);
                cmd.Parameters.AddWithValue("@Password", Password);
                sda.SelectCommand = cmd;
                sda.Fill(dt);
                sqlcon.Close();
            }



        }
        catch (SqlException se)
        {
            //DBErLog.DbServLog(se, se.ToString());
        }
        finally
        {
            sqlcon.Close();
        }
        return dt;



    }
    ///string RefID = HttpUtility.UrlEncode(Encrypt(txtdbrpt.Text.Trim()));

    public string Encrypt(string clearText)
    {
        string EncryptionKey = "MAKV2SPBNI99212";
        byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(clearBytes, 0, clearBytes.Length);
                    cs.Close();
                }
                clearText = Convert.ToBase64String(ms.ToArray());
            }
        }
        return HttpUtility.UrlEncode(clearText);
    }
    public string Decrypt(string cipherText)
    {
        string EncryptionKey = "MAKV2SPBNI99212";
        cipherText = cipherText.Replace(" ", "+");
        byte[] cipherBytes = Convert.FromBase64String(cipherText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(cipherBytes, 0, cipherBytes.Length);
                    cs.Close();
                }
                cipherText = Encoding.Unicode.GetString(ms.ToArray());
            }
        }
        return cipherText;
    }


    
    public DataTable ShowLoa(String Id)
    {
         SqlConnection sqlcon = new SqlConnection(cnn);
        SqlDataAdapter sda = new SqlDataAdapter();
        DataTable dt = new DataTable();
        try
        {
            sqlcon.Open();
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = sqlcon;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ShowDigitalLoa";
                cmd.Parameters.AddWithValue("@id", Id);
            
                sda.SelectCommand = cmd;
                sda.Fill(dt);
                sqlcon.Close();
            }



        }
        catch (SqlException se)
        {
            //DBErLog.DbServLog(se, se.ToString());
        }
        finally
        {
            sqlcon.Close();
        }
        return dt;
    }

}
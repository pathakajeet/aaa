using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for CMSAdmin
/// </summary>
public class CMSAdmin
{
    public CMSAdmin()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    #region 
        public static void UpdateMenu(Int64 MenuID, string Text, string AlternateText, string TargetURL, string TargetWindow, Int64 ParentMenuID, string UpdatedBy)
        {
            using (SqlConnection Cn = new SqlConnection())
            {
                Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                SqlCommand SqlCmd = Cn.CreateCommand();
                SqlParameter SqlParam;
                SqlCmd.CommandText = "spUpdateMenu";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParam = new SqlParameter("@MenuID", SqlDbType.BigInt);
                SqlParam.Value = MenuID;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@Text", SqlDbType.NVarChar, 50);
                SqlParam.Value = Text;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@AlternateText", SqlDbType.NVarChar, 50);
                SqlParam.Value = AlternateText;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@TargetURL", SqlDbType.Text);
                SqlParam.Value = TargetURL;
                SqlCmd.Parameters.Add(SqlParam);


                SqlParam = new SqlParameter("@TargetWindow", SqlDbType.NVarChar, 10);
                SqlParam.Value = TargetWindow;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@ParentMenuID", SqlDbType.BigInt);
                SqlParam.Value = ParentMenuID;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar, 300);
                SqlParam.Value = UpdatedBy;
                SqlCmd.Parameters.Add(SqlParam);

                Cn.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCmd.Dispose();
                Cn.Close();
                Cn.Dispose();
            }
        }

        public static DataTable GetMenu(Int64 MenuID)
        {
            using (SqlConnection Cn = new SqlConnection())
            {
                Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                SqlCommand SqlCmd = Cn.CreateCommand();
                SqlParameter SqlParam;
                SqlCmd.CommandText = "spGetMenu";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParam = new SqlParameter("@MenuID", SqlDbType.BigInt);
                SqlParam.Value = MenuID;
                SqlCmd.Parameters.Add(SqlParam);

                DataTable Dt = new DataTable();

                Cn.Open();
                Dt.Load(SqlCmd.ExecuteReader());
                SqlCmd.Dispose();
                Cn.Close();
                Cn.Dispose();

                return Dt;
            }
        }

        public static void AddMenu(string Text, string AlternateText, string TargetURL, string TargetWindow, Int64 ParentMenuID)
        {
            using (SqlConnection Cn = new SqlConnection())
            {
                Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                SqlCommand SqlCmd = Cn.CreateCommand();
                SqlParameter SqlParam;
                SqlCmd.CommandText = "spAddMenu";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParam = new SqlParameter("@Text", SqlDbType.NVarChar, 50);
                SqlParam.Value = Text;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@AlternateText", SqlDbType.NVarChar, 50);
                SqlParam.Value = AlternateText;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@TargetURL", SqlDbType.Text);
                SqlParam.Value = TargetURL;
                SqlCmd.Parameters.Add(SqlParam);


                SqlParam = new SqlParameter("@TargetWindow", SqlDbType.NVarChar, 10);
                SqlParam.Value = TargetWindow;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@ParentMenuID", SqlDbType.BigInt);
                SqlParam.Value = ParentMenuID;
                SqlCmd.Parameters.Add(SqlParam);

                Cn.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCmd.Dispose();
                Cn.Close();
                Cn.Dispose();
            }
        }

        public static DataTable GetSpotLightContent()
        {
            using (SqlConnection Cn = new SqlConnection())
            {
                Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                SqlCommand SqlCmd = Cn.CreateCommand();
                SqlCmd.CommandText = "spGetSpotLightContent";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                DataTable Dt = new DataTable();

                Cn.Open();
                Dt.Load(SqlCmd.ExecuteReader());
                SqlCmd.Dispose();
                Cn.Close();
                Cn.Dispose();

                return Dt;
            }
        }

    //public static DataTable BindGridAll()
    //{
    //    using (SqlConnection Cn = new SqlConnection())
    //    {
    //        Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
    //        SqlCommand SqlCmd = Cn.CreateCommand();
    //        SqlCmd.CommandText = "fillReport";
    //        SqlCmd.CommandType = CommandType.StoredProcedure;

    //        DataTable Dt = new DataTable();

    //        Cn.Open();
    //        Dt.Load(SqlCmd.ExecuteReader());
    //        SqlCmd.Dispose();
    //        Cn.Close();
    //        Cn.Dispose();

    //        return Dt;
    //    }
    //}

        public static void InsertUpdateSpotlight(Int64 ID, string Content, string UpdatedBy)
        {
            using (SqlConnection Cn = new SqlConnection())
            {
                Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                SqlCommand SqlCmd = Cn.CreateCommand();
                SqlParameter SqlParam;
                SqlCmd.CommandText = "spInsertUpdateSpotlight";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParam = new SqlParameter("@ID", SqlDbType.BigInt);
                SqlParam.Value = ID;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@Content", SqlDbType.NText);
                SqlParam.Value = Content;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar, 300);
                SqlParam.Value = UpdatedBy;
                SqlCmd.Parameters.Add(SqlParam);

                Cn.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCmd.Dispose();
                Cn.Close();
                Cn.Dispose();
            }
        }

        public static void AddEditCheckList(Int64 PageID, string Content, string UpdatedBy)
        {
            using (SqlConnection Cn = new SqlConnection())
            {
                Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                SqlCommand SqlCmd = Cn.CreateCommand();
                SqlParameter SqlParam;
                SqlCmd.CommandText = "spAddEditCheckList";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParam = new SqlParameter("@PageID", SqlDbType.BigInt);
                SqlParam.Value = PageID;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@Content", SqlDbType.NText);
                SqlParam.Value = Content;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar, 300);
                SqlParam.Value = UpdatedBy;
                SqlCmd.Parameters.Add(SqlParam);

                Cn.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCmd.Dispose();
                Cn.Close();
                Cn.Dispose();
            }
        }

        public static DataTable GetCheckList(Int64 PageID)
        {
            using (SqlConnection Cn = new SqlConnection())
            {
                Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                SqlCommand SqlCmd = Cn.CreateCommand();
                SqlParameter SqlParam;
                SqlCmd.CommandText = "spGetCheckList";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParam = new SqlParameter("@PageID", SqlDbType.BigInt);
                SqlParam.Value = PageID;
                SqlCmd.Parameters.Add(SqlParam);

                DataTable Dt = new DataTable();

                Cn.Open();
                Dt.Load(SqlCmd.ExecuteReader());
                SqlCmd.Dispose();
                Cn.Close();
                Cn.Dispose();

                return Dt;
            }
        }

        public static void AddNewFAQ(Int64 PageID, string Question, string Answer, Int64 TypeID)
        {
            using (SqlConnection Cn = new SqlConnection())
            {
                Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                SqlCommand SqlCmd = Cn.CreateCommand();
                SqlParameter SqlParam;
                SqlCmd.CommandText = "spAddNewFAQ";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParam = new SqlParameter("@PageID", SqlDbType.BigInt);
                SqlParam.Value = PageID;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@Question", SqlDbType.NVarChar, 4000);
                SqlParam.Value = Question;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@Answer", SqlDbType.NText);
                SqlParam.Value = Answer;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@TypeID", SqlDbType.BigInt);
                SqlParam.Value = TypeID;
                SqlCmd.Parameters.Add(SqlParam);

                Cn.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCmd.Dispose();
                Cn.Close();
                Cn.Dispose();
            }
        }

        public static void UpdateFAQ(Int64 ID, string Question, string Answer, string UpdatedBy)
        {
            using (SqlConnection Cn = new SqlConnection())
            {
                Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                SqlCommand SqlCmd = Cn.CreateCommand();
                SqlParameter SqlParam;
                SqlCmd.CommandText = "spUpdateFAQ";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParam = new SqlParameter("@ID", SqlDbType.BigInt);
                SqlParam.Value = ID;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@Question", SqlDbType.NVarChar, 4000);
                SqlParam.Value = Question;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@Answer", SqlDbType.NText);
                SqlParam.Value = Answer;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar, 300);
                SqlParam.Value = UpdatedBy;
                SqlCmd.Parameters.Add(SqlParam);

                Cn.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCmd.Dispose();
                Cn.Close();
                Cn.Dispose();
            }
        }

        public static DataTable GetFAQ(Int64 ID)
        {
            using (SqlConnection Cn = new SqlConnection())
            {
                Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                SqlCommand SqlCmd = Cn.CreateCommand();
                SqlParameter SqlParam;
                SqlCmd.CommandText = "spGetFAQ";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParam = new SqlParameter("@ID", SqlDbType.BigInt);
                SqlParam.Value = ID;
                SqlCmd.Parameters.Add(SqlParam);

                DataTable Dt = new DataTable();

                Cn.Open();
                Dt.Load(SqlCmd.ExecuteReader());
                SqlCmd.Dispose();
                Cn.Close();
                Cn.Dispose();

                return Dt;
            }
        }

        public static string GetPageName(Int64 ID)
        {
            using (SqlConnection Cn = new SqlConnection())
            {
                Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                SqlCommand SqlCmd = Cn.CreateCommand();
                SqlParameter SqlParam;
                SqlCmd.CommandText = "spGetPageName";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParam = new SqlParameter("@ID", SqlDbType.BigInt);
                SqlParam.Value = ID;
                SqlCmd.Parameters.Add(SqlParam);

                string StrPageName = "";
                Cn.Open();
                StrPageName = SqlCmd.ExecuteScalar().ToString();
                SqlCmd.Dispose();
                Cn.Close();
                Cn.Dispose();

                return StrPageName;
            }
        }


        public static DataTable GetPage(Int64 ID)
        {
            using (SqlConnection Cn = new SqlConnection())
            {
                Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                SqlCommand SqlCmd = Cn.CreateCommand();
                SqlParameter SqlParam;
                SqlCmd.CommandText = "spGetPage";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParam = new SqlParameter("@ID", SqlDbType.BigInt);
                SqlParam.Value = ID;
                SqlCmd.Parameters.Add(SqlParam);

                DataTable Dt = new DataTable();

                Cn.Open();
                Dt.Load(SqlCmd.ExecuteReader());
                SqlCmd.Dispose();
                Cn.Close();
                Cn.Dispose();

                return Dt;
            }
        }

        public static void AddNewPage(string Name, Int64 Theme, string Content, string MetaKeywords, string MetaDesc, string PageTitle, string ImageURL, Boolean BeforeFAQ, Boolean AfterFAQ, Boolean @CheckList)
        {
            using (SqlConnection Cn = new SqlConnection())
            {
                Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                SqlCommand SqlCmd = Cn.CreateCommand();
                SqlParameter SqlParam;
                SqlCmd.CommandText = "spAddNewPage";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParam = new SqlParameter("@Name", SqlDbType.NVarChar, 300);
                SqlParam.Value = Name;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@theme", SqlDbType.BigInt);
                SqlParam.Value = Theme;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@Content", SqlDbType.Text);
                SqlParam.Value = Content;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@MetaKeywords", SqlDbType.NVarChar, 500);
                SqlParam.Value = MetaKeywords;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@MetaDesc", SqlDbType.NVarChar, 500);
                SqlParam.Value = MetaDesc;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@PageTitle", SqlDbType.NVarChar, 500);
                SqlParam.Value = PageTitle;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@ImageURL", SqlDbType.Text);
                SqlParam.Value = ImageURL;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@BeforeFAQ", SqlDbType.Bit);
                SqlParam.Value = BeforeFAQ;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@AfterFAQ", SqlDbType.Bit);
                SqlParam.Value = AfterFAQ;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@CheckList", SqlDbType.Bit);
                SqlParam.Value = CheckList;
                SqlCmd.Parameters.Add(SqlParam);

                Cn.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCmd.Dispose();
                Cn.Close();
                Cn.Dispose();
            }
        }

        public static void UpdatePageContent(Int64 ID, string Name, Int64 Theme, string Content, string MetaKeywords, string MetaDesc, string PageTitle, string ImageURL, Boolean BeforeFAQ, Boolean AfterFAQ, Boolean @CheckList, string UpdatedBy)
        {
            using (SqlConnection Cn = new SqlConnection())
            {
                Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                SqlCommand SqlCmd = Cn.CreateCommand();
                SqlParameter SqlParam;
                SqlCmd.CommandText = "spUpdatePageContent";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParam = new SqlParameter("@ID", SqlDbType.BigInt);
                SqlParam.Value = ID;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@Name", SqlDbType.NVarChar, 300);
                SqlParam.Value = Name;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@theme", SqlDbType.BigInt);
                SqlParam.Value = Theme;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@Content", SqlDbType.Text);
                SqlParam.Value = Content;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@MetaKeywords", SqlDbType.NVarChar, 500);
                SqlParam.Value = MetaKeywords;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@MetaDesc", SqlDbType.NVarChar, 500);
                SqlParam.Value = MetaDesc;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@PageTitle", SqlDbType.NVarChar, 500);
                SqlParam.Value = PageTitle;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@ImageURL", SqlDbType.Text);
                SqlParam.Value = ImageURL;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@BeforeFAQ", SqlDbType.Bit);
                SqlParam.Value = BeforeFAQ;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@AfterFAQ", SqlDbType.Bit);
                SqlParam.Value = AfterFAQ;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@CheckList", SqlDbType.Bit);
                SqlParam.Value = CheckList;
                SqlCmd.Parameters.Add(SqlParam);

                SqlParam = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar, 300);
                SqlParam.Value = UpdatedBy;
                SqlCmd.Parameters.Add(SqlParam);

                Cn.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCmd.Dispose();
                Cn.Close();
                Cn.Dispose();
            }
        }
    #endregion

    #region 
        #region Insert
            public static void InsertVideoUrl(string Title, string VideoUrl, string LastUpdatedBy)
            {
                using (SqlConnection Cn = new SqlConnection())
                {
                    Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                    SqlCommand SqlCmd = Cn.CreateCommand();
                    SqlCmd.CommandText = "spInsertVideoUrl";
                    SqlCmd.CommandType = CommandType.StoredProcedure;

                    SqlParameter SqlParam;

                    SqlParam = new SqlParameter("@Title", SqlDbType.NVarChar, 50);			//@Title nvarchar(50),
                    SqlParam.Value = Title;
                    SqlCmd.Parameters.Add(SqlParam);

                    SqlParam = new SqlParameter("@VideoURL", SqlDbType.Text);		        //@VideoURL text,
                    SqlParam.Value = VideoUrl;
                    SqlCmd.Parameters.Add(SqlParam);

                    SqlParam = new SqlParameter("@LastUpdatedBy", SqlDbType.NVarChar, 300);	   //@LastUpdatedBy nvarchar(300)
                    SqlParam.Value = LastUpdatedBy;
                    SqlCmd.Parameters.Add(SqlParam);

                    Cn.Open();
                    SqlCmd.ExecuteNonQuery();
                    SqlCmd.Dispose();
                    Cn.Close();
                    Cn.Dispose();
                }
            }

            public static void InsertUser(string UserName, string Password, string UserType )//, string LastUpdatedBy)
            {
                using (SqlConnection Cn = new SqlConnection())
                {
                    Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                    SqlCommand SqlCmd = Cn.CreateCommand();
                    SqlCmd.CommandText = "spInsertUser";
                    SqlCmd.CommandType = CommandType.StoredProcedure;

                    SqlParameter SqlParam;

                    SqlParam = new SqlParameter("@UserName", SqlDbType.NVarChar, 300);			//@UserName nvarchar(300),
                    SqlParam.Value = UserName;
                    SqlCmd.Parameters.Add(SqlParam);

                    SqlParam = new SqlParameter("@Password", SqlDbType.NVarChar, 100);			//@Password nvarchar(100),
                    SqlParam.Value = Password;
                    SqlCmd.Parameters.Add(SqlParam);

                    SqlParam = new SqlParameter("@UserType", SqlDbType.NVarChar, 100);			//@IsAdmin bit,
                    SqlParam.Value = UserType;
                    SqlCmd.Parameters.Add(SqlParam);

                    //SqlParam = new SqlParameter("@LastUpdatedBy", SqlDbType.NVarChar, 300);		//@LastUpdatedBy nvarchar(300)
                    //SqlParam.Value = LastUpdatedBy;
                    //SqlCmd.Parameters.Add(SqlParam);

                    //SqlParam = new SqlParameter("@IsDeo", SqlDbType.Bit);			//@IsDeo bit,
                    //SqlParam.Value = IsDeo;
                    //SqlCmd.Parameters.Add(SqlParam);

                    Cn.Open();
                    SqlCmd.ExecuteNonQuery();
                    SqlCmd.Dispose();
                    Cn.Close();
                    Cn.Dispose();
                }
            }
        #endregion

        #region Get
        public static DataTable GetMetaInformation(Int64 ID)
        {
            using (SqlConnection Cn = new SqlConnection())
            {
                Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                SqlCommand SqlCmd = Cn.CreateCommand();
                SqlCmd.CommandText = "spGetMetaInformation";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter SqlParam = new SqlParameter("@ID", SqlDbType.BigInt);		//@ID numeric(18,0)
                SqlParam.Value = ID;
                SqlCmd.Parameters.Add(SqlParam);

                DataTable Dt = new DataTable();

                Cn.Open();
                Dt.Load(SqlCmd.ExecuteReader());
                SqlCmd.Dispose();
                Cn.Close();
                Cn.Dispose();

                return Dt;
            }
        }
    #endregion

        #region Update
            public static void UpdateMetaInformation(Int64 ID, string title, string Description, string Keywords, string LastUpdatedBy)
            {
                using (SqlConnection Cn = new SqlConnection())
                {
                    Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                    SqlCommand SqlCmd = Cn.CreateCommand();
                    SqlCmd.CommandText = "spUpdateMetaInformation";
                    SqlCmd.CommandType = CommandType.StoredProcedure;

                    SqlParameter SqlParam;

                    SqlParam = new SqlParameter("@ID", SqlDbType.BigInt);				//@ID numeric(18, 0),
                    SqlParam.Value = ID;
                    SqlCmd.Parameters.Add(SqlParam);

                    SqlParam = new SqlParameter("@title", SqlDbType.NVarChar, 500);			//@title nvarchar(500),
                    SqlParam.Value = title;
                    SqlCmd.Parameters.Add(SqlParam);

                    SqlParam = new SqlParameter("@Description", SqlDbType.NVarChar, 2000);	//@Description	nvarchar(2000),
                    SqlParam.Value = Description;
                    SqlCmd.Parameters.Add(SqlParam);

                    SqlParam = new SqlParameter("@Keywords", SqlDbType.NVarChar, 2000);		//@Keywords nvarchar(2000),
                    SqlParam.Value = Keywords;
                    SqlCmd.Parameters.Add(SqlParam);

                    SqlParam = new SqlParameter("@LastUpdatedBy", SqlDbType.NVarChar, 300);	//@LastUpdatedBy nvarchar(300)
                    SqlParam.Value = LastUpdatedBy;
                    SqlCmd.Parameters.Add(SqlParam);

                    Cn.Open();
                    SqlCmd.ExecuteNonQuery();
                    SqlCmd.Dispose();
                    Cn.Close();
                    Cn.Dispose();
                }
            }

    public static void UpdateAdminStatus(string UserID, bool IsAdmin, string UserType)
            {
                using (SqlConnection Cn = new SqlConnection())
                {
                    Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                    SqlCommand SqlCmd = Cn.CreateCommand();
                    SqlCmd.CommandText = "spUpdateAdminStatus";
                    SqlCmd.CommandType = CommandType.StoredProcedure;

                    SqlParameter SqlParam;

                    SqlParam = new SqlParameter("@UserID", SqlDbType.NVarChar, 256);			//@UserID nvarchar(256),	
                    SqlParam.Value = UserID;
                    SqlCmd.Parameters.Add(SqlParam);

                    SqlParam = new SqlParameter("@IsAdmin", SqlDbType.Bit);		//@IsAdmin bit,
                    SqlParam.Value = IsAdmin;
                    SqlCmd.Parameters.Add (SqlParam);

                    SqlParam = new SqlParameter("@UserType", SqlDbType.NVarChar, 300);	//@LastUpdatedBy nvarchar(300)
                    SqlParam.Value = UserType;
                    SqlCmd.Parameters.Add(SqlParam);

                    Cn.Open();
                    SqlCmd.ExecuteNonQuery();
                    SqlCmd.Dispose();
                    Cn.Close();
                    Cn.Dispose();
                }
            }

            public static void UpdatePassword(string UserID, string Password, string LastUpdatedBy)
            {
                using (SqlConnection Cn = new SqlConnection())
                {
                    Cn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MYConnectionString"].ToString();
                    SqlCommand SqlCmd = Cn.CreateCommand();
                    SqlCmd.CommandText = "spUpdatePassword";
                    SqlCmd.CommandType = CommandType.StoredProcedure;

                    SqlParameter SqlParam;

                    SqlParam = new SqlParameter("@UserID", SqlDbType.NVarChar, 256);			//@UserID nvarchar(256),	
                    SqlParam.Value = UserID;
                    SqlCmd.Parameters.Add(SqlParam);

                    SqlParam = new SqlParameter("@Password", SqlDbType.NVarChar, 100);		//@Password nvarchar(100),
                    SqlParam.Value = Password;
                    SqlCmd.Parameters.Add(SqlParam);

                    SqlParam = new SqlParameter("@LastUpdatedBy", SqlDbType.NVarChar, 300);	//@LastUpdatedBy nvarchar(300)
                    SqlParam.Value = LastUpdatedBy;
                    SqlCmd.Parameters.Add(SqlParam);

                    Cn.Open();
                    SqlCmd.ExecuteNonQuery();
                    SqlCmd.Dispose();
                    Cn.Close();
                    Cn.Dispose();
                }
            }
    #endregion
    #endregion

}

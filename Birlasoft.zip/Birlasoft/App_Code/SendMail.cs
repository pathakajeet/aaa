using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Mail;


/// <summary>
/// Summary description for SendMail
/// </summary>
/// 
namespace SendMails
{
    
    public class SendMail
    {
        public SendMail()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        public string sendMail(string subject, string body)
        {

            //string from1 = ConfigurationManager.AppSettings["From"];
            // Mail initialization
            MailMessage mailMsg = new MailMessage();


            mailMsg.From = "info@iiservz.com";
          //  mailMsg.Cc = "narenderbisht@iiservz.com";
            mailMsg.To = "info@iiservz.com";
	  

            
            mailMsg.Subject = subject;

            //if (cc != "")
            //{
            //    mailMsg.Cc = cc;
            //}

            //if (bcc != "")
            //{
            //    mailMsg.Bcc = bcc;
            //}
            mailMsg.BodyFormat = MailFormat.Html;
            mailMsg.Body = body;
            mailMsg.Priority = MailPriority.High;


            // Smtp configuration
            //string server = ConfigurationManager.AppSettings["SmtpServer"];
            string server = "smtp.rediffmailpro.com";
            SmtpMail.SmtpServer = server;

            try
            {
                SmtpMail.Send(mailMsg);
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string sendMailtoanil(string subject, string body)
        {

            //string from1 = ConfigurationManager.AppSettings["From"];
            // Mail initialization
            MailMessage mailMsg = new MailMessage();


            mailMsg.From = "digantanayak@iiservz.com ";
            mailMsg.Cc = "hemendrasingh@iiservz.com,ravinderkumar@iiservz.com,sandeepkaur@iiservz.com";
            mailMsg.To = "operation1@iiservz.com,operation2@iiservz.com,digantanayak@iiservz.com";



            mailMsg.Subject = subject;

            //if (cc != "")
            //{
            //    mailMsg.Cc = cc;
            //}

            //if (bcc != "")
            //{
            //    mailMsg.Bcc = bcc;
            //}
            mailMsg.BodyFormat = MailFormat.Html;
            mailMsg.Body = body;
            mailMsg.Priority = MailPriority.High;


            // Smtp configuration
            //string server = ConfigurationManager.AppSettings["SmtpServer"];
            string server = "smtp.rediffmailpro.com";
            SmtpMail.SmtpServer = server;

            try
            {
                SmtpMail.Send(mailMsg);
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        public string sendMailtoEducation(string subject, string body)
        {

            //string from1 = ConfigurationManager.AppSettings["From"];
            // Mail initialization
            MailMessage mailMsg = new MailMessage();


            mailMsg.From = "digantanayak@iiservz.com ";
            mailMsg.Cc = "saraswatichalam@iiservz.com,jyotibala@iiservz.com,divyabhambri@iiservz.com";
            mailMsg.To = "education@iiservz.com";



            mailMsg.Subject = subject;

            //if (cc != "")
            //{
            //    mailMsg.Cc = cc;
            //}

            //if (bcc != "")
            //{
            //    mailMsg.Bcc = bcc;
            //}
            mailMsg.BodyFormat = MailFormat.Html;
            mailMsg.Body = body;
            mailMsg.Priority = MailPriority.High;


            // Smtp configuration
            //string server = ConfigurationManager.AppSettings["SmtpServer"];
            string server = "smtp.rediffmailpro.com";
            SmtpMail.SmtpServer = server;

            try
            {
                SmtpMail.Send(mailMsg);
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string sendMailoperationtoEdu(string subject, string body)
        {

            //string from1 = ConfigurationManager.AppSettings["From"];
            // Mail initialization
            MailMessage mailMsg = new MailMessage();


            mailMsg.From = "sandeepkaur@iiservz.com";
            mailMsg.Cc = "saraswatichalam@iiservz.com,jyotibala@iiservz.com,divyabhambri@iiservz.com,digantanayak@iiservz.com";
            mailMsg.To = "education@iiservz.com";



            mailMsg.Subject = subject;

            //if (cc != "")
            //{
            //    mailMsg.Cc = cc;
            //}

            //if (bcc != "")
            //{
            //    mailMsg.Bcc = bcc;
            //}
            mailMsg.BodyFormat = MailFormat.Html;
            mailMsg.Body = body;
            mailMsg.Priority = MailPriority.High;


            // Smtp configuration
            //string server = ConfigurationManager.AppSettings["SmtpServer"];
            string server = "smtp.rediffmailpro.com";
            SmtpMail.SmtpServer = server;

            try
            {
                SmtpMail.Send(mailMsg);
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }


    }
}
﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.OleDb;
using System.Data.Common;
using System.Drawing;
using System.Drawing.Imaging;

public partial class _ChangePassword : System.Web.UI.Page
{
    string Uan = "";
    string Username = "";
    int Employeeid = 0;
    string UserType = "";
    DataTable DtImage = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {
       // Username = Session["Username"].ToString();
        //Employeeid = Convert.ToInt32(Username);
        //UserType = Session["UserType"].ToString();
       // txtUsername.Text = Username.ToString();
        if (!IsPostBack)
        {
            
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        
    }

   
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (txtUsername.Text == "")
        {
            lblMsg.Text = "User Name Should Not Be Blank!";
            lblMsg.ForeColor = System.Drawing.Color.Red;
            lblMsg.Font.Bold = true;
            return;
        }
        if (txtOldPassword.Text == "")
        {
            lblMsg.Text = "Old Password Should Not Be Blank!";
            lblMsg.ForeColor = System.Drawing.Color.Red;
            lblMsg.Font.Bold = true;
            return;
        }

        if (txtNewPassword.Text == "")
        {
            lblMsg.Text = "New Password Should Not Be Blank!";
            lblMsg.ForeColor = System.Drawing.Color.Red;
            lblMsg.Font.Bold = true;
            return;
        }
        string Username = txtUsername.Text;
        string OldPassword = txtOldPassword.Text;
        string NewPassword = txtNewPassword.Text;
        string CS = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(CS);
        DataTable ds = new DataTable();
        con.Open();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select * from LoginUsers where username=" + "'" + Username + "'";
        da.SelectCommand = cmd;
        da.Fill(ds);
        con.Close();
        if (ds.Rows.Count > 0)
        {
            string MatchPwd = ds.Rows[0]["Password"].ToString();
            if (OldPassword.ToString() == MatchPwd.ToString())
            {
                con.Open();
                SqlCommand cmd1 = new SqlCommand("UpdatePassword", con);
                cmd1.CommandType = CommandType.StoredProcedure;
                cmd1.Parameters.AddWithValue("@Username", txtUsername.Text);
                cmd1.Parameters.AddWithValue("@Password", txtNewPassword.Text);
                int i = 0;
                i = cmd1.ExecuteNonQuery();
                con.Close();
                lblMsg.Text = "Successfully Updated";
                lblMsg.ForeColor = System.Drawing.Color.Green;
                lblMsg.Font.Bold = true;

            }
            else
            {
                lblMsg.Text = "Old and New password Did not Match!";
                lblMsg.ForeColor = System.Drawing.Color.Red;
                lblMsg.Font.Bold = true;
            }
        }

        else
        {
            lblMsg.Text = "User Id Not Matched";
            lblMsg.ForeColor = System.Drawing.Color.Red;
            lblMsg.Font.Bold = true;
        }
    }
    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/HrLogin.aspx");
    }
}
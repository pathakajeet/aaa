﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Net;
using RestSharp;
using System.Xml;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;

public partial class BgvDetails : System.Web.UI.Page
{
    DataTable ds = new DataTable();
    DataTable ds1 = new DataTable();
    DataTable ds2 = new DataTable();
    SqlDataAdapter adapter = new SqlDataAdapter();
    string sql = null;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());

    protected void Page_Load(object sender, EventArgs e)
    {
        var clients = new RestClient("https://api44preview.sapsf.com/odata/v2/JobApplication?$select=firstName,middleName,lastName,gender,cellPhone,contactEmail,outsideWorkExperience/employer,outsideWorkExperience/startTitle,outsideWorkExperience/startDate,outsideWorkExperience/endDate,education/institution,education/ProgramNav/localeLabel,education/endDate,education/educationlevelNav/localeLabel&$format=json");
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        var requests = new RestRequest(Method.GET);
        requests.AddHeader("Authorization", "Basic SW50ZWdyYXRpb25fUHJldmlld0BiaXJsYXNvZnRsVDE6V2VsY29tZUA5ODc=");
        requests.AddParameter("undefined", ParameterType.RequestBody);
        IRestResponse responses = clients.Execute(requests);
        if (responses.StatusCode.ToString() == "OK")
        {
            string Apiresponse = responses.Content;
             var myDetails = JsonConvert.DeserializeObject<Root>(Apiresponse);
            // ds = JsonStringToDataTable(Apiresponse);
            Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(Apiresponse);

            con.Open();
            for (int i = 0; i <= myDeserializedClass.d.results.Count - 1; i++)
            {
                string jsonString = JsonConvert.SerializeObject(myDeserializedClass.d.results[i]);
                if (myDeserializedClass.d.results[i].cellPhone == null)
                {
                    myDeserializedClass.d.results[i].cellPhone = null;
                }

                string authors = myDeserializedClass.d.results[i].__metadata.uri.ToString();
                string[] authorsList = authors.Split('(');
                string applicationnumber = authorsList[1].Replace(")", "");

                sql = " IF NOT EXISTS (SELECT * FROM biralasoftapidatatable WHERE applicationno = '" + applicationnumber + "') BEGIN insert into biralasoftapidatatable (applicationno,firstName,lastName,gender,contactEmail,middleName,cellPhone) values('" + applicationnumber + "',' " + myDeserializedClass.d.results[i].firstName + " ',' " + myDeserializedClass.d.results[i].lastName + " ',' " + myDeserializedClass.d.results[i].gender + " ',' " + myDeserializedClass.d.results[i].contactEmail + " ',' " + myDeserializedClass.d.results[i].middleName + " ',' " + myDeserializedClass.d.results[i].cellPhone + " ' ) END ";

                try
                {

                    adapter.InsertCommand = new SqlCommand(sql, con);
                    adapter.InsertCommand.ExecuteNonQuery();

                }
                catch (Exception ex)
                {

                }


            }
            
        }
        else
        {
            error.Text = "Error in fetching  API data";
        }

        string dtt = "select applicationno,firstName,middleName,lastName,gender,contactEmail,cellPhone,FORMAT ( DateReceived, 'd', 'en-IN') as Date from biralasoftapidatatable where receive=1";
        SqlDataAdapter gridadpt = new SqlDataAdapter(dtt, con);
        gridadpt.Fill(ds);

        grid1.DataSource = ds;
        grid1.DataBind();

    }

    public DataTable JsonStringToDataTable(string jsonString)
    {
        DataTable dt = new DataTable();
        string[] jsonStringArray = Regex.Split(jsonString.Replace("[", "").Replace("]", ""), "},{");
        List<string> ColumnsName = new List<string>();
        foreach (string jSA in jsonStringArray)
        {
            string[] jsonStringData = Regex.Split(jSA.Replace("{", "").Replace("}", ""), ",");
            foreach (string ColumnsNameData in jsonStringData)
            {
                try
                {
                    int idx = ColumnsNameData.IndexOf(":");
                    string ColumnsNameString = ColumnsNameData.Substring(0, idx - 1).Replace("\"", "");
                    if (!ColumnsName.Contains(ColumnsNameString))
                    {
                        ColumnsName.Add(ColumnsNameString);
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(string.Format("Error Parsing Column Name : {0}", ColumnsNameData));
                }
            }
            break;
        }
        foreach (string AddColumnName in ColumnsName)
        {
            dt.Columns.Add(AddColumnName);
        }
        foreach (string jSA in jsonStringArray)
        {
            string[] RowData = Regex.Split(jSA.Replace("{", "").Replace("}", ""), ",");
            DataRow nr = dt.NewRow();
            foreach (string rowData in RowData)
            {
                try
                {
                    int idx = rowData.IndexOf(":");
                    string RowColumns = rowData.Substring(0, idx - 1).Replace("\"", "");
                    string RowDataString = rowData.Substring(idx + 1).Replace("\"", "");
                    nr[RowColumns] = RowDataString;
                }
                catch (Exception ex)
                {
                    continue;
                }
            }
            dt.Rows.Add(nr);
        }
        return dt;
    }

    protected void grid1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Select")
        {
            int rowIndex = Convert.ToInt32(e.CommandArgument);
            GridViewRow row = grid1.Rows[rowIndex];
            string Cid = row.Cells[1].Text;

            // --https://api44preview.sapsf.com/odata/v2/JobApplication(561L)

            var client = new RestClient("https://api44preview.sapsf.com/odata/v2/JobApplication(" + Cid + ")");
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", "Basic SW50ZWdyYXRpb25fUHJldmlld0BiaXJsYXNvZnRsVDE6V2VsY29tZUA5ODc=");
           // request.AddHeader("Content-Type", "application/json");
            request.AddParameter("undefined",  ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            string Apiresponse = response.Content; 
             var myDetails = JsonConvert.DeserializeObject<candidatedetail>(Apiresponse);
            ds = JsonStringToDataTable(Apiresponse);

            //save employee information
            SqlCommand comm = new SqlCommand("EmployeeIfo_Insert", con);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.Add("@Metadata_type" ,SqlDbType.VarChar,400).Value = myDetails.d.__metadata.type ?? "";
            comm.Parameters.Add("@Metadata_Url", SqlDbType.VarChar, 400).Value = myDetails.d.__metadata.uri ?? "";
            comm.Parameters.Add("@applicationId" ,SqlDbType.VarChar,400).Value = myDetails.d.applicationId ?? ""; 
            comm.Parameters.Add("@sectDisclaimer" ,SqlDbType.VarChar,400).Value = myDetails.d.sectDisclaimer ?? ""; 
            comm.Parameters.Add("@PANnumber",SqlDbType.VarChar,400).Value = myDetails.d.PANnumber ?? "";
            comm.Parameters.Add("@instrInternalPolicy"  ,SqlDbType.VarChar,400).Value = myDetails.d.instrInternalPolicy ?? "";
            comm.Parameters.Add("@usersSysId"  ,SqlDbType.VarChar,400).Value = myDetails.d.usersSysId ?? "";
            comm.Parameters.Add("@instrUKDisability" ,SqlDbType.VarChar,400).Value = myDetails.d.instrUKDisability ?? "";
            comm.Parameters.Add("@disclaimerAcknowledge", SqlDbType.VarChar, 400).Value = myDetails.d.disclaimerAcknowledge ?? "";
            comm.Parameters.Add("@preferredName" , SqlDbType.VarChar, 400).Value = myDetails.d.preferredName ?? "";
            comm.Parameters.Add("@instrContractInfo"  , SqlDbType.VarChar, 400).Value = myDetails.d.instrContractInfo ?? "";
            comm.Parameters.Add("@zip"  , SqlDbType.VarChar, 400).Value = myDetails.d.zip ?? "";
            comm.Parameters.Add("@instrInterview"  , SqlDbType.VarChar, 400).Value = myDetails.d.instrInterview ?? "";
            comm.Parameters.Add("@currentCompany"  , SqlDbType.VarChar, 400).Value = myDetails.d.currentCompany ?? "";
            comm.Parameters.Add("@cust_expcompcur" , SqlDbType.VarChar, 400).Value = myDetails.d.cust_expcompcur ?? "";
            comm.Parameters.Add("@customInterviewDateTime"  , SqlDbType.VarChar, 400).Value = myDetails.d.customInterviewDateTime ?? "";
            comm.Parameters.Add("@statusComments"  , SqlDbType.VarChar, 400).Value = myDetails.d.statusComments ?? "";
            comm.Parameters.Add("@startDate", SqlDbType.DateTime).Value = myDetails.d.startDate?? DateTime.Now;
            comm.Parameters.Add("@status"  , SqlDbType.VarChar, 400).Value = myDetails.d.status ?? "";
            comm.Parameters.Add("@lastName"  , SqlDbType.VarChar, 400).Value = myDetails.d.lastName ?? "";
            comm.Parameters.Add("@gender"  , SqlDbType.VarChar, 400).Value = myDetails.d.gender ?? "";
            comm.Parameters.Add("@city" , SqlDbType.VarChar, 400).Value = myDetails.d.city ?? "";
            comm.Parameters.Add("@sourceLabel"  , SqlDbType.VarChar, 400).Value = myDetails.d.sourceLabel ?? "";
            comm.Parameters.Add("@customVisaYes"  , SqlDbType.VarChar, 400).Value = myDetails.d.customVisaYes ?? "";
            comm.Parameters.Add("@customOtherCompDetails" , SqlDbType.VarChar, 400).Value = myDetails.d.customOtherCompDetails ?? "";
            comm.Parameters.Add("@profileUpdated", SqlDbType.VarChar, 400).Value = myDetails.d.profileUpdated ?? "";
            comm.Parameters.Add("@customBaseSal"  , SqlDbType.VarChar, 400).Value = myDetails.d.customBaseSal ?? "";
            comm.Parameters.Add("@duplicateProfile"  , SqlDbType.VarChar, 400).Value = myDetails.d.duplicateProfile ?? "";
            comm.Parameters.Add("@countryCode"  , SqlDbType.VarChar, 400).Value = myDetails.d.countryCode ?? "";
            comm.Parameters.Add("@averageRating"  , SqlDbType.VarChar, 400).Value = myDetails.d.averageRating ?? "";
            comm.Parameters.Add("@instrGlobalEEO"  , SqlDbType.VarChar, 400).Value = myDetails.d.instrGlobalEEO ?? "";
            comm.Parameters.Add("@customInterviewList"  , SqlDbType.VarChar, 400).Value = myDetails.d.customInterviewList ?? "";
            comm.Parameters.Add("@endDateContract"  , SqlDbType.VarChar, 400).Value = myDetails.d.endDateContract ?? "";
            comm.Parameters.Add("@jobReqId"  , SqlDbType.VarChar, 400).Value = myDetails.d.jobReqId ?? "";
            comm.Parameters.Add("@address" , SqlDbType.VarChar, 400).Value = myDetails.d.address ?? "";
            comm.Parameters.Add("@nonApplicantStatus" , SqlDbType.VarChar, 400).Value = myDetails.d.nonApplicantStatus ?? "";
            comm.Parameters.Add("@resumeUploadDate" , SqlDbType.VarChar, 400).Value = myDetails.d.resumeUploadDate ?? "";
            comm.Parameters.Add("@appStatusSetItemId" , SqlDbType.VarChar, 400).Value = myDetails.d.appStatusSetItemId ?? "";
            comm.Parameters.Add("@UANnumber"  , SqlDbType.VarChar, 400).Value = myDetails.d.UANnumber ?? "";
            comm.Parameters.Add("@candConversionProcessed"  , SqlDbType.VarChar, 400).Value = myDetails.d.candConversionProcessed ?? "";
            comm.Parameters.Add("@customCarAllowAmt"  , SqlDbType.VarChar, 400).Value = myDetails.d.customCarAllowAmt ?? "";
            comm.Parameters.Add("@referenceComments" , SqlDbType.VarChar, 400).Value = myDetails.d.referenceComments ?? "";
            comm.Parameters.Add("@customRelocAmount"  , SqlDbType.VarChar, 400).Value = myDetails.d.customRelocAmount ?? "";
            comm.Parameters.Add("@anonymizedFlag"  , SqlDbType.VarChar, 400).Value = myDetails.d.anonymizedFlag ?? "";
            comm.Parameters.Add("@referredBy", SqlDbType.VarChar, 400).Value = myDetails.d.referredBy ?? "";
            comm.Parameters.Add("@cellPhone"  , SqlDbType.VarChar, 400).Value = myDetails.d.cellPhone ?? "";
            comm.Parameters.Add("@instrDisabilityBurdStmt"  , SqlDbType.VarChar, 400).Value = myDetails.d.instrDisabilityBurdStmt ?? "";
            comm.Parameters.Add("@applicationTemplateId" , SqlDbType.VarChar, 400).Value = myDetails.d.applicationTemplateId ?? "";
            comm.Parameters.Add("@country"  , SqlDbType.VarChar, 400).Value = myDetails.d.country ?? "";
            comm.Parameters.Add("@instrApplication"  , SqlDbType.VarChar, 400).Value = myDetails.d.instrApplication ?? "";
            comm.Parameters.Add("@preOfferInst" , SqlDbType.VarChar, 400).Value = myDetails.d.preOfferInst ?? "";
            comm.Parameters.Add("@instrVets1"  , SqlDbType.VarChar, 400).Value = myDetails.d.instrVets1 ?? "";
            comm.Parameters.Add("@lastModifiedDateTime"  , SqlDbType.DateTime).Value = myDetails.d.lastModifiedDateTime ?? null;
            comm.Parameters.Add("@jobTitle" , SqlDbType.VarChar, 400).Value = myDetails.d.jobTitle ?? "";
            comm.Parameters.Add("@rating"  , SqlDbType.VarChar, 400).Value = myDetails.d.rating ?? "";
            comm.Parameters.Add("@source"  , SqlDbType.VarChar, 400).Value = myDetails.d.source ?? "";
            comm.Parameters.Add("@instrVets2"  , SqlDbType.VarChar, 400).Value = myDetails.d.instrVets2 ?? "";
            comm.Parameters.Add("@customEEOPoster" , SqlDbType.VarChar, 400).Value = myDetails.d.customEEOPoster ?? "";
            comm.Parameters.Add("@agencyInfo" , SqlDbType.VarChar, 400).Value = myDetails.d.agencyInfo ?? "";
            comm.Parameters.Add("@reference"  , SqlDbType.VarChar, 400).Value = myDetails.d.reference ?? "";
            comm.Parameters.Add("@instrRewardInfo" , SqlDbType.VarChar, 400).Value = myDetails.d.instrRewardInfo ?? "";
            comm.Parameters.Add("@customCarAllowanceMonths"  , SqlDbType.VarChar, 400).Value = myDetails.d.customCarAllowanceMonths ?? "";
            comm.Parameters.Add("@LegacyAppID"  , SqlDbType.VarChar, 400).Value = myDetails.d.LegacyAppID ?? "";
            comm.Parameters.Add("@addressLine2", SqlDbType.VarChar, 400).Value = myDetails.d.addressLine2 ?? "";
            comm.Parameters.Add("@customFinalSignOn"  , SqlDbType.VarChar, 400).Value = myDetails.d.customFinalSignOn ?? "";
            comm.Parameters.Add("@timeToHire"  , SqlDbType.VarChar, 400).Value = myDetails.d.timeToHire ?? "";
            comm.Parameters.Add("@instrEligWork" , SqlDbType.VarChar, 400).Value = myDetails.d.instrEligWork ?? "";
            comm.Parameters.Add("@nickName" , SqlDbType.VarChar, 400).Value = myDetails.d.nickName ?? "";
            comm.Parameters.Add("@homePhone" , SqlDbType.VarChar, 400).Value = myDetails.d.homePhone ?? "";
            comm.Parameters.Add("@custSalaryDesired"  , SqlDbType.VarChar, 400).Value = myDetails.d.custSalaryDesired ?? "";
            comm.Parameters.Add("@ownershpDate"  , SqlDbType.VarChar, 400).Value = myDetails.d.ownershpDate ?? "";
            comm.Parameters.Add("@customTargetBonusAmount"  , SqlDbType.VarChar, 400).Value = myDetails.d.customTargetBonusAmount ?? "";
            comm.Parameters.Add("@firstName", SqlDbType.VarChar, 400).Value = myDetails.d.firstName ?? "";
            comm.Parameters.Add("@aadhaarNumber"  , SqlDbType.VarChar, 400).Value = myDetails.d.aadhaarNumber ?? "";
            comm.Parameters.Add("@currentTitle", SqlDbType.VarChar, 400).Value = myDetails.d.currentTitle ?? "";
            comm.Parameters.Add("@lastModifiedByProxy" , SqlDbType.VarChar, 400).Value = myDetails.d.lastModifiedByProxy ?? "";
            comm.Parameters.Add("@instrDisclaimer"  , SqlDbType.VarChar, 400).Value = myDetails.d.instrDisclaimer ?? "";
            comm.Parameters.Add("@anonymizedDate"  , SqlDbType.VarChar, 400).Value = myDetails.d.anonymizedDate ?? "";
            comm.Parameters.Add("@candidateId" , SqlDbType.VarChar, 400).Value = myDetails.d.candidateId ?? "";
            comm.Parameters.Add("@customAdjustmentsOther"  , SqlDbType.VarChar, 400).Value = myDetails.d.customAdjustmentsOther ?? "";
            comm.Parameters.Add("@dataSource"  , SqlDbType.VarChar, 400).Value = myDetails.d.dataSource ?? "";
            comm.Parameters.Add("@customLTI"  , SqlDbType.VarChar, 400).Value = myDetails.d.customLTI ?? "";
            comm.Parameters.Add("@applicationDate"  , SqlDbType.DateTime).Value = myDetails.d.applicationDate ?? null;
            comm.Parameters.Add("@candTypeWhenHired" , SqlDbType.VarChar, 400).Value = myDetails.d.candTypeWhenHired ?? "";
            comm.Parameters.Add("@hiredOn"  , SqlDbType.VarChar, 400).Value = myDetails.d.hiredOn ?? "";
            comm.Parameters.Add("@instrEmpInfo" , SqlDbType.VarChar, 400).Value = myDetails.d.instrEmpInfo ?? "";
            comm.Parameters.Add("@LegacyCandID" , SqlDbType.VarChar, 400).Value = myDetails.d.LegacyCandID ?? "";
            comm.Parameters.Add("@instrDisability1" , SqlDbType.VarChar, 400).Value = myDetails.d.instrDisability1 ?? "";
            comm.Parameters.Add("@instrDisability2" , SqlDbType.VarChar, 400).Value = myDetails.d.instrDisability2 ?? "";
            comm.Parameters.Add("@customOtherAllowanceDetails" , SqlDbType.VarChar, 400).Value = myDetails.d.customOtherAllowanceDetails ?? "";
            comm.Parameters.Add("@customInterviewComments1"  , SqlDbType.VarChar, 400).Value = myDetails.d.customInterviewComments1 ?? "";
            comm.Parameters.Add("@instrEEO1"  , SqlDbType.VarChar, 400).Value = myDetails.d.instrEEO1 ?? "";
            comm.Parameters.Add("@instrEEO2" , SqlDbType.VarChar, 400).Value = myDetails.d.instrEEO2 ?? "";
            comm.Parameters.Add("@owner" , SqlDbType.VarChar, 400).Value = myDetails.d.owner ?? "";
            comm.Parameters.Add("@bkgrndChkStatus" , SqlDbType.VarChar, 400).Value = myDetails.d.bkgrndChkStatus ?? "";
            comm.Parameters.Add("@instrEEOFooter"  , SqlDbType.VarChar, 400).Value = myDetails.d.instrEEOFooter ?? "";
            comm.Parameters.Add("@contactEmail"  , SqlDbType.VarChar, 400).Value = myDetails.d.contactEmail ?? "";
            comm.Parameters.Add("@jobAppGuid"  , SqlDbType.VarChar, 400).Value = myDetails.d.jobAppGuid ?? "";
            comm.Parameters.Add("@lastModifiedBy"  , SqlDbType.VarChar, 400).Value = myDetails.d.lastModifiedBy ?? "";
            comm.Parameters.Add("@exportedOn" , SqlDbType.VarChar, 400).Value = myDetails.d.exportedOn ?? "";
            comm.Parameters.Add("@instrAccommodations", SqlDbType.VarChar, 400).Value = myDetails.d.instrAccommodations ?? "";
            comm.Parameters.Add("@middleName"  , SqlDbType.VarChar, 400).Value = myDetails.d.middleName ?? "";
            comm.Parameters.Add("@customEligibleOther" , SqlDbType.VarChar, 400).Value = myDetails.d.customEligibleOther ?? "";
            comm.Parameters.Add("@appLocale"  , SqlDbType.VarChar, 400).Value = myDetails.d.appLocale ?? "";
            comm.Parameters.Add("@snapShotDate"  , SqlDbType.DateTime).Value = myDetails.d.snapShotDate ?? DateTime.Now;
            comm.Parameters.Add("@CustomNoticePeriod_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customNoticePeriod.__deferred.uri ?? "";
            comm.Parameters.Add("@Education_Url", SqlDbType.VarChar, 400).Value = myDetails.d.education.__deferred.uri ?? "";
            //comm.Parameters.Add("@Prefix_Url", SqlDbType.VarChar, 400).Value = myDetails.d.prefix.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomAgeGroup_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customAgeGroup.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomAdjustments_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customAdjustments.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomSourceSecondary_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customSourceSecondary.__deferred.uri ?? "";
            comm.Parameters.Add("@CoverLetter_Url", SqlDbType.VarChar, 400).Value = myDetails.d.coverLetter.__deferred.uri ?? "";
            comm.Parameters.Add("@JobApplicationComments_Url", SqlDbType.VarChar, 400).Value = myDetails.d.jobApplicationComments.__deferred.uri ?? "";
            comm.Parameters.Add("@State_Url", SqlDbType.VarChar, 400).Value = myDetails.d.state.__deferred.uri ?? "";
            comm.Parameters.Add("@JobApplicationAssessmentOrder_Url", SqlDbType.VarChar, 400).Value = myDetails.d.jobApplicationAssessmentOrder.__deferred.uri ?? "";
            comm.Parameters.Add("@ReferredByNav_Url", SqlDbType.VarChar, 400).Value = myDetails.d.referredByNav.__deferred.uri ?? "";
            comm.Parameters.Add("@OfferLetter_Url", SqlDbType.VarChar, 400).Value = myDetails.d.offerLetter.__deferred.uri ?? "";
            comm.Parameters.Add("@JobApplicationInterview_Url", SqlDbType.VarChar, 400).Value = myDetails.d.jobApplicationInterview.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomNoticeDuringProbPeriod_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customNoticeDuringProbPeriod.__deferred.uri ?? "";
            comm.Parameters.Add("@Certificates_Url", SqlDbType.VarChar, 400).Value = myDetails.d.certificates.__deferred.uri ?? "";
            comm.Parameters.Add("@StatusId_Url", SqlDbType.VarChar, 400).Value = myDetails.d.statusId.__deferred.uri ?? "";
            comm.Parameters.Add("@JobRequisition_Url", SqlDbType.VarChar, 400).Value = myDetails.d.jobRequisition.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomInterviewType1_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customInterviewType1.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomInterviewRound_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customInterviewRound.__deferred.uri ?? "";
            comm.Parameters.Add("@JobApplicationQuestionResponse_Url", SqlDbType.VarChar, 400).Value = myDetails.d.jobApplicationQuestionResponse.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomTypeHire_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customTypeHire.__deferred.uri ?? "";
            comm.Parameters.Add("@JobOffer_Url", SqlDbType.VarChar, 400).Value = myDetails.d.jobOffer.__deferred.uri ?? "";
            comm.Parameters.Add("@CountryPicklist_Url", SqlDbType.VarChar, 400).Value = myDetails.d.countryPicklist.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomProbPeriod_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customProbPeriod.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomNationality_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customNationality.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomAdditionalAttach_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customAdditionalAttach.__deferred.uri ?? "";
            comm.Parameters.Add("@Resume_Url", SqlDbType.VarChar, 400).Value = myDetails.d.resume.__deferred.uri ?? "";
            comm.Parameters.Add("@UserNav_Url", SqlDbType.VarChar, 400).Value = myDetails.d.userNav.__deferred.uri ?? "";
            comm.Parameters.Add("@PhoneTypePrimary_Url", SqlDbType.VarChar, 400).Value = myDetails.d.phoneTypePrimary.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomInternalPolicy_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customInternalPolicy.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomBasePayFreq_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customBasePayFreq.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomSourcePrimary_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customSourcePrimary.__deferred.uri ?? "";
           // comm.Parameters.Add("@Refrences_Url", SqlDbType.VarChar, 400).Value = myDetails.d.refrences.__deferred.uri ?? "";
            comm.Parameters.Add("@InsideWorkExperience_Url", SqlDbType.VarChar, 400).Value = myDetails.d.insideWorkExperience.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomUKEthnicity_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customUKEthnicity.__deferred.uri ?? "";
            comm.Parameters.Add("@VeteranStatus_Url", SqlDbType.VarChar, 400).Value = myDetails.d.veteranStatus.__deferred.uri ?? "";
            comm.Parameters.Add("@JobAppStatus_Url", SqlDbType.VarChar, 400).Value = myDetails.d.jobAppStatus.__deferred.uri ?? "";
            comm.Parameters.Add("@PaySlips_Url", SqlDbType.VarChar, 400).Value = myDetails.d.paySlips.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomSexualOrientation_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customSexualOrientation.__deferred.uri ?? "";
            comm.Parameters.Add("@BkgrndChkAttachment_Url", SqlDbType.VarChar, 400).Value = myDetails.d.bkgrndChkAttachment.__deferred.uri ?? "";
            comm.Parameters.Add("@JobApplicationOnboardingData_Url", SqlDbType.VarChar, 400).Value = myDetails.d.jobApplicationOnboardingData.__deferred.uri ?? "";
            comm.Parameters.Add("@JobApplicationAudit_Url", SqlDbType.VarChar, 400).Value = myDetails.d.jobApplicationAudit.__deferred.uri ?? "";
            comm.Parameters.Add("@OutsideWorkExperience_Url", SqlDbType.VarChar, 400).Value = myDetails.d.outsideWorkExperience.__deferred.uri ?? "";
            comm.Parameters.Add("@CustTravel_Url", SqlDbType.VarChar, 400).Value = myDetails.d.custTravel.__deferred.uri ?? "";
            comm.Parameters.Add("@AadharCopy_Url", SqlDbType.VarChar, 400).Value = myDetails.d.aadharCopy.__deferred.uri ?? "";
            comm.Parameters.Add("@DisabilityStatus_Url", SqlDbType.VarChar, 400).Value = myDetails.d.disabilityStatus.__deferred.uri ?? "";
            comm.Parameters.Add("@CustONBPrefLang_Url", SqlDbType.VarChar, 400).Value = myDetails.d.custONBPrefLang.__deferred.uri ?? "";
            comm.Parameters.Add("@JobApplicationStatusAuditTrail_Url", SqlDbType.VarChar, 400).Value = myDetails.d.jobApplicationStatusAuditTrail.__deferred.uri ?? "";
            comm.Parameters.Add("@PhoneTypeAlternate_Url", SqlDbType.VarChar, 400).Value = myDetails.d.phoneTypeAlternate.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomCarAllowRequired_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customCarAllowRequired.__deferred.uri ?? "";
            comm.Parameters.Add("@Candidate_Url", SqlDbType.VarChar, 400).Value = myDetails.d.candidate.__deferred.uri ?? "";
            comm.Parameters.Add("@PANCopy_Url", SqlDbType.VarChar, 400).Value = myDetails.d.PANCopy.__deferred.uri ?? "";
            comm.Parameters.Add("@Race_Url", SqlDbType.VarChar, 400).Value = myDetails.d.race.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomEligibleToWork_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customEligibleToWork.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomVisa_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customVisa.__deferred.uri ?? "";
            comm.Parameters.Add("@CustomLegalAuth_Url", SqlDbType.VarChar, 400).Value = myDetails.d.customLegalAuth.__deferred.uri ?? "";
           
             int Count = comm.ExecuteNonQuery();

            //--

            //--https://api44preview.sapsf.com/odata/v2/JobApplication(561L)/education

            var client1 = new RestClient("https://api44preview.sapsf.com/odata/v2/JobApplication(" + Cid + ")/education");
            var request1 = new RestRequest(Method.GET);
            request1.AddHeader("Authorization", "Basic SW50ZWdyYXRpb25fUHJldmlld0BiaXJsYXNvZnRsVDE6V2VsY29tZUA5ODc=");
            // request.AddHeader("Content-Type", "application/json");
            request1.AddParameter("undefined", ParameterType.RequestBody);
            IRestResponse response1 = client1.Execute(request1);
            string Apiresponse1 = response1.Content;
            var myDetails1 = JsonConvert.DeserializeObject<Root1>(Apiresponse1);            
            ds1 = JsonStringToDataTable(Apiresponse1);
            
            //save employee education  information
            for(int i=0;i< myDetails1.d.results.Count ;i++)
            {
             SqlCommand educmd = new SqlCommand("EmployeeEdu_Insert", con);
            educmd.CommandType = CommandType.StoredProcedure;
            educmd.Parameters.Add("@Metadata_Type", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].__metadata.type ?? "";
            educmd.Parameters.Add("@Metadata_Url", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].__metadata.uri ?? "";
            educmd.Parameters.Add("@backgroundElementId", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].backgroundElementId ?? "";
            educmd.Parameters.Add("@gpaoutof", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].gpaoutof ?? "";
            educmd.Parameters.Add("@Program", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].Program ?? "";
            educmd.Parameters.Add("@lastModifiedDateTime", SqlDbType.DateTime).Value = myDetails1.d.results[i].lastModifiedDateTime ?? null;
            educmd.Parameters.Add("@endDate", SqlDbType.DateTime).Value = myDetails1.d.results[i].endDate ?? DateTime.Now;
            educmd.Parameters.Add("@educationlevel", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].educationlevel ?? "";
            educmd.Parameters.Add("@institution", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].institution ?? "";
            educmd.Parameters.Add("@otherinstitution", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].otherinstitution ?? "";
            educmd.Parameters.Add("@bgOrderPos", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].bgOrderPos ?? "";
            educmd.Parameters.Add("@gpa", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].gpa ?? "";
            educmd.Parameters.Add("@applicationId", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].applicationId ?? "";
            educmd.Parameters.Add("@startDate", SqlDbType.DateTime).Value = myDetails1.d.results[i].startDate ?? DateTime.Now;
            educmd.Parameters.Add("@otherProgram", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].otherProgram ?? "";
            educmd.Parameters.Add("@InstitutionNav_Url", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].institutionNav.__deferred.uri ?? "";
            educmd.Parameters.Add("@EducationlevelNav_Url", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].educationlevelNav.__deferred.uri ?? "";
            educmd.Parameters.Add("@Application_Url", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].application.__deferred.uri ?? "";
            educmd.Parameters.Add("@ProgramNav_Url", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].ProgramNav.__deferred.uri ?? "";
            int Count1 = educmd.ExecuteNonQuery();
            }
            //---
            //--https://api44preview.sapsf.com/odata/v2/JobApplication(561L)/outsideWorkExperience

            var client2 = new RestClient("https://api44preview.sapsf.com/odata/v2/JobApplication(" + Cid + ")/outsideWorkExperience");
            var request2 = new RestRequest(Method.GET);
            request2.AddHeader("Authorization", "Basic SW50ZWdyYXRpb25fUHJldmlld0BiaXJsYXNvZnRsVDE6V2VsY29tZUA5ODc=");
            // request.AddHeader("Content-Type", "application/json");
            request2.AddParameter("undefined", ParameterType.RequestBody);
            IRestResponse response2 = client2.Execute(request2);
            string Apiresponse2 = response2.Content;
            var myDetails2 = JsonConvert.DeserializeObject<Root2>(Apiresponse2);
            ds2 = JsonStringToDataTable(Apiresponse2);
            //save Employedment Detail
            for (int i = 0; i < myDetails2.d.results.Count; i++)
            {
             SqlCommand empcmd = new SqlCommand("EmployeeEmp_Insert", con);
             empcmd.CommandType = CommandType.StoredProcedure;
             empcmd.Parameters.Add("@Metadata_Type", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].__metadata.type ?? "";
	         empcmd.Parameters.Add("@Metadata_Url", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].__metadata.uri ?? "";
             empcmd.Parameters.Add("@backgroundElementId  ", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].backgroundElementId ?? "";
             empcmd.Parameters.Add("@achievements", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].achievements ?? "";
             empcmd.Parameters.Add("@lastModifiedDateTime", SqlDbType.DateTime).Value = myDetails2.d.results[i].lastModifiedDateTime ?? DateTime.Now;
             empcmd.Parameters.Add("@endDate", SqlDbType.DateTime).Value = myDetails2.d.results[i].endDate ?? DateTime.Now;
             empcmd.Parameters.Add("@otheremployer", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].otheremployer ?? "";
             empcmd.Parameters.Add("@jobFunction", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].jobFunction ?? "";
             empcmd.Parameters.Add("@bgOrderPos", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].bgOrderPos ?? "";
             empcmd.Parameters.Add("@employer", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].employer ?? "";
             empcmd.Parameters.Add("@applicationId", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].applicationId ?? "";
             empcmd.Parameters.Add("@otherFunction", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].otherFunction ?? "";
             empcmd.Parameters.Add("@startDate", SqlDbType.DateTime).Value = myDetails2.d.results[i].startDate ?? DateTime.Now;
             empcmd.Parameters.Add("@presentEmployer", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].presentEmployer ?? "";
             empcmd.Parameters.Add("@presentEmployerNav_Url", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].presentEmployerNav.__deferred.uri ?? "";
             empcmd.Parameters.Add("@jobFunctionNav_Url", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].jobFunctionNav.__deferred.uri ?? "";
            // empcmd.Parameters.Add("@employerNav_Url", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].employerNav.__deferred.uri ?? "";
             empcmd.Parameters.Add("@application_Url", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].application.__deferred.uri ?? "";
             empcmd.ExecuteNonQuery();
            }
            //--
            Response.Write("<Script Language='javascript'> alert('Data Fetched Successfully !')</Script>");
            SqlCommand upcmd = new SqlCommand("UPDATE biralasoftapidatatable SET receive=0 where applicationno= '" + Cid + "'", con);
            upcmd.ExecuteNonQuery();   

           }


             Response.Redirect("BgvDetails.aspx");

    }

//basic detail
    public class D
    {
        public List<Result> results { get; set; }
    }
    public class Deferred
    {
        public string uri { get; set; }
    }
    public class Education
    {
        public Deferred __deferred { get; set; }
    }
    public class Metadata
    {
        public string uri { get; set; }
        public string type { get; set; }
    }
    public class OutsideWorkExperience
    {
        public Deferred __deferred { get; set; }
    }
    public class Result
    {
        public Metadata __metadata { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string gender { get; set; }
        public string contactEmail { get; set; }
        public string middleName { get; set; }
        public string cellPhone { get; set; }
        public Education education { get; set; }
        public OutsideWorkExperience outsideWorkExperience { get; set; }
    }
    public class Root
    {
        public D d { get; set; }
    }
    //
    //Fetching Basic Detail
   
    public class AadharCopy
    {
        public Deferred __deferred { get; set; }
    }
    public class BkgrndChkAttachment
    {
        public Deferred __deferred { get; set; }
    }
    public class Candidate
    {
        public Deferred __deferred { get; set; }
    }
    public class Certificates
    {
        public Deferred __deferred { get; set; }
    }
    public class CountryPicklist
    {
        public Deferred __deferred { get; set; }
    }
    public class CoverLetter
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomAdditionalAttach
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomAdjustments
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomAgeGroup
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomBasePayFreq
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomCarAllowRequired
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomEligibleToWork
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomInternalPolicy
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomInterviewRound
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomInterviewType1
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomLegalAuth
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomNationality
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomNoticeDuringProbPeriod
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomNoticePeriod
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomProbPeriod
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomSexualOrientation
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomSourcePrimary
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomSourceSecondary
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomTypeHire
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomUKEthnicity
    {
        public Deferred __deferred { get; set; }
    }
    public class CustomVisa
    {
        public Deferred __deferred { get; set; }
    }
    public class CustONBPrefLang
    {
        public Deferred __deferred { get; set; }
    }
    public class CustTravel
    {
        public Deferred __deferred { get; set; }
    }
    public class result
    {
        public Metadata __metadata { get; set; }
        public string applicationId { get; set; }
        public object sectDisclaimer { get; set; }
        public object PANnumber { get; set; }
        public object instrInternalPolicy { get; set; }
        public object usersSysId { get; set; }
        public object instrUKDisability { get; set; }
        public string disclaimerAcknowledge { get; set; }
        public object preferredName { get; set; }
        public object instrContractInfo { get; set; }
        public string zip { get; set; }
        public object instrInterview { get; set; }
        public string currentCompany { get; set; }
        public object cust_expcompcur { get; set; }
        public object customInterviewDateTime { get; set; }
        public object statusComments { get; set; }
        public DateTime? startDate { get; set; }
        public string status { get; set; }
        public string lastName { get; set; }
        public string gender { get; set; }
        public string city { get; set; }
        public string sourceLabel { get; set; }
        public object customVisaYes { get; set; }
        public object customOtherCompDetails { get; set; }
        public string profileUpdated { get; set; }
        public object customBaseSal { get; set; }
        public string duplicateProfile { get; set; }
        public string countryCode { get; set; }
        public string averageRating { get; set; }
        public object instrGlobalEEO { get; set; }
        public object customInterviewList { get; set; }
        public object endDateContract { get; set; }
        public string jobReqId { get; set; }
        public string address { get; set; }
        public string nonApplicantStatus { get; set; }
        public object resumeUploadDate { get; set; }
        public string appStatusSetItemId { get; set; }
        public object UANnumber { get; set; }
        public object candConversionProcessed { get; set; }
        public object customCarAllowAmt { get; set; }
        public object referenceComments { get; set; }
        public object customRelocAmount { get; set; }
        public string anonymizedFlag { get; set; }
        public string referredBy { get; set; }
        public string cellPhone { get; set; }
        public object instrDisabilityBurdStmt { get; set; }
        public string applicationTemplateId { get; set; }
        public string country { get; set; }
        public object instrApplication { get; set; }
        public object preOfferInst { get; set; }
        public object instrVets1 { get; set; }
        public DateTime? lastModifiedDateTime { get; set; }
        public string jobTitle { get; set; }
        public string rating { get; set; }
        public string source { get; set; }
        public object instrVets2 { get; set; }
        public object customEEOPoster { get; set; }
        public object agencyInfo { get; set; }
        public object reference { get; set; }
        public object instrRewardInfo { get; set; }
        public object customCarAllowanceMonths { get; set; }
        public object LegacyAppID { get; set; }
        public object addressLine2 { get; set; }
        public object customFinalSignOn { get; set; }
        public object timeToHire { get; set; }
        public object instrEligWork { get; set; }
        public object nickName { get; set; }
        public object homePhone { get; set; }
        public string custSalaryDesired { get; set; }
        public object ownershpDate { get; set; }
        public object customTargetBonusAmount { get; set; }
        public string firstName { get; set; }
        public object aadhaarNumber { get; set; }
        public string currentTitle { get; set; }
        public object lastModifiedByProxy { get; set; }
        public object instrDisclaimer { get; set; }
        public object anonymizedDate { get; set; }
        public string candidateId { get; set; }
        public object customAdjustmentsOther { get; set; }
        public string dataSource { get; set; }
        public object customLTI { get; set; }
        public DateTime? applicationDate { get; set; }
        public object candTypeWhenHired { get; set; }
        public object hiredOn { get; set; }
        public object instrEmpInfo { get; set; }
        public object LegacyCandID { get; set; }
        public object instrDisability1 { get; set; }
        public object instrDisability2 { get; set; }
        public object customOtherAllowanceDetails { get; set; }
        public object customInterviewComments1 { get; set; }
        public object instrEEO1 { get; set; }
        public object instrEEO2 { get; set; }
        public object owner { get; set; }
        public object bkgrndChkStatus { get; set; }
        public object instrEEOFooter { get; set; }
        public string contactEmail { get; set; }
        public object jobAppGuid { get; set; }
        public string lastModifiedBy { get; set; }
        public object exportedOn { get; set; }
        public object instrAccommodations { get; set; }
        public object middleName { get; set; }
        public object customEligibleOther { get; set; }
        public string appLocale { get; set; }
        public DateTime? snapShotDate { get; set; }
        public CustomNoticePeriod customNoticePeriod { get; set; }
        public Education education { get; set; }
        public Prefix prefix { get; set; }
        public CustomAgeGroup customAgeGroup { get; set; }
        public CustomAdjustments customAdjustments { get; set; }
        public CustomSourceSecondary customSourceSecondary { get; set; }
        public CoverLetter coverLetter { get; set; }
        public JobApplicationComments jobApplicationComments { get; set; }
        public State state { get; set; }
        public JobApplicationAssessmentOrder jobApplicationAssessmentOrder { get; set; }
        public ReferredByNav referredByNav { get; set; }
        public OfferLetter offerLetter { get; set; }
        public JobApplicationInterview jobApplicationInterview { get; set; }
        public CustomNoticeDuringProbPeriod customNoticeDuringProbPeriod { get; set; }
        public Certificates certificates { get; set; }
        public StatusId statusId { get; set; }
        public JobRequisition jobRequisition { get; set; }
        public CustomInterviewType1 customInterviewType1 { get; set; }
        public CustomInterviewRound customInterviewRound { get; set; }
        public JobApplicationQuestionResponse jobApplicationQuestionResponse { get; set; }
        public CustomTypeHire customTypeHire { get; set; }
        public JobOffer jobOffer { get; set; }
        public CountryPicklist countryPicklist { get; set; }
        public CustomProbPeriod customProbPeriod { get; set; }
        public CustomNationality customNationality { get; set; }
        public CustomAdditionalAttach customAdditionalAttach { get; set; }
        public Resume resume { get; set; }
        public UserNav userNav { get; set; }
        public PhoneTypePrimary phoneTypePrimary { get; set; }
        public CustomInternalPolicy customInternalPolicy { get; set; }
        public CustomBasePayFreq customBasePayFreq { get; set; }
        public CustomSourcePrimary customSourcePrimary { get; set; }
        public Refrences refrences { get; set; }
        public InsideWorkExperience insideWorkExperience { get; set; }
        public CustomUKEthnicity customUKEthnicity { get; set; }
        public VeteranStatus veteranStatus { get; set; }
        public JobAppStatus jobAppStatus { get; set; }
        public PaySlips paySlips { get; set; }
        public CustomSexualOrientation customSexualOrientation { get; set; }
        public BkgrndChkAttachment bkgrndChkAttachment { get; set; }
        public JobApplicationOnboardingData jobApplicationOnboardingData { get; set; }
        public JobApplicationAudit jobApplicationAudit { get; set; }
        public OutsideWorkExperience outsideWorkExperience { get; set; }
        public CustTravel custTravel { get; set; }
        public AadharCopy aadharCopy { get; set; }
        public DisabilityStatus disabilityStatus { get; set; }
        public CustONBPrefLang custONBPrefLang { get; set; }
        public JobApplicationStatusAuditTrail jobApplicationStatusAuditTrail { get; set; }
        public PhoneTypeAlternate phoneTypeAlternate { get; set; }
        public CustomCarAllowRequired customCarAllowRequired { get; set; }
        public Candidate candidate { get; set; }
        public PANCopy PANCopy { get; set; }
        public Race race { get; set; }
        public CustomEligibleToWork customEligibleToWork { get; set; }
        public CustomVisa customVisa { get; set; }
        public CustomLegalAuth customLegalAuth { get; set; }
    }
    public class DisabilityStatus
    {
        public Deferred __deferred { get; set; }
    }
    public class InsideWorkExperience
    {
        public Deferred __deferred { get; set; }
    }
    public class JobApplicationAssessmentOrder
    {
        public Deferred __deferred { get; set; }
    }
    public class JobApplicationAudit
    {
        public Deferred __deferred { get; set; }
    }
    public class JobApplicationComments
    {
        public Deferred __deferred { get; set; }
    }
    public class JobApplicationInterview
    {
        public Deferred __deferred { get; set; }
    }
    public class JobApplicationOnboardingData
    {
        public Deferred __deferred { get; set; }
    }
    public class JobApplicationQuestionResponse
    {
        public Deferred __deferred { get; set; }
    }
    public class JobApplicationStatusAuditTrail
    {
        public Deferred __deferred { get; set; }
    }
    public class JobAppStatus
    {
        public Deferred __deferred { get; set; }
    }
    public class JobOffer
    {
        public Deferred __deferred { get; set; }
    }
    public class JobRequisition
    {
        public Deferred __deferred { get; set; }
    }
    public class OfferLetter
    {
        public Deferred __deferred { get; set; }
    }   
    public class PANCopy
    {
        public Deferred __deferred { get; set; }
    }
    public class PaySlips
    {
        public Deferred __deferred { get; set; }
    }
    public class PhoneTypeAlternate
    {
        public Deferred __deferred { get; set; }
    }
    public class PhoneTypePrimary
    {
        public Deferred __deferred { get; set; }
    }
    public class Prefix
    {
        public Deferred __deferred { get; set; }
    }
    public class Race
    {
        public Deferred __deferred { get; set; }
    }
    public class ReferredByNav
    {
        public Deferred __deferred { get; set; }
    }
    public class Refrences
    {
        public Deferred __deferred { get; set; }
    }
    public class Resume
    {
        public Deferred __deferred { get; set; }
    }
    public class candidatedetail
    {
        public result d { get; set; }
    }
    public class State
    {
        public Deferred __deferred { get; set; }
    }
    public class StatusId
    {
        public Deferred __deferred { get; set; }
    }
    public class UserNav
    {
        public Deferred __deferred { get; set; }
    }
    public class VeteranStatus
    {
        public Deferred __deferred { get; set; }
    }

    //
    //education detail   
    public class Application
    {
        public Deferred __deferred { get; set; }
    }
    public class D1
    {
        public List<Result1> results { get; set; }
    }   
    public class EducationlevelNav
    {
        public Deferred __deferred { get; set; }
    }
    public class InstitutionNav
    {
        public Deferred __deferred { get; set; }
    }
    public class ProgramNav
    {
        public Deferred __deferred { get; set; }
    }
    public class Result1
    {
        public Metadata __metadata { get; set; }
        public string backgroundElementId { get; set; }
        public object gpaoutof { get; set; }
        public object Program { get; set; }
        public DateTime? lastModifiedDateTime { get; set; }
        public DateTime? endDate { get; set; }
        public object educationlevel { get; set; }
        public string institution { get; set; }
        public string otherinstitution { get; set; }
        public string bgOrderPos { get; set; }
        public object gpa { get; set; }
        public string applicationId { get; set; }
        public DateTime? startDate { get; set; }
        public object otherProgram { get; set; }
        public InstitutionNav institutionNav { get; set; }
        public EducationlevelNav educationlevelNav { get; set; }
        public Application application { get; set; }
        public ProgramNav ProgramNav { get; set; }
    }
    public class Root1
    {
        public D1 d { get; set; }
    }
    //
    //Employedment Detail
    public class D2
    {
        public List<Result2> results { get; set; }
    }   
    public class EmployerNav
    {
        public Deferred __deferred { get; set; }
    }
    public class JobFunctionNav
    {
        public Deferred __deferred { get; set; }
    }
    public class PresentEmployerNav
    {
        public Deferred __deferred { get; set; }
    }
    public class Result2
    {
        public Metadata __metadata { get; set; }
        public string backgroundElementId { get; set; }
        public string achievements { get; set; }
        public DateTime? lastModifiedDateTime { get; set; }
        public DateTime? endDate { get; set; }
        public object otheremployer { get; set; }
        public object jobFunction { get; set; }
        public string bgOrderPos { get; set; }
        public object employer { get; set; }
        public string applicationId { get; set; }
        public string otherFunction { get; set; }
        public DateTime? startDate { get; set; }
        public object presentEmployer { get; set; }
        public PresentEmployerNav presentEmployerNav { get; set; }
        public JobFunctionNav jobFunctionNav { get; set; }
        public EmployerNav employerNav { get; set; }
        public Application application { get; set; }
    }
    public class Root2
    {
        public D2 d { get; set; }
    }
    //
}

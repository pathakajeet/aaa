﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Net;
using System.IO;
using RestSharp;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;

public partial class ReportUpload : System.Web.UI.Page
{
    string connetionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
   

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGridview();
        }

    }

    private void BindGridview()
    {
        DataTable dt = new DataTable();
        string Query = "select ReportFileName, ReportFileExtention,VendorReferenceID,ClientId,UploadTime, CASE WHEN ReportColor = '2' THEN 'Red' WHEN ReportColor = '3' THEN 'Orange' WHEN ReportColor = '1' THEN 'Green'  END AS 'ReportColor', CASE WHEN ReportType = '1' THEN 'Interim' WHEN ReportType = '2' THEN 'Supplimentry' WHEN ReportType = '3' THEN 'Final'  END AS 'ReportType' from ReportUploads";
        using (SqlConnection con = new SqlConnection(connetionString))
        {
            DataTable ds = new DataTable();
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = Query;
            da.SelectCommand = cmd;
            da.Fill(ds);
            con.Close();
            grdFileUploadDownload.DataSource = ds;
            grdFileUploadDownload.DataBind();
        }
    }

    private DataSet getDataset(string query)
    {
        SqlConnection con = new SqlConnection(connetionString);
        con.Open();
        DataSet tempDataSet = new DataSet();
        SqlDataAdapter dap = new SqlDataAdapter(query, con);
        dap.Fill(tempDataSet);
        return tempDataSet;
    }

      public static DataTable Tabulate(string json)
    {
        var jsonLinq = JObject.Parse(json);       
        var srcArray = jsonLinq.Descendants().Where(d => d is JArray).First();
        var trgArray = new JArray();
        foreach (JObject row in srcArray.Children<JObject>())
        {
            var cleanRow = new JObject();
            foreach (JProperty column in row.Properties())
            {
               if (column.Value is JValue)
                {
                    cleanRow.Add(column.Name, column.Value);
                }
            }
            trgArray.Add(cleanRow);
        }
        return JsonConvert.DeserializeObject<DataTable>(trgArray.ToString());
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        if (txtrefid.Text == "")
        {
            lblMsg.Text = "Please Provide Refid!";
            lblMsg.ForeColor = System.Drawing.Color.OrangeRed;
            return;
        }

        if(ddlRptType.SelectedIndex == 0)
        {
            lblMsg.Text = "Please Provide Report Type!";
            lblMsg.ForeColor = System.Drawing.Color.OrangeRed;
            return;
        }

        if (ddlRptColor.SelectedIndex == 0)
        {
            lblMsg.Text = "Please Provide Report Color!";
            lblMsg.ForeColor = System.Drawing.Color.OrangeRed;
            return;
        }
        if (FileUpload1.HasFile == true && txtrefid.Text != "")
        {
            string filename = FileUpload1.PostedFile.FileName;

            //

            //string str = string.Format("select * from tbl_BS_Candidate_info where applicationId =" + Convert.ToInt32(txtrefid.Text.ToString()));
            string applicationid = "";
            string jobreqid = "";
            string candidateid ="";
            string Attachid = "";
            string temp_inBase64 = "";

            string str = string.Format("select * from tbl_BS_Candidate_info where applicationId =" + txtrefid.Text.ToString());
            DataSet ds1 = getDataset(str);
            if (ds1.Tables[0].Rows.Count > 0)
            {
               applicationid = ds1.Tables[0].Rows[0]["applicationId"].ToString();
               jobreqid = ds1.Tables[0].Rows[0]["jobReqId"].ToString();
               candidateid = ds1.Tables[0].Rows[0]["candidateId"].ToString();
            }
            
            string FilecontentType = FileUpload1.PostedFile.ContentType;
            using (Stream s = FileUpload1.PostedFile.InputStream)
            {
                using (BinaryReader br = new BinaryReader(s))
                {
                    byte[] Databytes = br.ReadBytes((Int32)s.Length);
                    temp_inBase64 = Convert.ToBase64String(Databytes);                  
                    
                }
            }

            // Sending Attachment file
            StringBuilder sa = new StringBuilder();
            sa.Append("{");
            sa.Append("    \"__metadata\": {");
            sa.Append("     \"uri\": \"Attachment\",");
            sa.Append("     \"type\": \"SFOData.Attachment\"");
            sa.Append("    }, ");
            sa.Append("    \"fileName\": \"" + filename + "\",");
            sa.Append("    \"module\": \"RECRUITING\",");
            sa.Append("    \"userId\": \"Deloitte_Integration\",");
            sa.Append("    \"fileContent\": \"" + temp_inBase64 + "\"");
            sa.Append("}");

            string finalResult1 = sa.ToString();
            var client1 = new RestClient("https://api44preview.sapsf.com/odata/v2/upsert");
            var request1 = new RestRequest(Method.POST);
            request1.AddHeader("Authorization", "Basic SW50ZWdyYXRpb25fUHJldmlld0BiaXJsYXNvZnRsVDE6V2VsY29tZUA5ODc=");
            request1.AddHeader("Content-Type", "application/json");
            request1.AddParameter("application/json", finalResult1, ParameterType.RequestBody);
            try
            {
                IRestResponse response1 = client1.Execute(request1);
                if (response1.StatusCode.ToString() == "OK")
                {
                    string Apiresponse1 = response1.Content;
                    DataTable Atts = Tabulate(Apiresponse1);
                    // Atts.Rows[0].ItemArray[0]
                    string[] Attkey = (Atts.Rows[0].ItemArray[0]).ToString().Split('=');
                    Attachid = Attkey[1].Replace(" \" ", "");
                }
            }
            catch (Exception ex)
            {
            }

            //Sending Report
            StringBuilder sa1 = new StringBuilder();
            sa1.Append("{");
            sa1.Append("    \"__metadata\": {");
            sa1.Append("        \"uri\": \"JobApplication\",");
            sa1.Append("        \"type\": \"SFOData.JobApplication\"");
            sa1.Append("    },");
            sa1.Append("    \"jobReqId\": \"" + jobreqid + "\",");
            sa1.Append("    \"applicationId\": \"" + applicationid + "\",");
            sa1.Append("    \"cust_BGC_IISERVZ_ResultFinalComment\": \"Check Complete\",");
            sa1.Append("    \"cust_BGC_IISERVZ_ResultColorCode\": \"Green\",");
            sa1.Append("    \"cust_BGC_IISERVZ_ResultPDFReport\": {");
            sa1.Append("        \"__metadata\": {");
            sa1.Append("            \"uri\": \"Attachment(" + Attachid + "L)\"");
            sa1.Append("        }");
            sa1.Append("    }");
            sa1.Append("}");

            string finalResult2 = sa.ToString();
            var client2 = new RestClient("https://api44preview.sapsf.com/odata/v2/upsert");
            var request2 = new RestRequest(Method.POST);
            request2.AddHeader("Authorization", "Basic SW50ZWdyYXRpb25fUHJldmlld0BiaXJsYXNvZnRsVDE6V2VsY29tZUA5ODc=");
            request2.AddHeader("Content-Type", "application/json");
            request2.AddParameter("application/json", finalResult2, ParameterType.RequestBody);
            try
            {
                IRestResponse response2 = client2.Execute(request2);
                if (response2.StatusCode.ToString() == "OK")
                {
                    string Apiresponse2 = response2.Content;
                    DataTable Frs = Tabulate(Apiresponse2);
                }
            }
            catch (Exception ex)
            {
            }
            //

            int i = -1;
            string[] filepathSplit = filename.Split('\\');
            foreach (string arrStr in filepathSplit)
            {
                i++;
            }
            string file = filepathSplit[i].ToString();

            string extension = Path.GetExtension(file);
            string fileRename = filename;
            FileUpload1.PostedFile.SaveAs(Server.MapPath("~\\ReportUploded\\") + fileRename);
            SqlConnection con = new SqlConnection(connetionString);
            con.Open();
            SqlCommand com = new SqlCommand("ReportUpload_insert", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add("@ReportFileName", SqlDbType.VarChar).Value = fileRename;
            com.Parameters.Add("@ReportFileExtention", SqlDbType.VarChar, 50).Value = extension;
            com.Parameters.Add("@VendorReferenceID", SqlDbType.VarChar, 50).Value = txtrefid.Text.ToString();
            com.Parameters.Add("@ReportType", SqlDbType.VarChar).Value = ddlRptType.SelectedIndex;
            com.Parameters.Add("@ReportStatus", SqlDbType.VarChar, 50).Value = "1";
            com.Parameters.Add("@ClientId", SqlDbType.VarChar, 50).Value = "";
            com.Parameters.Add("@ReportColor", SqlDbType.VarChar, 50).Value = ddlRptColor.SelectedIndex;
            int ip = com.ExecuteNonQuery();
            lblMsg.Text = "Your File Successful Uploaded!";
            lblMsg.ForeColor = System.Drawing.Color.Green;
            con.Close();
            BindGridview();
            ddlRptType.SelectedIndex = 0;
            ddlRptColor.SelectedIndex = 0;
            txtrefid.Text = "";

        }

        else
        {
            //Response.Write("<Script Language='javascript'> alert('File Not Uploaded!')</Script>");
            lblMsg.Text = "Please Select File for Upload!";
            lblMsg.ForeColor = System.Drawing.Color.OrangeRed;
            return;
        }
    }
    protected void grdFileUploadDownload_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string filename = Convert.ToString(e.CommandArgument);
        if (filename != "")
        {
            string FolderPath = Server.MapPath("~\\ReportUploded\\");
            string path = FolderPath + filename;
            System.IO.FileInfo file = new System.IO.FileInfo(path);
            if (file.Exists)
            {
                Response.Clear();
                Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);
                Response.AddHeader("Content-Length", file.Length.ToString());
                Response.ContentType = "application/octet-stream";
                Response.WriteFile(file.FullName);
                Response.End();
            }

            else

                Response.Write("");

        }
    }
}

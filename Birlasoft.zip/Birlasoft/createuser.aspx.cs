﻿using System;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.SqlClient;
using IISERVZCLASS;
using DataAccess;
using classgen1;
using EmployeeInfonamespace;
using CandidateInfonamespace;
using procall1;
using Casestatus;
using UploadDownloadManager;
using System.Data.OleDb;




public partial class createuser : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
    CandidateInfonamespace.CandidateDetails candidateobj = new CandidateInfonamespace.CandidateDetails();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            try
            {
                if (Session["UserType"].ToString() == null)
                {
                    Response.Redirect("Logout.aspx");
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("Logout.aspx");
            }
            
        }
        string str = Session["UserType"].ToString();
        string username = Session["UserName"].ToString();
        Txtdoj.Attributes.Add("readonly", "readonly");
        txtDateOfBirth.Attributes.Add("readonly", "readonly");
        if (username == "kpmg" && str == "ClientPlusReject")
        {
            //fc.Visible = false;
            //bs.Visible = false;
        }
        else
        {
            //fc.Visible = true;
            //bs.Visible = true;
        }
         if (str == "Admin")
        {
            //td1.Visible = false;
            //td2.Visible = true;
            //rj.Visible = false;
            //fc.Visible = false;
            //rj.Visible = false;


        }
        if (str == "Hiring")
        {
            //td1.Visible = false;
            //td2.Visible = false;
            //rj.Visible = false;
            //fc.Visible = false;
            //rj.Visible = false;

        }
        if (str == "ClientPlusReject")
        {
            //td1.Visible = true;
            //td2.Visible = false;
            //rj.Visible = true;
           

        }

        if (!IsPostBack)
        {
            Page.Validate();
            
        }
    }



    private DataSet getDataset(string query)
    {
        DataSet tempDataSet = new DataSet();
        SqlDataAdapter dap = new SqlDataAdapter(query, con);
        dap.Fill(tempDataSet);
        return tempDataSet;
    }
    public static string CreateRandomPassword(int PasswordLength)
    {
        string _allowedChars = "0123456789abcdefghijklmnopqrstuvwxyz";
        Random randNum = new Random();
        char[] chars = new char[PasswordLength];
        int allowedCharCount = _allowedChars.Length;
        for (int i = 0; i < PasswordLength; i++)
        {
            chars[i] = _allowedChars[(int)((_allowedChars.Length) * randNum.NextDouble())];
        }
        return new string(chars);
    }
    protected void btn_Click(object sender, EventArgs e)
    {

        btn.Attributes.Add("OnClientClick", "if (! confirm(''Are you sure you want to add this estimate data??')) return false;");
      
        candidateobj.band4candidatename = txtCandidateName.Text.Trim().ToString();
        candidateobj.band4middlename = middlename.Text.Trim().ToString();
        candidateobj.band4surname = surname.Text.Trim().ToString();
        candidateobj.band4emailid = txtEmail.Text.Trim().ToString();
        candidateobj.band4mobile = txtMobile.Text.Trim().ToString();
        candidateobj.FatherName = txtFatherName.Text.Trim().ToString();
        candidateobj.DOB = txtDateOfBirth.Text.Trim().ToString();
        candidateobj.Category = dprcategory.SelectedItem.Text.Trim().ToString();
        candidateobj.DateofJoining = Txtdoj.Text.Trim().ToString();
        candidateobj.Empid = txtempid.Text.Trim().ToString();
        

   
        string password = CreateRandomPassword(8);


        int dc = candidateobj.doublecheck(candidateobj);
        if (dc != 0)
        {
            Response.Write("<Script Language='javascript'> alert('Data already Exists !')</Script>");

        }
        else
        {
            int dtInsert = candidateobj.candidateband4info(candidateobj, password);

            if (dtInsert == 0)
            {
                Response.Write("<Script Language='javascript'> alert('Detail Saved and the Candidate will receive his/her login detail through an email.')</Script>");
                Server.Transfer("createuser.aspx");

            }
            else if (dtInsert == -2)
            {

                Response.Write("<Script Language='javascript'> alert('Already Data Saved !')</Script>");
            }
            else if (dtInsert == -1)
            {

                Response.Write("<Script Language='javascript'> alert('Error In Procedure...InsertEmployeeInfo!')</Script>");
            }
        }


    }
    protected void btnSend_Click(object sender, EventArgs e)
    {
        if (GridView1.Rows.Count > 0)
        {
            string firstnme = string.Empty;
            string middlename = string.Empty;
            string surname = string.Empty;
            string emailid = string.Empty;
            string mobileno = string.Empty;
            string fathername = string.Empty;
            string hrmanagername = string.Empty;
            string hrmangeremailid = string.Empty;
            string dob = string.Empty;
            string category = string.Empty;
            string doj = string.Empty;
            string processname = string.Empty;
            string Empid = string.Empty;







            int GVCount = GridView1.Rows.Count;

            foreach (GridViewRow GVRow in GridView1.Rows)
            {
                firstnme = GVRow.Cells[0].Text;
                middlename = GVRow.Cells[1].Text;
                surname = GVRow.Cells[2].Text;
                emailid = GVRow.Cells[3].Text;
                mobileno = GVRow.Cells[4].Text;
                fathername = GVRow.Cells[5].Text;

                dob = GVRow.Cells[6].Text;
                category = GVRow.Cells[7].Text;
                doj = GVRow.Cells[8].Text;
                Empid = GVRow.Cells[9].Text;







                //if (firstnme != "&nbsp;" && emailid != "&nbsp;" && surname != "&nbsp;" && category != "&nbsp;" && mobileno != "&nbsp;" && processname != "&nbsp;" && Empid!="&nbsp;")
                    if (firstnme != "&nbsp;")
                {
                    candidateobj.band4candidatename = (firstnme == "&nbsp;") ? "" : firstnme;
                    candidateobj.band4middlename = (middlename == "&nbsp;") ? "" : middlename;
                    candidateobj.band4surname = (surname == "&nbsp;") ? "" : surname;
                    candidateobj.band4emailid = (emailid == "&nbsp;") ? "" : emailid;
                    candidateobj.band4mobile = (mobileno == "&nbsp;") ? "" : mobileno;

                    candidateobj.DOB = (dob == "&nbsp;") ? "" : dob;
                    candidateobj.Category = (category == "&nbsp;") ? "" : category;

                    candidateobj.FatherName = (fathername == "&nbsp;") ? "" : fathername;
                    candidateobj.DateofJoining = (doj == "&nbsp;") ? "" : doj;

                    candidateobj.Empid = (Empid == "&nbsp;") ? "" : Empid;

                    string password = CreateRandomPassword(8);
                    string username = User.Identity.Name.ToString();
                    candidateobj.user = Session["UserName"].ToString();

                    int dc = candidateobj.doublecheck(candidateobj);
                    int dtInsert = candidateobj.candidateband4info(candidateobj, password);
                    //if (dc != 0)
                    //{
                    //    Response.Write("<Script Language='javascript'> alert('OHRID-"+ohrid+" already Exists !')</Script>");

                    //}
                    //else
                    //{
                    //    int dtInsert = candidateobj.candidateband4info(candidateobj, password);
                    //}

                }

            }
            Response.Write("<script>alert('Data Uploaded');</script>");
        }
        else
        {
            Response.Write("<script>alert('Please Choose Records for Upload!');</script>");
        }

    }
    public void uploadFile()
    {
        FileUploadDownloadManager fm = new FileUploadDownloadManager();

        if (fileuploadExcel.HasFile == true)
        {
            string filename = fileuploadExcel.PostedFile.FileName;
            string file = System.IO.Path.GetFileName(filename);
            fileuploadExcel.PostedFile.SaveAs(Server.MapPath("~\\UplodedWiproExcel\\") + DateTime.Now.ToString().Replace("/", "-").Replace(" ", "").Replace(":", "-").Trim() + "-" + file);
            file = Server.MapPath("~\\UplodedWiproExcel\\") + DateTime.Now.ToString().Replace("/", "-").Replace(" ", "").Replace(":", "-").Trim() + "-" + file;

            string strConn;
            strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + file + ";Extended Properties='Excel 12.0 Xml;HDR=YES;Persist Security Info=False;'";



            string query = String.Format("select * from [Sheet1$]");
            OleDbDataAdapter myCmd = new OleDbDataAdapter(query, strConn);
            myCmd.Fill(ds);
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("createuser.aspx");
    }
    protected void format_Click(object sender, EventArgs e)
    {
        string filename = "Canidate.xlsx";




        if (filename != "")
        {

            string FolderPath = Server.MapPath("~\\Uploaded\\");
            string path = FolderPath + filename;

            System.IO.FileInfo file = new System.IO.FileInfo(path);

            if (file.Exists)
            {

                Response.Clear();

                Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);

                Response.AddHeader("Content-Length", file.Length.ToString());

                Response.ContentType = "application/octet-stream";

                Response.WriteFile(file.FullName);

                Response.End();

            }

            else


                Response.Write("");



        }
    }
    protected void Btnshow_Click(object sender, EventArgs e)
    {
 
        if (fileuploadExcel.HasFile == true)
        {
            uploadFile();
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
        }
        else
        {
            Response.Write("<script>alert('Please Choose a File!');</script>");
        }


    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //e.Row.Cells[4].Visible = false;
    }
    protected void btnshowunuploaded_Click(object sender, EventArgs e)
    {
        //ds = gen.showunuploadeddata();
        //GridView1.DataSource = ds;
        //GridView1.DataBind();
    }
    protected void btnPassport_Click(object sender, EventArgs e)
    {

    }
}
﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web.Services;
using System.Data.SqlClient;
using System.Configuration;
using IISERVZ;

public partial class DashBoard : System.Web.UI.Page
{

    String tatMonth;
    String talvalue;
    String withintatvalue;

    String green;
    String red;
    String amber;
    String ColorMonth;
    String PiChart;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {

            if (Session["UserType"] == null)
            {
                Response.Redirect("HRLogin.aspx");
            }
            else
            {
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");
            }


        }

        if (!Page.IsPostBack)
        {
            ClassDashBoard obj = new ClassDashBoard();

            DataTable dt = obj.ShowTat("out", "Omega Healthcare");
            //'June', 'July', 'August', 'September', 'October', 'November', 'December','February', 'March', 'April', 'May'
            //10,15,18,25,11,19,15,10,3,2,5,50
            //TotalCase,MonthValue 
            int count = 0;

            // Code For Out Tat Value ***************
            foreach (DataRow r in dt.Rows)
            {
                if (count == 0)
                {
                    tatMonth = "'" + r["MonthValue"].ToString() + "'";
                }
                else
                {
                    tatMonth = tatMonth + "," + "'" + r["MonthValue"].ToString() + "'";
                }

                if (count == 0)
                {
                    talvalue = r["TotalCase"].ToString();
                }
                else
                {
                    talvalue = talvalue + "," + r["TotalCase"].ToString();
                }

                count = 1;

            }


            // Code For Within Tat Value ***************
            count = 0;
            dt = obj.ShowTat("within", "Omega Healthcare");
            foreach (DataRow r in dt.Rows)
            {
                if (count == 0)
                {
                    withintatvalue = r["TotalCase"].ToString();
                }
                else
                {
                    withintatvalue = withintatvalue + "," + r["TotalCase"].ToString();
                }

                count = 1;

            }





            #region ColorCode

            count = 0;
            dt = obj.ShowTatColor("Omega Healthcare");
            //TotalCase,MonthValue,TatStatus

            foreach (DataRow r in dt.Rows)
            {
                if (count == 0)
                {
                    ColorMonth = "'" + r["MonthValue"].ToString() + "'";
                }
                else
                {
                    if (!ColorMonth.Contains(r["MonthValue"].ToString()))
                    {
                        ColorMonth = ColorMonth + "," + "'" + r["MonthValue"].ToString() + "'";
                    }

                }



                if (count == 0)
                {

                    green = r["Green"].ToString();
                    red = r["Red"].ToString();
                    amber = r["Amber"].ToString();

                }
                else
                {

                    green = green + "," + r["Green"].ToString();
                    red = red + "," + r["Red"].ToString();
                    amber = amber + "," + r["Amber"].ToString();

                }

                count = 1;

            }

            #endregion


            /****************
             * Total BGS case Statuse ****
             * *****/
            dt = obj.ShowBGCStatus("Omega Healthcare");
            if (dt.Rows.Count > 0)
            {
                gridStatus.Visible = true;
                gridStatus.DataSource = dt;
                gridStatus.DataBind();
            }
            else
            {
                gridStatus.Visible = false;
            }


            int Month = DateTime.Now.Month;

            foreach (DataRow r in dt.Rows)
            {
                if (Month.ToString() == r["mont"].ToString())
                {
                    PiChart = r["INSUFF"].ToString() + "," + r["WIP"].ToString() + "," + r["Closed"].ToString() + "," + r["Closed"].ToString();
                }
            }



        }




    }


    public String GetPaiChart()
    {
        return PiChart;
    }

    public string GetTatMonth()
    {
        return tatMonth;
    }


    public string GetTatValue()
    {
        return talvalue;
    }

    public string GetWithinTat()
    {
        return withintatvalue;
    }

    public string GetColorMonth()
    {
        return ColorMonth;
    }

    public string GetColorGreen()
    {
        return green;
    }
    public string GetColorRed()
    {
        return red;
    }
    public string GetColorAmber()
    {
        return amber;
    }
}
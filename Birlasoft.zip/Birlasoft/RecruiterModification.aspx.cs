﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DataAccess;
using procall1;
using Casestatus;
using System.Drawing;
using IISERVZCLASS;
using System.Text;
using System.Net;

public partial class RecruiterModification : System.Web.UI.Page
{
    CandidateInfonamespace.CandidateDetails candidateobj = new CandidateInfonamespace.CandidateDetails();

    procall pc = new procall();
    DataSet ds = new DataSet();
    string localComputerName = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["UserType"] == null)
            {
                Response.Redirect("HrLogin.aspx");
            }
            if (Session["UserType"].ToString() == "Hiring")
            {
                Response.Redirect("CandidateLogin.aspx");
            }
        }


        if (!IsPostBack)
        {
            //ds = pc.showallreqruiterdata();
            string username = Session["UserName"].ToString();
            ds = pc.acceptreject(username);
            GridView1.DataSource = ds;
            GridView1.DataBind();

            GridView1.Columns[1].Visible = false;
            GridView1.Columns[4].Visible = false;
            GridView1.Columns[5].Visible = false;
            GridView1.Columns[6].Visible = false;


        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    public string Encript(String RefId)
    {
        ValidateLogin obj = new ValidateLogin();
        string val = obj.Encrypt(RefId);
        return val;
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string strScript = "uncheckOthers(" + ((CheckBox)e.Row.Cells[0].FindControl("caseinitialize")).ClientID + ");";
            ((CheckBox)e.Row.Cells[0].FindControl("caseinitialize")).Attributes.Add("onclick", "javascript:return Selectone(this,'" + GridView1.ClientID + "');");

            ((CheckBox)e.Row.FindControl("caseinitialize")).Attributes.Add("onclick", "javascript:return HideandShowTextBox('" + ((CheckBox)e.Row.FindControl("caseinitialize")).ClientID + "*" + ((Button)e.Row.FindControl("btn1")).ClientID + "')");

            ((CheckBox)e.Row.FindControl("rejectcase")).Attributes.Add("onclick", "javascript:return HideandShowTextBox('" + ((CheckBox)e.Row.FindControl("rejectcase")).ClientID + "*" + ((TextBox)e.Row.FindControl("txtremarks")).ClientID + "*" + ((Button)e.Row.FindControl("btn2")).ClientID + "')");

            ((CheckBox)e.Row.FindControl("followup")).Attributes.Add("onclick", "javascript:return HideandShowTextBox('" + ((CheckBox)e.Row.FindControl("followup")).ClientID + "*" + ((Button)e.Row.FindControl("btnfl")).ClientID + "')");
            ((CheckBox)e.Row.FindControl("stop")).Attributes.Add("onclick", "javascript:return HideandShowTextBox('" + ((CheckBox)e.Row.FindControl("stop")).ClientID + "*" + ((Button)e.Row.FindControl("btnstop")).ClientID + "')");
            ((Button)e.Row.FindControl("btn1")).Style.Add("display", "none");
            ((Button)e.Row.FindControl("btn2")).Style.Add("display", "none");
            ((Button)e.Row.FindControl("btnfl")).Style.Add("display", "none");
            ((Button)e.Row.FindControl("btnstop")).Style.Add("display", "none");
            ((TextBox)e.Row.FindControl("txtremarks")).Style.Add("display", "none");



            ((CheckBox)e.Row.FindControl("chkemail")).Attributes.Add("onclick", "javascript:return HideandShowTextBox('" + ((CheckBox)e.Row.FindControl("chkemail")).ClientID + "*" + ((TextBox)e.Row.FindControl("txtemailid")).ClientID + "*" + ((Button)e.Row.FindControl("btnUpload")).ClientID + "')");
            ((Button)e.Row.FindControl("btnUpload")).Style.Add("display", "none");
            ((TextBox)e.Row.FindControl("txtemailid")).Style.Add("display", "none");



        }

    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "btn1")// for accept
            {
                procall pc = new procall();
                DataSet ds = new DataSet();
                for (int i = 0; i < GridView1.Rows.Count; i++)
                {
                    GridViewRow row = GridView1.Rows[i];
                    bool isrevert = ((CheckBox)row.FindControl("caseinitialize")).Checked;
                    if (isrevert)
                    {
                        string acceptuser = Session["UserName"].ToString();
                        string candidateid = GridView1.Rows[i].Cells[8].Text;
                        string name = GridView1.Rows[i].Cells[10].Text;

                        candidateobj.accept(candidateid, name, acceptuser);



                        //ds = candidateobj.SmsMobileNumber(candidateid);

                        //string mobile = ds.Tables[0].Rows[0]["Mobile"].ToString();
                        //string username = ds.Tables[0].Rows[0]["UserName"].ToString();
                        //string candidatename = candidateid + "-" + name;

                        //string URL = "";

                        //URL = "http://203.122.58.168/prepaidgetbroadcast/PrepaidGetBroadcast?userid=iiservz&pwd=arun1234&msgtype=s&ctype=1&sender=IISERV&pno=" + mobile + "&msgtxt=Dear+" + username + "%2C%0A%0AThe+candidate+" + candidatename + "+has+been+Accepted+for+verification+done+by+IISERVZ.&alert=1";

                        //HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(URL);
                        //request.Method = "POST";
                        //HttpWebResponse response = (HttpWebResponse)request.GetResponse();


                    }

                }
                Response.Write("<Script Language='javascript'> alert('Case has been Accepted')</Script>");
                string strplace;


                strplace = "";


                ds = pc.acceptreject(strplace);
                GridView1.DataSource = ds;
                GridView1.DataBind();


            }
            if (e.CommandName == "btn2") // for reject
            {
                // Retrieve the row index stored in the 
                // CommandArgument property.
                //// int index = Convert.ToInt32(e.CommandArgument);

                // Retrieve the row that contains the button 
                // from the Rows collection.
                ////GridViewRow row = GridView1.Rows[index];

                // Add code here to add the item to the shopping cart.
                procall pc = new procall();
                DataSet ds = new DataSet();
                for (int i = 0; i < GridView1.Rows.Count; i++)
                {
                    GridViewRow row = GridView1.Rows[i];
                    bool isrevert = ((CheckBox)row.FindControl("rejectcase")).Checked;
                    if (isrevert)
                    {

                        string rejectuser = Session["UserName"].ToString();
                        Status st = new Status();
                        string candidateid = GridView1.Rows[i].Cells[8].Text;
                        string name = GridView1.Rows[i].Cells[10].Text;
                        string remarks = ((TextBox)row.FindControl("txtremarks")).Text;


                        string ii = st.reject(candidateid, name, rejectuser, remarks);


                        //ds = candidateobj.SmsMobileNumber(candidateid);

                        //string mobile = ds.Tables[0].Rows[0]["Mobile"].ToString();
                        //string username = ds.Tables[0].Rows[0]["UserName"].ToString();
                        //string candidatename = candidateid + "-" + name;


                        //string URL = "";

                        //URL = "http://203.122.58.168/prepaidgetbroadcast/PrepaidGetBroadcast?userid=iiservz&pwd=arun1234&msgtype=s&ctype=1&sender=IISERV&pno=" + mobile + "&msgtxt=Dear+" + username + "%2C%0A%0AThe+candidate+" + candidatename + "+has+been+Rejected+for+verification+done+by+IISERVZ.&alert=1";

                        //HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(URL);
                        //request.Method = "POST";
                        //HttpWebResponse response = (HttpWebResponse)request.GetResponse();




                    }

                }
                Response.Write("<Script Language='javascript'> alert('Case has been Reject')</Script>");
                string strplace;

                strplace = "";
                ds = pc.acceptreject(strplace);
                GridView1.DataSource = ds;
                GridView1.DataBind();

            }


            if (e.CommandName == "Updatee") // for Alter Name
            {

                procall pc = new procall();
                DataSet ds = new DataSet();
                for (int i = 0; i < GridView1.Rows.Count; i++)
                {
                    GridViewRow row = GridView1.Rows[i];
                    bool isrevert = ((CheckBox)row.FindControl("chkemail")).Checked;
                    if (isrevert)
                    {

                        string rejectuser = Session["UserName"].ToString();
                        Status st = new Status();
                        string mobile = GridView1.Rows[i].Cells[16].Text;
                        string name = GridView1.Rows[i].Cells[10].Text;
                        string remarks = ((TextBox)row.FindControl("txtemailid")).Text;

                        string ii = st.updateemail(mobile, name, rejectuser, remarks);


                    }

                }
                Response.Write("<Script Language='javascript'> alert('Email ID Has Been Updated')</Script>");
                string strplace;

                strplace = "";
                ds = pc.acceptreject(strplace);
                GridView1.DataSource = ds;
                GridView1.DataBind();

            }


            if (e.CommandName == "btnfl") // for reject
            {
                // Retrieve the row index stored in the 
                // CommandArgument property.
                //// int index = Convert.ToInt32(e.CommandArgument);

                // Retrieve the row that contains the button 
                // from the Rows collection.
                ////GridViewRow row = GridView1.Rows[index];

                // Add code here to add the item to the shopping cart.
                procall pc = new procall();
                DataSet ds = new DataSet();
                for (int i = 0; i < GridView1.Rows.Count; i++)
                {
                    GridViewRow row = GridView1.Rows[i];
                    bool isrevert = ((CheckBox)row.FindControl("followup")).Checked;
                    if (isrevert)
                    {

                        string user = Session["UserName"].ToString();
                        Status st = new Status();



                        string mobile = GridView1.Rows[i].Cells[16].Text;

                        string ii = st.Fnsmail(mobile);


                        //ds = candidateobj.SmsMobileNumber(candidateid);

                        //string mobile = ds.Tables[0].Rows[0]["Mobile"].ToString();
                        //string username = ds.Tables[0].Rows[0]["UserName"].ToString();
                        //string candidatename = candidateid + "-" + name;


                        //string URL = "";

                        //URL = "http://203.122.58.168/prepaidgetbroadcast/PrepaidGetBroadcast?userid=iiservz&pwd=arun1234&msgtype=s&ctype=1&sender=IISERV&pno=" + mobile + "&msgtxt=Dear+" + username + "%2C%0A%0AThe+candidate+" + candidatename + "+has+been+Rejected+for+verification+done+by+IISERVZ.&alert=1";

                        //HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(URL);
                        //request.Method = "POST";
                        //HttpWebResponse response = (HttpWebResponse)request.GetResponse();




                    }

                }
                Response.Write("<Script Language='javascript'> alert('Reminder mail Has been sent')</Script>");

                GridView1.Visible = true;
                ds = pc.SearchbyClientt(Session["userName"].ToString(), Session["UserType"].ToString(), "", "", "FNS");
                if (ds.Tables.Count > 0)
                {
                    GridView1.DataSource = ds;
                    GridView1.DataBind();
                }


                GridView1.Columns[1].Visible = false;
                GridView1.Columns[0].Visible = false;
                GridView1.Columns[2].Visible = false;
                GridView1.Columns[3].Visible = false;
                GridView1.Columns[4].Visible = true;
                GridView1.Columns[5].Visible = true;


            }


            if (e.CommandName == "btnstop") // for reject
            {
                // Retrieve the row index stored in the 
                // CommandArgument property.
                //// int index = Convert.ToInt32(e.CommandArgument);

                // Retrieve the row that contains the button 
                // from the Rows collection.
                ////GridViewRow row = GridView1.Rows[index];

                // Add code here to add the item to the shopping cart.
                procall pc = new procall();
                DataSet ds = new DataSet();
                for (int i = 0; i < GridView1.Rows.Count; i++)
                {
                    GridViewRow row = GridView1.Rows[i];
                    bool isrevert = ((CheckBox)row.FindControl("stop")).Checked;
                    if (isrevert)
                    {

                        string user = Session["UserName"].ToString();
                        Status st = new Status();



                        string mobile = GridView1.Rows[i].Cells[16].Text;

                        string ii = st.FNSstop(mobile);


                        //ds = candidateobj.SmsMobileNumber(candidateid);

                        //string mobile = ds.Tables[0].Rows[0]["Mobile"].ToString();
                        //string username = ds.Tables[0].Rows[0]["UserName"].ToString();
                        //string candidatename = candidateid + "-" + name;


                        //string URL = "";

                        //URL = "http://203.122.58.168/prepaidgetbroadcast/PrepaidGetBroadcast?userid=iiservz&pwd=arun1234&msgtype=s&ctype=1&sender=IISERV&pno=" + mobile + "&msgtxt=Dear+" + username + "%2C%0A%0AThe+candidate+" + candidatename + "+has+been+Rejected+for+verification+done+by+IISERVZ.&alert=1";

                        //HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(URL);
                        //request.Method = "POST";
                        //HttpWebResponse response = (HttpWebResponse)request.GetResponse();




                    }

                }
                Response.Write("<Script Language='javascript'> alert('The Case Has been Stopped')</Script>");

                GridView1.Visible = true;
                ds = pc.SearchbyClientt(Session["userName"].ToString(), Session["UserType"].ToString(), "", "", "FNS");
                if (ds.Tables.Count > 0)
                {
                    GridView1.DataSource = ds;
                    GridView1.DataBind();
                }


                GridView1.Columns[1].Visible = false;
                GridView1.Columns[0].Visible = false;
                GridView1.Columns[2].Visible = false;
                GridView1.Columns[3].Visible = false;
                GridView1.Columns[4].Visible = true;
                GridView1.Columns[5].Visible = true;


            }



        }
        catch (Exception ex)
        {
            Response.Write("<script language='javascript'>alert('" + ex.Message + "')</script>");
        }
    }

    private string reject(string p, string candidateid, string name, string location)
    {
        throw new NotImplementedException();
    }
    protected void btnexporttoexcel_Click(object sender, EventArgs e)
    {
        if (GridView1.Rows.Count > 0)
        {

            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                GridView1.HeaderRow.Cells[0].Visible = false;
                GridView1.HeaderRow.Cells[1].Visible = false;
                GridView1.HeaderRow.Cells[2].Visible = false;
                GridView1.HeaderRow.Cells[3].Visible = false;

                GridViewRow row = GridView1.Rows[i];
                row.Cells[0].Visible = false;
                row.Cells[1].Visible = false;
                row.Cells[2].Visible = false;
                row.Cells[3].Visible = false;

            }

            GridView1.HeaderStyle.BackColor = System.Drawing.Color.White;
            GridView1.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            GridView1.ForeColor = System.Drawing.Color.Black;
            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=FRESH-CASES" + DateTime.Now.ToString("dd-MM-yyyy") + ".xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.xls";
            this.EnableViewState = false;
            System.IO.StringWriter stringWrite = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
            HtmlForm form1 = new HtmlForm();
            this.Controls.Add(form1);

            form1.Controls.Add(GridView1);
            form1.RenderControl(htmlWrite);

            Response.Write(stringWrite.ToString());
            Response.End();
        }
        else
        {
            Response.Write("<Script Language='javascript'> alert('No Rows!')</Script>");
        }
    }
    protected void btnfns_Click(object sender, EventArgs e)
    {
        procall pc = new procall();
        DataSet ds = new DataSet();
        GridView1.Visible = true;
        ds = pc.SearchbyClientt(Session["userName"].ToString(), Session["UserType"].ToString(), "", "", "FNS");
        if (ds.Tables.Count > 0)
        {
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }


        GridView1.Columns[1].Visible = false;
        GridView1.Columns[0].Visible = false;
        GridView1.Columns[2].Visible = false;
        GridView1.Columns[3].Visible = false;
        GridView1.Columns[4].Visible = true;
        GridView1.Columns[5].Visible = true;
        GridView1.Columns[6].Visible = true;

    }
    protected void btnaccept_Click(object sender, EventArgs e)
    {
        GridView1.Visible = true;
        string strplace;
        GridView1.Columns[1].Visible = true;
        GridView1.Columns[0].Visible = true;
        GridView1.Columns[2].Visible = true;
        GridView1.Columns[3].Visible = true;
        GridView1.Columns[1].Visible = false;
        GridView1.Columns[4].Visible = false;
        GridView1.Columns[5].Visible = false;
        GridView1.Columns[6].Visible = false;

        strplace = "";
        if (GridView1.Rows.Count > 0)
        {
            ds = pc.acceptreject(strplace);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
        else
        {
            Response.Write("<Script Language='javascript'> alert('No Rows!')</Script>");
        }

    }
    protected void btndigital_Click(object sender, EventArgs e)
    {
        //  procall pc = new procall();
        //  DataSet ds = new DataSet();
        //  GridView1.Visible = false;
        //  GridView2.Visible = true;
        //   ds = pc.showloa();
        //   GridView2.DataBind();
        //GridView2.DataSource = ds;
        //  //if (GridView2.Rows.Count > 0)
        //  //{
        //  //    ds = pc.showloa();
        //  //    GridView2.DataSource = ds;
        //  //    GridView2.DataBind();
        //  //}
        //  //else
        //  //{
        //  //    Response.Write("<Script Language='javascript'> alert('No Rows!')</Script>");
        //  //}

    //    procall pc = new procall();
    //    DataSet ds = new DataSet();
    //    GridView1.Visible = true;
    //    ds = pc.showloa();
    //    if (ds.Tables.Count > 0)
    //    {
    //        GridView1.DataSource = ds;
    //        GridView1.DataBind();
    //    }


    //    GridView1.Columns[2].Visible = false;
    //    GridView1.Columns[0].Visible = false;
    //    GridView1.Columns[3].Visible = false;
    //    GridView1.Columns[1].Visible = true;
    }
}

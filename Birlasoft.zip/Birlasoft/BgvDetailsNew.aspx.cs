﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Net;
using RestSharp;
using System.Xml;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;

public partial class BgvDetailsNew : System.Web.UI.Page
{
    DataTable ds = new DataTable();
    DataSet ds1 = new DataSet();
    DataSet ds2 = new DataSet();
    DataSet ds3 = new DataSet();
    DataSet tempdemo = new DataSet();
    SqlDataAdapter adapter = new SqlDataAdapter();
    string sql = null;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {
        //var clients = new RestClient("https://api44preview.sapsf.com/odata/v2/JobApplication?$format=json&$select=candidateId,applicationId,firstName,middleName,lastName,cellPhone,dateOfBirth,cust_curaddress,cust_addressLine2,cust_curLandmark,cust_curzip,cust_curcountry/localeLabel,cust_curstate/localeLabel,cust_curcity,cust_curPeriodofStay,cust_curtilldate,cust_curperiodofstayend,cust_instrCurrentaddress,cust_Permaddline1,cust_Permaddline2,cust_Permlandmark,cust_Permzip,cust_Permcountry/localeLabel,cust_Permstate1/localeLabel,cust_Permcity1,cust_Permperiodofstay,cust_Permtilldate,cust_Permperiodofstayend,cust_instrPermaddress,custaddressproof/fileContent,custaddressproof/fileExtension,custaddressproof/fileName,custaddressproof/mimeType,cust_highcomedu,cust_uni1,cust_insname1,cust_coursecom1,cust_roll1,cust_endyr1,cust_Empname1,cust_startdate1,cust_tenenddate1,cust_empid1,cust_LastDesig,cust_Reasonforchange,cust_UAN,custLetterOfAuthorization/fileContent,custLetterOfAuthorization/fileExtension,custLetterOfAuthorization/fileName,custLetterOfAuthorization/mimeType,cust_instrref1,cust_name1,cust_org1,cust_rel1,cust_num1,cust_instrref2, cust_name2, cust_org2,cust_rel2,cust_num2,cust_instrref3,cust_name3,cust_org3,cust_rel3,cust_num3,custeducationdetails/fileContent,custeducationdetails/fileExtension,custeducationdetails/fileName,custeducationdetails/mimeType,cust_BGCApplicableType/localeLabel,cust_instrBGCIISERVZ,custPANattach/fileContent,custPANattach/fileExtension,custPANattach/fileName,custPANattach/mimeType,custAadhaarattach/fileContent,custAadhaarattach/fileExtension,custAadhaarattach/fileName,custAadhaarattach/mimeType&$expand=custLetterOfAuthorization,cust_curcountry,cust_curstate,cust_Permcountry,cust_Permstate1,custaddressproof,custeducationdetails,cust_BGCApplicableType,custPANattach,custAadhaarattach");
        //var clients = new RestClient("https://api44preview.sapsf.com/odata/v2/JobApplication?$format=json&$select=candidateId,applicationId,firstName,middleName,lastName,cellPhone,dateOfBirth,cust_curaddress,cust_addressLine2,cust_curLandmark,cust_curcity,cust_curPeriodofStay,cust_curtilldate,cust_curperiodofstayend,cust_instrCurrentaddress,cust_Permaddline1,cust_Permaddline2,cust_Permlandmark,cust_Permzip,cust_Permcity1,cust_Permperiodofstay,cust_Permtilldate,cust_Permperiodofstayend,cust_instrPermaddress,cust_highcomedu,cust_uni1,cust_insname1,cust_coursecom1,cust_roll1,cust_endyr1,cust_Empname1,cust_startdate1,cust_tenenddate1,cust_empid1,cust_LastDesig,cust_Reasonforchange,cust_UAN,cust_instrref1,cust_name1,cust_org1,cust_rel1,cust_num1,cust_instrref2, cust_name2, cust_org2,cust_rel2,cust_num2,cust_instrref3,cust_name3,cust_org3,cust_rel3,cust_num3,cust_instrBGCIISERVZ,&$expand=custLetterOfAuthorization,cust_curcountry,cust_curstate,cust_Permcountry,cust_Permstate1,custaddressproof,custeducationdetails,cust_BGCApplicableType,custPANattach,custAadhaarattach");

        var clients = new RestClient("https://api44preview.sapsf.com/odata/v2/JobApplication?$format=json&$select=candidateId,applicationId,firstName,middleName,lastName,cellPhone,dateOfBirth,cust_curaddress,cust_addressLine2,cust_curLandmark,cust_curcity,cust_curPeriodofStay,cust_curtilldate,cust_curperiodofstayend,cust_instrCurrentaddress,cust_Permaddline1,cust_Permaddline2,cust_Permlandmark,cust_Permzip,cust_Permcity1,cust_Permperiodofstay,cust_Permtilldate,cust_Permperiodofstayend,cust_instrPermaddress,cust_highcomedu,cust_uni1,cust_insname1,cust_coursecom1,cust_roll1,cust_endyr1,cust_Empname1,cust_startdate1,cust_tenenddate1,cust_empid1,cust_LastDesig,cust_Reasonforchange,cust_UAN,cust_instrref1,cust_name1,cust_org1,cust_rel1,cust_num1,cust_instrref2, cust_name2, cust_org2,cust_rel2,cust_num2,cust_instrref3,cust_name3,cust_org3,cust_rel3,cust_num3,cust_instrBGCIISERVZ,packageId/localeLabel&$expand=custLetterOfAuthorization,cust_curcountry,cust_curstate,cust_Permcountry,cust_Permstate1,custaddressproof,custeducationdetails,cust_BGCApplicableType,custPANattach,custAadhaarattach,packageId");
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        var requests = new RestRequest(Method.GET);
        requests.AddHeader("Authorization", "Basic SW50ZWdyYXRpb25fUHJldmlld0BiaXJsYXNvZnRsVDE6V2VsY29tZUA5ODc=");
        requests.AddParameter("undefined", ParameterType.RequestBody);
        IRestResponse responses = clients.Execute(requests);
        if (responses.StatusCode.ToString() == "OK")
        {
            string Apiresponse = responses.Content;
            var myDetails = JsonConvert.DeserializeObject<Root>(Apiresponse);
            // ds = JsonStringToDataTable(Apiresponse);
            Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(Apiresponse);

            con.Open();
            for (int i = 0; i <= myDeserializedClass.d.results.Count - 1; i++)
            {
                string jsonString = JsonConvert.SerializeObject(myDeserializedClass.d.results[i]);
                if (myDeserializedClass.d.results[i].cellPhone == null)
                {
                    myDeserializedClass.d.results[i].cellPhone = null;
                }

                string authors = myDeserializedClass.d.results[i].__metadata.uri.ToString();
                string[] authorsList = authors.Split('(');
                string applicationnumber = authorsList[1].Replace(")", "");



                //save employee information
                SqlCommand comm = new SqlCommand("uspInsert_BS_APIData", con);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.Add("@metadatauri", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].__metadata.uri ?? " ";
                comm.Parameters.Add("@metadatatype", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].__metadata.type ?? " ";
                comm.Parameters.Add("@applicationId", SqlDbType.Int).Value = myDetails.d.results[i].applicationId ?? " ";
                comm.Parameters.Add("@candidateId", SqlDbType.Int).Value = myDetails.d.results[i].candidateId ?? " ";
                comm.Parameters.Add("@cust_instrBGCIISERVZ", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_instrBGCIISERVZ ?? " ";
                comm.Parameters.Add("@firstName", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].firstName ?? " ";
                comm.Parameters.Add("@middleName", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].middleName ?? " ";
                comm.Parameters.Add("@lastName", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].lastName ?? " ";
                comm.Parameters.Add("@cellPhone", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cellPhone ?? " ";
                comm.Parameters.Add("@dateOfBirth", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].dateOfBirth ?? " ";
                comm.Parameters.Add("@cust_Permaddline1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permaddline1 ?? " ";
                comm.Parameters.Add("@cust_Permaddline2", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permaddline2 ?? " ";
                comm.Parameters.Add("@cust_Permcity1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permcity1 ?? " ";
                comm.Parameters.Add("@cust_Permzip", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permzip ?? " ";
                comm.Parameters.Add("@cust_curaddress", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_curaddress ?? " ";
                comm.Parameters.Add("@cust_addressLine2", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_addressLine2 ?? " ";
                comm.Parameters.Add("@cust_curcity", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_curcity ?? " ";
                comm.Parameters.Add("@cust_curLandmark", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_curLandmark ?? " ";
                comm.Parameters.Add("@cust_instrPermaddress", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_instrPermaddress ?? " ";
                comm.Parameters.Add("@cust_instrref3", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_instrref3 ?? " ";
                comm.Parameters.Add("@cust_rel3", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_rel3 ?? " ";
                comm.Parameters.Add("@cust_rel2", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_rel2 ?? " ";
                comm.Parameters.Add("@cust_rel1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_rel1 ?? " ";
                comm.Parameters.Add("@cust_org2", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_org2 ?? " ";
                comm.Parameters.Add("@cust_org3", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_org3 ?? " ";
                comm.Parameters.Add("@cust_org1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_org1 ?? " ";
                comm.Parameters.Add("@cust_highcomedu", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_highcomedu ?? " ";
                comm.Parameters.Add("@cust_uni1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_uni1 ?? " ";
                comm.Parameters.Add("@cust_Empname1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Empname1 ?? " ";
                comm.Parameters.Add("@cust_endyr1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_endyr1 ?? " ";
                comm.Parameters.Add("@cust_Reasonforchange", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Reasonforchange ?? " ";
                comm.Parameters.Add("@cust_Permperiodofstay", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permperiodofstay ?? " ";
                comm.Parameters.Add("@cust_Permperiodofstayend", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permperiodofstayend ?? " ";
                comm.Parameters.Add("@cust_curPeriodofStay", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_curPeriodofStay ?? " ";
                comm.Parameters.Add("@cust_coursecom1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_coursecom1 ?? " ";
                comm.Parameters.Add("@cust_instrCurrentaddress", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_instrCurrentaddress ?? " ";
                comm.Parameters.Add("@cust_curperiodofstayend", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_curperiodofstayend ?? " ";
                comm.Parameters.Add("@cust_insname1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_insname1 ?? " ";
                comm.Parameters.Add("@cust_curtilldate", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_curtilldate ?? " ";
                comm.Parameters.Add("@cust_tenenddate1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_tenenddate1 ?? " ";
                comm.Parameters.Add("@cust_UAN", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_UAN ?? " ";
                comm.Parameters.Add("@cust_roll1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_roll1 ?? " ";
                comm.Parameters.Add("@cust_Permtilldate", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permtilldate ?? " ";
                comm.Parameters.Add("@cust_empid1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_empid1 ?? " ";
                comm.Parameters.Add("@cust_name3", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_name3 ?? " ";
                comm.Parameters.Add("@cust_name2", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_name2 ?? " ";
                comm.Parameters.Add("@cust_name1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_name1 ?? " ";
                comm.Parameters.Add("@cust_startdate1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_startdate1 ?? " ";
                comm.Parameters.Add("@cust_LastDesig", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_LastDesig ?? " ";
                comm.Parameters.Add("@cust_Permlandmark", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permlandmark ?? " ";
                comm.Parameters.Add("@cust_num3", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_num3 ?? " ";
                comm.Parameters.Add("@cust_num2", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_num2 ?? " ";
                comm.Parameters.Add("@cust_num1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_num1 ?? " ";
                comm.Parameters.Add("@cust_instrref2", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_instrref2 ?? " ";
                comm.Parameters.Add("@cust_instrref1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_instrref1 ?? " ";

                comm.Parameters.Add("@cust_startdate2", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_startdate2 ?? " ";
                comm.Parameters.Add("@cust_startdate3", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_startdate3 ?? " ";
                comm.Parameters.Add("@cust_PostGradModeofEdu", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_PostGradModeofEdu ?? " ";
                comm.Parameters.Add("@cust_12thModeofEdu", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_12thModeofEdu ?? " ";
                comm.Parameters.Add("@cust_10thModeofEdu", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_10thModeofEdu ?? " ";
                comm.Parameters.Add("@cust_DiplomaModeofEdu", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_DiplomaModeofEdu ?? " ";
                comm.Parameters.Add("@custPermAddProofattach", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].custPermAddProofattach ?? " ";

                if (myDetails.d.results[i].packageId.results.Count > 0)
                {

                    var pacname = JsonConvert.DeserializeObject<packagename>(myDetails.d.results[i].packageId.results[0].ToString());
                    comm.Parameters.Add("@packagename", SqlDbType.VarChar, 400).Value = pacname.localeLabel ?? " ";
                }


                int Count = comm.ExecuteNonQuery();

                //}


            }

        }
        else
        {
            error.Text = "Error in fetching  API data";
        }

        string dtt = "select applicationId,candidateId,firstName,middleName,lastName,packageName,received_date from tbl_BS_APIData where received_data=0";
        SqlDataAdapter gridadpt = new SqlDataAdapter(dtt, con);
        gridadpt.Fill(ds);

        grid1.DataSource = ds;
        grid1.DataBind();


    }

    private DataSet getDataset(string query)
    {
        DataSet tempDataSet = new DataSet();
        SqlDataAdapter dap = new SqlDataAdapter(query, con);
        dap.Fill(tempDataSet);
        return tempDataSet;
    }

    protected void grid1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Select")
        {
            int rowIndex = Convert.ToInt32(e.CommandArgument);
            GridViewRow row = grid1.Rows[rowIndex];
            string Cid = row.Cells[1].Text;
            string url1 = "";
            url1 = "https://api44preview.sapsf.com/odata/v2/JobApplication?$format=json&$select=jobReqId,candidateId,applicationId,firstName,middleName,lastName,cellPhone,dateOfBirth,cust_curaddress,cust_curaddressLine2,cust_curLandmark,cust_curzip,cust_curcountry/localeLabel,cust_curstate/localeLabel,cust_curcity,cust_curPeriodofStay,cust_curtilldate,cust_curperiodofstayend,cust_instrCurrentaddress,cust_Permaddline1,cust_Permaddline2,cust_Permlandmark,cust_Permzip,cust_Permcountry/localeLabel,cust_Permstate1/localeLabel,cust_Permcity1,cust_Permperiodofstay,cust_Permtilldate,cust_Permperiodofstayend,cust_instrPermaddress,custCurAddProofattach/fileContent,custCurAddProofattach/fileExtension,custCurAddProofattach/fileName,custCurAddProofattach/mimeType,cust_insname1,cust_cntr1/localeLabel,cust_stat1/localeLabel,cust_roll1,cust_instrpostgrad,cust_endyr1,cust_startyr1,cust_uni1,cust_insname2,cust_cntr2/localeLabel,cust_stat2/localeLabel,cust_roll2,cust_instrbacdeg,cust_endyr2,cust_startyr2,cust_uni2,cust_sch3,cust_stat3/localeLabel,cust_cntr3/localeLabel,cust_roll3,cust_instr12th,cust_endyr3,cust_startyr3,cust_board3,cust_sch4,cust_cntr4/localeLabel,cust_stat4/localeLabel,cust_roll4,cust_instr10th,cust_endyr4,cust_startyr4,cust_board4,cust_nameadd5,cust_roll5,cust_dip5,cust_degdip5,cust_endyr5,cust_coursecom5,cust_instrEmployer1,cust_Empname1,cust_empid1,cust_lastdeg1,cust_reasonforchange1,cust_connectemp1,cust_instrEmployer2,cust_Empname2,cust_empid2,cust_lastdeg2,cust_reasonforchange2,cust_connectemp2,cust_instrEmployer3,cust_Empname3,cust_empid3,cust_lastdeg3,cust_reasonforchange3,cust_connectemp3,cust_emptype1/localeLabel,cust_emptype2/localeLabel,cust_emptype3/localeLabel,cust_PAN,custLetterattach1/fileContent,custLetterattach1/fileExtension,custLetterattach1/fileName,custLetterattach1/mimeType,custLetterattach2/fileContent,custLetterattach2/fileExtension,custLetterattach2/fileName,custLetterattach2/mimeType,custLetterattach3/fileContent,custLetterattach3/fileExtension,custLetterattach3/fileName,custLetterattach3/mimeType,cust_UAN,custLetterOfAuthorization/fileContent,custLetterOfAuthorization/fileExtension,custLetterOfAuthorization/fileName,custLetterOfAuthorization/mimeType,cust_instrref1,cust_name1,cust_org1,cust_rel1,cust_num1,cust_instrref2,cust_name2,cust_instrref1,cust_name1,cust_desi1,cust_num1,cust_instrref2,cust_name2,cust_desi2,cust_num2,cust_instrref3,cust_name3,cust_desi3,cust_num3,cust_instrrefdetails,cust_org2,cust_rel2,cust_num2,cust_instrref3,cust_name3,cust_org3,cust_rel3,cust_num3,cust_BGCApplicableType/localeLabel,cust_instrBGCIISERVZ,custPANattach/fileContent,custPANattach/fileExtension,custPANattach/fileName,custPANattach/mimeType,custAadhaarattach/fileContent,custAadhaarattach/fileExtension,custAadhaarattach/fileName,custAadhaarattach/mimeType,packageId/localeLabel,custPermAddProofattach/fileContent,custPermAddProofattach/fileExtension,custPermAddProofattach/fileName,custPermAddProofattach/mimeType,cust_PostGradModeofEdu/localeLabel,cust_BatchModeofEdu/localeLabel,cust_12thModeofEdu/localeLabel,cust_10thModeofEdu/localeLabel,cust_DiplomaModeofEdu/localeLabel,cust_startdate1,cust_startdate2,cust_startdate3,cust_highcomedu,custPostGradDegattach/fileContent,custPostGradDegattach/fileExtension,custPostGradDegattach/fileName,custPostGradDegattach/mimeType,custBachDegattach/fileContent,custBachDegattach/fileExtension,custBachDegattach/fileName,custBachDegattach/mimeType,cust12attach/fileContent,cust12attach/fileExtension,cust12attach/fileName,cust12attach/mimeType,cust10attach/fileContent,cust10attach/fileExtension,cust10attach/fileName,cust10attach/mimeType,custDiplomaattach/fileContent,custDiplomaattach/fileExtension,custDiplomaattach/fileName,custDiplomaattach/mimeType,cust_tenenddate1,cust_tenenddate2,cust_tenenddate3&$expand=custLetterattach1,custLetterattach2,custLetterattach3,custLetterOfAuthorization,cust_curcountry,cust_curstate,cust_Permcountry,cust_Permstate1,custCurAddProofattach,cust_BGCApplicableType,custPANattach,custAadhaarattach,packageId,cust_cntr1,cust_cntr2,cust_stat1,cust_stat2,cust_stat3,cust_cntr3,cust_cntr4,cust_stat4,cust_emptype1,cust_emptype2,cust_emptype3,custPermAddProofattach,cust_PostGradModeofEdu,cust_BatchModeofEdu,cust_12thModeofEdu,cust_10thModeofEdu,cust_DiplomaModeofEdu,custPostGradDegattach,custBachDegattach,cust12attach,cust10attach,custDiplomaattach,&$filter=jobAppStatus/appStatusName eq 'IISERVZ' and lastModifiedDateTime ge datetime'2023-09-13T00:00:00'";
            string ApplicationId = "", JobReqId = "";
            con.Open();
           
                var client = new RestClient(url1);
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Basic SW50ZWdyYXRpb25fUHJldmlld0BiaXJsYXNvZnRsVDE6V2VsY29tZUA5ODc=");
                // request.AddHeader("Content-Type", "application/json");
                request.AddParameter("undefined", ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                if (response.StatusCode.ToString() == "OK")
                {
                 try
            {
                string Apiresponse = response.Content;
                var EmployeeDetail = JsonConvert.DeserializeObject<candidate>(Apiresponse);
                if (EmployeeDetail.d.results.Count > 0)
                {
                for(int i = 0; i <= EmployeeDetail.d.results.Count - 1; i++)
                {
                ApplicationId = EmployeeDetail.d.results[i].applicationId;
                JobReqId = EmployeeDetail.d.results[i].jobReqId;
     
                SqlCommand comm = new SqlCommand("uspInsert_BS_Candidate_Info", con);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.Add("@applicationId",SqlDbType.Int).Value=EmployeeDetail.d.results[i].applicationId??"";
                comm.Parameters.Add("@candidateId", SqlDbType.Int).Value = EmployeeDetail.d.results[i].candidateId ?? "";
                comm.Parameters.Add("@jobReqId", SqlDbType.Int).Value = EmployeeDetail.d.results[i].jobReqId ?? "";
                comm.Parameters.Add("@firstName", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].firstName ?? "";
                comm.Parameters.Add("@middleName", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].middleName ?? "";
                comm.Parameters.Add("@lastName", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].lastName ?? "";
                comm.Parameters.Add("@dateOfBirth", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].dateOfBirth ?? null;
                comm.Parameters.Add("@cellPhone", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cellPhone ?? "";
                comm.Parameters.Add("@cust_highcomedu", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_highcomedu ?? "";
                comm.Parameters.Add("@cust_UAN", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_UAN ?? "";
                comm.Parameters.Add("@cust_PAN", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_PAN ?? "";
                comm.Parameters.Add("@cust_curaddress", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_curaddress ?? "";
                comm.Parameters.Add("@cust_curaddressLine2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_curaddressLine2 ?? "";
                comm.Parameters.Add("@cust_curLandmark", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_curLandmark ?? "";
                comm.Parameters.Add("@cust_curzip", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_curzip ?? "";
                if (EmployeeDetail.d.results[i].cust_curcountry.results.Count > 0) 
                {
                    comm.Parameters.Add("@cust_curcountry", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_curcountry.results[0].localeLabel ?? "";
                }
                if (EmployeeDetail.d.results[i].cust_curstate.results.Count > 0)
                {
                    comm.Parameters.Add("@cust_curstate", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_curstate.results[0].localeLabel ?? "";
                }               
                comm.Parameters.Add("@cust_curcity", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_curcity ?? "";
                comm.Parameters.Add("@cust_curPeriodofStay", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_curPeriodofStay ?? null;
                comm.Parameters.Add("@cust_curtilldate", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_curtilldate.ToString() ?? "";
                comm.Parameters.Add("@cust_curperiodofstayend", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_curperiodofstayend ?? null;
                comm.Parameters.Add("@cust_instrCurrentaddress", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_instrCurrentaddress ?? "";
                 //  comm.Parameters.Add("@custaddressproof", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].custaddressproof ?? "";
                comm.Parameters.Add("@cust_Permaddline1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_Permaddline1 ?? "";
                comm.Parameters.Add("@cust_Permaddline2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_Permaddline2 ?? "";
                comm.Parameters.Add("@cust_Permlandmark",SqlDbType.VarChar, 400).Value =  EmployeeDetail.d.results[i].applicationId??"";
                comm.Parameters.Add("@cust_Permzip", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_Permzip ?? "";
                if (EmployeeDetail.d.results[i].cust_Permcountry.results.Count > 0)
                {
                    comm.Parameters.Add("@cust_Permcountry", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_Permcountry.results[0].localeLabel ?? "";
                }
              
                if (EmployeeDetail.d.results[i].cust_Permstate1.results.Count > 0)
                {
                    comm.Parameters.Add("@cust_PermState1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_Permstate1.results[0].localeLabel ?? "";
                }
             
                comm.Parameters.Add("@cust_Permcity1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_Permcity1 ?? "";
                comm.Parameters.Add("@cust_Permperiodofstay", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_Permperiodofstay ?? null;
               comm.Parameters.Add("@cust_Permtilldate", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_Permtilldate.ToString() ?? "";
                comm.Parameters.Add("@cust_Permperiodofstayend", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_Permperiodofstayend ?? null;
                comm.Parameters.Add("@cust_instrPermaddress", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_instrPermaddress ?? "";
                
             //   comm.Parameters.Add("@custPermAddProofattach", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].custPermAddProofattach ?? "";
                comm.Parameters.Add("@cust_org1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_org1 ?? "";
                comm.Parameters.Add("@cust_instrEmployer1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_instrEmployer1 ?? "";
                comm.Parameters.Add("@cust_Empname1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_Empname1 ?? "";
                comm.Parameters.Add("@cust_empid1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_empid1 ?? "";
                comm.Parameters.Add("@cust_lastdeg1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_lastdeg1 ?? "";
                comm.Parameters.Add("@cust_reasonforchange1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_reasonforchange1 ?? "";
                comm.Parameters.Add("@cust_connectemp1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_connectemp1 ?? "";
                comm.Parameters.Add("@cust_tenenddate1", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_tenenddate1 ?? null;
                if (EmployeeDetail.d.results[i].cust_emptype1.results.Count > 0)
                {
                    comm.Parameters.Add("@cust_emptype1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_emptype1.results[0].localeLabel ?? "";
                }        
                // comm.Parameters.Add("@cust_empAttach1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_empAttach1?? "";
                comm.Parameters.Add("@cust_startdate1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_startdate1 ?? "";
                comm.Parameters.Add("@cust_org2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_org2 ?? "";
                comm.Parameters.Add("@cust_instrEmployer2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_instrEmployer2 ?? "";
                comm.Parameters.Add("@cust_Empname2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_Empname2 ?? "";
                comm.Parameters.Add("@cust_empid2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_empid2 ?? "";
                comm.Parameters.Add("@cust_lastdeg2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_lastdeg2 ?? "";
                comm.Parameters.Add("@cust_reasonforchange2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_reasonforchange2 ?? "";
                comm.Parameters.Add("@cust_connectemp2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_connectemp2 ?? "";
                comm.Parameters.Add("@cust_tenenddate2", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_tenenddate2 ?? null;
                if (EmployeeDetail.d.results[i].cust_emptype2.results.Count > 0)
                {
                   comm.Parameters.Add("@cust_emptype2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_emptype2.results[0].localeLabel ?? "";
                }
             
                //  comm.Parameters.Add("@cust_empAttach2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_empAttach2 ?? "";
                comm.Parameters.Add("@cust_startdate2", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_startdate2 ?? null;
                comm.Parameters.Add("@cust_org3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_org3 ?? "";
                comm.Parameters.Add("@cust_instrEmployer3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_instrEmployer3 ?? "";
                comm.Parameters.Add("@cust_Empname3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_Empname3 ?? "";
                comm.Parameters.Add("@cust_empid3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_empid3 ?? "";
                comm.Parameters.Add("@cust_lastdeg3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_lastdeg3 ?? "";
                comm.Parameters.Add("@cust_reasonforchange3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_reasonforchange3 ?? "";
                comm.Parameters.Add("@cust_connectemp3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_connectemp3 ?? "";
                comm.Parameters.Add("@cust_tenenddate3", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_tenenddate3 ?? null;
                if (EmployeeDetail.d.results[i].cust_emptype3.results.Count > 0)
                {
                   comm.Parameters.Add("@cust_emptype3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_emptype3.results[0].localeLabel ?? "";
                }
              
              //  comm.Parameters.Add("@cust_empAttach3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_empAttach3 ?? "";
                comm.Parameters.Add("@cust_startdate3", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_startdate3 ?? null;
               //  comm.Parameters.Add("@cust_insname1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_insname1 ?? "";
                 //  comm.Parameters.Add("@cust_cntr1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_cntr1 ?? "";
               //  comm.Parameters.Add("@cust_stat1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_stat1 ?? "";
                comm.Parameters.Add("@cust_roll1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_roll1 ?? "";
                comm.Parameters.Add("@cust_instrpostgrad", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_instrpostgrad ?? "";
                comm.Parameters.Add("@cust_endyr1", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_endyr1 ?? null;
                comm.Parameters.Add("@cust_startyr1", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_startyr1 ?? null;
               // comm.Parameters.Add("@custPostGradDegattach", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].custPostGradDegattach ?? "";    
                 // comm.Parameters.Add("@cust_PostGradModeofEdu", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_PostGradModeofEdu ?? "";
                comm.Parameters.Add("@cust_uni1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_uni1 ?? "";
                comm.Parameters.Add("@cust_insname2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_insname2 ?? "";
               //  comm.Parameters.Add("@cust_cntr2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_cntr2 ?? "";
                 //   comm.Parameters.Add("@cust_stat2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_stat2 ?? "";
                comm.Parameters.Add("@cust_roll2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_roll2 ?? "";
                comm.Parameters.Add("@cust_instrbacdeg", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_instrbacdeg ?? "";
                comm.Parameters.Add("@cust_endyr2", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_endyr2 ?? null;
                comm.Parameters.Add("@cust_startyr2", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_startyr2 ?? null;
                 // comm.Parameters.Add("@custBachDegattach", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].custBachDegattach ?? "";  
                //  comm.Parameters.Add("@cust_BatchModeofEdu", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_BatchModeofEdu ?? "";
                comm.Parameters.Add("@cust_uni2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_uni2 ?? "";
                comm.Parameters.Add("@cust_sch3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_sch3 ?? "";
               // comm.Parameters.Add("@cust_stat3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_stat3 ?? "";
                  //  comm.Parameters.Add("@cust_cntr3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_cntr3 ?? "";
                comm.Parameters.Add("@cust_roll3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_roll3 ?? "";
                comm.Parameters.Add("@cust_instr12th", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_instr12th ?? "";
                comm.Parameters.Add("@cust_endyr3", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_endyr3 ?? null;
                comm.Parameters.Add("@cust_startyr3", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_startyr3 ?? null;
                // comm.Parameters.Add("@cust12attach", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust12attach ?? "";  
                   // comm.Parameters.Add("@cust_12thModeofEdu", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_12thModeofEdu ?? "";
                comm.Parameters.Add("@cust_board3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_board3 ?? "";
                comm.Parameters.Add("@cust_sch4", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_sch4 ?? "";
                // comm.Parameters.Add("@cust_cntr4", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_cntr4 ?? "";
                // comm.Parameters.Add("@cust_stat4", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_stat4 ?? "";
                comm.Parameters.Add("@cust_roll4", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_roll4 ?? "";
                comm.Parameters.Add("@cust_instr10th", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_instr10th ?? "";
                comm.Parameters.Add("@cust_endyr4", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_endyr4 ?? null;
                comm.Parameters.Add("@cust_startyr4", SqlDbType.DateTime).Value = EmployeeDetail.d.results[i].cust_startyr4 ?? null;
                //  comm.Parameters.Add("@cust10Degattach", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust10attach ?? "";  
                  //comm.Parameters.Add("@cust_10thModeofEdu", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_10thModeofEdu ?? "";
                comm.Parameters.Add("@cust_board4", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_board4 ?? "";
                comm.Parameters.Add("@cust_nameadd5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_nameadd5 ?? "";
                comm.Parameters.Add("@cust_roll5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_roll5 ?? "";
                comm.Parameters.Add("@cust_dip5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_dip5 ?? "";
                comm.Parameters.Add("@cust_degdip5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_degdip5 ?? "";
                comm.Parameters.Add("@cust_endyr5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_endyr5 ?? "";
                comm.Parameters.Add("@cust_coursecom5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_coursecom5 ?? "";
                // comm.Parameters.Add("@custDiplomDegaattach", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].custDiplomaattach ?? ""; 
                 // comm.Parameters.Add("@cust_DiplomaModeofEdu", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_DiplomaModeofEdu ?? "";
                comm.Parameters.Add("@cust_rel1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_rel1 ?? "";
                comm.Parameters.Add("@cust_instrref1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_instrref1 ?? "";
                comm.Parameters.Add("@cust_name1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_name1 ?? "";
                comm.Parameters.Add("@cust_desi1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_desi1 ?? "";
                comm.Parameters.Add("@cust_num1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_num1 ?? "";
                comm.Parameters.Add("@cust_rel2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_rel2 ?? "";
                comm.Parameters.Add("@cust_instrref2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_instrref2 ?? "";
                comm.Parameters.Add("@cust_name2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_name2 ?? "";
                comm.Parameters.Add("@cust_desi2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_desi2 ?? "";
                comm.Parameters.Add("@cust_num2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_num2 ?? "";
                comm.Parameters.Add("@cust_rel3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_rel3 ?? "";
                comm.Parameters.Add("@cust_instrref3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_instrref3 ?? "";
                comm.Parameters.Add("@cust_name3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_name3 ?? "";
                comm.Parameters.Add("@cust_desi3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_desi3 ?? "";
                comm.Parameters.Add("@Cust_num3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.results[i].cust_num3 ?? "";	     

                //Attachment
                if (EmployeeDetail.d.results[i].custAadhaarattach.results[0] != null)
                {
                    string base64 = EmployeeDetail.d.results[0].custAadhaarattach.results[0].fileContent;
                    string fileName = "Aadhar";
                    string ext = ".png";
                    var Data = FromBase64(base64);
                  //  string filePath = Server.MapPath("~/Files/" + EmployeeDetail.d.results[i].applicationId);
                    string filePath = Server.MapPath("~/Files");
                    string Rename = System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                    fileName = EmployeeDetail.d.results[i].applicationId + "_" + fileName + "_" + Rename + ext;
                    DirectoryInfo info = new DirectoryInfo(filePath);
                    if (!info.Exists)
                    {
                        info.Create();
                    }
                    string path = Path.Combine(filePath, fileName);
                    using (FileStream outputFileStream = new FileStream(path, FileMode.Create))
                    {
                        Data.CopyTo(outputFileStream);
                    }
                    Data.Close();
                    string filefullpath = filePath + "\\" + fileName;
                    string attsql = "insert into tbl_BS_Attachment ([ApplicationId],[CandidateId],[fileName],[mimeType],[fileExtension],[filePath]) values('" + EmployeeDetail.d.results[i].applicationId + "',' " + EmployeeDetail.d.results[i].candidateId + " ',' " + EmployeeDetail.d.results[i].custAadhaarattach.results[0].fileName + " ','',' " + ext + " ',' " + filefullpath + " ' )  ";

                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        adapter.InsertCommand = new SqlCommand(attsql, con);
                        adapter.InsertCommand.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                    }
                    // EmployeeDetail.d.results[0].custAadhaarattach.results[0].fileContent

                }
                if (EmployeeDetail.d.results[i].custPANattach.results[0] != null)
                {
                    string base64 = EmployeeDetail.d.results[0].custPANattach.results[0].fileContent;
                    string fileName = "Pan Pay Slip";
                    string ext = ".docx";
                    var Data = FromBase64(base64);
                    string filePath = Server.MapPath("~/Files");
                    string Rename = System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                    //fileName = Name + "_" + Cid + "_" + Guid.NewGuid() + "." + ext;
                    fileName = EmployeeDetail.d.results[i].applicationId + "_" + fileName + "_" + Rename + ext;
                    DirectoryInfo info = new DirectoryInfo(filePath);
                    if (!info.Exists)
                    {
                        info.Create();
                    }
                    string path = Path.Combine(filePath, fileName);
                    using (FileStream outputFileStream = new FileStream(path, FileMode.Create))
                    {
                        Data.CopyTo(outputFileStream);
                    }
                    Data.Close();

                    string filefullpath=filePath+ "\\" + fileName;
                    string attsql = "insert into tbl_BS_Attachment ([ApplicationId],[CandidateId],[fileName],[mimeType],[fileExtension],[filePath]) values('" + EmployeeDetail.d.results[i].applicationId + "',' " + EmployeeDetail.d.results[i].candidateId + " ',' " + EmployeeDetail.d.results[i].custPANattach.results[0].fileName + " ','  ',' " + ext + " ',' " + filefullpath + " ' )  ";

                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        adapter.InsertCommand = new SqlCommand(attsql, con);
                        adapter.InsertCommand.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                    }

                    // EmployeeDetail.d.results[0].custAadhaarattach.results[0].fileContent

                }
                if (EmployeeDetail.d.results[i].custBachDegattach.results[0] != null)
                {
                    string base64 = EmployeeDetail.d.results[0].custBachDegattach.results[0].fileContent;
                    string fileName = "Graduate Degree";
                    string ext = ".docx";
                    var Data = FromBase64(base64);
                    string filePath = Server.MapPath("~/Files");
                    string Rename = System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                    fileName = EmployeeDetail.d.results[i].applicationId + "_" + fileName + "_" + Rename + ext;
                    DirectoryInfo info = new DirectoryInfo(filePath);
                    if (!info.Exists)
                    {
                        info.Create();
                    }
                    string path = Path.Combine(filePath, fileName);
                    using (FileStream outputFileStream = new FileStream(path, FileMode.Create))
                    {
                        Data.CopyTo(outputFileStream);
                    }
                    Data.Close();

                    string filefullpath = filePath + "\\" + fileName;
                    string attsql = "insert into tbl_BS_Attachment ([ApplicationId],[CandidateId],[fileName],[mimeType],[fileExtension],[filePath]) values('" + EmployeeDetail.d.results[i].applicationId + "',' " + EmployeeDetail.d.results[i].candidateId + " ',' " + EmployeeDetail.d.results[i].custBachDegattach.results[0].fileName + " ','  ',' " + ext + " ',' " + filefullpath + " ' )  ";

                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        adapter.InsertCommand = new SqlCommand(attsql, con);
                        adapter.InsertCommand.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                    }

                }
                if (EmployeeDetail.d.results[i].custLetterattach2.results[0] != null)
                {
                    string base64 = EmployeeDetail.d.results[0].custLetterattach2.results[0].fileContent;
                    string fileName = "Relieving Letter 2";
                    string ext = ".docx";
                    var Data = FromBase64(base64);
                    string filePath = Server.MapPath("~/Files");
                    string Rename = System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                    fileName = EmployeeDetail.d.results[i].applicationId + "_" + fileName + "_" + Rename + ext;
                    DirectoryInfo info = new DirectoryInfo(filePath);
                    if (!info.Exists)
                    {
                        info.Create();
                    }
                    string path = Path.Combine(filePath, fileName);
                    using (FileStream outputFileStream = new FileStream(path, FileMode.Create))
                    {
                        Data.CopyTo(outputFileStream);
                    }
                    Data.Close();

                    string filefullpath = filePath + "\\" + fileName;
                    string attsql = "insert into tbl_BS_Attachment ([ApplicationId],[CandidateId],[fileName],[mimeType],[fileExtension],[filePath]) values('" + EmployeeDetail.d.results[i].applicationId + "',' " + EmployeeDetail.d.results[i].candidateId + " ',' " + EmployeeDetail.d.results[i].custLetterattach2.results[0].fileName + " ',' ',' " + ext + " ',' " + filefullpath + " ' )  ";

                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        adapter.InsertCommand = new SqlCommand(attsql, con);
                        adapter.InsertCommand.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                    }

                }
                if (EmployeeDetail.d.results[i].custLetterattach3.results[0] != null)
                {
                    string base64 = EmployeeDetail.d.results[0].custLetterattach3.results[0].fileContent;
                    string fileName = "Relieving Letter 3";
                    string ext = ".docx";
                    var Data = FromBase64(base64);
                    string filePath = Server.MapPath("~/Files");
                    string Rename = System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                    fileName = EmployeeDetail.d.results[i].applicationId + "_" + fileName + "_" + Rename + ext;
                    DirectoryInfo info = new DirectoryInfo(filePath);
                    if (!info.Exists)
                    {
                        info.Create();
                    }
                    string path = Path.Combine(filePath, fileName);
                    using (FileStream outputFileStream = new FileStream(path, FileMode.Create))
                    {
                        Data.CopyTo(outputFileStream);
                    }
                    Data.Close();

                    string filefullpath = filePath + "\\" + fileName;
                    string attsql = "insert into tbl_BS_Attachment ([ApplicationId],[CandidateId],[fileName],[mimeType],[fileExtension],[filePath]) values('" + EmployeeDetail.d.results[i].applicationId + "',' " + EmployeeDetail.d.results[i].candidateId + " ',' " + EmployeeDetail.d.results[i].custLetterattach3.results[0].fileName + " ',' ',' " + ext + " ',' " + filefullpath + " ' )  ";

                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        adapter.InsertCommand = new SqlCommand(attsql, con);
                        adapter.InsertCommand.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                    }

                }
                if (EmployeeDetail.d.results[i].custLetterattach1.results[0] != null)
                {
                    string base64 = EmployeeDetail.d.results[0].custLetterattach1.results[0].fileContent;
                    string fileName = "Relieving Letter 1";
                    string ext = ".docx";
                    var Data = FromBase64(base64);
                    string filePath = Server.MapPath("~/Files");
                    string Rename = System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                    fileName = EmployeeDetail.d.results[i].applicationId + "_" + fileName + "_" + Rename + ext;
                    DirectoryInfo info = new DirectoryInfo(filePath);
                    if (!info.Exists)
                    {
                        info.Create();
                    }
                    string path = Path.Combine(filePath, fileName);
                    using (FileStream outputFileStream = new FileStream(path, FileMode.Create))
                    {
                        Data.CopyTo(outputFileStream);
                    }
                    Data.Close();

                    string filefullpath = filePath + "\\" + fileName;
                    string attsql = "insert into tbl_BS_Attachment ([ApplicationId],[CandidateId],[fileName],[mimeType],[fileExtension],[filePath]) values('" + EmployeeDetail.d.results[i].applicationId + "',' " + EmployeeDetail.d.results[i].candidateId + " ',' " + EmployeeDetail.d.results[i].custLetterattach1.results[0].fileName + " ','  ',' " + ext + " ',' " + filefullpath + " ' )  ";

                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        adapter.InsertCommand = new SqlCommand(attsql, con);
                        adapter.InsertCommand.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                    }
                }
                if (EmployeeDetail.d.results[i].custPermAddProofattach.results[0] != null)
                {
                    string base64 = EmployeeDetail.d.results[0].custPermAddProofattach.results[0].fileContent;
                    string fileName = "Permanent Address Proof";
                    string ext = ".docx";
                    var Data = FromBase64(base64);
                    string filePath = Server.MapPath("~/Files");
                    string Rename = System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                    fileName = EmployeeDetail.d.results[i].applicationId + "_" + fileName + "_" + Rename + ext;
                    DirectoryInfo info = new DirectoryInfo(filePath);
                    if (!info.Exists)
                    {
                        info.Create();
                    }
                    string path = Path.Combine(filePath, fileName);
                    using (FileStream outputFileStream = new FileStream(path, FileMode.Create))
                    {
                        Data.CopyTo(outputFileStream);
                    }
                    Data.Close();

                    string filefullpath = filePath + "\\" + fileName;
                    string attsql = "insert into tbl_BS_Attachment ([ApplicationId],[CandidateId],[fileName],[mimeType],[fileExtension],[filePath]) values('" + EmployeeDetail.d.results[i].applicationId + "',' " + EmployeeDetail.d.results[i].candidateId + " ',' " + EmployeeDetail.d.results[i].custPermAddProofattach.results[0].fileName + " ','  ',' " + ext + " ',' " + filefullpath + " ' )  ";

                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        adapter.InsertCommand = new SqlCommand(attsql, con);
                        adapter.InsertCommand.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                    }

                }

                if (EmployeeDetail.d.results[i].cust12attach.results[0] != null)
                {
                    string base64 = EmployeeDetail.d.results[0].cust12attach.results[0].fileContent;
                    string fileName = "12th";
                    string ext = ".docx";
                    var Data = FromBase64(base64);
                    string filePath = Server.MapPath("~/Files");
                    string Rename = System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                    fileName = EmployeeDetail.d.results[i].applicationId + "_" + fileName + "_" + Rename + ext;
                    DirectoryInfo info = new DirectoryInfo(filePath);
                    if (!info.Exists)
                    {
                        info.Create();
                    }
                    string path = Path.Combine(filePath, fileName);
                    using (FileStream outputFileStream = new FileStream(path, FileMode.Create))
                    {
                        Data.CopyTo(outputFileStream);
                    }
                    Data.Close();

                    string filefullpath = filePath + "\\" + fileName;
                    string attsql = "insert into tbl_BS_Attachment ([ApplicationId],[CandidateId],[fileName],[mimeType],[fileExtension],[filePath]) values('" + EmployeeDetail.d.results[i].applicationId + "',' " + EmployeeDetail.d.results[i].candidateId + " ',' " + EmployeeDetail.d.results[i].cust12attach.results[0].fileName + " ','  ',' " + ext + " ',' " + filefullpath + " ' )  ";

                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        adapter.InsertCommand = new SqlCommand(attsql, con);
                        adapter.InsertCommand.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                    }
                }

                if (EmployeeDetail.d.results[i].custDiplomaattach.results[0] != null)
                {
                    string base64 = EmployeeDetail.d.results[0].custDiplomaattach.results[0].fileContent;
                    string fileName = "Diploma";
                    string ext = ".docx";
                    var Data = FromBase64(base64);
                    string filePath = Server.MapPath("~/Files");
                    string Rename = System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                    fileName = EmployeeDetail.d.results[i].applicationId + "_" + fileName + "_" + Rename + ext;
                    DirectoryInfo info = new DirectoryInfo(filePath);
                    if (!info.Exists)
                    {
                        info.Create();
                    }
                    string path = Path.Combine(filePath, fileName);
                    using (FileStream outputFileStream = new FileStream(path, FileMode.Create))
                    {
                        Data.CopyTo(outputFileStream);
                    }
                    Data.Close();

                    string filefullpath = filePath + "\\" + fileName;
                    string attsql = "insert into tbl_BS_Attachment ([ApplicationId],[CandidateId],[fileName],[mimeType],[fileExtension],[filePath]) values('" + EmployeeDetail.d.results[i].applicationId + "',' " + EmployeeDetail.d.results[i].candidateId + " ',' " + EmployeeDetail.d.results[i].custDiplomaattach.results[0].fileName + " ',' ',' " + ext + " ',' " + filefullpath + " ' )  ";

                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        adapter.InsertCommand = new SqlCommand(attsql, con);
                        adapter.InsertCommand.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                    }
                }
                if (EmployeeDetail.d.results[i].custLetterOfAuthorization.results[0] != null)
                {
                    string base64 = EmployeeDetail.d.results[0].custLetterOfAuthorization.results[0].fileContent;
                    string fileName = "Letter of Authorization";
                    string ext = ".docx";
                    var Data = FromBase64(base64);
                    string filePath = Server.MapPath("~/Files");
                    string Rename = System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                    fileName = EmployeeDetail.d.results[i].applicationId + "_" + fileName + "_" + Rename + ext;
                    DirectoryInfo info = new DirectoryInfo(filePath);
                    if (!info.Exists)
                    {
                        info.Create();
                    }
                    string path = Path.Combine(filePath, fileName);
                    using (FileStream outputFileStream = new FileStream(path, FileMode.Create))
                    {
                        Data.CopyTo(outputFileStream);
                    }
                    Data.Close();

                    string filefullpath = filePath + "\\" + fileName;
                    string attsql = "insert into tbl_BS_Attachment ([ApplicationId],[CandidateId],[fileName],[mimeType],[fileExtension],[filePath]) values('" + EmployeeDetail.d.results[i].applicationId + "',' " + EmployeeDetail.d.results[i].candidateId + " ',' " + EmployeeDetail.d.results[i].custLetterOfAuthorization.results[0].fileName + " ',' ',' " + ext + " ',' " + filefullpath + " ' )  ";

                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        adapter.InsertCommand = new SqlCommand(attsql, con);
                        adapter.InsertCommand.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                    }
                }

                if (EmployeeDetail.d.results[i].custCurAddProofattach.results[0] != null)
                {
                    string base64 = EmployeeDetail.d.results[0].custCurAddProofattach.results[0].fileContent;
                    string fileName = "Current Address Proof";
                    string ext = ".docx";
                    var Data = FromBase64(base64);
                    string filePath = Server.MapPath("~/Files");
                    string Rename = System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                    fileName = EmployeeDetail.d.results[i].applicationId + "_" + fileName + "_" + Rename + ext;
                    DirectoryInfo info = new DirectoryInfo(filePath);
                    if (!info.Exists)
                    {
                        info.Create();
                    }
                    string path = Path.Combine(filePath, fileName);
                    using (FileStream outputFileStream = new FileStream(path, FileMode.Create))
                    {
                        Data.CopyTo(outputFileStream);
                    }
                    Data.Close();

                    string filefullpath = filePath + "\\" + fileName;
                    string attsql = "insert into tbl_BS_Attachment ([ApplicationId],[CandidateId],[fileName],[mimeType],[fileExtension],[filePath]) values('" + EmployeeDetail.d.results[i].applicationId + "',' " + EmployeeDetail.d.results[i].candidateId + " ',' " + EmployeeDetail.d.results[i].custCurAddProofattach.results[0].fileName + " ','  ',' " + ext + " ',' " + filefullpath + " ' )  ";

                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        adapter.InsertCommand = new SqlCommand(attsql, con);
                        adapter.InsertCommand.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                    }

                }
                if (EmployeeDetail.d.results[i].cust10attach.results[0] != null)
                {
                    string base64 = EmployeeDetail.d.results[0].cust10attach.results[0].fileContent;
                    string fileName = "10th";
                    string ext = ".docx";
                    var Data = FromBase64(base64);
                    string filePath = Server.MapPath("~/Files");
                    string Rename = System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                    fileName = EmployeeDetail.d.results[i].applicationId + "_" + fileName + "_" + Rename + ext;
                    DirectoryInfo info = new DirectoryInfo(filePath);
                    if (!info.Exists)
                    {
                        info.Create();
                    }
                    string path = Path.Combine(filePath, fileName);
                    using (FileStream outputFileStream = new FileStream(path, FileMode.Create))
                    {
                        Data.CopyTo(outputFileStream);
                    }
                    Data.Close();


                    string filefullpath = filePath + "\\" + fileName;
                    string attsql = "insert into tbl_BS_Attachment ([ApplicationId],[CandidateId],[fileName],[mimeType],[fileExtension],[filePath]) values('" + EmployeeDetail.d.results[i].applicationId + "',' " + EmployeeDetail.d.results[i].candidateId + " ',' " + EmployeeDetail.d.results[i].cust10attach.results[0].fileName + " ',' ',' " + ext + " ',' " + filefullpath + " ' )  ";

                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        adapter.InsertCommand = new SqlCommand(attsql, con);
                        adapter.InsertCommand.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                    }

                }
                if (EmployeeDetail.d.results[i].custPostGradDegattach.results[0] != null)
                {
                    string base64 = EmployeeDetail.d.results[0].custPostGradDegattach.results[0].fileContent;
                    string fileName = "Post Graduate Degree";
                    string ext = ".docx";
                    var Data = FromBase64(base64);
                    string filePath = Server.MapPath("~/Files");
                    string Rename = System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                    fileName = EmployeeDetail.d.results[i].applicationId+"_" + fileName + "_" + Rename + ext;
                    DirectoryInfo info = new DirectoryInfo(filePath);
                    if (!info.Exists)
                    {
                        info.Create();
                    }
                    string path = Path.Combine(filePath, fileName);
                    using (FileStream outputFileStream = new FileStream(path, FileMode.Create))
                    {
                        Data.CopyTo(outputFileStream);
                    }
                    Data.Close();


                    string filefullpath = filePath + "\\" + fileName;
                    string attsql = "insert into tbl_BS_Attachment ([ApplicationId],[CandidateId],[fileName],[mimeType],[fileExtension],[filePath]) values('" + EmployeeDetail.d.results[i].applicationId + "',' " + EmployeeDetail.d.results[i].candidateId + " ',' " + EmployeeDetail.d.results[i].custPostGradDegattach.results[0].fileName + " ','  ',' " + ext + " ',' " + filefullpath + " ' )  ";

                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        adapter.InsertCommand = new SqlCommand(attsql, con);
                        adapter.InsertCommand.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {

                    }

                }

                    //

                int Count = comm.ExecuteNonQuery();

                }
                    }
               
                #region Client Side Status Update
                DataSet ds1 = new DataSet();
                ds1 = getDataset("Select top 1 BSCandidateInfoId from tbl_BS_Candidate_info where applicationId=" + ApplicationId + " and jobReqId=" + JobReqId + "");
                string vendorId = ds1.Tables[0].Rows[0][0].ToString();

                StringBuilder sb = new StringBuilder();

                sb.Append("{");
                sb.Append("    \"__metadata\": {");
                sb.Append("        \"uri\": \"JobApplication\",");
                sb.Append("        \"type\": \"SFOData.JobApplication\"");
                sb.Append("    },");
                sb.Append("    \"jobReqId\": \"" + JobReqId + "\",");
                sb.Append("    \"applicationId\": \"" + ApplicationId + "\",");
                sb.Append("    \"cust_BGC_IISERVZ_RefId\":\"" + vendorId + "\",");
                sb.Append("    \"cust_BGC_IISERVZ_ACKComment\": \"Success\",");
                sb.Append("}");

                string finalResult = sb.ToString();
                var clientt = new RestClient("https://api44preview.sapsf.com/odata/v2/upsert");
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                var requestt = new RestRequest(Method.POST);
                requestt.AddHeader("Authorization", "Basic SW50ZWdyYXRpb25fUHJldmlld0BiaXJsYXNvZnRsVDE6V2VsY29tZUA5ODc=");
                requestt.AddHeader("Content-Type", "application/json");
                requestt.AddParameter("application/json", finalResult, ParameterType.RequestBody);
                IRestResponse responses = clientt.Execute(requestt);
                string Apiresponsee = responses.Content;

                #endregion
            }
            
            catch (Exception ex)
            {
                #region Client Side Status Update
                //DataSet ds1 = new DataSet();
                //ds1 = getDataset("Select top 1 CanId from tbl_BS_Candidate_info where candidateId='" + CandidateId + "'");
                string vendorId = "";

                StringBuilder sb = new StringBuilder();

                sb.Append("{");
                sb.Append("    \"__metadata\": {");
                sb.Append("        \"uri\": \"JobApplication\",");
                sb.Append("        \"type\": \"SFOData.JobApplication\"");
                sb.Append("    },");
                sb.Append("    \"jobReqId\": \"" + JobReqId + "\",");
                sb.Append("    \"applicationId\": \"" + ApplicationId + "\",");
                sb.Append("    \"cust_BGC_IISERVZ_RefId\":\"" + vendorId + "\",");
                sb.Append("    \"cust_BGC_IISERVZ_ACKComment\": \"'" + ex.Message + "'\",");
                sb.Append("}");

                string finalResult = sb.ToString();
                var clientt = new RestClient("https://api44preview.sapsf.com/odata/v2/upsert");
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                var requestt = new RestRequest(Method.POST);
                requestt.AddHeader("Authorization", "Basic SW50ZWdyYXRpb25fUHJldmlld0BiaXJsYXNvZnRsVDE6V2VsY29tZUA5ODc=");
                requestt.AddHeader("Content-Type", "application/json");
                requestt.AddParameter("application/json", finalResult, ParameterType.RequestBody);
                IRestResponse responses = clientt.Execute(requestt);
                string Apiresponsee = responses.Content;

                #endregion
                Response.Write(ex.Message);

                SqlCommand akcom = new SqlCommand("uspSendExceptionEmailToClient", con);
                akcom.CommandType = CommandType.StoredProcedure;
                akcom.Parameters.Add("@applicationId", SqlDbType.Int).Value = ApplicationId ?? " ";
                akcom.Parameters.Add("@JobReqId", SqlDbType.Int).Value = JobReqId ?? " ";
                akcom.Parameters.Add("@message", SqlDbType.VarChar, 400).Value = ex.Message ?? " ";
                int Count = akcom.ExecuteNonQuery();
            }
                }
        }

        Response.Redirect("BgvDetailsNew.aspx");
    }

    public static Stream FromBase64(String base64)
    {
        Byte[] bytes = Convert.FromBase64String(base64);
        Stream stream = new MemoryStream(bytes);
        return stream;
    }
    // basic detail of all candidate
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class D
    {
        public List<Result> results { get; set; }
    }

  
    public class PackageId1
    {
        public List<object> results { get; set; }
    }

    public class packagename
    {
        public Metadata __metadata { get; set; }
        public string localeLabel { get; set; }
    }

    public class Result
    {
        public Metadata __metadata { get; set; }
        public string applicationId { get; set; }
        public object cust_instrPermaddress { get; set; }
        public object cust_instrref3 { get; set; }
        public object cust_rel3 { get; set; }
        public object cust_rel2 { get; set; }
        public object cust_rel1 { get; set; }
        public object cust_Permaddline2 { get; set; }
        public string cust_Permcity1 { get; set; }
        public string cust_Permaddline1 { get; set; }
        public object cust_org2 { get; set; }
        public object cust_org3 { get; set; }
        public object cust_org1 { get; set; }
        public object cust_highcomedu { get; set; }
        public object cust_uni1 { get; set; }
        public object cust_Empname1 { get; set; }
        public object cust_endyr1 { get; set; }
        public string cust_Reasonforchange { get; set; }
        public object cust_Permperiodofstay { get; set; }
        public string cust_Permzip { get; set; }
        public string cust_addressLine2 { get; set; }
        public object cust_Permperiodofstayend { get; set; }
        public object cust_curPeriodofStay { get; set; }
        public string firstName { get; set; }
        public object cust_coursecom1 { get; set; }
        public object cust_curLandmark { get; set; }
        public string candidateId { get; set; }
        public object cust_instrCurrentaddress { get; set; }
        public string lastName { get; set; }
        public object cust_curperiodofstayend { get; set; }
        public object cust_insname1 { get; set; }
        public object cust_curtilldate { get; set; }
        public object cust_tenenddate1 { get; set; }
        public object cust_UAN { get; set; }
        public string cust_curcity { get; set; }
        public object cust_roll1 { get; set; }
        public string cust_curaddress { get; set; }
        public object cust_Permtilldate { get; set; }
        public object cust_instrBGCIISERVZ { get; set; }
        public object cust_empid1 { get; set; }
        public object cust_name3 { get; set; }
        public object cust_name2 { get; set; }
        public object cust_name1 { get; set; }
        public object cust_startdate1 { get; set; }
        public object dateOfBirth { get; set; }
        public string cust_LastDesig { get; set; }
        public object cust_Permlandmark { get; set; }
        public object cust_num3 { get; set; }
        public object cust_num2 { get; set; }
        public string middleName { get; set; }
        public object cust_num1 { get; set; }
        public object cust_instrref2 { get; set; }
        public object cust_instrref1 { get; set; }
        public string cellPhone { get; set; }
        public PackageId1 packageId { get; set; }


        public object cust_startdate2 { get; set; }
        public object cust_startdate3 { get; set; }
        public object cust_PostGradModeofEdu { get; set; }
        public object cust_12thModeofEdu { get; set; }
        public object cust_10thModeofEdu { get; set; }
        public object cust_DiplomaModeofEdu { get; set; }
        public object custPermAddProofattach { get; set; }

    }


    public class Root
    {
        public D d { get; set; }
    }

    //// candidate detail

   
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class Cust10attach
    {
        public List<Result2> results { get; set; }
    }
    public class Deferred
    {
        public string uri { get; set; }
    }
    public class CustInsname1
    {
        public Deferred __deferred { get; set; }
    }
    public class Cust10thModeofEdu
    {
        public List<Result2> results { get; set; }
    }

    public class Cust12attach
    {
        public List<Result2> results { get; set; }
    }

    public class Cust12thModeofEdu
    {
        public List<Result2> results { get; set; }
    }

    public class CustAadhaarattach
    {
        public List<Result2> results { get; set; }
    }

    public class Custaddressproof
    {
        public List<object> results { get; set; }
    }

    public class CustBachDegattach
    {
        public List<Result2> results { get; set; }
    }

    public class CustBatchModeofEdu
    {
        public List<Result2> results { get; set; }
    }

    public class CustBGCApplicableType
    {
        public List<object> results { get; set; }
    }

    public class CustCntr1
    {
        public List<Result2> results { get; set; }
    }

    public class CustCntr2
    {
        public List<Result2> results { get; set; }
    }

    public class CustCntr3
    {
        public List<Result2> results { get; set; }
    }

    public class CustCntr4
    {
        public List<Result2> results { get; set; }
    }

    public class CustCurcountry
    {
        public List<Result2> results { get; set; }
    }

    public class CustCurstate
    {
        public List<Result2> results { get; set; }
    }

    public class CustDiplomaattach
    {
        public List<Result2> results { get; set; }
    }

    public class CustDiplomaModeofEdu
    {
        public List<Result2> results { get; set; }
    }
    public class CustCurAddProofattach
    {
        public List<Result2> results { get; set; }
    }
    public class CustEmptype1
    {
        public List<Result2> results { get; set; }
    }

    public class CustEmptype2
    {
        public List<Result2> results { get; set; }
    }

    public class CustEmptype3
    {
        public List<Result2> results { get; set; }
    }

    public class CustLetterattach1
    {
        public List<Result2> results { get; set; }
    }

    public class CustLetterattach2
    {
        public List<Result2> results { get; set; }
    }

    public class CustLetterattach3
    {
        public List<Result2> results { get; set; }
    }

    public class CustLetterOfAuthorization
    {
        public List<Result2> results { get; set; }
    }

    public class CustPANattach
    {
        public List<Result2> results { get; set; }
    }

    public class CustPermAddProofattach
    {
        public List<Result2> results { get; set; }
    }

    public class CustPermcountry
    {
        public List<Result2> results { get; set; }
    }

    public class CustPermstate1
    {
        public List<Result2> results { get; set; }
    }

    public class CustPostGradDegattach
    {
        public List<Result2> results { get; set; }
    }

    public class CustPostGradModeofEdu
    {
        public List<Result2> results { get; set; }
    }

    public class CustStat1
    {
        public List<Result2> results { get; set; }
    }

    public class CustStat2
    {
        public List<Result2> results { get; set; }
    }

    public class CustStat3
    {
        public List<Result2> results { get; set; }
    }

    public class CustStat4
    {
        public List<Result2> results { get; set; }
    }

    public class D11
    {
        public List<Result2> results { get; set; }
    }

    public class Metadata
    {
        public string uri { get; set; }
        public string type { get; set; }
    }

    public class PackageId
    {
        public List<Result2> results { get; set; }
    }

    public class Result2
    {
        public Metadata __metadata { get; set; }
        public string applicationId { get; set; }
        public string cust_connectemp1 { get; set; }
        public object cust_instrref3 { get; set; }
        public string cust_rel3 { get; set; }
        public string cust_rel2 { get; set; }
        public string cust_rel1 { get; set; }
        public string cust_connectemp2 { get; set; }
        public string cust_connectemp3 { get; set; }
        public string cust_org2 { get; set; }
        public string cust_org3 { get; set; }
        public string cust_org1 { get; set; }
        public DateTime? cust_endyr4 { get; set; }
        public string cust_endyr5 { get; set; }
        public DateTime? cust_endyr2 { get; set; }
        public DateTime? cust_endyr3 { get; set; }
        public DateTime? cust_endyr1 { get; set; }
        public string cust_curaddressLine2 { get; set; }
        public DateTime? cust_Permperiodofstay { get; set; }
        public string cust_coursecom5 { get; set; }
        public object cust_instr10th { get; set; }
        public string cust_curLandmark { get; set; }
        public object cust_instrCurrentaddress { get; set; }
        public string lastName { get; set; }
        public string cust_insname2 { get; set; }
        public string cust_UAN { get; set; }
        public string cust_curcity { get; set; }
        public object cust_dip5 { get; set; }
        public string jobReqId { get; set; }
        public string cust_name3 { get; set; }
        public string cust_name2 { get; set; }
        public string cust_desi3 { get; set; }
        public DateTime? cust_startdate2 { get; set; }
        public string cust_name1 { get; set; }
        public DateTime? cust_startdate3 { get; set; }
        public string cust_startdate1 { get; set; }
        public DateTime? dateOfBirth { get; set; }
        public string cust_desi1 { get; set; }
        public string cust_desi2 { get; set; }
        public string cellPhone { get; set; }
        public object cust_instrPermaddress { get; set; }
        public string cust_curzip { get; set; }
        public object cust_instrbacdeg { get; set; }
        public string cust_reasonforchange3 { get; set; }
        public string cust_PAN { get; set; }
        public string cust_reasonforchange1 { get; set; }
        public string cust_reasonforchange2 { get; set; }
        public string cust_Permaddline2 { get; set; }
        public string cust_Permcity1 { get; set; }
        public string cust_Permaddline1 { get; set; }
        public object cust_instrrefdetails { get; set; }
        public string cust_Empname3 { get; set; }
        public string cust_highcomedu { get; set; }
        public string cust_Empname2 { get; set; }
        public string cust_uni1 { get; set; }
        public string cust_Empname1 { get; set; }
        public string cust_uni2 { get; set; }
        public string cust_lastdeg3 { get; set; }
        public string cust_lastdeg2 { get; set; }
        public string cust_lastdeg1 { get; set; }
        public string cust_sch4 { get; set; }
        public string cust_sch3 { get; set; }
        public string cust_Permzip { get; set; }
        public DateTime? cust_Permperiodofstayend { get; set; }
        public DateTime? cust_curPeriodofStay { get; set; }
        public object cust_instr12th { get; set; }
        public string firstName { get; set; }
        public string candidateId { get; set; }
        public object cust_instrEmployer2 { get; set; }
        public object cust_instrEmployer1 { get; set; }
        public DateTime? cust_curperiodofstayend { get; set; }
        public DateTime? cust_startyr2 { get; set; }
        public DateTime? cust_startyr1 { get; set; }
        public DateTime? cust_startyr4 { get; set; }
        public DateTime? cust_startyr3 { get; set; }
        public string cust_board3 { get; set; }
        public string cust_board4 { get; set; }
        public bool? cust_curtilldate { get; set; }
        public DateTime? cust_tenenddate3 { get; set; }
        public DateTime? cust_tenenddate2 { get; set; }
        public DateTime? cust_tenenddate1 { get; set; }
        public string cust_degdip5 { get; set; }
        public object cust_instrEmployer3 { get; set; }
        public string cust_roll5 { get; set; }
        public string cust_roll3 { get; set; }
        public string cust_nameadd5 { get; set; }
        public string cust_roll4 { get; set; }
        public string cust_roll1 { get; set; }
        public string cust_roll2 { get; set; }
        public string cust_empid3 { get; set; }
        public string cust_curaddress { get; set; }
        public bool? cust_Permtilldate { get; set; }
        public string cust_empid2 { get; set; }
        public object cust_instrBGCIISERVZ { get; set; }
        public string cust_empid1 { get; set; }
        public object cust_instrpostgrad { get; set; }
        public string cust_Permlandmark { get; set; }
        public string cust_num3 { get; set; }
        public string cust_num2 { get; set; }
        public string middleName { get; set; }
        public string cust_num1 { get; set; }
        public object cust_instrref2 { get; set; }
        public object cust_instrref1 { get; set; }
        public CustEmptype2 cust_emptype2 { get; set; }
        public CustEmptype3 cust_emptype3 { get; set; }
        public CustEmptype1 cust_emptype1 { get; set; }
        public CustCurstate cust_curstate { get; set; }
        public CustDiplomaModeofEdu cust_DiplomaModeofEdu { get; set; }
        public CustBachDegattach custBachDegattach { get; set; }
        public CustLetterattach2 custLetterattach2 { get; set; }
        public CustLetterattach3 custLetterattach3 { get; set; }
        public CustPermstate1 cust_Permstate1 { get; set; }
        public CustInsname1 cust_insname1 { get; set; }
        public CustLetterattach1 custLetterattach1 { get; set; }
        public CustPermAddProofattach custPermAddProofattach { get; set; }
        public PackageId packageId { get; set; }
        public CustAadhaarattach custAadhaarattach { get; set; }
        public CustPostGradModeofEdu cust_PostGradModeofEdu { get; set; }
        public Cust12thModeofEdu cust_12thModeofEdu { get; set; }
        public Cust12attach cust12attach { get; set; }
        public CustDiplomaattach custDiplomaattach { get; set; }
        public CustLetterOfAuthorization custLetterOfAuthorization { get; set; }
        public CustCurcountry cust_curcountry { get; set; }
        public CustCurAddProofattach custCurAddProofattach { get; set; }
        public CustStat4 cust_stat4 { get; set; }
        public CustStat2 cust_stat2 { get; set; }
        public CustPANattach custPANattach { get; set; }
        public CustStat3 cust_stat3 { get; set; }
        public CustStat1 cust_stat1 { get; set; }
        public CustBatchModeofEdu cust_BatchModeofEdu { get; set; }
        public CustCntr3 cust_cntr3 { get; set; }
        public CustCntr4 cust_cntr4 { get; set; }
        public CustCntr1 cust_cntr1 { get; set; }
        public CustCntr2 cust_cntr2 { get; set; }
        public CustPermcountry cust_Permcountry { get; set; }
        public Cust10attach cust10attach { get; set; }
        public Cust10thModeofEdu cust_10thModeofEdu { get; set; }
        public CustBGCApplicableType cust_BGCApplicableType { get; set; }
        public CustPostGradDegattach custPostGradDegattach { get; set; }
        public string localeLabel { get; set; }
        public string fileName { get; set; }
        public string fileExtension { get; set; }
        public string mimeType { get; set; }
        public string fileContent { get; set; }
    }

    public class candidate
    {
        public D11 d { get; set; }
    }



}
﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DataAccess;
using procall1;
using Casestatus;
using System.Drawing;
using IISERVZCLASS;
using System.Text;


public partial class BgcStatus : System.Web.UI.Page
{
    procall pc = new procall();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {


        string str = "";
        if (!Page.IsPostBack)
        {
            if (Session["UserType"] == null)
            {
                Response.Redirect("HRLogin.aspx");
            }
            else
            {
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");
            }

           str= Session["UserType"].ToString();
            if (str == "Hiring")
            {
                Response.Redirect("CandidateLogin.aspx");
            }
        }
        GridView1.Width.Equals("200px");
      

        //GridView1.Columns[1].Visible = false;

        string username = Session["UserName"].ToString();
        if (username == "kpmg" && str == "ClientPlusReject")
        {
            //fc.Visible = false;
            //bs.Visible = false;
        }
        else
        {
            //fc.Visible = true;
            //bs.Visible = true;
        }

        if (str == "Admin")
        {
            //td1.Visible = false;
            //td2.Visible = true;
            //rj.Visible = false;
            //fc.Visible = false;
            //rj.Visible = false;


        }
        if (str == "Hiring")
        {
            //td1.Visible = false;
            //td2.Visible = false;
            //rj.Visible = false;
            //fc.Visible = false;
            //rj.Visible = false;

        }
        if (str == "ClientPlusReject")
        {
            //td1.Visible = true;
            //td2.Visible = false;
            //rj.Visible = true;


        }
   

        if (!IsPostBack)
        {
        //    DateTime dt = System.DateTime.Now;
        //    string str1 = dt.ToString("dd/MM/yyyy");
        //    txtFromDate.Text = str1;
        //    txtToDate.Text = str1;
        //    string fromdate = "";
        //    string todate = "";
            
        //    if (txtFromDate.Text.Length > 0 && txtToDate.Text.Length > 0)
        //    {
        //        fromdate = txtFromDate.Text;
        //        todate = txtToDate.Text;

        //        ds = pc.SearchbyClientt(Session["userName"].ToString(), Session["UserType"].ToString(), fromdate, todate,"Default");
        //        ViewState["Report"] = ds;
        //       if (ds.Tables.Count > 0)
        //    {
        //        GridView1.DataSource = ds;
        //        GridView1.DataBind();
        //    }
        //}
            BindGridview();
        }
        
    }

    private void BindGridview()
    {
        DataTable dt = new DataTable();
        string CS = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        string Query = "lightDashboard";
        using (SqlConnection con = new SqlConnection(CS))
        {
            DataTable ds = new DataTable();
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = Query;
            da.SelectCommand = cmd;
            da.Fill(ds);
            con.Close();
            GridView1.DataSource = ds;
            GridView1.DataBind();
            ViewState["Report"] = ds;
            lblTotalCount.Text = "Record -" + " " + "(" + GridView1.Rows.Count.ToString() + ")";
            //lblCount.Text = "Currently Record Found -" + " " + "(" + GridView1.Rows.Count.ToString() + ")";
        }
    }
      
  
    
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (Session["PortalUSerType"].ToString() != "iiservz")
        {
            //e.Row.Cells[0].Visible = false;
            //e.Row.Cells[5].Visible = false;
           // e.Row.Cells[11].Visible = false;
            //e.Row.Cells[0].Visible = false;
            //e.Row.Cells[0].Visible = false;
            //e.Row.Cells[0].Visible = false;
        }
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //if (Session["UserType"].ToString() == "Admin")
            //{
            //    ((CheckBox)e.Row.FindControl("chkofferdrop")).Attributes.Add("onclick", "javascript:return HideandShowTextBox('" + ((CheckBox)e.Row.FindControl("chkofferdrop")).ClientID + "*" + ((TextBox)e.Row.FindControl("txtcomment")).ClientID + "*" + ((Button)e.Row.FindControl("btn1")).ClientID + "')");
            //    ((Button)e.Row.FindControl("btn1")).Style.Add("display", "none");
            //    ((TextBox)e.Row.FindControl("txtcomment")).Style.Add("display", "none");
            //    ((CheckBox)e.Row.FindControl("chkofferdrop")).Enabled = false;

            //}
           
            
            //else
            //{
            //    string strScript = "uncheckOthers(" + ((CheckBox)e.Row.Cells[0].FindControl("chkofferdrop")).ClientID + ");";
            //    ((CheckBox)e.Row.Cells[0].FindControl("chkofferdrop")).Attributes.Add("onclick", "javascript:return Selectone(this,'" + GridView1.ClientID + "');");
            //    //((CheckBox)e.Row.Cells[0].FindControl("caseinitialize")).Attributes.Add("onclick", "checkBox1OnClick(this);");

            //    ((CheckBox)e.Row.FindControl("chkofferdrop")).Attributes.Add("onclick", "javascript:return HideandShowTextBox('" + ((CheckBox)e.Row.FindControl("chkofferdrop")).ClientID + "*" + ((TextBox)e.Row.FindControl("txtcomment")).ClientID + "*" + ((Button)e.Row.FindControl("btn1")).ClientID + "')");
            //    ((Button)e.Row.FindControl("btn1")).Style.Add("display", "none");
            //    ((TextBox)e.Row.FindControl("txtcomment")).Style.Add("display", "none");
            //}


        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    { 
                
         try
         {
             procall pc = new procall();
             DataSet ds = new DataSet();
                if (e.CommandName == "btn1")// for accept
                {
                  
                    for (int i = 0; i < GridView1.Rows.Count; i++)
                    {
                        Button bts = e.CommandSource as Button;
                        int rowIndex = Convert.ToInt32(e.CommandArgument);
                        GridViewRow row = GridView1.Rows[i];
                        bool isrevert = ((CheckBox)row.FindControl("chkfollow")).Checked;
                        if (isrevert)
                        {
                            
                            string acceptuser = Session["UserName"].ToString();
                           
                        }
                        
                    }
                    Response.Write("<Script Language='javascript'> alert('Case has been moved in fast track')</Script>");
                }
                DateTime dt = System.DateTime.Now;
                string str1 = dt.ToString("dd/MM/yyyy");
                txtFromDate.Text = str1;
                txtToDate.Text = str1;
                string fromdate = "";
                string todate = "";

                if (txtFromDate.Text.Length > 0 && txtToDate.Text.Length > 0)
                {
                    fromdate = txtFromDate.Text;
                    todate = txtToDate.Text;

                    ds = pc.SearchbyClientt(Session["userName"].ToString(), Session["UserType"].ToString(), fromdate, todate, "Default");
                    ViewState["Report"] = ds;
                    if (ds.Tables.Count > 0)
                    {
                        GridView1.DataSource = ds;
                        GridView1.DataBind();
                    }
                }
        }
         catch (Exception ex)
         {
             Response.Write("<script language='javascript'>alert('" + ex.Message + "')</script>");
         }
    }
    //protected void btncasestatus_Click(object sender, EventArgs e)
    //{
    //    procall pc = new procall();
    //    DataSet ds = new DataSet();
    //    ds = pc.casestatus(Session["userName"].ToString(), Session["UserType"].ToString());
    //    GridView1.DataSource = ds;
    //    GridView1.DataBind();

    //}
    protected void btnmisreport_Click(object sender, EventArgs e)
    {

        //procall pc = new procall();
        //DataSet ds = new DataSet();
        //string fromdate = "";
        //string todate = "";
        //fromdate = txtFromDate.Text;
        //todate = txtToDate.Text;
        //ds = pc.SearchbyClient(Session["userName"].ToString(), Session["UserType"].ToString(),fromdate,todate);
        //GridView1.DataSource = ds;
        //GridView1.DataBind();
    }

    public string Encript(String RefId)
    {
        ValidateLogin obj = new ValidateLogin();
        string val = obj.Encrypt(RefId);
        return val;
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        procall pc = new procall();
        DataSet ds = new DataSet();

        if (txtFromDate.Text != "" && txtToDate.Text != "")
        {
            
                string fromdate = "";
                string todate = "";
                fromdate = txtFromDate.Text;
                todate = txtToDate.Text;
                ds = pc.SearchbyClientt(Session["userName"].ToString(), Session["UserType"].ToString(), fromdate, todate, "Default");





              
                
            if (ds.Tables.Count > 0)
            {
                ViewState["Report"] = ds;
                GridView1.DataSource = ds;
                GridView1.DataBind();
            }
        }
        else
        {
            Response.Write("<Script Language='javascript'> alert('Please Select Date!')</Script>");
        }
    }
    protected void btnexporttoexcel_Click(object sender, EventArgs e)
    {
        GridView gridvw = new GridView();
        DataTable ds = ViewState["Report"] as DataTable;

        if (ds.Rows.Count > 0)
        {
            gridvw.DataSource = ds;
            gridvw.DataBind();
            ViewState["ReportList"] = ds;
        }



        if (gridvw.Rows.Count > 0)
        {

            for (int i = 0; i < gridvw.Rows.Count; i++)
            {
                //gridvw.HeaderRow.Cells[0].Visible = false;
                //gridvw.HeaderRow.Cells[1].Visible = false;

                //GridViewRow row = gridvw.Rows[i];
                //row.Cells[0].Visible = false;
                //row.Cells[1].Visible = false;
               
            }

            gridvw.HeaderStyle.BackColor = System.Drawing.Color.White;
            gridvw.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            gridvw.ForeColor = System.Drawing.Color.Black;
            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=MIS" + DateTime.Now.ToString("dd-MM-yyyy") + ".xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.xls";
            this.EnableViewState = false;
            System.IO.StringWriter stringWrite = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
            HtmlForm form1 = new HtmlForm();
            this.Controls.Add(form1);

            form1.Controls.Add(gridvw);
            form1.RenderControl(htmlWrite);

            Response.Write(stringWrite.ToString());
            Response.End();
        }
        else
        {
            Response.Write("<Script Language='javascript'> alert('No Rows!')</Script>");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        procall pc = new procall();
        DataSet ds = new DataSet();
       
        ds = pc.SearchbyClientt(Session["userName"].ToString(), Session["UserType"].ToString(), "", "", "FNS");
        if (ds.Tables.Count > 0)
        {
            ViewState["Report"] = ds;
        GridView1.DataSource = ds;
        GridView1.DataBind();
        }
        GridView1.Columns[1].Visible = true;
        GridView1.Columns[0].Visible = false;
        

    }

    protected void ImageButton1_Click(object sender, EventArgs e)
    {
        procall pc = new procall();
        DataSet ds = new DataSet();

        if (txtFromDate.Text != "" && txtToDate.Text != "")
        {

            string fromdate = "";
            string todate = "";
            fromdate = txtFromDate.Text;
            todate = txtToDate.Text;
            ds = pc.SearchbyClientt(Session["userName"].ToString(), Session["UserType"].ToString(), fromdate, todate, "Default");
            if (ds.Tables.Count > 0)
            {
                ViewState["Report"] = ds;
                GridView1.DataSource = ds;
                GridView1.DataBind();
            }
        }
        else
        {
            Response.Write("<Script Language='javascript'> alert('Please Select Date!')</Script>");
        }
    }


    public string GetVisual()
    {
        if (Session["userName"].ToString().ToLower() == "iiservz")
        {
            return "true";
        }
        else
        {
            return "false";
        }
    }
}


﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Net;
using RestSharp;
using System.Xml;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;

public partial class BgvDetailsNew : System.Web.UI.Page
{
    DataTable ds = new DataTable();
    DataSet ds1 = new DataSet();
    DataSet ds2 = new DataSet();
    DataSet ds3 = new DataSet();
   
    SqlDataAdapter adapter = new SqlDataAdapter();
    string sql = null;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {
        //var clients = new RestClient("https://api44preview.sapsf.com/odata/v2/JobApplication?$format=json&$select=candidateId,applicationId,firstName,middleName,lastName,cellPhone,dateOfBirth,cust_curaddress,cust_addressLine2,cust_curLandmark,cust_curzip,cust_curcountry/localeLabel,cust_curstate/localeLabel,cust_curcity,cust_curPeriodofStay,cust_curtilldate,cust_curperiodofstayend,cust_instrCurrentaddress,cust_Permaddline1,cust_Permaddline2,cust_Permlandmark,cust_Permzip,cust_Permcountry/localeLabel,cust_Permstate1/localeLabel,cust_Permcity1,cust_Permperiodofstay,cust_Permtilldate,cust_Permperiodofstayend,cust_instrPermaddress,custaddressproof/fileContent,custaddressproof/fileExtension,custaddressproof/fileName,custaddressproof/mimeType,cust_highcomedu,cust_uni1,cust_insname1,cust_coursecom1,cust_roll1,cust_endyr1,cust_Empname1,cust_startdate1,cust_tenenddate1,cust_empid1,cust_LastDesig,cust_Reasonforchange,cust_UAN,custLetterOfAuthorization/fileContent,custLetterOfAuthorization/fileExtension,custLetterOfAuthorization/fileName,custLetterOfAuthorization/mimeType,cust_instrref1,cust_name1,cust_org1,cust_rel1,cust_num1,cust_instrref2, cust_name2, cust_org2,cust_rel2,cust_num2,cust_instrref3,cust_name3,cust_org3,cust_rel3,cust_num3,custeducationdetails/fileContent,custeducationdetails/fileExtension,custeducationdetails/fileName,custeducationdetails/mimeType,cust_BGCApplicableType/localeLabel,cust_instrBGCIISERVZ,custPANattach/fileContent,custPANattach/fileExtension,custPANattach/fileName,custPANattach/mimeType,custAadhaarattach/fileContent,custAadhaarattach/fileExtension,custAadhaarattach/fileName,custAadhaarattach/mimeType&$expand=custLetterOfAuthorization,cust_curcountry,cust_curstate,cust_Permcountry,cust_Permstate1,custaddressproof,custeducationdetails,cust_BGCApplicableType,custPANattach,custAadhaarattach");
        //var clients = new RestClient("https://api44preview.sapsf.com/odata/v2/JobApplication?$format=json&$select=candidateId,applicationId,firstName,middleName,lastName,cellPhone,dateOfBirth,cust_curaddress,cust_addressLine2,cust_curLandmark,cust_curcity,cust_curPeriodofStay,cust_curtilldate,cust_curperiodofstayend,cust_instrCurrentaddress,cust_Permaddline1,cust_Permaddline2,cust_Permlandmark,cust_Permzip,cust_Permcity1,cust_Permperiodofstay,cust_Permtilldate,cust_Permperiodofstayend,cust_instrPermaddress,cust_highcomedu,cust_uni1,cust_insname1,cust_coursecom1,cust_roll1,cust_endyr1,cust_Empname1,cust_startdate1,cust_tenenddate1,cust_empid1,cust_LastDesig,cust_Reasonforchange,cust_UAN,cust_instrref1,cust_name1,cust_org1,cust_rel1,cust_num1,cust_instrref2, cust_name2, cust_org2,cust_rel2,cust_num2,cust_instrref3,cust_name3,cust_org3,cust_rel3,cust_num3,cust_instrBGCIISERVZ,&$expand=custLetterOfAuthorization,cust_curcountry,cust_curstate,cust_Permcountry,cust_Permstate1,custaddressproof,custeducationdetails,cust_BGCApplicableType,custPANattach,custAadhaarattach");

        var clients = new RestClient("https://api44preview.sapsf.com/odata/v2/JobApplication?$format=json&$select=candidateId,applicationId,firstName,middleName,lastName,cellPhone,dateOfBirth,cust_curaddress,cust_addressLine2,cust_curLandmark,cust_curcity,cust_curPeriodofStay,cust_curtilldate,cust_curperiodofstayend,cust_instrCurrentaddress,cust_Permaddline1,cust_Permaddline2,cust_Permlandmark,cust_Permzip,cust_Permcity1,cust_Permperiodofstay,cust_Permtilldate,cust_Permperiodofstayend,cust_instrPermaddress,cust_highcomedu,cust_uni1,cust_insname1,cust_coursecom1,cust_roll1,cust_endyr1,cust_Empname1,cust_startdate1,cust_tenenddate1,cust_empid1,cust_LastDesig,cust_Reasonforchange,cust_UAN,cust_instrref1,cust_name1,cust_org1,cust_rel1,cust_num1,cust_instrref2, cust_name2, cust_org2,cust_rel2,cust_num2,cust_instrref3,cust_name3,cust_org3,cust_rel3,cust_num3,cust_instrBGCIISERVZ,packageId/localeLabel&$expand=custLetterOfAuthorization,cust_curcountry,cust_curstate,cust_Permcountry,cust_Permstate1,custaddressproof,custeducationdetails,cust_BGCApplicableType,custPANattach,custAadhaarattach,packageId");
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        var requests = new RestRequest(Method.GET);
        requests.AddHeader("Authorization", "Basic SW50ZWdyYXRpb25fUHJldmlld0BiaXJsYXNvZnRsVDE6V2VsY29tZUA5ODc=");
        requests.AddParameter("undefined", ParameterType.RequestBody);
        IRestResponse responses = clients.Execute(requests);
        if (responses.StatusCode.ToString() == "OK")
        {
            string Apiresponse = responses.Content;
            var myDetails = JsonConvert.DeserializeObject<Root>(Apiresponse);
            // ds = JsonStringToDataTable(Apiresponse);
            Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(Apiresponse);

            con.Open();
            for (int i = 0; i <= myDeserializedClass.d.results.Count - 1; i++)
            {
                string jsonString = JsonConvert.SerializeObject(myDeserializedClass.d.results[i]);
                if (myDeserializedClass.d.results[i].cellPhone == null)
                {
                    myDeserializedClass.d.results[i].cellPhone = null;
                }

                string authors = myDeserializedClass.d.results[i].__metadata.uri.ToString();
                string[] authorsList = authors.Split('(');
                string applicationnumber = authorsList[1].Replace(")", "");

               

                //save employee information
                SqlCommand comm = new SqlCommand("EmployeeInfo_API_Insert", con);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.Add("@metadatauri", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].__metadata.uri ?? " ";
                comm.Parameters.Add("@metadatatype", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].__metadata.type ?? " ";
                comm.Parameters.Add("@applicationId", SqlDbType.Int).Value = myDetails.d.results[i].applicationId ?? " ";
                comm.Parameters.Add("@candidateId", SqlDbType.Int).Value = myDetails.d.results[i].candidateId ?? " ";
                comm.Parameters.Add("@cust_instrBGCIISERVZ", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_instrBGCIISERVZ ?? " ";
                comm.Parameters.Add("@firstName", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].firstName ?? " ";
                comm.Parameters.Add("@middleName", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].middleName ?? " ";
                comm.Parameters.Add("@lastName", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].lastName ?? " ";
                comm.Parameters.Add("@cellPhone", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cellPhone ?? " ";
                comm.Parameters.Add("@dateOfBirth", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].dateOfBirth ?? " ";
                comm.Parameters.Add("@cust_Permaddline1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permaddline1 ?? " ";
                comm.Parameters.Add("@cust_Permaddline2", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permaddline2 ?? " ";
                comm.Parameters.Add("@cust_Permcity1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permcity1 ?? " ";
                comm.Parameters.Add("@cust_Permzip", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permzip ?? " ";
                comm.Parameters.Add("@cust_curaddress", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_curaddress ?? " ";
                comm.Parameters.Add("@cust_addressLine2", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_addressLine2 ?? " ";
                comm.Parameters.Add("@cust_curcity", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_curcity ?? " ";
                comm.Parameters.Add("@cust_curLandmark", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_curLandmark ?? " ";
                comm.Parameters.Add("@cust_instrPermaddress", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_instrPermaddress ?? " ";
                comm.Parameters.Add("@cust_instrref3", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_instrref3 ?? " ";
                comm.Parameters.Add("@cust_rel3", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_rel3 ?? " ";
                comm.Parameters.Add("@cust_rel2", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_rel2 ?? " ";
                comm.Parameters.Add("@cust_rel1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_rel1 ?? " ";
                comm.Parameters.Add("@cust_org2", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_org2 ?? " ";
                comm.Parameters.Add("@cust_org3", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_org3 ?? " ";
                comm.Parameters.Add("@cust_org1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_org1 ?? " ";
                comm.Parameters.Add("@cust_highcomedu", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_highcomedu ?? " ";
                comm.Parameters.Add("@cust_uni1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_uni1 ?? " ";
                comm.Parameters.Add("@cust_Empname1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Empname1 ?? " ";
                comm.Parameters.Add("@cust_endyr1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_endyr1 ?? " ";
                comm.Parameters.Add("@cust_Reasonforchange", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Reasonforchange ?? " ";
                comm.Parameters.Add("@cust_Permperiodofstay", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permperiodofstay ?? " ";
                comm.Parameters.Add("@cust_Permperiodofstayend", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permperiodofstayend ?? " ";
                comm.Parameters.Add("@cust_curPeriodofStay", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_curPeriodofStay ?? " ";
                comm.Parameters.Add("@cust_coursecom1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_coursecom1 ?? " ";
                comm.Parameters.Add("@cust_instrCurrentaddress", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_instrCurrentaddress ?? " ";
                comm.Parameters.Add("@cust_curperiodofstayend", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_curperiodofstayend ?? " ";
                comm.Parameters.Add("@cust_insname1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_insname1 ?? " ";
                comm.Parameters.Add("@cust_curtilldate", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_curtilldate ?? " ";
                comm.Parameters.Add("@cust_tenenddate1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_tenenddate1 ?? " ";
                comm.Parameters.Add("@cust_UAN", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_UAN ?? " ";
                comm.Parameters.Add("@cust_roll1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_roll1 ?? " ";
                comm.Parameters.Add("@cust_Permtilldate", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permtilldate ?? " ";
                comm.Parameters.Add("@cust_empid1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_empid1 ?? " ";
                comm.Parameters.Add("@cust_name3", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_name3 ?? " ";
                comm.Parameters.Add("@cust_name2", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_name2 ?? " ";
                comm.Parameters.Add("@cust_name1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_name1 ?? " ";
                comm.Parameters.Add("@cust_startdate1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_startdate1 ?? " ";
                comm.Parameters.Add("@cust_LastDesig", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_LastDesig ?? " ";
                comm.Parameters.Add("@cust_Permlandmark", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_Permlandmark ?? " ";
                comm.Parameters.Add("@cust_num3", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_num3 ?? " ";
                comm.Parameters.Add("@cust_num2", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_num2 ?? " ";
                comm.Parameters.Add("@cust_num1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_num1 ?? " ";
                comm.Parameters.Add("@cust_instrref2", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_instrref2 ?? " ";
                comm.Parameters.Add("@cust_instrref1", SqlDbType.VarChar, 400).Value = myDetails.d.results[i].cust_instrref1 ?? " ";
                if (myDetails.d.results[i].packageId.results.Count > 0)
                {

                    var pacname = JsonConvert.DeserializeObject<packagename>(myDetails.d.results[i].packageId.results[0].ToString());
                    comm.Parameters.Add("@packagename", SqlDbType.VarChar, 400).Value = pacname.localeLabel ?? " ";
                }


                int Count = comm.ExecuteNonQuery();

                //}


            }

        }
        else
        {
            error.Text = "Error in fetching  API data";
        }

        string dtt = "select applicationId,candidateId,firstName,middleName,lastName,packageName,received_date from tbl_biralaSoftAPIData where received_data=0";
        SqlDataAdapter gridadpt = new SqlDataAdapter(dtt, con);
        gridadpt.Fill(ds);

        grid1.DataSource = ds;
        grid1.DataBind();
        

    }

    private DataSet getDataset(string query)
    {
        DataSet tempDataSet = new DataSet();
        SqlDataAdapter dap = new SqlDataAdapter(query, con);
        dap.Fill(tempDataSet);
        return tempDataSet;
    }

    protected void grid1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Select")
        {
            int rowIndex = Convert.ToInt32(e.CommandArgument);
            GridViewRow row = grid1.Rows[rowIndex];
            string Cid = row.Cells[1].Text;           
            string url1 = "";
            string url2 = "";
            string url3 = "";
            string str = string.Format("select metadatauri from tbl_biralaSoftAPIData where applicationId =" + Cid);
            ds1 = getDataset(str);
             url1 = ds1.Tables[0].Rows[0]["metadatauri"].ToString();


             var client = new RestClient(url1);
             var request = new RestRequest(Method.GET);
             request.AddHeader("Authorization", "Basic SW50ZWdyYXRpb25fUHJldmlld0BiaXJsYXNvZnRsVDE6V2VsY29tZUA5ODc=");
             // request.AddHeader("Content-Type", "application/json");
             request.AddParameter("undefined", ParameterType.RequestBody);
             IRestResponse response = client.Execute(request);
             string Apiresponse = response.Content;
             var EmployeeDetail = JsonConvert.DeserializeObject<CandidateDetail>(Apiresponse);

            //
             SqlCommand comm = new SqlCommand("candidateInfo_Data_Insert", con);
             comm.CommandType = CommandType.StoredProcedure;
             comm.Parameters.Add("@metadatauri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.__metadata.uri ?? " ";
             comm.Parameters.Add("@metadatatype", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.__metadata.type ?? " ";
             comm.Parameters.Add("@applicationId", SqlDbType.Int).Value = EmployeeDetail.d.applicationId ?? " ";
             comm.Parameters.Add("@candidateId", SqlDbType.Int).Value = EmployeeDetail.d.candidateId ?? " ";
             comm.Parameters.Add("@firstName", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.firstName ?? " ";
             comm.Parameters.Add("@middleName", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.middleName ?? " ";
             comm.Parameters.Add("@lastName", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.lastName ?? " ";
             comm.Parameters.Add("@contactEmail", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.contactEmail ?? " ";
             comm.Parameters.Add("@gender", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.gender ?? " ";
             comm.Parameters.Add("@cellPhone", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cellPhone ?? " ";
             comm.Parameters.Add("@cust_PAN", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_PAN ?? " ";
             comm.Parameters.Add("@cust_UAN", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_UAN ?? " ";
             comm.Parameters.Add("@jobReqId", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.jobReqId ?? " ";
             comm.Parameters.Add("@address", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.address ?? " ";
             comm.Parameters.Add("@city", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.city ?? " ";
             comm.Parameters.Add("@country", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.country ?? " ";
             comm.Parameters.Add("@countryCode", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.countryCode ?? " ";
             comm.Parameters.Add("@zip", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.zip ?? " ";
             comm.Parameters.Add("@cust_AadhaarNumber", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_AadhaarNumber ?? " ";
             comm.Parameters.Add("@cust_Addiskills", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Addiskills ?? " ";
             comm.Parameters.Add("@cust_addr1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_addr1 ?? " ";
             comm.Parameters.Add("@cust_addr2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_addr2 ?? " ";
             comm.Parameters.Add("@cust_addr3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_addr3 ?? " ";
             comm.Parameters.Add("@cust_addr4", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_addr4 ?? " ";
             comm.Parameters.Add("@cust_addr5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_addr5 ?? " ";
             comm.Parameters.Add("@cust_addr6", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_addr6 ?? " ";
             comm.Parameters.Add("@cust_addr7", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_addr7 ?? " ";
             comm.Parameters.Add("@cust_PassportExpiry", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_PassportExpiry ?? " ";
             comm.Parameters.Add("@cust_PassportNo", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_PassportNo ?? " ";
             comm.Parameters.Add("@cust_Permaddline1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Permaddline1 ?? " ";
             comm.Parameters.Add("@cust_Permaddline2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Permaddline2 ?? " ";
             comm.Parameters.Add("@cust_Permbesttime", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Permbesttime ?? " ";
             comm.Parameters.Add("@cust_Permcity", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Permcity ?? " ";
             comm.Parameters.Add("@cust_Permcity1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Permcity1 ?? " ";
             comm.Parameters.Add("@cust_Permcontact", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Permcontact ?? " ";
             comm.Parameters.Add("@cust_Permlandmark", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Permlandmark ?? " ";
             comm.Parameters.Add("@cust_Permzip", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Permzip ?? " ";
             comm.Parameters.Add("@cust_BGC_AB_ResultCaseStatus", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_AB_ResultCaseStatus ?? " ";
             comm.Parameters.Add("@cust_BGC_AB_ResultReportDate", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_AB_ResultReportDate ?? " ";
             comm.Parameters.Add("@cust_BGC_AB_ResultReportSeverity1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_AB_ResultReportSeverity1 ?? " ";
             comm.Parameters.Add("@cust_BGC_AB_ResultReportSeverity2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_AB_ResultReportSeverity2 ?? " ";
             comm.Parameters.Add("@cust_BGC_AB_ResultReportSeverity3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_AB_ResultReportSeverity3 ?? " ";
             comm.Parameters.Add("@cust_BGC_AB_ResultReportSeverity4", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_AB_ResultReportSeverity4 ?? " ";
             comm.Parameters.Add("@cust_BGC_AB_ResultReportSeverity5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_AB_ResultReportSeverity5 ?? " ";
             comm.Parameters.Add("@cust_BGC_AB_ResultReportSeverity6", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_AB_ResultReportSeverity6 ?? " ";
             comm.Parameters.Add("@cust_BGC_AB_ResultReportType", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_AB_ResultReportType ?? " ";
             comm.Parameters.Add("@cust_BGC_AB_ResultUniqueID", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_AB_ResultUniqueID ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ACKComment", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ACKComment ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_RefId", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_RefId ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultCheckwiseComment1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultCheckwiseComment1 ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultCheckwiseComment2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultCheckwiseComment2 ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultCheckwiseComment3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultCheckwiseComment3 ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultCheckwiseComment4", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultCheckwiseComment4 ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultCheckwiseComment5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultCheckwiseComment5 ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultCheckwiseComment6", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultCheckwiseComment6 ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultCheckwiseComment7", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultCheckwiseComment7 ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultCheckwiseStatus1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultCheckwiseStatus1 ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultCheckwiseStatus2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultCheckwiseStatus2 ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultCheckwiseStatus3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultCheckwiseStatus3 ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultCheckwiseStatus4", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultCheckwiseStatus4 ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultCheckwiseStatus5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultCheckwiseStatus5 ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultCheckwiseStatus6", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultCheckwiseStatus6 ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultCheckwiseStatus7", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultCheckwiseStatus7 ?? " ";
            //
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultColorCode", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultColorCode ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultFinalComment", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultFinalComment ?? " ";
             comm.Parameters.Add("@cust_connectemp1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_connectemp1 ?? " ";
             comm.Parameters.Add("@cust_TALeadComments", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_TALeadComments ?? " ";
             comm.Parameters.Add("@cust_connectemp2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_connectemp2 ?? " ";
             comm.Parameters.Add("@cust_connectemp3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_connectemp3 ?? " ";
             comm.Parameters.Add("@usersSysId", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.usersSysId ?? " ";
             comm.Parameters.Add("@cust_TotalExpyrs", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_TotalExpyrs ?? " ";
             comm.Parameters.Add("@cust_disclaimerAcknowledge", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_disclaimerAcknowledge ?? " ";
             comm.Parameters.Add("@cust_LastEmplr", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_LastEmplr ?? " ";
             comm.Parameters.Add("@cust_Permperiodofstay", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Permperiodofstay ?? " ";
             comm.Parameters.Add("@statusComments", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.statusComments ?? " ";
             comm.Parameters.Add("@cust_HighEdu", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_HighEdu ?? " ";
             comm.Parameters.Add("@cust_curLandmark", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_curLandmark ?? " ";
             comm.Parameters.Add("@cust_SpecialAnnual", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_SpecialAnnual ?? " ";
             comm.Parameters.Add("@Cust_CandidateName", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_CandidateName ?? " ";
             comm.Parameters.Add("@duplicateProfile", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.duplicateProfile ?? " ";
             comm.Parameters.Add("@cust_curcity", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_curcity ?? " ";
             comm.Parameters.Add("@cust_curcontact", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_curcontact ?? " ";
             comm.Parameters.Add("@cust_TotExpmth", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_TotExpmth ?? " ";
             comm.Parameters.Add("@cust_Gratuity", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Gratuity ?? " ";
             comm.Parameters.Add("@cust_dip5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_dip5 ?? " ";
             comm.Parameters.Add("@cust_instrOfferedCTC", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrOfferedCTC ?? " ";
             comm.Parameters.Add("@cust_name3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_name3 ?? " ";
             comm.Parameters.Add("@cust_name2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_name2 ?? " ";
             comm.Parameters.Add("@cust_name1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_name1 ?? " ";
             comm.Parameters.Add("@cust_instrPreliminaryInfo", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrPreliminaryInfo ?? " ";
             comm.Parameters.Add("@cust_SpecialBonus1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_SpecialBonus1 ?? " ";
             comm.Parameters.Add("@cust_interviewnotes", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_interviewnotes ?? " ";
             comm.Parameters.Add("@cust_deg2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_deg2 ?? " ";
             comm.Parameters.Add("@cust_deg1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_deg1 ?? " ";
             comm.Parameters.Add("@cust_instrbacdeg", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrbacdeg ?? " ";
             comm.Parameters.Add("@preferredLoc", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.preferredLoc ?? " ";
             comm.Parameters.Add("@cust_PF_Annual", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_PF_Annual ?? " ";
             comm.Parameters.Add("@LegacyAppid", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.LegacyAppid ?? " ";
             comm.Parameters.Add("@cust_MedicalAnnual", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_MedicalAnnual ?? " ";
             comm.Parameters.Add("@cust_uni1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_uni1 ?? " ";
             comm.Parameters.Add("@cust_uni2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_uni2 ?? " ";
             comm.Parameters.Add("@cust_mintimetojoin", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_mintimetojoin ?? " ";
             comm.Parameters.Add("@cust_TotExpyrs", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_TotExpyrs ?? " ";
             comm.Parameters.Add("@cust_Reasonforchange", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Reasonforchange ?? " ";
             comm.Parameters.Add("@cust_instrreldetails", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrreldetails ?? " ";
             comm.Parameters.Add("@ownershpDate", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.ownershpDate ?? " ";
             comm.Parameters.Add("@anonymizedDate", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.anonymizedDate ?? " ";
             comm.Parameters.Add("@cust_rel", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_rel ?? " ";
             comm.Parameters.Add("@cust_Designation", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Designation ?? " ";
             comm.Parameters.Add("@Cust_TSCScreeningQ6", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_TSCScreeningQ6 ?? " ";
             comm.Parameters.Add("@cust_reldeg", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_reldeg ?? " ";
             comm.Parameters.Add("@applicationDate", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.applicationDate ?? " ";
             comm.Parameters.Add("@cust_hremail2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_hremail2 ?? " ";
             comm.Parameters.Add("@cust_reldep", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_reldep ?? " ";
             comm.Parameters.Add("@cust_hremail3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_hremail3 ?? " ";
             comm.Parameters.Add("@cust_curperiodofstayend", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_curperiodofstayend ?? " ";
             comm.Parameters.Add("@cust_board3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_board3 ?? " ";
             comm.Parameters.Add("@cust_board4", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_board4 ?? " ";
             comm.Parameters.Add("@cust_hremail1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_hremail1 ?? " ";
             comm.Parameters.Add("@cust_instrbgcchkini", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrbgcchkini ?? " ";
             comm.Parameters.Add("@cust_Asondate", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Asondate ?? " ";
             comm.Parameters.Add("@cust_roll5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_roll5 ?? " ";
             comm.Parameters.Add("@cust_roll3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_roll3 ?? " ";
             comm.Parameters.Add("@cust_roll4", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_roll4 ?? " ";
             comm.Parameters.Add("@cust_roll1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_roll1 ?? " ";
             comm.Parameters.Add("@cust_roll2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_roll2 ?? " ";
             comm.Parameters.Add("@owner", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.owner ?? " ";
             comm.Parameters.Add("@cust_BasketAllowanceAnnual", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BasketAllowanceAnnual ?? " ";
             comm.Parameters.Add("@cust_instracademicrec", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instracademicrec ?? " ";
             comm.Parameters.Add("@cust_LastDesig", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_LastDesig ?? " ";
             comm.Parameters.Add("@exportedOn", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.exportedOn ?? " ";
             comm.Parameters.Add("@cust_empid", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_empid ?? " ";
             comm.Parameters.Add("@cust_num3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_num3 ?? " ";
             comm.Parameters.Add("@cust_num2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_num2 ?? " ";
             comm.Parameters.Add("@cust_Currency", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Currency ?? " ";
             comm.Parameters.Add("@cust_VPI", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_VPI ?? " ";
             comm.Parameters.Add("@cust_num1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_num1 ?? " ";
             comm.Parameters.Add("@cust_instrref3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrref3 ?? " ";
             comm.Parameters.Add("@cust_cost", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_cost ?? " ";
             comm.Parameters.Add("@cust_addressLine2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_addressLine2 ?? " ";
             comm.Parameters.Add("@cust_comaddress3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_comaddress3 ?? " ";
             comm.Parameters.Add("@cust_comaddress2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_comaddress2 ?? " ";
             comm.Parameters.Add("@cust_comaddress1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_comaddress1 ?? " ";
             comm.Parameters.Add("@cust_currentwork1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_currentwork1 ?? " ";
             comm.Parameters.Add("@cust_currentwork2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_currentwork2 ?? " ";
             comm.Parameters.Add("@cust_OfferCreation", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_OfferCreation ?? " ";
             comm.Parameters.Add("@cust_currentwork3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_currentwork3 ?? " ";
             comm.Parameters.Add("@cust_instrCurrentaddress", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrCurrentaddress ?? " ";
             comm.Parameters.Add("@cust_instrOtherDetails", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrOtherDetails ?? " ";
             comm.Parameters.Add("@cust_TotalExpmth", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_TotalExpmth ?? " ";
             comm.Parameters.Add("@status", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.status ?? " ";
             comm.Parameters.Add("@cust_instrBGCPackage", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrBGCPackage ?? " ";
             comm.Parameters.Add("@nonApplicantStatus", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.nonApplicantStatus ?? " ";
             comm.Parameters.Add("@resumeUploadDate", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.resumeUploadDate ?? " ";
             comm.Parameters.Add("@cust_pername", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_pername ?? " ";
             comm.Parameters.Add("@dateOfBirth", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.dateOfBirth ?? " ";
             comm.Parameters.Add("@appStatusSetItemId", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.appStatusSetItemId ?? " ";
             comm.Parameters.Add("@cust_AnnualizedCost", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_AnnualizedCost ?? " ";
             comm.Parameters.Add("@cust_instrempdetails", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrempdetails ?? " ";
             comm.Parameters.Add("@cust_VPIncentiveAnnual", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_VPIncentiveAnnual ?? " ";
             comm.Parameters.Add("@cust_VisaExpiry", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_VisaExpiry ?? " ";
             comm.Parameters.Add("@cust_reasonforchange3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_reasonforchange3 ?? " ";
             comm.Parameters.Add("@rating", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.rating ?? " ";
             comm.Parameters.Add("@cust_reasonforchange1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_reasonforchange1 ?? " ";
             comm.Parameters.Add("@cust_reasonforchange2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_reasonforchange2 ?? " ";
             comm.Parameters.Add("@cust_SpecialBonus2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_SpecialBonus2 ?? " ";
             comm.Parameters.Add("@cust_alledudetails", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_alledudetails ?? " ";
             comm.Parameters.Add("@cust_instrrefdetails", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrrefdetails ?? " ";
             comm.Parameters.Add("@cust_VPIPercent", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_VPIPercent ?? " ";
             comm.Parameters.Add("@cust_instrDisclaimer", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrDisclaimer ?? " ";
             comm.Parameters.Add("@timeToHire", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.timeToHire ?? " ";
             comm.Parameters.Add("@cust_expcompamt", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_expcompamt ?? " ";
             comm.Parameters.Add("@cust_AmountBonus", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_AmountBonus ?? " ";
             comm.Parameters.Add("@cust_empdesig", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_empdesig ?? " ";
             comm.Parameters.Add("@cust_OtherVisa", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_OtherVisa ?? " ";
             comm.Parameters.Add("@cust_startyr2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_startyr2 ?? " ";
             comm.Parameters.Add("@candTypeWhenHired", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.candTypeWhenHired ?? " ";
             comm.Parameters.Add("@cust_startyr1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_startyr1 ?? " ";
             comm.Parameters.Add("@cust_startyr4", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_startyr4 ?? " ";
             comm.Parameters.Add("@cust_startyr3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_startyr3 ?? " ";
             comm.Parameters.Add("@cust_TTC", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_TTC ?? " ";
             comm.Parameters.Add("@cust_Sourceinfo", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Sourceinfo ?? " ";
             comm.Parameters.Add("@cust_Permtilldate", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Permtilldate ?? " ";
             comm.Parameters.Add("@jobAppGuid", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.jobAppGuid ?? " ";
             comm.Parameters.Add("@cust_VendorCompanyEmailPhone", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_VendorCompanyEmailPhone ?? " ";
             comm.Parameters.Add("@cust_instrpostgrad", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrpostgrad ?? " ";
             comm.Parameters.Add("@cust_RelExpyrs", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_RelExpyrs ?? " ";
             comm.Parameters.Add("@cust_HRA_Annual", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_HRA_Annual ?? " ";
             comm.Parameters.Add("@sectDisclaimer", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.sectDisclaimer ?? " ";
             comm.Parameters.Add("@cust_rel3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_rel3 ?? " ";
             comm.Parameters.Add("@cust_rel2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_rel2 ?? " ";
             comm.Parameters.Add("@cust_rel1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_rel1 ?? " ";
             comm.Parameters.Add("@cust_instrBGCAuthBridge", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrBGCAuthBridge ?? " ";
             comm.Parameters.Add("@cust_HMComments", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_HMComments ?? " ";
             comm.Parameters.Add("@cust_CTC", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_CTC ?? " ";
             comm.Parameters.Add("@cust_instrApplication", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrApplication ?? " ";
             comm.Parameters.Add("@cust_endyr4", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_endyr4 ?? " ";
             comm.Parameters.Add("@cust_endyr5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_endyr5 ?? " ";
             comm.Parameters.Add("@cust_endyr2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_endyr2 ?? " ";
             comm.Parameters.Add("@cust_endyr3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_endyr3 ?? " ";
             comm.Parameters.Add("@cust_endyr1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_endyr1 ?? " ";
             comm.Parameters.Add("@cust_curaddressLine2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_curaddressLine2 ?? " ";
             comm.Parameters.Add("@cust_coursecom5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_coursecom5 ?? " ";
             comm.Parameters.Add("@cust_coursecom2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_coursecom2 ?? " ";
             comm.Parameters.Add("@cust_instr10th", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instr10th ?? " ";
             comm.Parameters.Add("@cust_TSCHeadComments", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_TSCHeadComments ?? " ";
             comm.Parameters.Add("@cust_coursecom3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_coursecom3 ?? " ";
             comm.Parameters.Add("@cust_coursecom1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_coursecom1 ?? " ";
             comm.Parameters.Add("@startDate", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.startDate ?? " ";
             comm.Parameters.Add("@cust_PrintedName", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_PrintedName ?? " ";
             comm.Parameters.Add("@sourceLabel", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.sourceLabel ?? " ";
             comm.Parameters.Add("@customVisaYes", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.customVisaYes ?? " ";
             comm.Parameters.Add("@profileUpdated", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.profileUpdated ?? " ";
             comm.Parameters.Add("@cust_lastcompamt", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_lastcompamt ?? " ";
             comm.Parameters.Add("@cust_ReferralEmp", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_ReferralEmp ?? " ";
             comm.Parameters.Add("@cust_desi3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_desi3 ?? " ";
             comm.Parameters.Add("@cust_startdate2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_startdate2 ?? " ";
             comm.Parameters.Add("@cust_startdate3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_startdate3 ?? " ";
             comm.Parameters.Add("@cust_instrknowanyone", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrknowanyone ?? " ";
             comm.Parameters.Add("@cust_startdate1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_startdate1 ?? " ";
             comm.Parameters.Add("@candConversionProcessed", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.candConversionProcessed ?? " ";
             comm.Parameters.Add("@cust_desi1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_desi1 ?? " ";
             comm.Parameters.Add("@cust_desi2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_desi2 ?? " ";
             comm.Parameters.Add("@cust_instrPermaddress", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrPermaddress ?? " ";
             comm.Parameters.Add("@lastModifiedDateTime", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.lastModifiedDateTime ??" ";
             comm.Parameters.Add("@Cust_BusinessScreeningStatus", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_BusinessScreeningStatus ?? " ";
             comm.Parameters.Add("@cust_interinlast6mnth", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_interinlast6mnth ?? " ";
             comm.Parameters.Add("@source", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.source ?? " ";
             comm.Parameters.Add("@cust_OthPerksBenfits", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_OthPerksBenfits ?? " ";
             comm.Parameters.Add("@cust_RelExpmth", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_RelExpmth ?? " ";
             comm.Parameters.Add("@cust_nickName", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_nickName ?? " ";
             comm.Parameters.Add("@cust_empids", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_empids ?? " ";
             comm.Parameters.Add("@cust_NoticePeriod", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_NoticePeriod ?? " ";
             comm.Parameters.Add("@cust_Empname3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Empname3 ?? " ";
             comm.Parameters.Add("@cust_highcomedu", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_highcomedu ?? " ";
             comm.Parameters.Add("@cust_Empname2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Empname2 ?? " ";
             comm.Parameters.Add("@cust_Empname1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Empname1 ?? " ";
             comm.Parameters.Add("@cust_sch4", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_sch4 ?? " ";
             comm.Parameters.Add("@homePhone", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.homePhone ?? " ";
             comm.Parameters.Add("@cust_sch3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_sch3 ?? " ";
             comm.Parameters.Add("@Cust_TSCScreeningA6", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_TSCScreeningA6 ?? " ";
             comm.Parameters.Add("@cust_instrlast7yrs", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrlast7yrs ?? " ";
             comm.Parameters.Add("@cust_Permperiodofstayend", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Permperiodofstayend ?? " ";
             comm.Parameters.Add("@cust_curPeriodofStay", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_curPeriodofStay ?? " ";
             comm.Parameters.Add("@cust_instr12th", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instr12th ?? " ";
             comm.Parameters.Add("@lastModifiedByProxy", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.lastModifiedByProxy ?? " ";
             comm.Parameters.Add("@cust_instrEmployer2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrEmployer2 ?? " ";
             comm.Parameters.Add("@cust_instrEmployer1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrEmployer1 ?? " ";
             comm.Parameters.Add("@hiredOn", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.hiredOn ?? " ";
             comm.Parameters.Add("@cust_CurrentLoc", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_CurrentLoc ?? " ";
             comm.Parameters.Add("@cust_curtilldate", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_curtilldate ?? " ";
             comm.Parameters.Add("@LegacyCandidateId", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.LegacyCandidateId ?? " ";
             comm.Parameters.Add("@cust_degdip5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_degdip5 ?? " ";
             comm.Parameters.Add("@cust_instrEmployer3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrEmployer3 ?? " ";
             comm.Parameters.Add("@cust_city1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_city1 ?? " ";
             comm.Parameters.Add("@cust_city2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_city2 ?? " ";
             comm.Parameters.Add("@cust_city3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_city3 ?? " ";
             comm.Parameters.Add("@cust_nameadd5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_nameadd5 ?? " ";
             comm.Parameters.Add("@cust_empid3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_empid3 ?? " ";
             comm.Parameters.Add("@cust_curaddress", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_curaddress ?? " ";
             comm.Parameters.Add("@cust_empid2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_empid2 ?? " ";
             comm.Parameters.Add("@cust_empid1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_empid1 ?? " ";
             comm.Parameters.Add("@cust_clientinterviewnotes", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_clientinterviewnotes ?? " ";
             comm.Parameters.Add("@cust_curbesttime", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_curbesttime ?? " ";
             comm.Parameters.Add("@cust_instrref2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrref2 ?? " ";
             comm.Parameters.Add("@appLocale", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.appLocale ?? " ";
             comm.Parameters.Add("@cust_instrref1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrref1 ?? " ";
             comm.Parameters.Add("@cust_org2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_org2 ?? " ";
             comm.Parameters.Add("@cust_org3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_org3 ?? " ";
             comm.Parameters.Add("@cust_BasicAnnual", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BasicAnnual ?? " ";
             comm.Parameters.Add("@cust_org1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_org1 ?? " ";
             comm.Parameters.Add("@cust_maj2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_maj2 ?? " ";
             comm.Parameters.Add("@cust_maj5", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_maj5 ?? " ";
             comm.Parameters.Add("@cust_FixedAnnual", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_FixedAnnual ?? " ";
             comm.Parameters.Add("@cust_maj1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_maj1 ?? " ";
             comm.Parameters.Add("@cust_instrPassportVisaDetails", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrPassportVisaDetails ?? " ";
             comm.Parameters.Add("@cust_insname1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_insname1 ?? " ";
             comm.Parameters.Add("@cust_insname2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_insname2 ?? " ";
             comm.Parameters.Add("@cust_instrveteranQ", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrveteranQ ?? " ";
             comm.Parameters.Add("@cust_VendorCompanyname", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_VendorCompanyname ?? " ";
             comm.Parameters.Add("@cust_InternalApprovalDate", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_InternalApprovalDate ?? " ";
             comm.Parameters.Add("@cust_MonthlyBonusAnnual", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_MonthlyBonusAnnual ?? " ";
             comm.Parameters.Add("@cust_break3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_break3 ?? " ";
             comm.Parameters.Add("@referenceComments", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.referenceComments ?? " ";
             comm.Parameters.Add("@cust_relname", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_relname ?? " ";
             comm.Parameters.Add("@cust_empdep", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_empdep ?? " ";
             comm.Parameters.Add("@anonymizedFlag", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.anonymizedFlag ?? " ";
             comm.Parameters.Add("@referredBy", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.referredBy ?? " ";
             comm.Parameters.Add("@applicationTemplateId", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.applicationTemplateId ?? " ";
             comm.Parameters.Add("@cust_curzip", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_curzip ?? " ";
             comm.Parameters.Add("@jobTitle", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.jobTitle ?? " ";
             comm.Parameters.Add("@agencyInfo", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.agencyInfo ?? " ";
             comm.Parameters.Add("@reference", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.reference ?? " ";
             comm.Parameters.Add("@Cust_TSCScreeningSum", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_TSCScreeningSum ?? " ";
             comm.Parameters.Add("@cust_break1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_break1 ?? " ";
             comm.Parameters.Add("@cust_break2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_break2 ?? " ";
             comm.Parameters.Add("@cust_VendorCompanyaddress", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_VendorCompanyaddress ?? " ";
             comm.Parameters.Add("@cust_lastdeg3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_lastdeg3 ?? " ";
             comm.Parameters.Add("@cust_lastdeg2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_lastdeg2 ?? " ";
             comm.Parameters.Add("@cust_lastdeg1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_lastdeg1 ?? " ";
             comm.Parameters.Add("@cust_instrRewardInfo", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrRewardInfo ?? " ";
             comm.Parameters.Add("@cust_Secemail", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Secemail ?? " ";
             comm.Parameters.Add("@cust_instrEmpInfo", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrEmpInfo ?? " ";
             comm.Parameters.Add("@dataSource", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.dataSource ?? " ";
             comm.Parameters.Add("@cust_tenenddate3", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_tenenddate3 ?? " ";
             comm.Parameters.Add("@cust_JoiningB", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_JoiningB ?? " ";
             comm.Parameters.Add("@cust_tenenddate2", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_tenenddate2 ?? " ";
             comm.Parameters.Add("@cust_tenenddate1", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_tenenddate1 ?? " ";
             comm.Parameters.Add("@cust_SSNIssueDate", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_SSNIssueDate ?? " ";
             comm.Parameters.Add("@cust_instrBGCIISERVZ", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_instrBGCIISERVZ ?? " ";
             comm.Parameters.Add("@cust_TARemarks", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_TARemarks ?? " ";
             comm.Parameters.Add("@lastModifiedBy", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.lastModifiedBy ?? " ";
             comm.Parameters.Add("@snapShotDate", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.snapShotDate ?? " ";
             comm.Parameters.Add("@cust_BGC_IISERVZ_ResultPDFReport_deferreduri ", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_AB_ResultReportPDF.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_CandidateConfirmation_deferreduri    ", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_CandidateConfirmation.__deferred.uri ?? " ";
             comm.Parameters.Add("@referralSource_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.referralSource.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_BGC_AB_ResultReportPDF_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGC_IISERVZ_ResultPDFReport.__deferred.uri ?? " ";
             comm.Parameters.Add("@jobApplicationComments_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.jobApplicationComments.__deferred.uri ?? " ";
             comm.Parameters.Add("@offerLetter_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.offerLetter.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_CandAvailabilitydate_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_CandAvailabilitydate.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_prefix_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_prefix.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_ExtInterviewStatus_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_ExtInterviewStatus.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_InterpersonalSkills_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_InterpersonalSkills.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_TSCScreeningQ2_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_TSCScreeningQ2.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_TSCScreeningQ1_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_TSCScreeningQ1.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_BSLformat_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BSLformat.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_InterviewRequired1_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_InterviewRequired1.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_InterviewRequired3_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_InterviewRequired3.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_InterviewRequired2_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_InterviewRequired2.__deferred.uri ?? " ";
             comm.Parameters.Add("@resume_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.resume.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_SpecialBonusAttach_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_SpecialBonusAttach.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_approvalemail_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_approvalemail.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_InterviewRequired5_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_InterviewRequired5.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_InterviewRequired4_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_InterviewRequired4.__deferred.uri ?? " ";
             comm.Parameters.Add("@custAadhaarattach_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.custAadhaarattach.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_ValidPassport_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_ValidPassport.__deferred.uri ?? " ";
             comm.Parameters.Add("@custeducationdetails_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.custeducationdetails.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_ImmigrationStatus_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_ImmigrationStatus.__deferred.uri ?? " ";
             comm.Parameters.Add("@custcandPhotoattach_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.custcandPhotoattach.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_Travel_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Travel.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_BGCStatus_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGCStatus.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_PermState_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_PermState.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_TSCScreeningQ4_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_TSCScreeningQ4.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_TSCScreeningQ3_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_TSCScreeningQ3.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_TSCScreeningQ5_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_TSCScreeningQ5.__deferred.uri ?? " ";
             comm.Parameters.Add("@custPANattach_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.custPANattach.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_WorkAuthStatus_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_WorkAuthStatus.__deferred.uri ?? " ";
             comm.Parameters.Add("@custaddressproof_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.custaddressproof.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_BlacklistUniv_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BlacklistUniv.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_ScreeningStatus3_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_ScreeningStatus3.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_BGCApplicableType_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BGCApplicableType.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_ScreeningStatus1_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_ScreeningStatus1.__deferred.uri ?? " ";
             comm.Parameters.Add("@custPostGradDegattach_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.custPostGradDegattach.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_emptype2_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_emptype2.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_emptype3_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_emptype3.__deferred.uri ?? " ";
             comm.Parameters.Add("@education_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.education.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_emptype1_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_emptype1.__deferred.uri ?? " ";
             comm.Parameters.Add("@custUANattach_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.custUANattach.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_interviewedInBirlasoft_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_interviewedInBirlasoft.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_expcompcur_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_expcompcur.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_formeremployee_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_formeremployee.__deferred.uri ?? " ";
             comm.Parameters.Add("@veteranA_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.veteranA.__deferred.uri ?? " ";
             comm.Parameters.Add("@jobRequisition_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.jobRequisition.__deferred.uri ?? " ";
             comm.Parameters.Add("@custBachDegattach_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.custBachDegattach.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_source_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_source.__deferred.uri ?? " ";
             comm.Parameters.Add("@custPermAddProofattach_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.custPermAddProofattach.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_OfferedStream_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_OfferedStream.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_ExtInterviewResult_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_ExtInterviewResult.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_TSCScreeningSkill_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_TSCScreeningSkill.__deferred.uri ?? " ";
             comm.Parameters.Add("@bgiAccountId_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.bgiAccountId.__deferred.uri ?? " ";
             comm.Parameters.Add("@insideWorkExperience_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.insideWorkExperience.__deferred.uri ?? " ";
           //  comm.Parameters.Add("@cust_clientinterviewstatus_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_clientinterviewstatus.__deferred.uri ?? " ";
             comm.Parameters.Add("@jobAppStatus_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.jobAppStatus.__deferred.uri ?? " ";
             comm.Parameters.Add("@custLetterOfAuthorization_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.custLetterOfAuthorization.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_curcountry_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_curcountry.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_stat4_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_stat4.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_stat2_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_stat2.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_stat3_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_stat3.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_stat1_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_stat1.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_Turbohire_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Turbohire.__deferred.uri ?? " ";
            // comm.Parameters.Add("@cust_interviewsfeedback_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_interviewsfeedback.__deferred.uri ?? " ";
             comm.Parameters.Add("@jobApplicationStatusAuditTrail_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.jobApplicationStatusAuditTrail.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_cntr3_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_cntr3.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_cntr4_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_cntr4.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_cntr1_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_cntr1.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_RecCandidateSource_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_RecCandidateSource.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_cntr2_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_cntr2.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_secondaryskills_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_secondaryskills.__deferred.uri ?? " ";
             comm.Parameters.Add("@customLegalAuth_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.customLegalAuth.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_primaryskills_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_primaryskills.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_Relocate_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Relocate.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_curstate_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_curstate.__deferred.uri ?? " ";
             comm.Parameters.Add("@state_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.state.__deferred.uri ?? " ";
             comm.Parameters.Add("@referredByNav_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.referredByNav.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_lastcomptype_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_lastcomptype.__deferred.uri ?? " ";
             comm.Parameters.Add("@certificates_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.certificates.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_OfferedGrade_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_OfferedGrade.__deferred.uri ?? " ";
             comm.Parameters.Add("@statusId_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.statusId.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_Relocation1_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Relocation1.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_Relocation2_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Relocation2.__deferred.uri ?? " ";
             comm.Parameters.Add("@jobOffer_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.jobOffer.__deferred.uri ?? " ";
             comm.Parameters.Add("@countryPicklist_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.countryPicklist.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_candPhoto_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_candPhoto.__deferred.uri ?? " ";
             comm.Parameters.Add("@userNav_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.userNav.__deferred.uri ?? " ";
             comm.Parameters.Add("@jobApplicationOnboardingData_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.jobApplicationOnboardingData.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_TSCScreeningA4_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_TSCScreeningA4.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_TSCScreeningA3_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_TSCScreeningA3.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_TSCScreeningA5_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_TSCScreeningA5.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_TSCScreeningA2_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_TSCScreeningA2.__deferred.uri ?? " ";
             comm.Parameters.Add("@jobApplicationAudit_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.jobApplicationAudit.__deferred.uri ?? " ";
             comm.Parameters.Add("@Cust_TSCScreeningA1_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.Cust_TSCScreeningA1.__deferred.uri ?? " ";
             comm.Parameters.Add("@custCurAddProofattach_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.custCurAddProofattach.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_BlacklistCompanies_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_BlacklistCompanies.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_Rehire_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Rehire.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_lastcompcur_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_lastcompcur.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_Permcountry_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Permcountry.__deferred.uri ?? " ";
             comm.Parameters.Add("@customVisa_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.customVisa.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_HMFeedback_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_HMFeedback.__deferred.uri ?? " ";
             comm.Parameters.Add("@coverLetter_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.coverLetter.__deferred.uri ?? " ";
             comm.Parameters.Add("@jobApplicationAssessmentOrder_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.jobApplicationAssessmentOrder.__deferred.uri ?? " ";
             comm.Parameters.Add("@jobApplicationInterview_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.jobApplicationInterview.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_TSCHeadFeedback_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_TSCHeadFeedback.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_EmpType_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_EmpType.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_Nationality_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Nationality.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_Permstate1_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Permstate1.__deferred.uri ?? " ";
             comm.Parameters.Add("@jobApplicationQuestionResponse_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.jobApplicationQuestionResponse.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_Commskills_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Commskills.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_MaritalStatus_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_MaritalStatus.__deferred.uri ?? " ";
             comm.Parameters.Add("@packageId_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.packageId.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_expcomptype_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_expcomptype.__deferred.uri ?? " ";
             comm.Parameters.Add("@custpayslipattach_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.custpayslipattach.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust12attach_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust12attach.__deferred.uri ?? " ";
             comm.Parameters.Add("@custDiplomaattach_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.custDiplomaattach.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_Joining_SigningBonus_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Joining_SigningBonus.__deferred.uri ?? " ";
             comm.Parameters.Add("@custLetterattach_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.custLetterattach.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_Quartile_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Quartile.__deferred.uri ?? " ";
             comm.Parameters.Add("@outsideWorkExperience_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.outsideWorkExperience.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_TAleadFeedback_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_TAleadFeedback.__deferred.uri ?? " ";
             comm.Parameters.Add("@candidate_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.candidate.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_Citizenship_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_Citizenship.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_ExtInterviewVendors_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_ExtInterviewVendors.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_clientinterviewsfeedback_deferreduri  ", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_clientinterviewsfeedback.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_ScreeningResult3_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_ScreeningResult3.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust10attach_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust10attach.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_ScreeningResult2_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_ScreeningResult2.__deferred.uri ?? " ";
             comm.Parameters.Add("@cust_ScreeningResult1_deferreduri", SqlDbType.VarChar, 400).Value = EmployeeDetail.d.cust_ScreeningResult1.__deferred.uri ?? " ";

             int Count = comm.ExecuteNonQuery();

             //--https://api44preview.sapsf.com/odata/v2/JobApplication(561L)/education
             string str1 = string.Format("select education_deferreduri from tbl_BS_Candidate_info where applicationId =" + Cid);
             ds2 = getDataset(str1);
             url2 = ds2.Tables[0].Rows[0]["education_deferreduri"].ToString();

             var client1 = new RestClient("https://api44preview.sapsf.com/odata/v2/JobApplication(" + Cid + ")/education");
             var request1 = new RestRequest(Method.GET);
             request1.AddHeader("Authorization", "Basic SW50ZWdyYXRpb25fUHJldmlld0BiaXJsYXNvZnRsVDE6V2VsY29tZUA5ODc=");
             // request.AddHeader("Content-Type", "application/json");
             request1.AddParameter("undefined", ParameterType.RequestBody);
             IRestResponse response1 = client1.Execute(request1);
             string Apiresponse1 = response1.Content;
             var myDetails1 = JsonConvert.DeserializeObject<Root1>(Apiresponse1);            

             //save employee education  information
             for (int i = 0; i < myDetails1.d.results.Count; i++)
             {
                 SqlCommand educmd = new SqlCommand("EmployeeEdu_Insert", con);
                 educmd.CommandType = CommandType.StoredProcedure;
                 educmd.Parameters.Add("@Metadata_Type", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].__metadata.type ?? "";
                 educmd.Parameters.Add("@Metadata_Url", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].__metadata.uri ?? "";
                 educmd.Parameters.Add("@backgroundElementId", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].backgroundElementId ?? "";
                 educmd.Parameters.Add("@gpaoutof", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].gpaoutof ?? "";
                 educmd.Parameters.Add("@Program", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].Program ?? "";
                 educmd.Parameters.Add("@lastModifiedDateTime", SqlDbType.DateTime).Value = myDetails1.d.results[i].lastModifiedDateTime ?? null;
                 educmd.Parameters.Add("@endDate", SqlDbType.DateTime).Value = myDetails1.d.results[i].endDate ?? DateTime.Now;
                 educmd.Parameters.Add("@educationlevel", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].educationlevel ?? "";
                 educmd.Parameters.Add("@institution", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].institution ?? "";
                 educmd.Parameters.Add("@otherinstitution", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].otherinstitution ?? "";
                 educmd.Parameters.Add("@bgOrderPos", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].bgOrderPos ?? "";
                 educmd.Parameters.Add("@gpa", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].gpa ?? "";
                 educmd.Parameters.Add("@applicationId", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].applicationId ?? "";
                 educmd.Parameters.Add("@startDate", SqlDbType.DateTime).Value = myDetails1.d.results[i].startDate ?? DateTime.Now;
                 educmd.Parameters.Add("@otherProgram", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].otherProgram ?? "";
                 educmd.Parameters.Add("@InstitutionNav_Url", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].institutionNav.__deferred.uri ?? "";
                 educmd.Parameters.Add("@EducationlevelNav_Url", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].educationlevelNav.__deferred.uri ?? "";
                 educmd.Parameters.Add("@Application_Url", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].application.__deferred.uri ?? "";
                 educmd.Parameters.Add("@ProgramNav_Url", SqlDbType.VarChar, 400).Value = myDetails1.d.results[i].ProgramNav.__deferred.uri ?? "";
                 int Count1 = educmd.ExecuteNonQuery();
             }
             //---
             //--https://api44preview.sapsf.com/odata/v2/JobApplication(561L)/outsideWorkExperience
             string str2 = string.Format("select outsideWorkExperience_deferreduri from tbl_BS_Candidate_info where applicationId =" + Cid);
             ds3 = getDataset(str2);
             url3 = ds3.Tables[0].Rows[0]["outsideWorkExperience_deferreduri"].ToString();

             var client2 = new RestClient("https://api44preview.sapsf.com/odata/v2/JobApplication(" + Cid + ")/outsideWorkExperience");
             var request2 = new RestRequest(Method.GET);
             request2.AddHeader("Authorization", "Basic SW50ZWdyYXRpb25fUHJldmlld0BiaXJsYXNvZnRsVDE6V2VsY29tZUA5ODc=");
             // request.AddHeader("Content-Type", "application/json");
             request2.AddParameter("undefined", ParameterType.RequestBody);
             IRestResponse response2 = client2.Execute(request2);
             string Apiresponse2 = response2.Content;
             var myDetails2 = JsonConvert.DeserializeObject<Root2>(Apiresponse2);
             //save Employedment Detail
             for (int i = 0; i < myDetails2.d.results.Count; i++)
             {
                 SqlCommand empcmd = new SqlCommand("EmployeeEmp_Insert", con);
                 empcmd.CommandType = CommandType.StoredProcedure;
                 empcmd.Parameters.Add("@Metadata_Type", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].__metadata.type ?? "";
                 empcmd.Parameters.Add("@Metadata_Url", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].__metadata.uri ?? "";
                 empcmd.Parameters.Add("@backgroundElementId  ", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].backgroundElementId ?? "";
                 empcmd.Parameters.Add("@achievements", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].achievements ?? "";
                 empcmd.Parameters.Add("@lastModifiedDateTime", SqlDbType.DateTime).Value = myDetails2.d.results[i].lastModifiedDateTime ?? DateTime.Now;
                 empcmd.Parameters.Add("@endDate", SqlDbType.DateTime).Value = myDetails2.d.results[i].endDate ?? DateTime.Now;
                 empcmd.Parameters.Add("@otheremployer", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].otheremployer ?? "";
                 empcmd.Parameters.Add("@jobFunction", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].jobFunction ?? "";
                 empcmd.Parameters.Add("@bgOrderPos", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].bgOrderPos ?? "";
                 empcmd.Parameters.Add("@employer", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].employer ?? "";
                 empcmd.Parameters.Add("@applicationId", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].applicationId ?? "";
                 empcmd.Parameters.Add("@otherFunction", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].otherFunction ?? "";
                 empcmd.Parameters.Add("@startDate", SqlDbType.DateTime).Value = myDetails2.d.results[i].startDate ?? DateTime.Now;
                 empcmd.Parameters.Add("@presentEmployer", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].presentEmployer ?? "";
                 empcmd.Parameters.Add("@presentEmployerNav_Url", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].presentEmployerNav.__deferred.uri ?? "";
                 empcmd.Parameters.Add("@jobFunctionNav_Url", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].jobFunctionNav.__deferred.uri ?? "";
                 // empcmd.Parameters.Add("@employerNav_Url", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].employerNav.__deferred.uri ?? "";
                 empcmd.Parameters.Add("@application_Url", SqlDbType.VarChar, 400).Value = myDetails2.d.results[i].application.__deferred.uri ?? "";
                 empcmd.ExecuteNonQuery();
             }








            //
             Response.Write("<Script Language='javascript'> alert('Data Fetched Successfully !')</Script>");
             SqlCommand upcmd = new SqlCommand("UPDATE tbl_biralaSoftAPIData SET received_data=1 where applicationId= '" + Cid + "'", con);
             upcmd.ExecuteNonQuery();
            //
        }
        Response.Redirect("BgvDetailsNew.aspx");
    }

    // basic detail of all candidate
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class D
    {
        public List<Result> results { get; set; }
    }

    public class Metadata
    {
        public string uri { get; set; }
        public string type { get; set; }
    }
    public class PackageId1
    {
        public List<object> results { get; set; }
    }

    public class packagename
    {
        public Metadata __metadata { get; set; }
        public string localeLabel { get; set; }
    }

    public class Result
    {
        public Metadata __metadata { get; set; }
        public string applicationId { get; set; }
        public object cust_instrPermaddress { get; set; }
        public object cust_instrref3 { get; set; }
        public object cust_rel3 { get; set; }
        public object cust_rel2 { get; set; }
        public object cust_rel1 { get; set; }
        public object cust_Permaddline2 { get; set; }
        public string cust_Permcity1 { get; set; }
        public string cust_Permaddline1 { get; set; }
        public object cust_org2 { get; set; }
        public object cust_org3 { get; set; }
        public object cust_org1 { get; set; }
        public object cust_highcomedu { get; set; }
        public object cust_uni1 { get; set; }
        public object cust_Empname1 { get; set; }
        public object cust_endyr1 { get; set; }
        public string cust_Reasonforchange { get; set; }
        public object cust_Permperiodofstay { get; set; }
        public string cust_Permzip { get; set; }
        public string cust_addressLine2 { get; set; }
        public object cust_Permperiodofstayend { get; set; }
        public object cust_curPeriodofStay { get; set; }
        public string firstName { get; set; }
        public object cust_coursecom1 { get; set; }
        public object cust_curLandmark { get; set; }
        public string candidateId { get; set; }
        public object cust_instrCurrentaddress { get; set; }
        public string lastName { get; set; }
        public object cust_curperiodofstayend { get; set; }
        public object cust_insname1 { get; set; }
        public object cust_curtilldate { get; set; }
        public object cust_tenenddate1 { get; set; }
        public object cust_UAN { get; set; }
        public string cust_curcity { get; set; }
        public object cust_roll1 { get; set; }
        public string cust_curaddress { get; set; }
        public object cust_Permtilldate { get; set; }
        public object cust_instrBGCIISERVZ { get; set; }
        public object cust_empid1 { get; set; }
        public object cust_name3 { get; set; }
        public object cust_name2 { get; set; }
        public object cust_name1 { get; set; }
        public object cust_startdate1 { get; set; }
        public object dateOfBirth { get; set; }
        public string cust_LastDesig { get; set; }
        public object cust_Permlandmark { get; set; }
        public object cust_num3 { get; set; }
        public object cust_num2 { get; set; }
        public string middleName { get; set; }
        public object cust_num1 { get; set; }
        public object cust_instrref2 { get; set; }
        public object cust_instrref1 { get; set; }
        public string cellPhone { get; set; }
        public PackageId1 packageId { get; set; }
    }
   

    public class Root
    {
        public D d { get; set; }
    }

   // candidate detail
    // Root myDeserializedClass = JsonConvert.DeserializeObject<CandidateDetail>(myJsonResponse);
    public class BgiAccountId
    {
        public Deferred __deferred { get; set; }
    }

    public class Candidate
    {
        public Deferred __deferred { get; set; }
    }

    public class Certificates
    {
        public Deferred __deferred { get; set; }
    }

    public class CountryPicklist
    {
        public Deferred __deferred { get; set; }
    }

    public class CoverLetter
    {
        public Deferred __deferred { get; set; }
    }

    public class Cust10attach
    {
        public Deferred __deferred { get; set; }
    }

    public class Cust12attach
    {
        public Deferred __deferred { get; set; }
    }

    public class CustAadhaarattach
    {
        public Deferred __deferred { get; set; }
    }

    public class Custaddressproof
    {
        public Deferred __deferred { get; set; }
    }

    public class CustApprovalemail
    {
        public Deferred __deferred { get; set; }
    }

    public class CustBachDegattach
    {
        public Deferred __deferred { get; set; }
    }

    public class CustBGCABResultReportPDF
    {
        public Deferred __deferred { get; set; }
    }

    public class CustBGCApplicableType
    {
        public Deferred __deferred { get; set; }
    }

    public class CustBGCIISERVZResultPDFReport
    {
        public Deferred __deferred { get; set; }
    }

    public class CustBGCStatus
    {
        public Deferred __deferred { get; set; }
    }

    public class CustBlacklistCompanies
    {
        public Deferred __deferred { get; set; }
    }

    public class CustBlacklistUniv
    {
        public Deferred __deferred { get; set; }
    }

    public class CustBSLformat
    {
        public Deferred __deferred { get; set; }
    }

    public class CustCandAvailabilitydate
    {
        public Deferred __deferred { get; set; }
    }

    public class CustCandidateConfirmation
    {
        public Deferred __deferred { get; set; }
    }

    public class CustCandPhoto
    {
        public Deferred __deferred { get; set; }
    }

    public class CustcandPhotoattach
    {
        public Deferred __deferred { get; set; }
    }

    public class CustCitizenship
    {
        public Deferred __deferred { get; set; }
    }

    public class CustClientinterviewsfeedback
    {
        public Deferred __deferred { get; set; }
    }

    public class CustClientinterviewstatus
    {
        public Deferred __deferred { get; set; }
    }

    public class CustCntr1
    {
        public Deferred __deferred { get; set; }
    }

    public class CustCntr2
    {
        public Deferred __deferred { get; set; }
    }

    public class CustCntr3
    {
        public Deferred __deferred { get; set; }
    }

    public class CustCntr4
    {
        public Deferred __deferred { get; set; }
    }

    public class CustCommskills
    {
        public Deferred __deferred { get; set; }
    }

    public class CustCurAddProofattach
    {
        public Deferred __deferred { get; set; }
    }

    public class CustCurcountry
    {
        public Deferred __deferred { get; set; }
    }

    public class CustCurstate
    {
        public Deferred __deferred { get; set; }
    }

    public class CustDiplomaattach
    {
        public Deferred __deferred { get; set; }
    }

    public class Custeducationdetails
    {
        public Deferred __deferred { get; set; }
    }

    public class CustEmpType
    {
        public Deferred __deferred { get; set; }
    }

    public class CustEmptype1
    {
        public Deferred __deferred { get; set; }
    }

    public class CustEmptype2
    {
        public Deferred __deferred { get; set; }
    }

    public class CustEmptype3
    {
        public Deferred __deferred { get; set; }
    }

    public class CustExpcompcur
    {
        public Deferred __deferred { get; set; }
    }

    public class CustExpcomptype
    {
        public Deferred __deferred { get; set; }
    }

    public class CustExtInterviewResult
    {
        public Deferred __deferred { get; set; }
    }

    public class CustExtInterviewStatus
    {
        public Deferred __deferred { get; set; }
    }

    public class CustExtInterviewVendors
    {
        public Deferred __deferred { get; set; }
    }

    public class CustFormeremployee
    {
        public Deferred __deferred { get; set; }
    }

    public class CustHMFeedback
    {
        public Deferred __deferred { get; set; }
    }

    public class CustImmigrationStatus
    {
        public Deferred __deferred { get; set; }
    }

    public class CustInterpersonalSkills
    {
        public Deferred __deferred { get; set; }
    }

    public class CustInterviewedInBirlasoft
    {
        public Deferred __deferred { get; set; }
    }

    public class CustInterviewRequired1
    {
        public Deferred __deferred { get; set; }
    }

    public class CustInterviewRequired2
    {
        public Deferred __deferred { get; set; }
    }

    public class CustInterviewRequired3
    {
        public Deferred __deferred { get; set; }
    }

    public class CustInterviewRequired4
    {
        public Deferred __deferred { get; set; }
    }

    public class CustInterviewRequired5
    {
        public Deferred __deferred { get; set; }
    }

    public class CustInterviewsfeedback
    {
        public Deferred __deferred { get; set; }
    }

    public class CustJoiningSigningBonus
    {
        public Deferred __deferred { get; set; }
    }

    public class CustLastcompcur
    {
        public Deferred __deferred { get; set; }
    }

    public class CustLastcomptype
    {
        public Deferred __deferred { get; set; }
    }

    public class CustLetterattach
    {
        public Deferred __deferred { get; set; }
    }

    public class CustLetterOfAuthorization
    {
        public Deferred __deferred { get; set; }
    }

    public class CustMaritalStatus
    {
        public Deferred __deferred { get; set; }
    }

    public class CustNationality
    {
        public Deferred __deferred { get; set; }
    }

    public class CustOfferedGrade
    {
        public Deferred __deferred { get; set; }
    }

    public class CustOfferedStream
    {
        public Deferred __deferred { get; set; }
    }

    public class CustomLegalAuth
    {
        public Deferred __deferred { get; set; }
    }

    public class CustomVisa
    {
        public Deferred __deferred { get; set; }
    }

    public class CustPANattach
    {
        public Deferred __deferred { get; set; }
    }

    public class Custpayslipattach
    {
        public Deferred __deferred { get; set; }
    }

    public class CustPermAddProofattach
    {
        public Deferred __deferred { get; set; }
    }

    public class CustPermcountry
    {
        public Deferred __deferred { get; set; }
    }

    public class CustPermState
    {
        public Deferred __deferred { get; set; }
    }

    public class CustPermstate1
    {
        public Deferred __deferred { get; set; }
    }

    public class CustPostGradDegattach
    {
        public Deferred __deferred { get; set; }
    }

    public class CustPrefix
    {
        public Deferred __deferred { get; set; }
    }

    public class CustPrimaryskills
    {
        public Deferred __deferred { get; set; }
    }

    public class CustQuartile
    {
        public Deferred __deferred { get; set; }
    }

    public class CustRecCandidateSource
    {
        public Deferred __deferred { get; set; }
    }

    public class CustRehire
    {
        public Deferred __deferred { get; set; }
    }

    public class CustRelocate
    {
        public Deferred __deferred { get; set; }
    }

    public class CustRelocation1
    {
        public Deferred __deferred { get; set; }
    }

    public class CustRelocation2
    {
        public Deferred __deferred { get; set; }
    }

    public class CustScreeningResult1
    {
        public Deferred __deferred { get; set; }
    }

    public class CustScreeningResult2
    {
        public Deferred __deferred { get; set; }
    }

    public class CustScreeningResult3
    {
        public Deferred __deferred { get; set; }
    }

    public class CustScreeningStatus1
    {
        public Deferred __deferred { get; set; }
    }

    public class CustScreeningStatus3
    {
        public Deferred __deferred { get; set; }
    }

    public class CustSecondaryskills
    {
        public Deferred __deferred { get; set; }
    }

    public class CustSource
    {
        public Deferred __deferred { get; set; }
    }

    public class CustSpecialBonusAttach
    {
        public Deferred __deferred { get; set; }
    }

    public class CustStat1
    {
        public Deferred __deferred { get; set; }
    }

    public class CustStat2
    {
        public Deferred __deferred { get; set; }
    }

    public class CustStat3
    {
        public Deferred __deferred { get; set; }
    }

    public class CustStat4
    {
        public Deferred __deferred { get; set; }
    }

    public class CustTAleadFeedback
    {
        public Deferred __deferred { get; set; }
    }

    public class CustTravel
    {
        public Deferred __deferred { get; set; }
    }

    public class CustTSCHeadFeedback
    {
        public Deferred __deferred { get; set; }
    }

    public class CustTSCScreeningA1
    {
        public Deferred __deferred { get; set; }
    }

    public class CustTSCScreeningA2
    {
        public Deferred __deferred { get; set; }
    }

    public class CustTSCScreeningA3
    {
        public Deferred __deferred { get; set; }
    }

    public class CustTSCScreeningA4
    {
        public Deferred __deferred { get; set; }
    }

    public class CustTSCScreeningA5
    {
        public Deferred __deferred { get; set; }
    }

    public class CustTSCScreeningQ1
    {
        public Deferred __deferred { get; set; }
    }

    public class CustTSCScreeningQ2
    {
        public Deferred __deferred { get; set; }
    }

    public class CustTSCScreeningQ3
    {
        public Deferred __deferred { get; set; }
    }

    public class CustTSCScreeningQ4
    {
        public Deferred __deferred { get; set; }
    }

    public class CustTSCScreeningQ5
    {
        public Deferred __deferred { get; set; }
    }

    public class CustTSCScreeningSkill
    {
        public Deferred __deferred { get; set; }
    }

    public class CustTurbohire
    {
        public Deferred __deferred { get; set; }
    }

    public class CustUANattach
    {
        public Deferred __deferred { get; set; }
    }

    public class CustValidPassport
    {
        public Deferred __deferred { get; set; }
    }

    public class CustWorkAuthStatus
    {
        public Deferred __deferred { get; set; }
    }

    public class Detail
    {
        public Metadata __metadata { get; set; }
        public string applicationId { get; set; }
        public object cust_connectemp1 { get; set; }
        public object cust_TALeadComments { get; set; }
        public object cust_connectemp2 { get; set; }
        public object cust_connectemp3 { get; set; }
        public object usersSysId { get; set; }
        public object cust_TotalExpyrs { get; set; }
        public object cust_disclaimerAcknowledge { get; set; }
        public object cust_LastEmplr { get; set; }
        public object cust_Permperiodofstay { get; set; }
        public object statusComments { get; set; }
        public object cust_HighEdu { get; set; }
        public object cust_curLandmark { get; set; }
        public object cust_SpecialAnnual { get; set; }
        public object Cust_CandidateName { get; set; }
        public string duplicateProfile { get; set; }
        public object cust_curcity { get; set; }
        public object cust_curcontact { get; set; }
        public object cust_TotExpmth { get; set; }
        public object cust_Gratuity { get; set; }
        public object cust_dip5 { get; set; }
        public object cust_instrOfferedCTC { get; set; }
        public string address { get; set; }
        public object cust_name3 { get; set; }
        public object cust_name2 { get; set; }
        public object cust_name1 { get; set; }
        public object cust_instrPreliminaryInfo { get; set; }
        public object cust_SpecialBonus1 { get; set; }
        public object cust_interviewnotes { get; set; }
        public object cust_deg2 { get; set; }
        public object cust_deg1 { get; set; }
        public object cust_instrbacdeg { get; set; }
        public object cust_PAN { get; set; }
        public object cust_BGC_IISERVZ_ResultColorCode { get; set; }
        public object preferredLoc { get; set; }
        public object cust_Permaddline2 { get; set; }
        public object cust_Permaddline1 { get; set; }
        public object cust_PF_Annual { get; set; }
        public object LegacyAppid { get; set; }
        public object cust_MedicalAnnual { get; set; }
        public object cust_uni1 { get; set; }
        public object cust_uni2 { get; set; }
        public object cust_mintimetojoin { get; set; }
        public object cust_TotExpyrs { get; set; }
        public object cust_PassportExpiry { get; set; }
        public object cust_Reasonforchange { get; set; }
        public object cust_instrreldetails { get; set; }
        public object ownershpDate { get; set; }
        public object cust_addr6 { get; set; }
        public object cust_addr5 { get; set; }
        public object cust_addr7 { get; set; }
        public object anonymizedDate { get; set; }
        public object cust_rel { get; set; }
        public object cust_Designation { get; set; }
        public object Cust_TSCScreeningQ6 { get; set; }
        public object cust_reldeg { get; set; }
        public object cust_addr2 { get; set; }
        public object cust_addr1 { get; set; }
        public object cust_addr4 { get; set; }
        public object applicationDate { get; set; }
        public object cust_addr3 { get; set; }
        public object cust_hremail2 { get; set; }
        public object cust_reldep { get; set; }
        public object cust_hremail3 { get; set; }
        public object cust_curperiodofstayend { get; set; }
        public object cust_board3 { get; set; }
        public object cust_board4 { get; set; }
        public object cust_hremail1 { get; set; }
        public object cust_instrbgcchkini { get; set; }
        public object cust_Permcity { get; set; }
        public object cust_Asondate { get; set; }
        public object cust_roll5 { get; set; }
        public object cust_roll3 { get; set; }
        public object cust_roll4 { get; set; }
        public object cust_roll1 { get; set; }
        public object cust_roll2 { get; set; }
        public object owner { get; set; }
        public object cust_BasketAllowanceAnnual { get; set; }
        public object cust_instracademicrec { get; set; }
        public object cust_LastDesig { get; set; }
        public object exportedOn { get; set; }
        public object cust_empid { get; set; }
        public object cust_num3 { get; set; }
        public object cust_num2 { get; set; }
        public object cust_Currency { get; set; }
        public object cust_VPI { get; set; }
        public object cust_num1 { get; set; }
        public object cust_instrref3 { get; set; }
        public object cust_cost { get; set; }
        public object cust_addressLine2 { get; set; }
        public object cust_Addiskills { get; set; }
        public object cust_comaddress3 { get; set; }
        public object cust_comaddress2 { get; set; }
        public object cust_comaddress1 { get; set; }
        public object cust_currentwork1 { get; set; }
        public object cust_currentwork2 { get; set; }
        public object cust_OfferCreation { get; set; }
        public object cust_currentwork3 { get; set; }
        public object cust_instrCurrentaddress { get; set; }
        public object cust_instrOtherDetails { get; set; }
        public object cust_BGC_AB_ResultCaseStatus { get; set; }
        public object cust_TotalExpmth { get; set; }
        public string status { get; set; }
        public object cust_instrBGCPackage { get; set; }
        public string city { get; set; }
        public object cust_BGC_AB_ResultReportDate { get; set; }
        public string countryCode { get; set; }
        public string nonApplicantStatus { get; set; }
        public object resumeUploadDate { get; set; }
        public object cust_pername { get; set; }
        public object dateOfBirth { get; set; }
        public string appStatusSetItemId { get; set; }
        public object cust_AnnualizedCost { get; set; }
        public object cust_instrempdetails { get; set; }
        public string cellPhone { get; set; }
        public object cust_VPIncentiveAnnual { get; set; }
        public object cust_VisaExpiry { get; set; }
        public object cust_reasonforchange3 { get; set; }
        public string rating { get; set; }
        public object cust_reasonforchange1 { get; set; }
        public object cust_reasonforchange2 { get; set; }
        public object cust_Permcity1 { get; set; }
        public object cust_SpecialBonus2 { get; set; }
        public object cust_alledudetails { get; set; }
        public object cust_instrrefdetails { get; set; }
        public object cust_VPIPercent { get; set; }
        public object cust_instrDisclaimer { get; set; }
        public object cust_AadhaarNumber { get; set; }
        public object timeToHire { get; set; }
        public object cust_expcompamt { get; set; }
        public object cust_AmountBonus { get; set; }
        public object cust_empdesig { get; set; }
        public object cust_BGC_IISERVZ_ACKComment { get; set; }
        public object cust_OtherVisa { get; set; }
        public object cust_Permzip { get; set; }
        public string candidateId { get; set; }
        public object cust_startyr2 { get; set; }
        public object candTypeWhenHired { get; set; }
        public object cust_startyr1 { get; set; }
        public object cust_startyr4 { get; set; }
        public object cust_startyr3 { get; set; }
        public object cust_TTC { get; set; }
        public object cust_Sourceinfo { get; set; }
        public object cust_Permtilldate { get; set; }
        public string contactEmail { get; set; }
        public object jobAppGuid { get; set; }
        public object cust_VendorCompanyEmailPhone { get; set; }
        public object cust_instrpostgrad { get; set; }
        public object cust_BGC_IISERVZ_RefId { get; set; }
        public object cust_RelExpyrs { get; set; }
        public object cust_Permlandmark { get; set; }
        public object cust_HRA_Annual { get; set; }
        public object sectDisclaimer { get; set; }
        public object cust_rel3 { get; set; }
        public object cust_rel2 { get; set; }
        public object cust_rel1 { get; set; }
        public object cust_instrBGCAuthBridge { get; set; }
        public object cust_HMComments { get; set; }
        public object cust_CTC { get; set; }
        public object cust_instrApplication { get; set; }
        public object cust_endyr4 { get; set; }
        public object cust_endyr5 { get; set; }
        public object cust_endyr2 { get; set; }
        public object cust_endyr3 { get; set; }
        public object cust_endyr1 { get; set; }
        public object cust_curaddressLine2 { get; set; }
        public object cust_coursecom5 { get; set; }
        public object cust_coursecom2 { get; set; }
        public object cust_instr10th { get; set; }
        public object cust_TSCHeadComments { get; set; }
        public object cust_coursecom3 { get; set; }
        public object cust_coursecom1 { get; set; }
        public object startDate { get; set; }
        public object cust_PrintedName { get; set; }
        public string sourceLabel { get; set; }
        public object customVisaYes { get; set; }
        public string profileUpdated { get; set; }
        public object cust_lastcompamt { get; set; }
        public object cust_ReferralEmp { get; set; }
        public string jobReqId { get; set; }
        public object cust_desi3 { get; set; }
        public object cust_startdate2 { get; set; }
        public object cust_startdate3 { get; set; }
        public object cust_instrknowanyone { get; set; }
        public object cust_startdate1 { get; set; }
        public object candConversionProcessed { get; set; }
        public object cust_desi1 { get; set; }
        public object cust_desi2 { get; set; }
        public string country { get; set; }
        public object cust_instrPermaddress { get; set; }
        public object lastModifiedDateTime { get; set; }
        public object Cust_BusinessScreeningStatus { get; set; }
        public object cust_interinlast6mnth { get; set; }
        public string source { get; set; }
        public object cust_OthPerksBenfits { get; set; }
        public object cust_RelExpmth { get; set; }
        public object cust_nickName { get; set; }
        public object cust_empids { get; set; }
        public object cust_NoticePeriod { get; set; }
        public object cust_Empname3 { get; set; }
        public object cust_highcomedu { get; set; }
        public object cust_Empname2 { get; set; }
        public object cust_Empname1 { get; set; }
        public object cust_BGC_AB_ResultReportSeverity4 { get; set; }
        public object cust_BGC_AB_ResultReportSeverity3 { get; set; }
        public object cust_BGC_AB_ResultReportSeverity6 { get; set; }
        public object cust_BGC_AB_ResultReportSeverity5 { get; set; }
        public object cust_BGC_AB_ResultReportSeverity2 { get; set; }
        public object cust_BGC_AB_ResultReportSeverity1 { get; set; }
        public object cust_sch4 { get; set; }
        public object homePhone { get; set; }
        public object cust_sch3 { get; set; }
        public object cust_PassportNo { get; set; }
        public object Cust_TSCScreeningA6 { get; set; }
        public object cust_instrlast7yrs { get; set; }
        public object cust_Permperiodofstayend { get; set; }
        public object cust_curPeriodofStay { get; set; }
        public object cust_instr12th { get; set; }
        public string firstName { get; set; }
        public object lastModifiedByProxy { get; set; }
        public object cust_instrEmployer2 { get; set; }
        public object cust_instrEmployer1 { get; set; }
        public object hiredOn { get; set; }
        public object cust_CurrentLoc { get; set; }
        public object cust_curtilldate { get; set; }
        public object LegacyCandidateId { get; set; }
        public object cust_degdip5 { get; set; }
        public object cust_instrEmployer3 { get; set; }
        public object cust_city1 { get; set; }
        public object cust_city2 { get; set; }
        public object cust_city3 { get; set; }
        public object cust_nameadd5 { get; set; }
        public object cust_BGC_AB_ResultReportType { get; set; }
        public object cust_empid3 { get; set; }
        public object cust_curaddress { get; set; }
        public object cust_empid2 { get; set; }
        public object cust_empid1 { get; set; }
        public object cust_clientinterviewnotes { get; set; }
        public object cust_BGC_IISERVZ_ResultFinalComment { get; set; }
        public object cust_curbesttime { get; set; }
        public object middleName { get; set; }
        public object cust_instrref2 { get; set; }
        public string appLocale { get; set; }
        public object cust_instrref1 { get; set; }
        public object cust_org2 { get; set; }
        public object cust_org3 { get; set; }
        public object cust_BasicAnnual { get; set; }
        public object cust_org1 { get; set; }
        public string zip { get; set; }
        public object cust_maj2 { get; set; }
        public object cust_maj5 { get; set; }
        public object cust_FixedAnnual { get; set; }
        public object cust_maj1 { get; set; }
        public object cust_instrPassportVisaDetails { get; set; }
        public object cust_Permcontact { get; set; }
        public object cust_BGC_IISERVZ_ResultCheckwiseStatus3 { get; set; }
        public object cust_BGC_IISERVZ_ResultCheckwiseStatus4 { get; set; }
        public string lastName { get; set; }
        public object cust_BGC_IISERVZ_ResultCheckwiseStatus1 { get; set; }
        public object cust_insname1 { get; set; }
        public object cust_BGC_IISERVZ_ResultCheckwiseStatus2 { get; set; }
        public object cust_insname2 { get; set; }
        public object cust_BGC_IISERVZ_ResultCheckwiseStatus7 { get; set; }
        public string gender { get; set; }
        public object cust_BGC_IISERVZ_ResultCheckwiseStatus5 { get; set; }
        public object cust_instrveteranQ { get; set; }
        public object cust_BGC_IISERVZ_ResultCheckwiseStatus6 { get; set; }
        public object cust_UAN { get; set; }
        public object cust_VendorCompanyname { get; set; }
        public object cust_Permbesttime { get; set; }
        public object cust_InternalApprovalDate { get; set; }
        public object cust_BGC_IISERVZ_ResultCheckwiseComment7 { get; set; }
        public object cust_BGC_IISERVZ_ResultCheckwiseComment6 { get; set; }
        public object cust_MonthlyBonusAnnual { get; set; }
        public object cust_BGC_IISERVZ_ResultCheckwiseComment5 { get; set; }
        public object cust_BGC_IISERVZ_ResultCheckwiseComment4 { get; set; }
        public object cust_BGC_IISERVZ_ResultCheckwiseComment3 { get; set; }
        public object cust_BGC_IISERVZ_ResultCheckwiseComment2 { get; set; }
        public object cust_BGC_IISERVZ_ResultCheckwiseComment1 { get; set; }
        public object cust_break3 { get; set; }
        public object referenceComments { get; set; }
        public object cust_relname { get; set; }
        public object cust_empdep { get; set; }
        public string anonymizedFlag { get; set; }
        public string referredBy { get; set; }
        public string applicationTemplateId { get; set; }
        public object cust_curzip { get; set; }
        public string jobTitle { get; set; }
        public object agencyInfo { get; set; }
        public object reference { get; set; }
        public object Cust_TSCScreeningSum { get; set; }
        public object cust_break1 { get; set; }
        public object cust_break2 { get; set; }
        public object cust_VendorCompanyaddress { get; set; }
        public object cust_lastdeg3 { get; set; }
        public object cust_lastdeg2 { get; set; }
        public object cust_lastdeg1 { get; set; }
        public object cust_instrRewardInfo { get; set; }
        public object cust_Secemail { get; set; }
        public object cust_instrEmpInfo { get; set; }
        public string dataSource { get; set; }
        public object cust_tenenddate3 { get; set; }
        public object cust_JoiningB { get; set; }
        public object cust_tenenddate2 { get; set; }
        public object cust_tenenddate1 { get; set; }
        public object cust_SSNIssueDate { get; set; }
        public object cust_instrBGCIISERVZ { get; set; }
        public object cust_BGC_AB_ResultUniqueID { get; set; }
        public object cust_TARemarks { get; set; }
        public string lastModifiedBy { get; set; }
        public object snapShotDate { get; set; }
        public CustBGCIISERVZResultPDFReport cust_BGC_IISERVZ_ResultPDFReport { get; set; }
        public CustCandidateConfirmation cust_CandidateConfirmation { get; set; }
        public ReferralSource referralSource { get; set; }
        public CustBGCABResultReportPDF cust_BGC_AB_ResultReportPDF { get; set; }
        public JobApplicationComments jobApplicationComments { get; set; }
        public OfferLetter offerLetter { get; set; }
        public CustCandAvailabilitydate cust_CandAvailabilitydate { get; set; }
        public CustPrefix cust_prefix { get; set; }
        public CustExtInterviewStatus cust_ExtInterviewStatus { get; set; }
        public CustInterpersonalSkills cust_InterpersonalSkills { get; set; }
        public CustTSCScreeningQ2 Cust_TSCScreeningQ2 { get; set; }
        public CustTSCScreeningQ1 Cust_TSCScreeningQ1 { get; set; }
        public CustBSLformat cust_BSLformat { get; set; }
        public CustInterviewRequired1 Cust_InterviewRequired1 { get; set; }
        public CustInterviewRequired3 Cust_InterviewRequired3 { get; set; }
        public CustInterviewRequired2 Cust_InterviewRequired2 { get; set; }
        public Resume resume { get; set; }
        public CustSpecialBonusAttach cust_SpecialBonusAttach { get; set; }
        public CustApprovalemail cust_approvalemail { get; set; }
        public CustInterviewRequired5 Cust_InterviewRequired5 { get; set; }
        public CustInterviewRequired4 Cust_InterviewRequired4 { get; set; }
        public CustAadhaarattach custAadhaarattach { get; set; }
        public CustValidPassport cust_ValidPassport { get; set; }
        public Custeducationdetails custeducationdetails { get; set; }
        public CustImmigrationStatus cust_ImmigrationStatus { get; set; }
        public CustcandPhotoattach custcandPhotoattach { get; set; }
        public CustTravel cust_Travel { get; set; }
        public CustBGCStatus cust_BGCStatus { get; set; }
        public CustPermState cust_PermState { get; set; }
        public CustTSCScreeningQ4 Cust_TSCScreeningQ4 { get; set; }
        public CustTSCScreeningQ3 Cust_TSCScreeningQ3 { get; set; }
        public CustTSCScreeningQ5 Cust_TSCScreeningQ5 { get; set; }
        public CustPANattach custPANattach { get; set; }
        public CustWorkAuthStatus cust_WorkAuthStatus { get; set; }
        public Custaddressproof custaddressproof { get; set; }
        public CustBlacklistUniv cust_BlacklistUniv { get; set; }
        public CustScreeningStatus3 Cust_ScreeningStatus3 { get; set; }
        public CustBGCApplicableType cust_BGCApplicableType { get; set; }
        public CustScreeningStatus1 Cust_ScreeningStatus1 { get; set; }
        public CustPostGradDegattach custPostGradDegattach { get; set; }
        public CustEmptype2 cust_emptype2 { get; set; }
        public CustEmptype3 cust_emptype3 { get; set; }
        public Education education { get; set; }
        public CustEmptype1 cust_emptype1 { get; set; }
        public CustUANattach custUANattach { get; set; }
        public CustInterviewedInBirlasoft cust_interviewedInBirlasoft { get; set; }
        public CustExpcompcur cust_expcompcur { get; set; }
        public CustFormeremployee cust_formeremployee { get; set; }
        public VeteranA veteranA { get; set; }
        public JobRequisition jobRequisition { get; set; }
        public CustBachDegattach custBachDegattach { get; set; }
        public CustSource cust_source { get; set; }
        public CustPermAddProofattach custPermAddProofattach { get; set; }
        public CustOfferedStream cust_OfferedStream { get; set; }
        public CustExtInterviewResult cust_ExtInterviewResult { get; set; }
        public CustTSCScreeningSkill Cust_TSCScreeningSkill { get; set; }
        public BgiAccountId bgiAccountId { get; set; }
        public InsideWorkExperience insideWorkExperience { get; set; }
        public CustClientinterviewstatus cust_clientinterviewstatus { get; set; }
        public JobAppStatus jobAppStatus { get; set; }
        public CustLetterOfAuthorization custLetterOfAuthorization { get; set; }
        public CustCurcountry cust_curcountry { get; set; }
        public CustStat4 cust_stat4 { get; set; }
        public CustStat2 cust_stat2 { get; set; }
        public CustStat3 cust_stat3 { get; set; }
        public CustStat1 cust_stat1 { get; set; }
        public CustTurbohire cust_Turbohire { get; set; }
        public CustInterviewsfeedback cust_interviewsfeedback { get; set; }
        public JobApplicationStatusAuditTrail jobApplicationStatusAuditTrail { get; set; }
        public CustCntr3 cust_cntr3 { get; set; }
        public CustCntr4 cust_cntr4 { get; set; }
        public CustCntr1 cust_cntr1 { get; set; }
        public CustRecCandidateSource Cust_RecCandidateSource { get; set; }
        public CustCntr2 cust_cntr2 { get; set; }
        public CustSecondaryskills cust_secondaryskills { get; set; }
        public CustomLegalAuth customLegalAuth { get; set; }
        public CustPrimaryskills cust_primaryskills { get; set; }
        public CustRelocate cust_Relocate { get; set; }
        public CustCurstate cust_curstate { get; set; }
        public State state { get; set; }
        public ReferredByNav referredByNav { get; set; }
        public CustLastcomptype cust_lastcomptype { get; set; }
        public Certificates certificates { get; set; }
        public CustOfferedGrade cust_OfferedGrade { get; set; }
        public StatusId statusId { get; set; }
        public CustRelocation1 cust_Relocation1 { get; set; }
        public CustRelocation2 cust_Relocation2 { get; set; }
        public JobOffer jobOffer { get; set; }
        public CountryPicklist countryPicklist { get; set; }
        public CustCandPhoto cust_candPhoto { get; set; }
        public UserNav userNav { get; set; }
        public JobApplicationOnboardingData jobApplicationOnboardingData { get; set; }
        public CustTSCScreeningA4 Cust_TSCScreeningA4 { get; set; }
        public CustTSCScreeningA3 Cust_TSCScreeningA3 { get; set; }
        public CustTSCScreeningA5 Cust_TSCScreeningA5 { get; set; }
        public CustTSCScreeningA2 Cust_TSCScreeningA2 { get; set; }
        public JobApplicationAudit jobApplicationAudit { get; set; }
        public CustTSCScreeningA1 Cust_TSCScreeningA1 { get; set; }
        public CustCurAddProofattach custCurAddProofattach { get; set; }
        public CustBlacklistCompanies cust_BlacklistCompanies { get; set; }
        public CustRehire cust_Rehire { get; set; }
        public CustLastcompcur cust_lastcompcur { get; set; }
        public CustPermcountry cust_Permcountry { get; set; }
        public CustomVisa customVisa { get; set; }
        public CustHMFeedback cust_HMFeedback { get; set; }
        public CoverLetter coverLetter { get; set; }
        public JobApplicationAssessmentOrder jobApplicationAssessmentOrder { get; set; }
        public JobApplicationInterview jobApplicationInterview { get; set; }
        public CustTSCHeadFeedback cust_TSCHeadFeedback { get; set; }
        public CustEmpType cust_EmpType { get; set; }
        public CustNationality cust_Nationality { get; set; }
        public CustPermstate1 cust_Permstate1 { get; set; }
        public JobApplicationQuestionResponse jobApplicationQuestionResponse { get; set; }
        public CustCommskills cust_Commskills { get; set; }
        public CustMaritalStatus cust_MaritalStatus { get; set; }
        public PackageId packageId { get; set; }
        public CustExpcomptype cust_expcomptype { get; set; }
        public Custpayslipattach custpayslipattach { get; set; }
        public Cust12attach cust12attach { get; set; }
        public CustDiplomaattach custDiplomaattach { get; set; }
        public CustJoiningSigningBonus cust_Joining_SigningBonus { get; set; }
        public CustLetterattach custLetterattach { get; set; }
        public CustQuartile cust_Quartile { get; set; }
        public OutsideWorkExperience outsideWorkExperience { get; set; }
        public CustTAleadFeedback cust_TAleadFeedback { get; set; }
        public Candidate candidate { get; set; }
        public CustCitizenship cust_Citizenship { get; set; }
        public CustExtInterviewVendors cust_ExtInterviewVendors { get; set; }
        public CustClientinterviewsfeedback cust_clientinterviewsfeedback { get; set; }
        public CustScreeningResult3 cust_ScreeningResult3 { get; set; }
        public Cust10attach cust10attach { get; set; }
        public CustScreeningResult2 cust_ScreeningResult2 { get; set; }
        public CustScreeningResult1 cust_ScreeningResult1 { get; set; }
    }

    public class Deferred
    {
        public string uri { get; set; }
    }

    public class Education
    {
        public Deferred __deferred { get; set; }
    }

    public class InsideWorkExperience
    {
        public Deferred __deferred { get; set; }
    }

    public class JobApplicationAssessmentOrder
    {
        public Deferred __deferred { get; set; }
    }

    public class JobApplicationAudit
    {
        public Deferred __deferred { get; set; }
    }

    public class JobApplicationComments
    {
        public Deferred __deferred { get; set; }
    }

    public class JobApplicationInterview
    {
        public Deferred __deferred { get; set; }
    }

    public class JobApplicationOnboardingData
    {
        public Deferred __deferred { get; set; }
    }

    public class JobApplicationQuestionResponse
    {
        public Deferred __deferred { get; set; }
    }

    public class JobApplicationStatusAuditTrail
    {
        public Deferred __deferred { get; set; }
    }

    public class JobAppStatus
    {
        public Deferred __deferred { get; set; }
    }

    public class JobOffer
    {
        public Deferred __deferred { get; set; }
    }

    public class JobRequisition
    {
        public Deferred __deferred { get; set; }
    }

    public class OfferLetter
    {
        public Deferred __deferred { get; set; }
    }

    public class OutsideWorkExperience
    {
        public Deferred __deferred { get; set; }
    }

    public class PackageId
    {
        public Deferred __deferred { get; set; }
    }

    public class ReferralSource
    {
        public Deferred __deferred { get; set; }
    }

    public class ReferredByNav
    {
        public Deferred __deferred { get; set; }
    }

    public class Resume
    {
        public Deferred __deferred { get; set; }
    }

    public class CandidateDetail
    {
        public Detail d { get; set; }
    }

    public class State
    {
        public Deferred __deferred { get; set; }
    }

    public class StatusId
    {
        public Deferred __deferred { get; set; }
    }

    public class UserNav
    {
        public Deferred __deferred { get; set; }
    }

    public class VeteranA
    {
        public Deferred __deferred { get; set; }
    }

    //
    //candidate education and employedment
    //education detail   
    public class Application
    {
        public Deferred __deferred { get; set; }
    }
    public class D1
    {
        public List<Result1> results { get; set; }
    }
    public class EducationlevelNav
    {
        public Deferred __deferred { get; set; }
    }
    public class InstitutionNav
    {
        public Deferred __deferred { get; set; }
    }
    public class ProgramNav
    {
        public Deferred __deferred { get; set; }
    }
    public class Result1
    {
        public Metadata __metadata { get; set; }
        public string backgroundElementId { get; set; }
        public object gpaoutof { get; set; }
        public object Program { get; set; }
        public DateTime? lastModifiedDateTime { get; set; }
        public DateTime? endDate { get; set; }
        public object educationlevel { get; set; }
        public string institution { get; set; }
        public string otherinstitution { get; set; }
        public string bgOrderPos { get; set; }
        public object gpa { get; set; }
        public string applicationId { get; set; }
        public DateTime? startDate { get; set; }
        public object otherProgram { get; set; }
        public InstitutionNav institutionNav { get; set; }
        public EducationlevelNav educationlevelNav { get; set; }
        public Application application { get; set; }
        public ProgramNav ProgramNav { get; set; }
    }
    public class Root1
    {
        public D1 d { get; set; }
    }
    //
    //Employedment Detail
    public class D2
    {
        public List<Result2> results { get; set; }
    }
    public class EmployerNav
    {
        public Deferred __deferred { get; set; }
    }
    public class JobFunctionNav
    {
        public Deferred __deferred { get; set; }
    }
    public class PresentEmployerNav
    {
        public Deferred __deferred { get; set; }
    }
    public class Result2
    {
        public Metadata __metadata { get; set; }
        public string backgroundElementId { get; set; }
        public string achievements { get; set; }
        public DateTime? lastModifiedDateTime { get; set; }
        public DateTime? endDate { get; set; }
        public object otheremployer { get; set; }
        public object jobFunction { get; set; }
        public string bgOrderPos { get; set; }
        public object employer { get; set; }
        public string applicationId { get; set; }
        public string otherFunction { get; set; }
        public DateTime? startDate { get; set; }
        public object presentEmployer { get; set; }
        public PresentEmployerNav presentEmployerNav { get; set; }
        public JobFunctionNav jobFunctionNav { get; set; }
        public EmployerNav employerNav { get; set; }
        public Application application { get; set; }
    }
    public class Root2
    {
        public D2 d { get; set; }
    }
    //
    //






}
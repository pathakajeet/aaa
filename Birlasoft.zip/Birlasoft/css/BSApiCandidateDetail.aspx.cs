﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class BSApiCandidateDetail : System.Web.UI.Page
{
    DataTable ds = new DataTable();
    DataTable ds1 = new DataTable();
    DataTable ds2 = new DataTable();
    SqlDataAdapter adapter = new SqlDataAdapter();
    string sql = null;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());

    protected void Page_Load(object sender, EventArgs e)
    {

       
        ds.Clear();
        ds.Dispose();
        string dtt = "select applicationId  	as [APPLICATION ID],jobReqId 	as [JOB REQ ID],candidateId	as [CANDIDATE ID],firstName  	as [FIRST NAME],middleName  	as [MIDDLE NAME],lastName  	as [LAST NAME],gender  	as [GENDER],cellPhone  	as [CELL PHONE],contactEmail  	as [CONTACT EMAIL],city 	as [CITY],countryCode  	as [COUNTRY CODE],country 	as [COUNTRY],zip 	as [ZIP],address 	as [ADDRESS],jobTitle 	as [JOB TITLE],applicationDate 	as [APPLICATION DATE ],usersSysId  	as [USER SSYS ID], [cust_PAN] 	as [PAN NUMBER],[cust_UAN] 	as [UAN NUMBER],[cust_AadhaarNumber]  	as [AADHAAR NUMBER],status 	as [STATUS 	],homePhone  	as [HOME PHONE],owner  	as [OWNER],[address]  	as [ADDRESS] from tbl_BS_Candidate_info ";
        SqlDataAdapter gridadpt = new SqlDataAdapter(dtt, con);
        gridadpt.Fill(ds);
        Gridview1.DataSource = ds;
        Gridview1.DataBind();
       
       
        dtt = string.Empty;        
        ds1.Clear();
        ds1.Dispose();
        dtt = "select applicationId as [APPLICATION ID],backgroundElementId as [BACKGROUND ELEMENT ID],Program as [PROGRAM],otherProgram as [OTHER PROGRAM],educationlevel as [EDUCATION LEVEL],institution as [INSTITUTION],otherinstitution as [OTHER INSTITUTION],bgOrderPos as [BG ORDER POS] from BS_EducationHead ";
        gridadpt = new SqlDataAdapter(dtt, con);
        gridadpt.Fill(ds1);
        Gridview2.DataSource = ds1;
        Gridview2.DataBind();
      
       
        dtt = string.Empty;        
        ds2.Clear();
        ds2.Dispose();
        dtt = "select applicationId AS [APPLICATION ID],backgroundElementId AS [BACKGROUND ELEMENT ID], employer AS [EMPLOYER], presentEmployer AS [PRESENT EMPLOYER], otheremployer AS [OTHER EMPLOYER], jobFunction AS [JOB FUNCTION], startDate AS [START DATE], endDate AS [END DATE], otherFunction AS [OTHER FUNCTION] , bgOrderPos AS [BG ORDER POS]  from BS_EmployedmentHead ";
        gridadpt = new SqlDataAdapter(dtt, con);
        gridadpt.Fill(ds2);
        Gridview3.DataSource = ds2;
        Gridview3.DataBind();
    }
    protected void Fetch_Click(object sender, EventArgs e)
    {
       

        ds.Clear();
        ds.Dispose();
        string dtt = "select applicationId  	as [APPLICATION ID],jobReqId 	as [JOB REQ ID],candidateId	as [CANDIDATE ID],firstName  	as [FIRST NAME],middleName  	as [MIDDLE NAME],lastName  	as [LAST NAME],gender  	as [GENDER],cellPhone  	as [CELL PHONE],contactEmail  	as [CONTACT EMAIL],city 	as [CITY],countryCode  	as [COUNTRY CODE],country 	as [COUNTRY],zip 	as [ZIP],address 	as [ADDRESS],jobTitle 	as [JOB TITLE],applicationDate 	as [APPLICATION DATE ],usersSysId  	as [USER SSYS ID], [cust_PAN] 	as [PAN NUMBER],[cust_UAN] 	as [UAN NUMBER],[cust_AadhaarNumber]  	as [AADHAAR NUMBER],status 	as [STATUS 	],homePhone  	as [HOME PHONE],owner  	as [OWNER],[address]  	as [ADDRESS] from tbl_BS_Candidate_info where applicationId = '" + applicationidtxt.Text.ToString() + "' ";
        SqlDataAdapter gridadpt = new SqlDataAdapter(dtt, con);
        gridadpt.Fill(ds);
        Gridview1.DataSource = ds;
        Gridview1.DataBind();

        
        dtt = string.Empty;       
        ds1.Clear();
        ds1.Dispose();
        dtt = "select applicationId as [APPLICATION ID],backgroundElementId as [BACKGROUND ELEMENT ID],Program as [PROGRAM],otherProgram as [OTHER PROGRAM],educationlevel as [EDUCATION LEVEL],institution as [INSTITUTION],otherinstitution as [OTHER INSTITUTION],bgOrderPos as [BG ORDER POS] from BS_EducationHead where applicationId = '" + applicationidtxt.Text.ToString() + "' ";
        gridadpt = new SqlDataAdapter(dtt, con);
        gridadpt.Fill(ds1);
        Gridview2.DataSource = ds1;
        Gridview2.DataBind();

       
        dtt = string.Empty;        
        ds2.Clear();
        ds2.Dispose();
        dtt = "select applicationId AS [APPLICATION ID],backgroundElementId AS [BACKGROUND ELEMENT ID], employer AS [EMPLOYER], presentEmployer AS [PRESENT EMPLOYER], otheremployer AS [OTHER EMPLOYER], jobFunction AS [JOB FUNCTION],  startDate AS [START DATE], endDate AS [END DATE], otherFunction AS [OTHER FUNCTION] , bgOrderPos AS [BG ORDER POS]  from BS_EmployedmentHead where applicationId = '" + applicationidtxt.Text.ToString() + "' ";
        gridadpt = new SqlDataAdapter(dtt, con);
        gridadpt.Fill(ds2);
        Gridview3.DataSource = ds2;
        Gridview3.DataBind();

        edugrid.Visible = true;
        employergrid.Visible = true;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {


        ds.Clear();
        ds.Dispose();
        string dtt = "select applicationId  	as [APPLICATION ID],jobReqId 	as [JOB REQ ID],candidateId	as [CANDIDATE ID],firstName  	as [FIRST NAME],middleName  	as [MIDDLE NAME],lastName  	as [LAST NAME],gender  	as [GENDER],cellPhone  	as [CELL PHONE],contactEmail  	as [CONTACT EMAIL],city 	as [CITY],countryCode  	as [COUNTRY CODE],country 	as [COUNTRY],zip 	as [ZIP],address 	as [ADDRESS],jobTitle 	as [JOB TITLE],applicationDate 	as [APPLICATION DATE ],usersSysId  	as [USER SSYS ID], [cust_PAN] 	as [PAN NUMBER],[cust_UAN] 	as [UAN NUMBER],[cust_AadhaarNumber]  	as [AADHAAR NUMBER],status 	as [STATUS 	],homePhone  	as [HOME PHONE],owner  	as [OWNER],[address]  	as [ADDRESS] from tbl_BS_Candidate_info where firstName like '%" + TextBox1.Text.ToString() + "%' ";
        SqlDataAdapter gridadpt = new SqlDataAdapter(dtt, con);
        gridadpt.Fill(ds);
        Gridview1.DataSource = ds;
        Gridview1.DataBind();

        edugrid.Visible = false;
        employergrid.Visible = false;

        //dtt = string.Empty;
        //ds1.Clear();
        //ds1.Dispose();
        //dtt = "select applicationId as [APPLICATION ID],backgroundElementId as [BACKGROUND ELEMENT ID],Program as [PROGRAM],otherProgram as [OTHER PROGRAM],educationlevel as [EDUCATION LEVEL],institution as [INSTITUTION],otherinstitution as [OTHER INSTITUTION],bgOrderPos as [BG ORDER POS] from BS_EducationHead where applicationId = '" + applicationidtxt.Text.ToString() + "' ";
        //gridadpt = new SqlDataAdapter(dtt, con);
        //gridadpt.Fill(ds1);
        //Gridview2.DataSource = ds1;
        //Gridview2.DataBind();


        //dtt = string.Empty;
        //ds2.Clear();
        //ds2.Dispose();
        //dtt = "select applicationId AS [APPLICATION ID],backgroundElementId AS [BACKGROUND ELEMENT ID], startDate AS [START DATE], endDate AS [END DATE], employer AS [EMPLOYER], presentEmployer AS [PRESENT EMPLOYER], otheremployer AS [OTHER EMPLOYER], jobFunction AS [JOB FUNCTION], otherFunction AS [OTHER FUNCTION] , bgOrderPos AS [BG ORDER POS]  from BS_EmployedmentHead where applicationId = '" + applicationidtxt.Text.ToString() + "' ";
        //gridadpt = new SqlDataAdapter(dtt, con);
        //gridadpt.Fill(ds2);
        //Gridview3.DataSource = ds2;
        //Gridview3.DataBind();
    }
}
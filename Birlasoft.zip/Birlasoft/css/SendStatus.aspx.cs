﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Casestatus;

public partial class SendStatus : System.Web.UI.Page
{
    DataTable ds = new DataTable();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {

        string dtt = "select CheckRequiredId,	applicationId,'' as iiservzid,	backgroundElementId,	CheckName,	CreatedDate,	CheckStatus from tblCheckRequired";
        SqlDataAdapter gridadpt = new SqlDataAdapter(dtt, con);
        gridadpt.Fill(ds);

        gvCheckDetails.DataSource = ds;
        gvCheckDetails.DataBind();
        checkdetaildiv.Visible = false;

    }



    protected void BtnUpdateChkStatus_Click(object sender, EventArgs e)
    {
        //Status st = new Status();
        //DataSet ds = new DataSet();
        //bool IsUpdate = false;

        //for (int i = 0; i < gvCheckDetails.Rows.Count; i++)
        //{
        //    GridViewRow row = gvCheckDetails.Rows[i];

            
        //    string strClientId = ((Label)row.FindControl("lblDGClientId")).Text;
        //    string strIiservzId = ((Label)row.FindControl("lblDGIISERVZId")).Text;
        //    string strCaseStatus = ((DropDownList)row.FindControl("ddlCaseStatus")).SelectedValue.ToString();
        //    string strRemarks = ((TextBox)row.FindControl("txtRemarks")).Text;

        //    if (strCaseStatus != "0")
        //    {
        //        IsUpdate = false;

        //        if ((strCaseStatus == "3") || (strCaseStatus == "4") || (strCaseStatus == "5") || (strCaseStatus == "6"))
        //        {
        //            if (strRemarks == string.Empty)
        //            {
        //                Response.Write("<Script Language='javascript'> alert('Please enter remarks !!!')</Script>");
        //            }
        //            else
        //            {
        //                string ii = st.UpdateChkStatus(strCheckCode, strClientId, strRequestId, strCaseStatus, strRemarks);
        //                IsUpdate = true;
        //            }
        //        }
        //        else
        //        {
        //            string ii = st.UpdateChkStatus(strCheckCode, strClientId, strRequestId, strCaseStatus, strRemarks);
        //            IsUpdate = true;
        //        }

        //    }
        //}
        //if (IsUpdate)
        //{
        //    lblMsg.Text = "check status updated";
        //}
    }
    protected void BtnChkDetail_Click(object sender, EventArgs e)
    {
        checkdetaildiv.Visible = true;
        ds.Clear();
        ds.Dispose();
        string dtt = "select CheckRequiredId,applicationId,'' as iiservzid,backgroundElementId,CheckName,CreatedDate,CheckStatus from tblCheckRequired where applicationId = " + applicationidtxt.Text.ToString() + " ";
        SqlDataAdapter gridadpt = new SqlDataAdapter(dtt, con);
        gridadpt.Fill(ds);
        gvCheckDetails.DataSource = ds;
        gvCheckDetails.DataBind();
    }
    protected void BtnSendStatus_Click(object sender, EventArgs e)
    {

    }
}
﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Casestatus;
using System.Text;
using RestSharp;
using System.Net;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public partial class SendStatus : System.Web.UI.Page
{
    DataTable ds = new DataTable();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
    SqlDataAdapter adapter = new SqlDataAdapter();

    protected void Page_Load(object sender, EventArgs e)
    {

       

    }



    protected void BtnUpdateChkStatus_Click(object sender, EventArgs e)
    {
        
    }
    protected void BtnChkDetail_Click(object sender, EventArgs e)
    {
       
    }
    private DataSet getDataset(string query)
    {
        DataSet tempDataSet = new DataSet();
        SqlDataAdapter dap = new SqlDataAdapter(query, con);
        dap.Fill(tempDataSet);
        return tempDataSet;
    }

    public static DataTable Tabulate(string json)
    {
        var jsonLinq = JObject.Parse(json);       
        var srcArray = jsonLinq.Descendants().Where(d => d is JArray).First();
        var trgArray = new JArray();
        foreach (JObject row in srcArray.Children<JObject>())
        {
            var cleanRow = new JObject();
            foreach (JProperty column in row.Properties())
            {
               if (column.Value is JValue)
                {
                    cleanRow.Add(column.Name, column.Value);
                }
            }
            trgArray.Add(cleanRow);
        }
        return JsonConvert.DeserializeObject<DataTable>(trgArray.ToString());
    }
    protected void BtnSendStatus_Click(object sender, EventArgs e)
    {
        string strSQL = string.Empty;
        string applicationid = applicationidtxt.Text.ToString();
        strSQL = "SELECT TOP 1 jobReqId, "
            + " Case when cust_org1!='' then 'WIP' else '' end as [Check1],'' as [Remark1], "
            + " Case when cust_org2!='' then 'WIP' else '' end as [Check2],'' as [Remark2], "
            + " Case when cust_org3!='' then 'WIP' else '' end as [Check3],'' as [Remark3], "
            + " Case when cust_org3!='' then 'WIP' else '' end as [Check4],'' as [Remark4], "
            + " Case when cust_org3!='' then 'WIP' else '' end as [Check5],'' as [Remark5], "
            + " Case when cust_org3!='' then 'WIP' else '' end as [Check6],'' as [Remark6],  "
            + " Case when cust_org3!='' then 'WIP' else '' end as [Check7],'' as [Remark7]   "
            + " FROM tbl_BS_Candidate_info  "
            + " WHERE applicationId = '" + Convert.ToInt32(applicationid) + "' ";
                           
        //string str = string.Format("select top 1 jobReqId,Case when cust_org1!='' then 'WIP' else '' end as [Check1],'' as [Remark1],Case when cust_org2!='' then 'WIP' else '' end as [Check2],'' as [Remark2], Case when cust_org3!='' then 'WIP' else '' end as [Check3],'' as [Remark3], Case when cust_org3!='' then 'WIP' else '' end as [Check4],'' as [Remark4], Case when cust_org3!='' then 'WIP' else '' end as [Check5],'' as [Remark5], Case when cust_org3!='' then 'WIP' else '' end as [Check6],'' as [Remark6], Case when cust_org3!='' then 'WIP' else '' end as [Check7],'' as [Remark7]  from tbl_BS_Candidate_info where applicationId =" + Convert.ToInt32(applicationid));
        string str = string.Format(strSQL);
        DataSet ds1 = getDataset(str);
        string jobreqid = ds1.Tables[0].Rows[0]["jobReqId"].ToString();
        string check1 = ds1.Tables[0].Rows[0]["Check1"].ToString();
        string remark1 = ds1.Tables[0].Rows[0]["Remark1"].ToString();
        string check2 = ds1.Tables[0].Rows[0]["Check2"].ToString();
        string remark2 = ds1.Tables[0].Rows[0]["Remark2"].ToString();
        string check3 = ds1.Tables[0].Rows[0]["Check3"].ToString();
        string remark3 = ds1.Tables[0].Rows[0]["Remark3"].ToString();
        string check4 = ds1.Tables[0].Rows[0]["Check4"].ToString();
        string remark4 = ds1.Tables[0].Rows[0]["Remark4"].ToString();
        string check5 = ds1.Tables[0].Rows[0]["Check5"].ToString();
        string remark5 = ds1.Tables[0].Rows[0]["Remark5"].ToString();
        string check6 = ds1.Tables[0].Rows[0]["Check6"].ToString();
        string remark6 = ds1.Tables[0].Rows[0]["Remark6"].ToString();
        string check7 = ds1.Tables[0].Rows[0]["Check7"].ToString();
        string remark7 = ds1.Tables[0].Rows[0]["Remark7"].ToString();

        StringBuilder sb = new StringBuilder();

        sb.Append("{");
        sb.Append("    \"__metadata\": {");
        sb.Append("        \"uri\": \"JobApplication\",");
        sb.Append("        \"type\": \"SFOData.JobApplication\"");
        sb.Append("    },");
        sb.Append("    \"jobReqId\": \"" + jobreqid + "\",");
        sb.Append("    \"applicationId\": \"" + applicationid + "\",");
        sb.Append("    \"cust_BGC_IISERVZ_ResultCheckwiseStatus1\":  \"" + check1 + "\",");
        sb.Append("    \"cust_BGC_IISERVZ_ResultCheckwiseComment1\":  \"" + remark1 + "\",");
        sb.Append("    \"cust_BGC_IISERVZ_ResultCheckwiseStatus2\": \"WIP\",");
        sb.Append("    \"cust_BGC_IISERVZ_ResultCheckwiseComment2\": \"Work in Progress\",");
        sb.Append("    \"cust_BGC_IISERVZ_ResultCheckwiseStatus3\": \"WIP\",");
        sb.Append("    \"cust_BGC_IISERVZ_ResultCheckwiseComment3\": \"Work in Progress\",");
        sb.Append("    \"cust_BGC_IISERVZ_ResultCheckwiseStatus4\": \"WIP\",");
        sb.Append("    \"cust_BGC_IISERVZ_ResultCheckwiseComment4\": \"Work in Progress\",");
        sb.Append("    \"cust_BGC_IISERVZ_ResultCheckwiseStatus5\": \"WIP\",");
        sb.Append("    \"cust_BGC_IISERVZ_ResultCheckwiseComment5\": \"Work in Progress\",");
        sb.Append("    \"cust_BGC_IISERVZ_ResultCheckwiseStatus6\": \"Clear\",");
        sb.Append("    \"cust_BGC_IISERVZ_ResultCheckwiseComment6\": \"Check Done\",");
        sb.Append("    \"cust_BGC_IISERVZ_ResultCheckwiseStatus7\": \"Insufficiency\",");
        sb.Append("    \"cust_BGC_IISERVZ_ResultCheckwiseComment7\": \"Invalid data\"");
        sb.Append("}");

        string finalResult = sb.ToString();
        var client = new RestClient("https://api44preview.sapsf.com/odata/v2/upsert");
        //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        var request = new RestRequest(Method.POST);
        request.AddHeader("Authorization", "Basic SW50ZWdyYXRpb25fUHJldmlld0BiaXJsYXNvZnRsVDE6V2VsY29tZUA5ODc=");
        request.AddHeader("Content-Type", "application/json");
        request.AddParameter("application/json", finalResult, ParameterType.RequestBody);
        IRestResponse response = client.Execute(request);
        string Apiresponse = response.Content;
        DataTable cc = Tabulate(Apiresponse);

    }
}
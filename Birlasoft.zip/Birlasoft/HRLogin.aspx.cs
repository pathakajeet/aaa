﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using IISERVZCLASS;
using System.Text;


public partial class Hr : System.Web.UI.Page
{
    #region Global Connection
    private SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Session.Abandon();
            Session.Clear();
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1));
            Response.Cache.SetNoStore();
        }

        if (!IsPostBack)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
        }
    }
   
    protected void ImageButton1_Click(object sender, EventArgs e)
    {
        ValidateLogin login = new ValidateLogin();
        string ModifiedDate = "";
        DataTable dt = new DataTable();
        dt = login.ValidateUserLogin(txtUserName.Text.Trim(), txtPassword.Text.Trim());
        if (dt.Rows.Count > 0)
        {
            lblmsg.Visible = true;
            lblmsg.Text = "Invalid Credentials.Please Try Again";
            Session["userName"] = dt.Rows[0]["UserName"].ToString();
            Session["userID"] = dt.Rows[0]["UserID"].ToString();
            //Session["roleID"] = dS.Tables[0].Rows[0]["RoleID"].ToString();
            //Session["roleName"] = dS.Tables[0].Rows[0]["roleName"].ToString();
            //Session["UserBranchId"] = dS.Tables[0].Rows[0]["BranchId"].ToString();
            Session["UserType"] = dt.Rows[0]["UserType"].ToString();
            Session["UserName"] = dt.Rows[0]["UserName"].ToString();
            Session["PortalUSerType"] = dt.Rows[0]["PortalUSerType"].ToString();
            Session["Clientname"] = dt.Rows[0]["Clientname"].ToString();
            ModifiedDate = dt.Rows[0]["ModifiedDate"].ToString();

            //Session["Role"] = dt.Rows[0]["Role"].ToString();
            //Session["JoiningType"] = "Pre";
            string user = Session["UserType"].ToString();
            //if (user == "Admin")
            //{
            //    Response.Redirect("AcceptReject.aspx");
            //}
            //if (user == "ClientPlusReject")
            //{
            //    Response.Redirect("createuser.aspx");
            //}
            double diff = (DateTime.Now.Date - Convert.ToDateTime(ModifiedDate).Date).TotalDays;
            if (diff > 42)
            {
                UpdateUserStatus(Session["UserName"].ToString());
                Response.Write("<script>alert('Your Login ID is expired as you have not changed the password in last 42 days! Please contact IISERVZ Team!')</script>");
            }
            else
            {
                double x = 42 - diff;
                if (diff > 30)
                {

                    {
                        ClientScript.RegisterStartupScript(typeof(Page), "SymbolError", "<script type='text/javascript'>javascript:LoginConfirm(" + x + ",'BulkUploads.aspx')</script>");
                    }

                }
                else
                {
                    //ClientScript.RegisterStartupScript(typeof(Page), "SymbolError", "<script type='text/javascript'>javascript:LoginConfirm(" + x + ",'BulkUploads.aspx')</script>");
                    Response.Redirect("BulkUploads.aspx");
                }
               
            }
            
        }

        else
        {
            lblmsg.Visible = true;
            lblmsg.Text = "Invalid Credentials.Please Try Again";

        }

    }

    public string UpdateUserStatus(String UserName)
    {
        try
        {
            //SqlConnection con = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("ValidateLoginActive_Update", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@username", UserName);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return "1";
        }
        catch (Exception ex)
        {

            return "0";
        }


    }

   
    protected void lnkChangePassword_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ChangePassword.aspx");
    }
}

﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DataAccess;
using procall1;
using Casestatus;
using System.Drawing;
using IISERVZCLASS;
using System.Text;


public partial class OfferDrop : System.Web.UI.Page
{
    procall pc = new procall();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        string str = Session["UserType"].ToString();
        if (str == "Admin")
        {
            td1.Visible = false;
            td2.Visible = true;
            fc.Visible = false;
            rj.Visible = false;
            od.Visible = true;
            odr.Visible = true;

        }
        if (str == "Hiring")
        {
        
            td1.Visible = false;
            td2.Visible = false;
            odr.Visible = false;
            fc.Visible = false;
            rj.Visible = false;
        }
        if (str == "ClientPlusReject")
        {
            
            td1.Visible = false;
            td2.Visible = false;
            odr.Visible = true;
            fc.Visible = true;
            rj.Visible = true;
            od.Visible = true;
            odr.Visible = true;
        }


        if (!IsPostBack)
        {
            procall pc = new procall();
            DataSet ds = new DataSet();
            ds = pc.SearchbyClient(Session["userName"].ToString(), Session["UserType"].ToString());
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }

    }



    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {


        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (Session["UserType"].ToString() == "Admin")
            {
                ((CheckBox)e.Row.FindControl("chkofferdrop")).Attributes.Add("onclick", "javascript:return HideandShowTextBox('" + ((CheckBox)e.Row.FindControl("chkofferdrop")).ClientID + "*" + ((TextBox)e.Row.FindControl("txtcomment")).ClientID + "*" + ((Button)e.Row.FindControl("btn1")).ClientID + "')");
                ((Button)e.Row.FindControl("btn1")).Style.Add("display", "none");
                ((TextBox)e.Row.FindControl("txtcomment")).Style.Add("display", "none");
                //((CheckBox)e.Row.FindControl("chkofferdrop")).Enabled = false;

            }
            else
            {
                string strScript = "uncheckOthers(" + ((CheckBox)e.Row.Cells[0].FindControl("chkofferdrop")).ClientID + ");";
                ((CheckBox)e.Row.Cells[0].FindControl("chkofferdrop")).Attributes.Add("onclick", "javascript:return Selectone(this,'" + GridView1.ClientID + "');");
                //((CheckBox)e.Row.Cells[0].FindControl("caseinitialize")).Attributes.Add("onclick", "checkBox1OnClick(this);");

                ((CheckBox)e.Row.FindControl("chkofferdrop")).Attributes.Add("onclick", "javascript:return HideandShowTextBox('" + ((CheckBox)e.Row.FindControl("chkofferdrop")).ClientID + "*" + ((TextBox)e.Row.FindControl("txtcomment")).ClientID + "*" + ((Button)e.Row.FindControl("btn1")).ClientID + "')");
                ((Button)e.Row.FindControl("btn1")).Style.Add("display", "none");
                ((TextBox)e.Row.FindControl("txtcomment")).Style.Add("display", "none");
                ((CheckBox)e.Row.FindControl("chkofferdrop")).Enabled = false;
            }


        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "btn1")
        {
            procall pc = new procall();
            DataSet ds = new DataSet();
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                GridViewRow row = GridView1.Rows[i];
                bool isrevert = ((CheckBox)row.FindControl("chkofferdrop")).Checked;
                if (isrevert)
                {
                    Status st = new Status();
                    string candidateid = GridView1.Rows[i].Cells[2].Text;
                    if (candidateid == "&nbsp;")
                    {
                        Response.Write("<Script Language='javascript'> alert('Not yet started. So can't Drop')</Script>");
                    }
                    else
                    {
                        string ii = st.OfferDrop(candidateid, Session["UserName"].ToString(), ((TextBox)row.FindControl("txtcomment")).Text);
                    }

                }
            }
            ds = pc.SearchbyClient(Session["userName"].ToString(), Session["UserType"].ToString());
            GridView1.DataSource = ds;
            GridView1.DataBind();


        }

    }
    protected void btncasestatus_Click(object sender, EventArgs e)
    {
        procall pc = new procall();
        DataSet ds = new DataSet();
        ds = pc.casestatus(Session["userName"].ToString(), Session["UserType"].ToString());
        GridView1.DataSource = ds;
        GridView1.DataBind();

    }
    protected void btnmisreport_Click(object sender, EventArgs e)
    {

        procall pc = new procall();
        DataSet ds = new DataSet();
        ds = pc.SearchbyClient(Session["userName"].ToString(), Session["UserType"].ToString());
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (txtsearch.Text != "")
        {
            procall pc = new procall();
            DataSet ds = new DataSet();
            ds = pc.SearchMIS(txtsearch.Text);
            GridView1.DataSource = ds;
            GridView1.DataBind();

        }
    }
    protected void btnexporttoexcel_Click(object sender, EventArgs e)
    {
        if (GridView1.Rows.Count > 0)
        {

            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                GridView1.HeaderRow.Cells[0].Visible = false;
                GridView1.HeaderRow.Cells[1].Visible = false;

                GridViewRow row = GridView1.Rows[i];
                row.Cells[0].Visible = false;
                row.Cells[1].Visible = false;

            }

            GridView1.HeaderStyle.BackColor = System.Drawing.Color.White;
            GridView1.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            GridView1.ForeColor = System.Drawing.Color.Black;
            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=OfferDrop" + DateTime.Now.ToString("dd-MM-yyyy") + ".xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.xls";
            this.EnableViewState = false;
            System.IO.StringWriter stringWrite = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
            HtmlForm form1 = new HtmlForm();
            this.Controls.Add(form1);

            form1.Controls.Add(GridView1);
            form1.RenderControl(htmlWrite);

            Response.Write(stringWrite.ToString());
            Response.End();
        }
        else
        {
            Response.Write("<Script Language='javascript'> alert('No Rows!')</Script>");
        }
    }
}


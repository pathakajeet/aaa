﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using UploadDownloadManager;
using System.Data.OleDb;
using DataAccess;
using procall1;
using Casestatus;
using System.Drawing;
using IISERVZCLASS;
using System.Text;

public partial class bulkcases : System.Web.UI.Page
{
    CandidateInfonamespace.CandidateDetails candidateobj = new CandidateInfonamespace.CandidateDetails();
    procall pc = new procall();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
       


        string str = "";
        if (!Page.IsPostBack)
        {
            if (Session["UserType"] == null)
            {
                Response.Redirect("HRLogin.aspx");
            }
            else
            {
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");
            }

            str = Session["UserType"].ToString();
            if (str == "Hiring")
            {
                Response.Redirect("CandidateLogin.aspx");
            }
        }

        if (str == "Admin")
        {
            td1.Visible = false;
            //td2.Visible = true;
            //fc.Visible = false;
            rj.Visible = false;
            //od.Visible = true;

        }
        if (str == "Hiring")
        {

            td1.Visible = false;
            //td2.Visible = false;
            //fc.Visible = false;
            rj.Visible = false;
        }
        if (str == "ClientPlusReject")
        {

            td1.Visible = true;
           // td2.Visible = true;
            //fc.Visible = false;
            rj.Visible = true;
           // od.Visible = true;
        }

    }

    public static string CreateRandomPassword(int PasswordLength)
    {
        string _allowedChars = "0123456789abcdefghijkmnopqrstuvwxyz";
        Random randNum = new Random();
        char[] chars = new char[PasswordLength];
        int allowedCharCount = _allowedChars.Length;
        for (int i = 0; i < PasswordLength; i++)
        {
            chars[i] = _allowedChars[(int)((_allowedChars.Length) * randNum.NextDouble())];
        }
        return new string(chars);
    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
        if (GridView1.Rows.Count > 0)
        {
            string firstnme = string.Empty;
            string middlename = string.Empty;
            string surname = string.Empty;
            string emailid = string.Empty;
            string mobileno = string.Empty;
            string fathername = string.Empty;
            string hrmanagername = string.Empty;
            string hrmangeremailid = string.Empty;
            string dob = string.Empty;
            string category = string.Empty;
            string doj = string.Empty;
            string processname = string.Empty;







            int GVCount = GridView1.Rows.Count;

            foreach (GridViewRow GVRow in GridView1.Rows)
            {
                firstnme = GVRow.Cells[0].Text;
                middlename = GVRow.Cells[1].Text;
                surname = GVRow.Cells[2].Text;
                emailid = GVRow.Cells[3].Text;
                mobileno = GVRow.Cells[4].Text;
                fathername = GVRow.Cells[5].Text;

                dob = GVRow.Cells[6].Text;
                category = GVRow.Cells[7].Text;
                doj = GVRow.Cells[8].Text;
               






                if (firstnme != "&nbsp;" && emailid != "&nbsp;" && surname != "&nbsp;" && category != "&nbsp;" && mobileno != "&nbsp;" && processname != "&nbsp;")
                {
                    candidateobj.band4candidatename = (firstnme == "&nbsp;") ? "" : firstnme;
                    candidateobj.band4middlename = (middlename == "&nbsp;") ? "" : middlename;
                    candidateobj.band4surname = (surname == "&nbsp;") ? "" : surname;
                    candidateobj.band4emailid = (emailid == "&nbsp;") ? "" : emailid;
                    candidateobj.band4mobile = (mobileno == "&nbsp;") ? "" : mobileno;
                    
                    candidateobj.DOB = (dob == "&nbsp;") ? "" : dob;
                    candidateobj.Category = (category == "&nbsp;") ? "" : category;
              
                    candidateobj.FatherName = (fathername == "&nbsp;") ? "" : fathername;
                    candidateobj.DateofJoining = (doj == "&nbsp;") ? "" : doj;






                    string password = CreateRandomPassword(8);
                    string username = User.Identity.Name.ToString();
                    candidateobj.user = Session["UserName"].ToString();

                    int dc = candidateobj.doublecheck(candidateobj);
                    int dtInsert = candidateobj.candidateband4info(candidateobj, password);
                    //if (dc != 0)
                    //{
                    //    Response.Write("<Script Language='javascript'> alert('OHRID-"+ohrid+" already Exists !')</Script>");

                    //}
                    //else
                    //{
                    //    int dtInsert = candidateobj.candidateband4info(candidateobj, password);
                    //}

                }

            }
            Response.Write("<script>alert('Data Uploaded');</script>");
        }
        else
        {
            Response.Write("<script>alert('Please Choose Records for Upload!');</script>");
        }

    }
    public void uploadFile()
    {
        FileUploadDownloadManager fm = new FileUploadDownloadManager();

        if (fileuploadExcel.HasFile == true)
        {
            string filename = fileuploadExcel.PostedFile.FileName;
            string file = System.IO.Path.GetFileName(filename);
            fileuploadExcel.PostedFile.SaveAs(Server.MapPath("~\\UplodedWiproExcel\\") + DateTime.Now.ToString().Replace("/", "-").Replace(" ", "").Replace(":", "-").Trim() + "-" + file);
            file = Server.MapPath("~\\UplodedWiproExcel\\") + DateTime.Now.ToString().Replace("/", "-").Replace(" ", "").Replace(":", "-").Trim() + "-" + file;

            string strConn;
            strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + file + ";Extended Properties='Excel 12.0 Xml;HDR=YES;Persist Security Info=False;'";



            string query = String.Format("select * from [Sheet1$]");
            OleDbDataAdapter myCmd = new OleDbDataAdapter(query, strConn);
            myCmd.Fill(ds);
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Bulkupload.aspx");
    }
    protected void format_Click(object sender, EventArgs e)
    {
        string filename = "Canidate.xlsx";




        if (filename != "")
        {

            string FolderPath = Server.MapPath("~\\Uploaded\\");
            string path = FolderPath + filename;

            System.IO.FileInfo file = new System.IO.FileInfo(path);

            if (file.Exists)
            {

                Response.Clear();

                Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);

                Response.AddHeader("Content-Length", file.Length.ToString());

                Response.ContentType = "application/octet-stream";

                Response.WriteFile(file.FullName);

                Response.End();

            }

            else


                Response.Write("");



        }
    }
    protected void Btnshow_Click(object sender, EventArgs e)
    {
        if (fileuploadExcel.HasFile == true)
        {
            uploadFile();
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
        }
        else
        {
            Response.Write("<script>alert('Please Choose a File!');</script>");
        }
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //e.Row.Cells[4].Visible = false;
    }
    protected void btnshowunuploaded_Click(object sender, EventArgs e)
    {
        //ds = gen.showunuploadeddata();
        //GridView1.DataSource = ds;
        //GridView1.DataBind();
    }
}

﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using CandidateInfonamespace;
using System.Data.SqlClient;
using DataAccess;
using System.Security.Principal;
using System.Collections.Generic;
using System.Text;
using System.IO;
using procall1;
using Casestatus;

public partial class BulkUpload : System.Web.UI.Page
{
    procall pc = new procall();
    DataSet ds = new DataSet();
    CandidateInfonamespace.CandidateDetails candidateobj = new CandidateInfonamespace.CandidateDetails();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());

    protected void Page_Load(object sender, EventArgs e)
    {
        //tdhome.Visible = false;
        string str = "";
        if (!Page.IsPostBack)
        {
            if (Session["UserType"] == null)
            {
                Response.Redirect("HRLogin.aspx");
            }
            else
            {
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");
            }

            str = Session["UserType"].ToString();
            if (str == "Hiring")
            {
                Response.Redirect("CandidateLogin.aspx");
            }
        }

        string username = Session["UserName"].ToString();
        if (username == "arun" && str == "ClientPlusReject")
        {
            fc.Visible = false;
          
        }
        else
        {
            fc.Visible = true;
            
        }
        if (username == "client" && str == "ClientPlusReject")
        {
            //td2.Visible = true;
            fc.Visible = true;
        }
        else
        {
            // td2.Visible = false;
            fc.Visible = true;
        }
        if (str == "Admin")
        {
            td1.Visible = false;
            //td2.Visible = true;
            rj.Visible = false;
            fc.Visible = false;
            rj.Visible = false;


        }
        if (str == "Hiring")
        {
            td1.Visible = false;
            //td2.Visible = false;
            rj.Visible = false;
            fc.Visible = false;
            rj.Visible = false;

        }
        if (str == "ClientPlusReject")
        {
            td1.Visible = true;
            //td2.Visible = false;
            rj.Visible = true;


        }

        if (!IsPostBack)
        {
            procall pc = new procall();
            DataSet ds = new DataSet();

            ds = pc.BulkUpload(username);
            grdFileUploadDownload.DataSource = ds;
            grdFileUploadDownload.DataBind();

            //lbltoda.Text = this.grdFileUploadDownload.Rows.Count.ToString();

            SqlDataAdapter adapter = new SqlDataAdapter("select count(id) as TotalCountedRows from BulkCases where convert(date,uploaddate,103)=convert(date,getdate(),103);", con);

            DataSet dss = new DataSet();
            adapter.Fill(dss);
            Object obj = new Object();
            obj = dss.Tables[0].Rows[0]["TotalCountedRows"];
            string str1 = Convert.ToString(obj);
            lbltoda.Text = str1;

            //string connString = @"your connection string here";
            //string query = "select * from table";

            //SqlConnection conn = new SqlConnection(connString);
            //SqlCommand cmd = new SqlCommand(query, conn);
            //conn.Open();

            //// create data adapter
            //SqlDataAdapter da = new SqlDataAdapter(cmd);
            //// this will query your database and return the result to your datatable
            //da.Fill(dataTable);
            //conn.Close();
            //da.Dispose();

            lbtotal.Text = this.grdFileUploadDownload.Rows.Count.ToString();


        }


    }
    protected void grdFileUploadDownload_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string filename = Convert.ToString(e.CommandArgument);
        if (filename != "")
        {

            string FolderPath = Server.MapPath("~\\BulkCases\\");
            string path = FolderPath + filename;

            System.IO.FileInfo file = new System.IO.FileInfo(path);

            if (file.Exists)
            {

                Response.Clear();

                Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);

                Response.AddHeader("Content-Length", file.Length.ToString());

                Response.ContentType = "application/octet-stream";

                Response.WriteFile(file.FullName);

                Response.End();

            }

            else

                //aq
                Response.Write("");
            //Response.Redirect("FileM.aspx");



        }

    }

    protected void btnexporttoexcel_Click(object sender, EventArgs e)
    {

        if (grdFileUploadDownload.Rows.Count > 0)
        {

            for (int i = 0; i < grdFileUploadDownload.Rows.Count; i++)
            {
                grdFileUploadDownload.HeaderRow.Cells[0].Visible = false;
                GridViewRow row = grdFileUploadDownload.Rows[i];
                row.Cells[0].Visible = false;
            }

            grdFileUploadDownload.HeaderStyle.BackColor = System.Drawing.Color.White;
            grdFileUploadDownload.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            grdFileUploadDownload.ForeColor = System.Drawing.Color.Black;
            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=Final-Report" + DateTime.Now.ToString("dd-MM-yyyy") + ".xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.xls";
            this.EnableViewState = false;
            System.IO.StringWriter stringWrite = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
            HtmlForm form1 = new HtmlForm();
            this.Controls.Add(form1);

            form1.Controls.Add(grdFileUploadDownload);
            form1.RenderControl(htmlWrite);

            Response.Write(stringWrite.ToString());
            Response.End();
        }
        else
        {
            Response.Write("<Script Language='javascript'> alert('No Rows!')</Script>");
        }
    }

    protected void btnupload_Click(object sender, EventArgs e)
    {
        uploadfiles.uploaddownloadfiles up = new uploadfiles.uploaddownloadfiles();
        try
        {
            HttpFileCollection hfc = Request.Files;
            for (int i = 0; i < hfc.Count; i++)
            {
                HttpPostedFile hpf = hfc[i];
                if (hpf.ContentLength > 0)
                {
                    try
                    {
                        //if (hpf.FileName == true)
                        //{
                        string filename = hpf.FileName;

                        //*********** sb.AppendLine we are Using for Create Log File *******
                        string file = System.IO.Path.GetFileName(filename);
                        string extension = Path.GetExtension(file);
                        // String NewFileName = "EmpID_" + empid + "_VerId_" + val + chk1 + i.ToString() + DateTime.Now.ToString().Replace("/", "-").Replace(" ", "").Replace(":", "-").Trim() + extension;
                        //fileuploadExcel.PostedFile.SaveAs(Server.MapPath("~\\UploadRevert\\") + NewFileName);
                        hpf.SaveAs(Server.MapPath("~\\BulkCases\\") + filename);
                        up.CandidateID = "";
                        up.FileName = filename.ToString();
                        if (ddlaccount.SelectedItem.Text != "Select")
                        {
                            up.ddlaccount = ddlaccount.SelectedItem.Text;

                        }
                        else
                        {
                            up.ddlaccount = "";
                        }
                        try
                        {
                            up.saveBulk(up);
                            up.saveBulkk(up);
                        }
                        catch (Exception ex)
                        {
                            Response.Write("<script>alert('" + ex.Message + "');</script>");
                        }
                       lblmsg.Text = "File Uploaded Successfully";
                       
                    }

                        
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    ///hpf.SaveAs(Server.MapPath("~/uploads/") +System.IO.Path.GetFileName(hpf.FileName));                        
                }
            }
        }
        catch (Exception)
        {
            throw;
        }


  
   
   
        procall pc = new procall();
        DataSet ds = new DataSet();
        ds = pc.SendVendorMail("");
         string username = Session["UserName"].ToString();
         ds = pc.BulkUpload(username);
         grdFileUploadDownload.DataSource = ds;
         grdFileUploadDownload.DataBind();
    }
    protected void grdFileUploadDownload_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //e.Row.Cells[10].Visible = false;
    }
}

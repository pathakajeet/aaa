﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DataAccess;
using procall1;
using Casestatus;
using System.Drawing;
using IISERVZCLASS;
using System.Text;
using System.IO;


public partial class RejectedCases : System.Web.UI.Page
{
    procall pc = new procall();
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        string str = "";
        if (!Page.IsPostBack)
        {
            if (Session["UserType"] == null)
            {
                Response.Redirect("HRLogin.aspx");
            }
            else
            {
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");
            }
            str = Session["UserType"].ToString();

            if (str == "Hiring")
            {
                Response.Redirect("CandidateLogin.aspx");
            }
        }
        str = Session["UserType"].ToString();
        string username = Session["UserName"].ToString();
       

        if (!IsPostBack)
        {
            procall pc = new procall();
            DataSet ds = new DataSet();

            ds = pc.rejectedlist("", "", "", "", "");
            GridView1.DataSource = ds;
            GridView1.DataBind();
            lblcount.Text = "Total Count = " + GridView1.Rows.Count.ToString();
        }


    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string filename = Convert.ToString(e.CommandArgument);
        if (filename != "")
        {

            string FolderPath = Server.MapPath("~\\Report\\");
            string path = FolderPath + filename;

            System.IO.FileInfo file = new System.IO.FileInfo(path);

            if (file.Exists)
            {

                Response.Clear();
                Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);
                Response.AddHeader("Content-Length", file.Length.ToString());
                Response.ContentType = "application/octet-stream";
                Response.WriteFile(file.FullName);
                Response.End();

            }

            else

                //aq
                Response.Write("");
            //Response.Redirect("FileM.aspx");



        }

    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        //required to avoid the run time error "  
        //Control 'GridView1' of type 'Grid View' must be placed inside a form tag with runat=server."  
    } 
    protected void btnexporttoexcel_Click(object sender, EventArgs e)
    {

        Response.Clear();
        Response.Buffer = true;
        Response.ClearContent();
        Response.ClearHeaders();
        Response.Charset = "";
        string FileName = "ReportList" + DateTime.Now + ".xls";
        StringWriter strwritter = new StringWriter();
        HtmlTextWriter htmltextwrtter = new HtmlTextWriter(strwritter);
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.ContentType = "application/vnd.ms-excel";
        Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName);
        GridView1.GridLines = GridLines.Both;
        GridView1.HeaderStyle.Font.Bold = true;
        GridView1.RenderControl(htmltextwrtter);
        Response.Write(strwritter.ToString());
        Response.End();      
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
       // e.Row.Cells[8].Visible = false;
    }
   

    protected void btnupload_Click(object sender, EventArgs e)
    {
        uploadfiles.uploaddownloadfiles up = new uploadfiles.uploaddownloadfiles();
        if (FileUpload1.HasFile == true && txtrefid.Text != "")
        {
            string filename = FileUpload1.PostedFile.FileName;
            int i = -1;
            string[] filepathSplit = filename.Split('\\');
            foreach (string arrStr in filepathSplit)
            {
                i++;
            }
            string file = filepathSplit[i].ToString();
            //save the file to the server
            string fileRename = file;
            FileUpload1.PostedFile.SaveAs(Server.MapPath("~\\Report\\") + fileRename);
            //lblStatus.Text = "File Saved to: " + Server.MapPath("~\\Uploaded\\") +EmpID+Checkype+ file;
            string Filename = Server.MapPath("~\\Report\\") + fileRename;
            up.CandidateID = txtrefid.Text.ToString();
            up.FileName = fileRename.ToString();
            try
            {
                up.saverpt(up);
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            lblmsg.Text = "File Uploaded Successfully";



        }
        else
        {
            //Response.Write("ss");
            Response.Write("<script>alert('Please Choose a File and Enter Refid !');</script>");
        }
        procall pc = new procall();
        DataSet ds = new DataSet();

        ds = pc.rejectedlist("", "", "", "", "");
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    protected void grdFileUploadDownload_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //e.Row.Cells[10].Visible = false;
    }
   
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        string search_criteria = Searchh.SelectedItem.Text.ToString();
        string search_keyword = txtSearch.Text.ToString();

        string datefrom = txtFromDate.Text.ToString();
        string dateto = txtToDate.Text.ToString();

        string usertype = Session["UserType"].ToString();
        string username = Session["UserName"].ToString();

        ds = pc.rejectedlist(search_criteria, search_keyword, username, datefrom,dateto);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
   
}

﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;

using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


public partial class PopUp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
//            string updateParentScript = @"function updateParentWindow()
//                              {                                                                               
//                               document.getElementById('lblEdu').value=""; 
//                                var fName=ocument.getElementById('lblEdu').value;
//                              var arrayValues= new Array(fName);
//                               window.opener.updateValues(arrayValues);       
//                               window.close(); 
//                              }";
//            this.ClientScript.RegisterStartupScript(this.GetType(), "UpdateParentWindow", updateParentScript, true);
            Label1.Visible = false;
            Label1.Text = Request["fn"];

            if (Label1.Text == "Edu")
            {
                pnlEdu.Visible = true;
                pnladd.Visible = false;
                pnlCibil.Visible = false;
                pnlRef.Visible = false;
                pnlEmp.Visible = false;
            }

            if (Label1.Text == "Add")
            {
                pnlEdu.Visible = false;
                pnladd.Visible = true;
                pnlCibil.Visible = false;
                pnlRef.Visible = false;
                pnlEmp.Visible = false;
            }
            if (Label1.Text == "Emp")
            {
                pnlEdu.Visible = false;
                pnladd.Visible = false;
                pnlCibil.Visible = false;
                pnlRef.Visible = false;
                pnlEmp.Visible = true;
            }

            if (Label1.Text == "ID")
            {
                pnlEdu.Visible = false;
                pnladd.Visible = false;
                pnlCibil.Visible = false;
                pnlRef.Visible = false;
                pnlEmp.Visible = false;
            }
            if (Label1.Text == "Ref")
            {
                pnlEdu.Visible = false;
                pnladd.Visible = false;
                pnlCibil.Visible = false;
                pnlRef.Visible = true;
                pnlEmp.Visible = false;
            }
            if (Label1.Text == "Cibil")
            {
                pnlEdu.Visible = false;
                pnladd.Visible = false;
                pnlCibil.Visible = true;
                pnlRef.Visible = false;
                pnlEmp.Visible = false;
            }
        }

     
    }
}

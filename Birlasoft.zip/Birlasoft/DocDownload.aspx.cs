﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;

public partial class DocDownload : System.Web.UI.Page
{
    DataTable ds = new DataTable();
    DataSet ds1 = new DataSet();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {
        string dtt = " select att.attachmentId,bsinfo.applicationId,bsinfo.candidateId,bsinfo.firstName,att.filename,att.createddate from  tbl_BS_Attachment att inner join tbl_BS_Candidate_info bsinfo on bsinfo.candidateId=att.ownerid ";
        SqlDataAdapter gridadpt = new SqlDataAdapter(dtt, con);
        gridadpt.Fill(ds);
        grdFileUploadDownload.DataSource = ds;
        grdFileUploadDownload.DataBind();
    }
    private DataSet getDataset(string query)
    {
        DataSet tempDataSet = new DataSet();
        SqlDataAdapter dap = new SqlDataAdapter(query, con);
        dap.Fill(tempDataSet);
        return tempDataSet;
    }
    protected void grdFileUploadDownload_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Download")
        {
          //  int rowIndex = Convert.ToInt32(e.CommandArgument);
            GridViewRow row = grdFileUploadDownload.Rows[0];
            string Cid = row.Cells[0].Text;      
            string url1 = "";
            string str = string.Format(" select filecontent  from  tbl_BS_Attachment where attachmentId =" + Cid);
            ds1 = getDataset(str);
            url1 = ds1.Tables[0].Rows[0]["filecontent"].ToString();
            byte[] textAsBytes = Encoding.ASCII.GetBytes(url1);
            string b64 = Convert.ToBase64String(textAsBytes);
        }
    }
}
﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using CandidateInfonamespace;
using System.Data.SqlClient;
using DataAccess;
using System.Security.Principal;
using System.Collections.Generic;
using System.Text;
using System.IO;


public partial class CandidateForm : System.Web.UI.Page
{
    CandidateInfonamespace.CandidateDetails candidateobj = new CandidateInfonamespace.CandidateDetails();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
    DataSet ds = new DataSet();
    DataSet dss = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.DefaultButton = btnSave.ClientID;
        Page.Form.DefaultButton = btnSave.UniqueID;

        imageedu.Attributes.Add("onclick", "openPopUpEdu('PopUp.aspx')");
        imageEmp.Attributes.Add("onclick", "openPopUpEmp('PopUp.aspx')");
        image2.Attributes.Add("onclick", "openPopUpRef('PopUp.aspx')");
        imageadd.Attributes.Add("onclick", "openPopUpAdd('PopUp.aspx')");
        image3.Attributes.Add("onclick", "openPopUpCibil('PopUp.aspx')");
        imagefileupload.Attributes.Add("onclick", "openPopUpdocument('PopUp.aspx')");


        if (!Page.IsPostBack)
        {
            string username = Session["UserName"].ToString();
            grdFileUploadDownload.Visible = true;

            if (Request.QueryString["mode"] == "View" && Request.QueryString["bgcview"] != "fresh")
            {
                ddlcibil.Enabled = true;

            }
            
            ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");

            Page.Validate();
            edu1.Visible = true;
            edu2.Visible = true;
            ad1.Visible = true;
            ref1.Visible = true;


            string category = Request.QueryString["Category"];
            //string textboxValue = txtcandidatemobile.Text.ToString();
            //string category = "";
            //dss = getDataset("select Category from candidateband4info where mobileno='" + textboxValue + "'");
            //if (dss.Tables[0].Rows.Count > 0)
            //{
            //    category = Convert.ToString(dss.Tables[0].Rows[0]["Category"]);
            //}
            if (category == "Experienced")
            {
                dropFresherexp.SelectedItem.Text = "Experienced";
            }

            if (dropFresherexp.SelectedItem.Text == "Experienced")
            {
                Cmp1.Visible = true;
                Cmp2.Visible = true;
                Cmp3.Visible = true;
                Cmp4.Visible = false;
                Cmp5.Visible = false;
            }

            else
            {
                Cmp1.Visible = false;
                Cmp2.Visible = false;
                Cmp3.Visible = false;
                Cmp4.Visible = false;
                Cmp5.Visible = false;
            }

            txtcmpny1expinyear.ReadOnly = true;
            txtemp2experience.ReadOnly = true;
            txtemp3experienceinyear.ReadOnly = true;
            txtemp4experience.ReadOnly = true;
            txtemp5experience.ReadOnly = true;
            if (dropFresherexp.SelectedItem.Text == "Fresher")
            {
                drpnoofcompany.Enabled = false;
            }
            else
            {
                drpnoofcompany.Enabled = true;
            }
            emp1agencydetail.ReadOnly = true;
            emp2agencydetail.ReadOnly = true;

            emp3agencydetail.ReadOnly = true;
            emp4agencydetail.ReadOnly = true;
            emp5agencydetail.ReadOnly = true;
            radiobuttoncurrentemp.Enabled = false;

            txtcmp1Std.Text = "+91";
            txt_parmanetSTD.Text = "+91";
            txtlogstaySTd.Text = "+91";
            txtaddcurentSTD.Text = "+91";
            txtemp1supervisorlevel1STD.Text = "+91";
            txtemp1supervisorlevel2STD.Text = "+91";

            emp2referenceYN.CausesValidation = false;
            emp3referenceYN.CausesValidation = false;
            emp4referenceYN.CausesValidation = false;
            emp5referenceYN.CausesValidation = false;

            if (Session["MobileNo"] == null)
            {
                txtcandidatemobile.Text = "";
            }
            else
            {
                txtcandidatemobile.Text = Session["MobileNo"].ToString();
                txtFirstName.Text = Session["UserName"].ToString();
                txtcandidatemobile.Enabled = false;
                txtFirstName.Enabled = false;
            }
            if (Session["UserName"] == null)
            {
                txtFirstName.Text = "";
            }
            btnSave.Enabled = false;





            FillState();
            FillCandidateData();
            ShowFile();

            if (grdFileUploadDownload.Rows.Count > 0)
            {
                btnSave.Enabled = true;
            }

        }


    }

    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> GetCountries(string prefixText)
    {
        SqlConnection con = new SqlConnection("data source=192.168.1.8;initial catalog=Case-Enter; user id = sa; password = sql@45678");
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from University where UniversityName like @Name+'%'", con);
        cmd.Parameters.AddWithValue("@Name", prefixText);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        List<string> CountryNames = new List<string>();
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            CountryNames.Add(dt.Rows[i][1].ToString());
        }
        return CountryNames;
    }

    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> GetCountriess(string prefixText)
    {
        SqlConnection con = new SqlConnection("data source=192.168.1.4;initial catalog=BgcPortal; user id = sa; password = sql@1234");
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from countrylist where countryname like @Name+'%'", con);
        cmd.Parameters.AddWithValue("@Name", prefixText);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        List<string> CountryNames = new List<string>();
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            CountryNames.Add(dt.Rows[i][1].ToString());
        }
        return CountryNames;
    }

    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static string[] GetCountries(string prefix, int parentId)
    {
        SqlCommand cmd = new SqlCommand();
        string query = "select countryid,countryname from countrylist where countryname LIKE @Prefix + '%'";
        cmd.Parameters.AddWithValue("@Prefix", prefix);

        cmd.CommandText = query;
        return PopulateAutoComplete(cmd);
    }

    private static string[] PopulateAutoComplete(SqlCommand cmd)
    {
        List<string> autocompleteItems = new List<string>();
        using (SqlConnection conn = new SqlConnection())
        {
            //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
            cmd.Connection = conn;
            conn.Open();
            using (SqlDataReader sdr = cmd.ExecuteReader())
            {
                while (sdr.Read())
                {
                    autocompleteItems.Add(string.Format("{0}-{1}", sdr[1], sdr[0]));
                }
            }
            conn.Close();
        }
        return autocompleteItems.ToArray();
    }

    private DataSet getDataset(string query)
    {
        DataSet tempDataSet = new DataSet();
        SqlDataAdapter dap = new SqlDataAdapter(query, con);
        dap.Fill(tempDataSet);
        return tempDataSet;
    }


    protected void FillState()
    {
        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        txtAddressparmentstate.DataTextField = "StateName";
        txtAddressparmentstate.DataValueField = "StateId";
        txtAddressparmentstate.DataSource = ds;
        txtAddressparmentstate.DataBind();
        txtAddressparmentstate.Items.Insert(0, new ListItem("Select", "0"));


        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        txtaddlongstaystate.DataTextField = "StateName";
        txtaddlongstaystate.DataValueField = "StateId";
        txtaddlongstaystate.DataSource = ds;
        txtaddlongstaystate.DataBind();
        txtaddlongstaystate.Items.Insert(0, new ListItem("Select", "0"));


        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        txtaddcurrentstate.DataTextField = "StateName";
        txtaddcurrentstate.DataValueField = "StateId";
        txtaddcurrentstate.DataSource = ds;
        txtaddcurrentstate.DataBind();
        txtaddcurrentstate.Items.Insert(0, new ListItem("Select", "0"));

        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        DropDownList2.DataTextField = "StateName";
        DropDownList2.DataValueField = "StateId";
        DropDownList2.DataSource = ds;
        DropDownList2.DataBind();
        DropDownList2.Items.Insert(0, new ListItem("Select", "0"));

        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        DropDownList4.DataTextField = "StateName";
        DropDownList4.DataValueField = "StateId";
        DropDownList4.DataSource = ds;
        DropDownList4.DataBind();
        DropDownList4.Items.Insert(0, new ListItem("Select", "0"));

        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        DropDownList6.DataTextField = "StateName";
        DropDownList6.DataValueField = "StateId";
        DropDownList6.DataSource = ds;
        DropDownList6.DataBind();
        DropDownList6.Items.Insert(0, new ListItem("Select", "0"));


        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        drpadd4.DataTextField = "StateName";
        drpadd4.DataValueField = "StateId";
        drpadd4.DataSource = ds;
        drpadd4.DataBind();
        drpadd4.Items.Insert(0, new ListItem("Select", "0"));

        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        drp5add.DataTextField = "StateName";
        drp5add.DataValueField = "StateId";
        drp5add.DataSource = ds;
        drp5add.DataBind();
        drp5add.Items.Insert(0, new ListItem("Select", "0"));
        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        drpadd6.DataTextField = "StateName";
        drpadd6.DataValueField = "StateId";
        drpadd6.DataSource = ds;
        drpadd6.DataBind();
        drpadd6.Items.Insert(0, new ListItem("Select", "0"));
        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        drpadd7.DataTextField = "StateName";
        drpadd7.DataValueField = "StateId";
        drpadd7.DataSource = ds;
        drpadd7.DataBind();
        drpadd7.Items.Insert(0, new ListItem("Select", "0"));
        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        drpadd8.DataTextField = "StateName";
        drpadd8.DataValueField = "StateId";
        drpadd8.DataSource = ds;
        drpadd8.DataBind();
        drpadd8.Items.Insert(0, new ListItem("Select", "0"));

        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        drpcri4.DataTextField = "StateName";
        drpcri4.DataValueField = "StateId";
        drpcri4.DataSource = ds;
        drpcri4.DataBind();
        drpcri4.Items.Insert(0, new ListItem("Select", "0"));
        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        drpcri5.DataTextField = "StateName";
        drpcri5.DataValueField = "StateId";
        drpcri5.DataSource = ds;
        drpcri5.DataBind();
        drpcri5.Items.Insert(0, new ListItem("Select", "0"));
        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        drpcri6.DataTextField = "StateName";
        drpcri6.DataValueField = "StateId";
        drpcri6.DataSource = ds;
        drpcri6.DataBind();
        drpcri6.Items.Insert(0, new ListItem("Select", "0"));
        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        drpcri7.DataTextField = "StateName";
        drpcri7.DataValueField = "StateId";
        drpcri7.DataSource = ds;
        drpcri7.DataBind();
        drpcri7.Items.Insert(0, new ListItem("Select", "0"));


        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        drpcri8.DataTextField = "StateName";
        drpcri8.DataValueField = "StateId";
        drpcri8.DataSource = ds;
        drpcri8.DataBind();
        drpcri8.Items.Insert(0, new ListItem("Select", "0"));



        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        Dprcri1state.DataTextField = "StateName";
        Dprcri1state.DataValueField = "StateId";
        Dprcri1state.DataSource = ds;
        Dprcri1state.DataBind();
        Dprcri1state.Items.Insert(0, new ListItem("Select", "0"));



        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        Dprcristate2.DataTextField = "StateName";
        Dprcristate2.DataValueField = "StateId";
        Dprcristate2.DataSource = ds;
        Dprcristate2.DataBind();
        Dprcristate2.Items.Insert(0, new ListItem("Select", "0"));


        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        Dprcri3state.DataTextField = "StateName";
        Dprcri3state.DataValueField = "StateId";
        Dprcri3state.DataSource = ds;
        Dprcri3state.DataBind();
        Dprcri3state.Items.Insert(0, new ListItem("Select", "0"));



        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        Dprcri4state.DataTextField = "StateName";
        Dprcri4state.DataValueField = "StateId";
        Dprcri4state.DataSource = ds;
        Dprcri4state.DataBind();
        Dprcri4state.Items.Insert(0, new ListItem("Select", "0"));



        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        Dprcri5state.DataTextField = "StateName";
        Dprcri5state.DataValueField = "StateId";
        Dprcri5state.DataSource = ds;
        Dprcri5state.DataBind();
        Dprcri5state.Items.Insert(0, new ListItem("Select", "0"));


        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        Dprcri6state.DataTextField = "StateName";
        Dprcri6state.DataValueField = "StateId";
        Dprcri6state.DataSource = ds;
        Dprcri6state.DataBind();
        Dprcri6state.Items.Insert(0, new ListItem("Select", "0"));


        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        Dprcri7state.DataTextField = "StateName";
        Dprcri7state.DataValueField = "StateId";
        Dprcri7state.DataSource = ds;
        Dprcri7state.DataBind();
        Dprcri7state.Items.Insert(0, new ListItem("Select", "0"));


        ds = getDataset("select StateId,StateName from State where activestatus=1 order by statename asc");
        Dprcri8state.DataTextField = "StateName";
        Dprcri8state.DataValueField = "StateId";
        Dprcri8state.DataSource = ds;
        Dprcri8state.DataBind();
        Dprcri8state.Items.Insert(0, new ListItem("Select", "0"));
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {



        candidateobj.Courtcountry1 = Courtcountry1.Text.ToString();
        candidateobj.Courtcountry2 = Courtcountry2.Text.ToString();
        candidateobj.Courtcountry3 = Courtcountry3.Text.ToString();
        candidateobj.Courtcountry4 = Courtcountry4.Text.ToString();
        candidateobj.Courtcountry5 = Courtcountry5.Text.ToString();
        candidateobj.Courtcountry6 = Courtcountry6.Text.ToString();
        candidateobj.Courtcountry7 = Courtcountry7.Text.ToString();
        candidateobj.Courtcountry8 = Courtcountry8.Text.ToString();

        candidateobj.gender = txtGender.Text.ToString();

        candidateobj.Band = "";
        candidateobj.PlaceofJoing = "";
        candidateobj.COE = "";
        candidateobj.DateofJoining = "";
        candidateobj.FirstName = txtFirstName.Text.ToString();
        candidateobj.Mobile = txtcandidatemobile.Text.ToString();
        candidateobj.MiddleName = txtMiddleName.Text.ToString();
        candidateobj.Surname = txtLastName.Text.ToString();
        candidateobj.FatherName = txtfathername.Text.ToString();
        candidateobj.DOB = txtcandidateDOB.Text.ToString();
        candidateobj.Mobile = txtcandidatemobile.Text.ToString();
        candidateobj.maritalstatus = txtmaritalstatus.Text.ToString();

        //if (ddlaccount.SelectedItem.Text != "Select")
        //{
        //    candidateobj.ddlaccount = ddlaccount.SelectedItem.Text;

        //}
        //else
        //{
        //    candidateobj.ddlaccount = "";
        //}ddlaccount

        if (drpeducation.SelectedItem.Text != "--Select--")
        {
            candidateobj.EducationList = drpeducation.SelectedItem.Text;

        }
        else
        {
            candidateobj.EducationList = "";
        }
        candidateobj.Edu1_CollegeName = txt_Edu1_CollageName.Text.ToString();
        candidateobj.Edu1_UniversityName = txt_Edu1_UniversityName0.Text.ToString();
        candidateobj.Edu1_Address = txtEdu1Address.Text.ToString();
        candidateobj.Edu1_RollNo = txtedu1Rollno.Text.ToString();
        candidateobj.Edu1_YearOfPassing = txt_Edu1_YearOfPassing0.Text.ToString();
        candidateobj.Edu1_EducationalQualification = txt_Edu1_EducationalQualification.Text.ToString();

        candidateobj.Edu2_CollegeName = txt_Edu2_CollageName.Text.ToString();
        candidateobj.Edu2_UniversityName = txt_Edu2_UniversityName0.Text.ToString();
        candidateobj.Edu2_Address = txtEdu2Address.Text.ToString();
        candidateobj.Edu2_RollNo = txtedu2Rollno.Text.ToString();
        candidateobj.Edu2_YearOfPassing = txt_Edu2_YearOfPassing0.Text.ToString();
        candidateobj.Edu2_EducationalQualification = txt_Edu2_EducationalQualification.Text.ToString();

        candidateobj.Edu3_CollegeName = txt_Edu3_CollageName.Text.ToString();
        candidateobj.Edu3_UniversityName = txt_Edu3_UniversityName0.Text.ToString();
        candidateobj.Edu3_Address = txtEdu3Address.Text.ToString();
        candidateobj.Edu3_RollNo = txtedu3Rollno.Text.ToString();
        candidateobj.YearOfPassing3 = txt_Edu3_YearOfPassing0.Text.ToString();
        candidateobj.Edu3_EducationalQualification = txt_Edu3_EducationalQualification.Text.ToString();

        candidateobj.Edu4_CollegeName = txt_Edu4_CollageName.Text.ToString();
        candidateobj.Edu4_UniversityName = txt_Edu4_UniversityName0.Text.ToString();
        candidateobj.Edu4_Address = txtEdu4Address.Text.ToString();
        candidateobj.Edu4_RollNo = txtedu4Rollno.Text.ToString();
        candidateobj.YearOfPassing4 = txt_Edu4_YearOfPassing0.Text.ToString();
        candidateobj.Edu4_EducationalQualification = txt_Edu4_EducationalQualification.Text.ToString();

        candidateobj.Edu5_CollegeName = txt_Edu5_CollageName.Text.ToString();
        candidateobj.Edu5_UniversityName = txt_Edu5_UniversityName0.Text.ToString();
        candidateobj.Edu5_Address = txtEdu5Address.Text.ToString();
        candidateobj.Edu5_RollNo = txtedu5Rollno.Text.ToString();
        candidateobj.YearOfPassing5 = txt_Edu5_YearOfPassing0.Text.ToString();
        candidateobj.Edu5_EducationalQualification = txt_Edu5_EducationalQualification.Text.ToString();

        candidateobj.Edu6_CollegeName = txt_Edu6_CollageName.Text.ToString();
        candidateobj.Edu6_UniversityName = txt_Edu6_UniversityName0.Text.ToString();
        candidateobj.Edu6_Address = txtEdu6Address.Text.ToString();
        candidateobj.Edu6_RollNo = txtedu6Rollno.Text.ToString();
        candidateobj.YearOfPassing6 = txt_Edu6_YearOfPassing0.Text.ToString();
        candidateobj.Edu6_EducationalQualification = txt_Edu6_EducationalQualification.Text.ToString();

        candidateobj.Edu7_CollegeName = txt_Edu7_CollageName.Text.ToString();
        candidateobj.Edu7_UniversityName = txt_Edu7_UniversityName0.Text.ToString();
        candidateobj.Edu7_Address = txtEdu7Address.Text.ToString();
        candidateobj.Edu7_RollNo = txtedu7Rollno.Text.ToString();
        candidateobj.YearOfPassing7 = txt_Edu7_YearOfPassing0.Text.ToString();
        candidateobj.Edu7_EducationalQualification = txt_Edu7_EducationalQualification.Text.ToString();

        candidateobj.Edu8_CollegeName = txt_Edu8_CollageName.Text.ToString();
        candidateobj.Edu8_UniversityName = txt_Edu8_UniversityName0.Text.ToString();
        candidateobj.Edu8_Address = txtEdu8Address.Text.ToString();
        candidateobj.Edu8_RollNo = txtedu8Rollno.Text.ToString();
        candidateobj.YearOfPassing8 = txt_Edu8_YearOfPassing0.Text.ToString();
        candidateobj.Edu8_EducationalQualification = txt_Edu8_EducationalQualification.Text.ToString();


        if (dropaddress.SelectedItem.Text != "--Select--")
        {
            candidateobj.AddressCheck = dropaddress.SelectedItem.Text;

        }
        else
        {
            candidateobj.AddressCheck = "";

        }

        candidateobj.PermanentAddress = txtaddress1parmanent.Text.ToString();

        if (txtAddressparmentstate.SelectedItem.Text != "--Select--")
        {
            candidateobj.Per_State = txtAddressparmentstate.SelectedItem.Text.ToString();
        }



        candidateobj.Per_City = txtadd1parmanentcity.Text.ToString();
        candidateobj.Per_AddressPhoneNo = txt_parmanetSTD.Text.ToString() + "-" + txt_parmanent_PhoneNo.Text.ToString();
        candidateobj.Per_Landmark = txtadd1parmanentlandmark.Text.ToString();
        if (txtadd1livingsince.SelectedItem.Text != "--Select--")
        {
            candidateobj.Per_LivingSince = txtadd1livingsince.SelectedItem.Text.ToString();
        }
        candidateobj.Per_LivingSince = "";
        candidateobj.Per_PoliceStation = txtadd1policestation.Text.ToString();
        candidateobj.Per_PostOffice = txtadd1pincode.Text.ToString();

        candidateobj.add1logeststay = txtadd1logeststay.Text.ToString();

        if (txtaddlongstaystate.SelectedItem.Text != "--Select--")
        {
            candidateobj.add1logeststarystate = txtaddlongstaystate.SelectedItem.Text.ToString();
        }

        candidateobj.add1logeststarycity = txtaddlongeststaycity.Text.ToString();
        candidateobj.add1logeststaryphonenumber = txtlogstaySTd.Text.ToString() + "-" + txtlongstayNumber.Text.ToString();
        candidateobj.add1logeststarylandmark = txtlongstaylandmark.Text.ToString();
        if (txtlongstaylivingsince.SelectedItem.Text != "--Select--")
        {
            candidateobj.add1logeststaryLeavingsince = txtlongstaylivingsince.SelectedItem.Text.ToString();
        }

        candidateobj.add1logeststaryLeavingsince = "";
        candidateobj.add1logeststarypolicestation = txtlongstaypolicestation.Text.ToString();
        candidateobj.add1logeststarypincode = txtlongstaypincode.Text.ToString();

        candidateobj.CurrentAddress = txtaddcurrentaddres.Text.ToString();

        if (txtaddcurrentstate.SelectedItem.Text != "--Select--")
        {
            candidateobj.Curr_State = txtaddcurrentstate.SelectedItem.Text.ToString();
        }



        candidateobj.Curr_City = txtaddcurentcity.Text.ToString();
        candidateobj.Curr_PhoneNo = txtaddcurentSTD.Text.ToString() + "-" + txtaddcurrentnumber.Text.ToString();

        candidateobj.add3landmark = TextBox49.Text.ToString();
        if (DropDownList14.SelectedItem.Text != "--Select--")
        {
            candidateobj.Add3livingduration = DropDownList14.SelectedItem.Text.ToString();
        }
        candidateobj.add3police = TextBox50.Text.ToString();
        candidateobj.add3pincode = TextBox51.Text.ToString();





        /////////////////////////////////


        candidateobj.add4address = txtadd4.Text.ToString();

        if (drpadd4.SelectedItem.Text != "--Select--")
        {
            candidateobj.add4state = drpadd4.SelectedItem.Text.ToString();
        }

        candidateobj.add4city = txtadd4city.Text.ToString();
        candidateobj.add4contact = txtadd4con.Text.ToString() + "-" + txtadd4contact.Text.ToString();
        candidateobj.add4land = txtadd4land.Text.ToString();
        if (txtlongstaylivingsince.SelectedItem.Text != "--Select--")
        {
            candidateobj.add4duration = drpadd4duration.SelectedItem.Text.ToString();
        }


        candidateobj.add4police = txtadd4police.Text.ToString();
        candidateobj.add4pincode = txtaddpincode.Text.ToString();

        ////////////////////////////
        candidateobj.add5address = textadd5.Text.ToString();

        if (drp5add.SelectedItem.Text != "--Select--")
        {
            candidateobj.add5state = drp5add.SelectedItem.Text.ToString();
        }

        candidateobj.add5city = txtcity5.Text.ToString();
        candidateobj.add5contact = txtcon5.Text.ToString() + "-" + txtcontact5.Text.ToString();
        candidateobj.add5land = txtlandmark5.Text.ToString();
        if (drplivingduration5.SelectedItem.Text != "--Select--")
        {
            candidateobj.add5duration = drplivingduration5.SelectedItem.Text.ToString();
        }


        candidateobj.add5police = txtpolice5.Text.ToString();
        candidateobj.add5pincode = txtpincode5.Text.ToString();

        ////////////////////////////////
        candidateobj.add6address = txtadd6.Text.ToString();

        if (drpadd6.SelectedItem.Text != "--Select--")
        {
            candidateobj.add6state = drpadd6.SelectedItem.Text.ToString();
        }

        candidateobj.add6city = txtcity6.Text.ToString();
        candidateobj.add6contact = txtcon6.Text.ToString() + "-" + txtcontact6.Text.ToString();
        candidateobj.add6land = txtlandmark6.Text.ToString();
        if (drplivngduration6.SelectedItem.Text != "--Select--")
        {
            candidateobj.add6duration = drplivngduration6.SelectedItem.Text.ToString();
        }


        candidateobj.add6police = txtpolice6.Text.ToString();
        candidateobj.add6pincode = txtpincode6.Text.ToString();
        ////////////////////////////////////////////////
        candidateobj.add7address = txtadd7.Text.ToString();

        if (drpadd7.SelectedItem.Text != "--Select--")
        {
            candidateobj.add7state = drpadd7.SelectedItem.Text.ToString();
        }

        candidateobj.add7city = txtcity7.Text.ToString();
        candidateobj.add7contact = txtcon7.Text.ToString() + "-" + txtcontact7.Text.ToString();
        candidateobj.add7land = txtlandmark7.Text.ToString();
        if (drplivingduration7.SelectedItem.Text != "--Select--")
        {
            candidateobj.add7duration = drplivingduration7.SelectedItem.Text.ToString();
        }


        candidateobj.add7police = txtpolice7.Text.ToString();
        candidateobj.add7pincode = txtpincode7.Text.ToString();

        /////////////////////////////////////////////////////////////////

        candidateobj.add8address = txtadd8.Text.ToString();

        if (drpadd8.SelectedItem.Text != "--Select--")
        {
            candidateobj.add8state = drpadd8.SelectedItem.Text.ToString();
        }

        candidateobj.add8city = txtcity8.Text.ToString();
        candidateobj.add8contact = txtcon8.Text.ToString() + "-" + txtcontact8.Text.ToString();
        candidateobj.add8land = txtlandmark8.Text.ToString();
        if (drplivingduration8.SelectedItem.Text != "--Select--")
        {
            candidateobj.add8duration = drplivingduration8.SelectedItem.Text.ToString();
        }

        candidateobj.add8duration = "";
        candidateobj.add8police = txtpolice8.Text.ToString();
        candidateobj.add8pincode = txtpincode8.Text.ToString();

        ///////////////////////////////////////////////////////



        if (drpcrichk.SelectedItem.Text != "--Select--")
        {
            candidateobj.CriminalCheck = drpcrichk.SelectedItem.Text;

        }
        else
        {
            candidateobj.CriminalCheck = "";

        }
        candidateobj.PermanentAddress1 = TextCriPerAdd.Text.ToString();

        if (DropDownList2.SelectedItem.Text != "--Select--")
        {
            candidateobj.Per_State1 = DropDownList2.SelectedItem.Text.ToString();
        }



        candidateobj.Per_City1 = TextCriPercityAdd.Text.ToString();
        candidateobj.Per_AddressPhoneNo1 = TextBox4.Text.ToString() + "-" + TextBox4.Text.ToString();
        candidateobj.Per_Landmark1 = TextBox5.Text.ToString();

        if (DropDownList3.SelectedItem.Text != "--Select--")
        {
            candidateobj.Per_LivingSince1 = DropDownList3.SelectedItem.Text.ToString();
        }
        candidateobj.Per_LivingSince1 = "";
        candidateobj.add1logeststay1 = TextBox8.Text.ToString();
        candidateobj.Per_PoliceStation1 = TextBox6.Text.ToString();
        candidateobj.Per_PostOffice1 = TextBox7.Text.ToString();

        candidateobj.add1logeststarystate1 = DropDownList3.SelectedItem.Text.ToString();


        candidateobj.add1logeststarycity1 = TextBox9.Text.ToString();
        candidateobj.add1logeststaryphonenumber1 = TextBox11.Text.ToString() + "-" + TextBox10.Text.ToString();
        candidateobj.add1logeststarylandmark1 = TextBox12.Text.ToString();
        if (DropDownList5.SelectedItem.Text != "--Select--")
        {
            candidateobj.add1logeststaryLeavingsince1 = DropDownList5.SelectedItem.Text.ToString();
        }

        candidateobj.add1logeststaryLeavingsince1 = "";
        candidateobj.add1logeststarypolicestation1 = TextBox13.Text.ToString();
        candidateobj.add1logeststarypincode1 = TextBox14.Text.ToString();
        /////////////////////////////////////////////////////////////////////////////////////////
        candidateobj.CurrentAddress1 = TextBox15.Text.ToString();

        if (DropDownList6.SelectedItem.Text != "--Select--")
        {
            candidateobj.Curr_State1 = DropDownList6.SelectedItem.Text.ToString();
        }



        candidateobj.Curr_City1 = TextBox16.Text.ToString();
        candidateobj.Curr_PhoneNo1 = TextBox17.Text.ToString() + "-" + TextBox18.Text.ToString();

        if (drpcourtduration3.SelectedItem.Text != "--Select--")
        {
            candidateobj.court3duration = drpcourtduration3.SelectedItem.Text.ToString();
        }
        candidateobj.court3land = txtcourtland3.Text.ToString();
        candidateobj.court3police = txtcourtpolice3.Text.ToString();
        candidateobj.court3pin = txtcourtpin3.Text.ToString();

        /////////////////////////////////////////////////////////////////////////////////


        candidateobj.court4add = txtcourt4.Text.ToString();

        if (drpcri4.SelectedItem.Text != "--Select--")
        {
            candidateobj.court4state = drpcri4.SelectedItem.Text.ToString();
        }



        candidateobj.court4city = txtcourtcity4.Text.ToString();
        candidateobj.court4contact = txtcourtcon4.Text.ToString() + "-" + txtcourtcontact4.Text.ToString();

        if (drpcourtduration4.SelectedItem.Text != "--Select--")
        {
            candidateobj.court4duration = drpcourtduration4.SelectedItem.Text.ToString();
        }
        candidateobj.court4land = txtcourtland4.Text.ToString();
        candidateobj.court4police = txtcourtpolice4.Text.ToString();
        candidateobj.court4pin = txtcourtpin4.Text.ToString();



        candidateobj.court5add = txtcourt5.Text.ToString();

        if (drpcri5.SelectedItem.Text != "--Select--")
        {
            candidateobj.court5state = drpcri5.SelectedItem.Text.ToString();
        }



        candidateobj.court5city = txtcourtcity5.Text.ToString();
        candidateobj.court4contact = txtcourtcon5.Text.ToString() + "-" + txtcourtcontact5.Text.ToString();

        if (drpcourtduration5.SelectedItem.Text != "--Select--")
        {
            candidateobj.court5duration = drpcourtduration5.SelectedItem.Text.ToString();
        }
        candidateobj.court5land = txtcourt5land.Text.ToString();
        candidateobj.court5police = txtcourtpolice5.Text.ToString();
        candidateobj.court5pin = txtcourtpin5.Text.ToString();

        //////////////////////////////////////////////////////////////////////////


        candidateobj.court6add = txtcourt6.Text.ToString();

        if (drpcri6.SelectedItem.Text != "--Select--")
        {
            candidateobj.court6state = drpcri6.SelectedItem.Text.ToString();
        }



        candidateobj.court6city = txtcourtcity6.Text.ToString();
        candidateobj.court6contact = txtcourtcon6.Text.ToString() + "-" + txtcourtcontact5.Text.ToString();

        if (drpcourtduration6.SelectedItem.Text != "--Select--")
        {
            candidateobj.court6duration = drpcourtduration6.SelectedItem.Text.ToString();
        }
        candidateobj.court6land = txtcourtland6.Text.ToString();
        candidateobj.court6police = txtcourtpolice6.Text.ToString();
        candidateobj.court6pin = txtcourtpin6.Text.ToString();




        //////////////////////////////////////////////////////////////



        candidateobj.court7add = txtcourt7.Text.ToString();

        if (drpcri7.SelectedItem.Text != "--Select--")
        {
            candidateobj.court7state = drpcri7.SelectedItem.Text.ToString();
        }



        candidateobj.court7city = txtcourtcity7.Text.ToString();
        candidateobj.court7contact = txtcourtcon7.Text.ToString() + "-" + txtcourtcontact5.Text.ToString();

        if (drpcourtduration7.SelectedItem.Text != "--Select--")
        {
            candidateobj.court7duration = drpcourtduration7.SelectedItem.Text.ToString();
        }
        candidateobj.court7land = txtcourtland7.Text.ToString();
        candidateobj.court7police = txtcourtploice7.Text.ToString();
        candidateobj.court7pin = txtcourtpin7.Text.ToString();



        candidateobj.court8add = txtcourt8.Text.ToString();

        if (drpcri8.SelectedItem.Text != "--Select--")
        {
            candidateobj.court8state = drpcri8.SelectedItem.Text.ToString();
        }



        candidateobj.court8city = tctcourtcity8.Text.ToString();
        candidateobj.court8contact = txtcourtcon8.Text.ToString() + "-" + txtcourtcontact5.Text.ToString();

        if (drpcourtduration8.SelectedItem.Text != "--Select--")
        {
            candidateobj.court8duration = drpcourtduration8.SelectedItem.Text.ToString();
        }
        candidateobj.court8land = txtcourtland8.Text.ToString();
        candidateobj.court8police = txtcourtpolice8.Text.ToString();
        candidateobj.court8pin = txtcourtpin8.Text.ToString();




        if (dropFresherexp.SelectedItem.Text == "Fresher")
        {
            candidateobj.FresherOrExp = "";
        }
        else
        {
            candidateobj.FresherOrExp = dropFresherexp.SelectedItem.Text.ToString();
        }
        if (drpnoofcompany.SelectedItem.Text == "--Select--")
        {
            candidateobj.NoOfComp = "";
        }
        else
        {
            if (drpnoofcompany.SelectedItem.Text == "1")
            {
                candidateobj.NoOfComp = "Company1";

            }
            if (drpnoofcompany.SelectedItem.Text == "2")
            {
                candidateobj.NoOfComp = "Company2";

            }
            if (drpnoofcompany.SelectedItem.Text == "3")
            {
                candidateobj.NoOfComp = "Company3";

            }
            if (drpnoofcompany.SelectedItem.Text == "4")
            {
                candidateobj.NoOfComp = "Company4";

            }
            if (drpnoofcompany.SelectedItem.Text == "5")
            {
                candidateobj.NoOfComp = "Company5";

            }

            candidateobj.NoOfComp = drpnoofcompany.SelectedItem.Text.ToString();
        }
        candidateobj.EmpHis1_CompnayNameandLocation = txtcmpy1nameloction.Text.ToString();
        candidateobj.EmpHis1_LastPositionHeldnDepartmentName = txtcmp1lastpostin.Text.ToString();
        candidateobj.cmp1department = txtcmp1department.Text.ToString();
        candidateobj.EmpHis1_TelephoneNo = txtcmp1Std.Text.ToString() + "-" + txtcmp1number.Text.ToString();
        candidateobj.EmpHis1_Address = txtemp1officeaddress.Text.ToString();
        candidateobj.EmpHis1_EmployeeCode = txtemp1employecode.Text.ToString();
        candidateobj.ExperienceInYears1 = txtcmpny1expinyear.Text.ToString();
        candidateobj.EmpHis1_PeriodofEmployment = periodofemployment1.Text.ToString();
        candidateobj.EmpHis1_PeriodofEmploymentRemark = periodofemptilldate1.Text.ToString();
        candidateobj.EmpHis1RLvl1_NameDesignatinOfSupervisor = txtemp1namedesignationofsupervisorlevel1.Text.ToString();
        candidateobj.cmp1HRdesignation = txtcmp1hrdesignation.Text.ToString();
        candidateobj.EmpHis1RLvl1_TelepnoneNo = txtemp1supervisorlevel1STD.Text.ToString() + "-" + txtemp1supervisorlevel1number.Text.ToString();
        candidateobj.EmpHis1RLvl1_MobileNo = txtemp1supervisorlevel1moblie.Text.ToString();
        candidateobj.EmpHis1RLvl1_EmailId = txtemp1supervisorlevel1email.Text.ToString();
        candidateobj.EmpHis1RLvl2_NameDesignatinOfSupervisor = txtemp1namedesignationofsupervisorlevel2.Text.ToString();
        candidateobj.cmp1RMdesignation = txtcmp1supervisordesignation.Text.ToString();

        candidateobj.EmpHis1RLvl2_TelepnoneNo = txtemp1supervisorlevel2STD.Text.ToString() + "-" + txtemp1supervisorlevel2number.Text.ToString();
        candidateobj.EmpHis1RLvl2_MobileNo = txtemp1supervisorlevel2mobile.Text.ToString();
        candidateobj.EmpHis1RLvl2_EmailId = txtemp1supervisorlevel2email.Text.ToString();
        candidateobj.EmpHis1_TempPerma = RadioButtoncmp1emptype.SelectedValue.ToString();
        candidateobj.EmpHis1_AgencyDetails = emp1agencydetail.Text.ToString();
        candidateobj.EmpHis1_RemunerationOrSalary = emp1remunerationsalary.Text.ToString();
        candidateobj.EmpHis1_ReasonOfLeaving = emp1reasonofleaving.Text.ToString();
        candidateobj.EmpHis1_referenceYN = emp1referenceYN.SelectedValue.ToString();
        //candidateobj.EmpHis1_IncaseOfGap = emp1incaseofgap.Text.ToString();
        candidateobj.EmpHis1_NoticePeriodorNot = RadioButtonemp1noticeperiodYN.SelectedValue.ToString();


        candidateobj.EmpHis2_CompnayNameandLocation = txtemp2compnyname.Text.ToString();
        candidateobj.EmpHis2_LastPositionHeldnDepartmentName = txtemp2lastposition.Text.ToString();
        candidateobj.cmp2department = txtcmp2department.Text.ToString();
        candidateobj.EmpHis2_TelephoneNo = emp2cmpSTD.Text.ToString() + "-" + emp2cmpnumber.Text.ToString();
        candidateobj.EmpHis2_Address = txtemp2officeaddress.Text.ToString();
        candidateobj.EmpHis2_EmployeeCode = txtemp2employeecode.Text.ToString();
        candidateobj.ExperienceInYears2 = txtemp2experience.Text.ToString();
        candidateobj.EmpHis2_PeriodofEmployment = periodofemployment2.Text.ToString();
        candidateobj.EmpHis2_PeriodofEmploymentRemark = periodofemptilldate2.Text.ToString();
        candidateobj.EmpHis2RLvl1_NameDesignatinOfSupervisor = txtemp2namedesignationofsupervisorlevel1.Text.ToString();
        candidateobj.cmp2HRdesignation = txtcmp2hrdesignation.Text.ToString();

        candidateobj.EmpHis2RLvl1_TelepnoneNo = txtemp2supervisorlevel1STD.Text.ToString() + "-" + txtemp2supervisorlevel1number.Text.ToString();
        candidateobj.EmpHis2RLvl1_MobileNo = txtemp2supervisorlevel1moblie.Text.ToString();
        candidateobj.EmpHis2RLvl1_EmailId = txtemp2supervisorlevel1email.Text.ToString();
        candidateobj.EmpHis2RLvl2_NameDesignatinOfSupervisor = txtemp2namedesignationofsupervisorlevel2.Text.ToString();
        candidateobj.cmp2RMdesignation = txtcmp2supervisordesignation.Text.ToString();

        candidateobj.EmpHis2RLvl2_TelepnoneNo = txtemp2supervisorlevel2STD.Text.ToString() + "-" + txtemp2supervisorlevel2number.Text.ToString();
        candidateobj.EmpHis2RLvl2_MobileNo = txtemp2supervisorlevel2mobile.Text.ToString();
        candidateobj.EmpHis2RLvl2_EmailId = txtemp2supervisorlevel2email.Text.ToString();
        candidateobj.EmpHis2_TempPerma = RadioButtoncmp2emptype.SelectedValue.ToString();
        candidateobj.EmpHis2_AgencyDetails = emp2agencydetail.Text.ToString();
        candidateobj.EmpHis2_RemunerationOrSalary = emp2remunerationsalary.Text.ToString();
        candidateobj.EmpHis2_ReasonOfLeaving = emp2reasonofleaving.Text.ToString();
        candidateobj.EmpHis2_referenceYN = emp2referenceYN.Text.ToString();
        // candidateobj.EmpHis2_IncaseOfGap = emp2incaseofgap.Text.ToString();
        candidateobj.EmpHis2_NoticePeriodorNot = RadioButtonemp2noticeperiodYN.SelectedValue.ToString();


        candidateobj.EmpHis3_CompnayNameandLocation = txtemp3companyname.Text.ToString();
        candidateobj.EmpHis3_LastPositionHeldnDepartmentName = txtemp3lastposition.Text.ToString();
        candidateobj.cmp3department = cmp3department.Text.ToString();

        candidateobj.EmpHis3_TelephoneNo = emp3cmpSTD.Text.ToString() + "-" + emp3cmpnumber.Text.ToString();
        candidateobj.EmpHis3_Address = txtemp3officeaddress.Text.ToString();
        candidateobj.EmpHis3_EmployeeCode = txtemp3employeecode.Text.ToString();
        candidateobj.ExperienceInYears3 = txtemp3experienceinyear.Text.ToString();
        candidateobj.EmpHis3_PeriodofEmployment = periodofemployment3.Text.ToString();
        candidateobj.EmpHis3_PeriodofEmploymentRemark = periodofemptilldate3.Text.ToString();
        candidateobj.EmpHis3RLvl1_NameDesignatinOfSupervisor = txtemp3namedesignationofsupervisorlevel1.Text.ToString();
        candidateobj.cmp3HRdesignation = txtcmp3hrdesignation.Text.ToString();

        candidateobj.EmpHis3RLvl1_TelepnoneNo = txtemp3supervisorlevel1STD.Text.ToString() + "-" + txtemp3supervisorlevel1number.Text.ToString();
        candidateobj.EmpHis3RLvl1_MobileNo = txtemp3supervisorlevel1moblie.Text.ToString();
        candidateobj.EmpHis3RLvl1_EmailId = txtemp3supervisorlevel1email.Text.ToString();
        candidateobj.EmpHis3RLvl2_NameDesignatinOfSupervisor = txtemp3namedesignationofsupervisorlevel2.Text.ToString();
        candidateobj.cmp3RMdesignation = txtcmp3supervisordesignation.Text.ToString();

        candidateobj.EmpHis3RLvl2_TelepnoneNo = txtemp3supervisorlevel2STD.Text.ToString() + "-" + txtemp3supervisorlevel2number.Text.ToString();
        candidateobj.EmpHis3RLvl2_MobileNo = txtemp3supervisorlevel2mobile.Text.ToString();
        candidateobj.EmpHis3RLvl2_EmailId = txtemp3supervisorlevel2email.Text.ToString();
        candidateobj.EmpHis3_TempPerma = RadioButtoncmp3emptype.SelectedValue.ToString();
        candidateobj.EmpHis3_AgencyDetails = emp3agencydetail.Text.ToString();
        candidateobj.EmpHis3_RemunerationOrSalary = emp3remunerationsalary.Text.ToString();
        candidateobj.EmpHis3_ReasonOfLeaving = emp3reasonofleaving.Text.ToString();
        candidateobj.EmpHis3_referenceYN = emp3referenceYN.Text.ToString();
        //candidateobj.EmpHis3_IncaseOfGap = emp3incaseofgap.Text.ToString();
        candidateobj.EmpHis3_NoticePeriodorNot = RadioButtonemp3noticeperiodYN.SelectedValue.ToString();


        candidateobj.EmpHis4_CompnayNameandLocation = txtemp4companyname.Text.ToString();
        candidateobj.EmpHis4_LastPositionHeldnDepartmentName = txtemp4lastpostion.Text.ToString();
        candidateobj.cmp4department = txtcmp4department.Text.ToString();

        candidateobj.EmpHis4_TelephoneNo = emp4cmpSTD.Text.ToString() + "-" + emp4cmpnumber.Text.ToString();
        candidateobj.EmpHis4_Address = txtemp4officeaddress.Text.ToString();
        candidateobj.EmpHis4_EmployeeCode = txtemp4employeecode.Text.ToString();
        candidateobj.ExperienceInYears4 = txtemp4experience.Text.ToString();
        candidateobj.EmpHis4_PeriodofEmployment = periodofemployment4.Text.ToString();
        candidateobj.EmpHis4_PeriodofEmploymentRemark = periodofemptilldate4.Text.ToString();
        candidateobj.EmpHis4RLvl1_NameDesignatinOfSupervisor = txtemp4namedesignationofsupervisorlevel1.Text.ToString();
        candidateobj.cmp4HRdesignation = txtcmp4hrdesignation.Text.ToString();

        candidateobj.EmpHis4RLvl1_TelepnoneNo = txtemp4supervisorlevel1STD.Text.ToString() + "-" + txtemp3supervisorlevel1number.Text.ToString();
        candidateobj.EmpHis4RLvl1_MobileNo = txtemp4supervisorlevel1moblie.Text.ToString();
        candidateobj.EmpHis4RLvl1_EmailId = txtemp4supervisorlevel1email.Text.ToString();
        candidateobj.EmpHis4RLvl2_NameDesignatinOfSupervisor = txtemp4namedesignationofsupervisorlevel2.Text.ToString();
        candidateobj.cmp4RMdesignation = txtcmp4supervisordesignation.Text.ToString();

        candidateobj.EmpHis4RLvl2_TelepnoneNo = txtemp4supervisorlevel2STD.Text.ToString() + "-" + txtemp3supervisorlevel2number.Text.ToString();
        candidateobj.EmpHis4RLvl2_MobileNo = txtemp4supervisorlevel2mobile.Text.ToString();
        candidateobj.EmpHis4RLvl2_EmailId = txtemp4supervisorlevel2email.Text.ToString();
        candidateobj.EmpHis4_TempPerma = RadioButtoncmp4emptype.SelectedValue.ToString();
        candidateobj.EmpHis4_AgencyDetails = emp4agencydetail.Text.ToString();
        candidateobj.EmpHis4_RemunerationOrSalary = emp4remunerationsalary.Text.ToString();
        candidateobj.EmpHis4_ReasonOfLeaving = emp4reasonofleaving.Text.ToString();
        candidateobj.EmpHis4_referenceYN = emp4referenceYN.Text.ToString();
        //candidateobj.EmpHis4_IncaseOfGap = emp4incaseofgap.Text.ToString();
        candidateobj.EmpHis4_NoticePeriodorNot = RadioButtonemp4noticeperiodYN.SelectedValue.ToString();


        candidateobj.EmpHis5_CompnayNameandLocation = txtemp5companyname.Text.ToString();
        candidateobj.EmpHis5_LastPositionHeldnDepartmentName = txtemp5lastposition.Text.ToString();
        candidateobj.cmp5department = txtcmp5department.Text.ToString();

        candidateobj.EmpHis5_TelephoneNo = emp5cmpSTD.Text.ToString() + "-" + emp5cmpnumber.Text.ToString();
        candidateobj.EmpHis5_Address = txtemp5officeaddress.Text.ToString();
        candidateobj.EmpHis5_EmployeeCode = txtemp5employeecode.Text.ToString();
        candidateobj.ExperienceInYears5 = txtemp5experience.Text.ToString();
        candidateobj.EmpHis5_PeriodofEmployment = periodofemployment5.Text.ToString();
        candidateobj.EmpHis5_PeriodofEmploymentRemark = periodofemptilldate5.Text.ToString();
        candidateobj.EmpHis5RLvl1_NameDesignatinOfSupervisor = txtemp5namedesignationofsupervisorlevel1.Text.ToString();
        candidateobj.cmp5HRdesignation = txtcmp5hrdesignation.Text.ToString();

        candidateobj.EmpHis5RLvl1_TelepnoneNo = txtemp5supervisorlevel1STD.Text.ToString() + "-" + txtemp3supervisorlevel1number.Text.ToString();
        candidateobj.EmpHis5RLvl1_MobileNo = txtemp5supervisorlevel1moblie.Text.ToString();
        candidateobj.EmpHis5RLvl1_EmailId = txtemp5supervisorlevel1email.Text.ToString();
        candidateobj.EmpHis5RLvl2_NameDesignatinOfSupervisor = txtemp5namedesignationofsupervisorlevel2.Text.ToString();
        candidateobj.cmp5RMdesignation = txtcmp5supervisordesignation.Text.ToString();

        candidateobj.EmpHis5RLvl2_TelepnoneNo = txtemp5supervisorlevel2STD.Text.ToString() + "-" + txtemp5supervisorlevel2number.Text.ToString();
        candidateobj.EmpHis5RLvl2_MobileNo = txtemp5supervisorlevel2mobile.Text.ToString();
        candidateobj.EmpHis5RLvl2_EmailId = txtemp5supervisorlevel2email.Text.ToString();
        candidateobj.EmpHis5_TempPerma = RadioButtoncmp5emptype.SelectedValue.ToString();
        candidateobj.EmpHis5_AgencyDetails = emp5agencydetail.Text.ToString();
        candidateobj.EmpHis5_RemunerationOrSalary = emp5remunerationsalary.Text.ToString();
        candidateobj.EmpHis5_ReasonOfLeaving = emp5reasonofleaving.Text.ToString();
        candidateobj.EmpHis5_referenceYN = emp5referenceYN.Text.ToString();
        //candidateobj.EmpHis5_IncaseOfGap = emp5incaseofgap.Text.ToString();
        candidateobj.EmpHis5_NoticePeriodorNot = RadioButtonemp5noticeperiodYN.SelectedValue.ToString();

        candidateobj.CurrentEmployment = radiobuttoncurrentemp.SelectedValue.ToString();




        candidateobj.RejectedRemarks1 = "";
        candidateobj.RejectedRemarks2 = "";
        candidateobj.RejectedRemarks3 = "";
        candidateobj.RejectedRemarks4 = "";
        candidateobj.RejectedRemarks5 = "";

        candidateobj.comment1 = "";
        candidateobj.comment2 = "";
        candidateobj.comment3 = "";
        candidateobj.comment4 = "";
        candidateobj.comment5 = "";

        //candidateobj.candidatealternateno = txtcandidatealternateno.Text.ToString();


        candidateobj.candidatealternateno = "";


        candidateobj.docreq = "";




        candidateobj.educheck = "";



        candidateobj.empcheck = "";




        candidateobj.cibilcheck = "";






        candidateobj.criminalcheck = "";







        candidateobj.drpempdoc = "";





        candidateobj.drpedudoc = "";



        candidateobj.drpcibildoc = "";





        candidateobj.drpcriminaldoc = "";

        candidateobj.candidateremarks = txtcandidateremarks.Text.ToString();

        //candidateobj.CAmemeber = txtCAmember.Text.ToString();
        //---mohan
        if (ddlref.SelectedItem.Text != "--Select--")
        {
            candidateobj.RefList = ddlref.SelectedItem.Text;

        }
        else
        {
            candidateobj.RefList = "";
        }

        candidateobj.Ref1RefName = txtRef1RefName.Text;
        candidateobj.Ref1CompName = txtRef1CompanyName.Text;
        candidateobj.Ref1Designation = txtRef1Designation.Text;
        candidateobj.Ref1Email = txtRef1EmailId.Text;
        candidateobj.Ref1Contact = txtRef1Contact.Text;

        candidateobj.Ref2RefName = txtRef2RefName.Text;
        candidateobj.Ref2CompName = txtRef2CompanyName.Text;
        candidateobj.Ref2Designation = txtRef2Designation.Text;
        candidateobj.Ref2Email = txtRef2EmailId.Text;
        candidateobj.Ref2Contact = txtRef2Contact.Text;

        if (ddlcibil.SelectedItem.Text != "--Select--")
        {
            candidateobj.CIBILList = ddlcibil.SelectedItem.Text;

        }
        else
        {
            candidateobj.CIBILList = "";
        }
        candidateobj.CIBILContact = txtCIBILContact.Text;
        candidateobj.CIBILDOB = dtpCIBILDOB.Text;
        candidateobj.CIBILEmail = txtCIBILEmail.Text;
        candidateobj.CIBILFullName = txtCIBILFullName.Text;
        candidateobj.CIBILGender = ddlCIBILgender.Text;
        candidateobj.CIBILPanCard = txtCIBILPanCard.Text;
        candidateobj.CIBILpassportno = txtCIBILpasportno.Text;
        candidateobj.CIBILvoterID = txtCIBILvoterid.Text;
        candidateobj.CIBILDrivinglicense = txtCIBILlience.Text;

        candidateobj.Countrylist = countrylist2.Text.ToString();




        if (ddlcri.SelectedItem.Text != "--Select--")
        {
            candidateobj.ddlcri = ddlcri.SelectedItem.Text;

        }
        else
        {
            candidateobj.ddlcri = "";

        }


        candidateobj.cri1address = Txtcri1address.Text.ToString();
        candidateobj.cri1city = Txtcri1city.Text.ToString();
        candidateobj.Dprcri1state = Dprcri1state.Text.ToString();
        candidateobj.cri1contactno = Txtcri1contactno.Text.ToString();
        candidateobj.cri1landmark = Txtcri1landmark.Text.ToString();
        candidateobj.Dprcri1livingsince = Dprcri1livingsince.Text.ToString();
        candidateobj.cri1police = Txtcri1police.Text.ToString();
        candidateobj.cri1pincode = Txtcri1pincode.Text.ToString();
        candidateobj.countrycri1 = countrycri1.Text.ToString();


        candidateobj.cri2address = Txtcri2address.Text.ToString();
        candidateobj.cri2city = Txtcri2city.Text.ToString();
        candidateobj.Dprcristate2 = Dprcristate2.Text.ToString();
        candidateobj.cri2contacno = Txtcri2contacno.Text.ToString();
        candidateobj.cri2landmark = Txtcri2landmark.Text.ToString();
        candidateobj.Dprcri2livingsince = Dprcri2livingsince.Text.ToString();
        candidateobj.cri2police = Txtcri2police.Text.ToString();
        candidateobj.cri2pincode = Txtcri2pincode.Text.ToString();
        candidateobj.countrycri2 = countrycri2.Text.ToString();

        candidateobj.cri3address = Txtcri3address.Text.ToString();
        candidateobj.cri3city = Txtcri3city.Text.ToString();
        candidateobj.Dprcri3state = Dprcri3state.Text.ToString();
        candidateobj.cri3contactno = Txtcri3contactno.Text.ToString();
        candidateobj.cri3landmark = Txtcri3landmark.Text.ToString();
        candidateobj.Dprcri3livingsince = Dprcri3livingsince.Text.ToString();
        candidateobj.cri3police = Txtcri3police.Text.ToString();
        candidateobj.cri3pincode = Txtcri3pincode.Text.ToString();
        candidateobj.countrycri3 = countrycri3.Text.ToString();


        candidateobj.cri4address = Txtcri4address.Text.ToString();
        candidateobj.cri4city = Txtcri4city.Text.ToString();
        candidateobj.Dprcri4state = Dprcri4state.Text.ToString();
        candidateobj.cri4contactno = Txtcri4contactno.Text.ToString();
        candidateobj.cri4landmark = Txtcri4landmark.Text.ToString();
        candidateobj.Dprcri4livingsince = Dprcri4livingsince.Text.ToString();
        candidateobj.cri4police = Txtcri4police.Text.ToString();
        candidateobj.cri4pincode = Txtcri4pincode.Text.ToString();
        candidateobj.countrycri4 = countrycri4.Text.ToString();


        candidateobj.cri5address = Txtcri5address.Text.ToString();
        candidateobj.cri5city = Txtcri5city.Text.ToString();
        candidateobj.Dprcri5state = Dprcri5state.Text.ToString();
        candidateobj.cri5contactno = Txtcri5contactno.Text.ToString();
        candidateobj.cri5landmark = Txtcri5landmark.Text.ToString();
        candidateobj.Dprcri5livingsince = Dprcri5livingsince.Text.ToString();
        candidateobj.cri5police = Txtcri5police.Text.ToString();
        candidateobj.cri5pincode = Txtcri5pincode.Text.ToString();
        candidateobj.countrycri5 = countrycri5.Text.ToString();


        candidateobj.cri6address = Txtcri6address.Text.ToString();
        candidateobj.cri6city = Txtcri6city.Text.ToString();
        candidateobj.Dprcri6state = Dprcri6state.Text.ToString();
        candidateobj.cri6contactno = Txtcri6contactno.Text.ToString();
        candidateobj.cri6landmark = Txtcri6landmark.Text.ToString();
        candidateobj.Dprcri6livingsince = Dprcri6livingsince.Text.ToString();
        candidateobj.cri6police = Txtcri6police.Text.ToString();
        candidateobj.cri6pincode = Txtcri6pincode.Text.ToString();
        candidateobj.countrycri6 = countrycri6.Text.ToString();


        candidateobj.cri7address = Txtcri7address.Text.ToString();
        candidateobj.cri7city = Txtcri7city.Text.ToString();
        candidateobj.Dprcri7state = Dprcri7state.Text.ToString();
        candidateobj.cri7contactno = Txtcri7contactno.Text.ToString();
        candidateobj.cri7landmark = Txtcri7landmark.Text.ToString();
        candidateobj.Dprcri7livingsince = Dprcri7livingsince.Text.ToString();
        candidateobj.cri7police = Txtcri7police.Text.ToString();
        candidateobj.cri7pincode = Txtcri7pincode.Text.ToString();
        candidateobj.countrycri7 = countrycri7.Text.ToString();

        candidateobj.cri8address = Txtcri8address.Text.ToString();
        candidateobj.cri8city = Txtcri8city.Text.ToString();
        candidateobj.Dprcri8state = Dprcri8state.Text.ToString();
        candidateobj.cri8contactno = Txtcri8contactno.Text.ToString();
        candidateobj.cri8landmark = Txtcri8landmark.Text.ToString();
        candidateobj.Dprcri8livingsince = Dprcri8livingsince.Text.ToString();
        candidateobj.cri8police = Txtcri8police.Text.ToString();
        candidateobj.cri8pincode = Txtcri8pincode.Text.ToString();
        candidateobj.countrycri8 = countrycri8.Text.ToString();

        string username = User.Identity.Name.ToString();
        candidateobj.user = username.ToString();
        if (Request.QueryString["cid"] == "0" || Request.QueryString["cid"] == "")
        {

            candidateobj.Mode = "0";
        }
        else
        {
            candidateobj.Mode = Request.QueryString["mode"];
        }
        if ((candidateobj.Mode == "undefined") || (candidateobj.Mode == "") || string.IsNullOrEmpty(candidateobj.Mode))
        {
            candidateobj.Mode = "0";
        }

        string url;
        url = "saveinfo.aspx?type=" + candidateobj.Mode;

        candidateobj.CandidateID = Convert.ToInt32(Request.QueryString[""]);


        if (txtFirstName.Text != "")
        {


            int dtInsert = candidateobj.saveband4CandidateDetails(candidateobj);
            if (dtInsert == 0)
            {
                Response.Redirect(url);
            }
            else if (dtInsert == -2)
            {

                Response.Write("<Script Language='javascript'> alert('Already Data Saved !')</Script>");
            }
            else if (dtInsert == -1)
            {

                Response.Write("<Script Language='javascript'> alert('Error In Procedure...InsertEmployeeInfo!')</Script>");
            }
        }
    }
    protected void drpnoofcompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpnoofcompany.SelectedValue == "0")
        {
            Cmp1.Visible = false;
            Cmp2.Visible = false;
            Cmp3.Visible = false;
            Cmp4.Visible = false;
            Cmp5.Visible = false;

        }
        if (drpnoofcompany.SelectedValue == "1")
        {
            Cmp1.Visible = true;
            Cmp2.Visible = false;
            Cmp3.Visible = false;
            Cmp4.Visible = false;
            Cmp5.Visible = false;

            Page.Validate();
        }
        if (drpnoofcompany.SelectedValue == "2")
        {
            Cmp1.Visible = true;
            Cmp2.Visible = true;
            Cmp3.Visible = false;
            Cmp4.Visible = false;
            Cmp5.Visible = false;

            Page.Validate();
        }
        if (drpnoofcompany.SelectedValue == "3")
        {
            Cmp1.Visible = true;
            Cmp2.Visible = true;
            Cmp3.Visible = true;
            Cmp4.Visible = false;
            Cmp5.Visible = false;

            Page.Validate();
        }
        if (drpnoofcompany.SelectedValue == "4")
        {
            Cmp1.Visible = true;
            Cmp2.Visible = true;
            Cmp3.Visible = true;
            Cmp4.Visible = true;
            Cmp5.Visible = false;

            Page.Validate();
        }
        if (drpnoofcompany.SelectedValue == "5")
        {
            Cmp1.Visible = true;
            Cmp2.Visible = true;
            Cmp3.Visible = true;
            Cmp4.Visible = true;
            Cmp5.Visible = true;

            Page.Validate();

        }

    }
    protected void dropaddress_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (dropaddress.SelectedValue == "0")
        {
            ad1.Visible = false;
            ad22.Visible = false;
            ad33.Visible = false;
            Add4.Visible = false;
            Add5.Visible = false;
            Add6.Visible = false;
            Add7.Visible = false;
            Add8.Visible = false;
        }
        if (dropaddress.SelectedValue == "Address Check1")
        {
            ad1.Visible = true;
            ad22.Visible = false;
            ad33.Visible = false;
            Add4.Visible = false;
            Add5.Visible = false;
            Add6.Visible = false;
            Add7.Visible = false;
            Add8.Visible = false;
            Page.Validate();
        }

        if (dropaddress.SelectedValue == "Address Check2")
        {
            ad1.Visible = true;
            ad22.Visible = true;

            ad33.Visible = false;
            Add4.Visible = false;
            Add5.Visible = false;
            Add6.Visible = false;
            Add7.Visible = false;
            Add8.Visible = false;
            Page.Validate();
        }

        if (dropaddress.SelectedValue == "Address Check3")
        {
            ad1.Visible = true;
            ad22.Visible = true;
            ad33.Visible = true;

            Add4.Visible = false;
            Add5.Visible = false;
            Add6.Visible = false;
            Add7.Visible = false;
            Add8.Visible = false;
            Page.Validate();
        }

        if (dropaddress.SelectedValue == "Address Check4")
        {
            ad1.Visible = true;
            ad22.Visible = true;
            ad33.Visible = true;
            Add4.Visible = true;


            Add5.Visible = false;
            Add6.Visible = false;
            Add7.Visible = false;
            Add8.Visible = false;
            Page.Validate();
        }

        if (dropaddress.SelectedValue == "Address Check5")
        {
            ad1.Visible = true;
            ad22.Visible = true;
            ad33.Visible = true;
            Add4.Visible = true;
            Add5.Visible = true;


            Add6.Visible = false;
            Add7.Visible = false;
            Add8.Visible = false;
            Page.Validate();
        }

        if (dropaddress.SelectedValue == "Address Check6")
        {
            ad1.Visible = true;
            ad22.Visible = true;
            ad33.Visible = true;
            Add4.Visible = true;
            Add5.Visible = true;
            Add6.Visible = true;


            Add7.Visible = false;
            Add8.Visible = false;

            Page.Validate();
        }

        if (dropaddress.SelectedValue == "Address Check7")
        {
            ad1.Visible = true;
            ad22.Visible = true;
            ad33.Visible = true;
            Add4.Visible = true;
            Add5.Visible = true;
            Add6.Visible = true;
            Add7.Visible = true;

            Add8.Visible = false;
            Page.Validate();
        }

        if (dropaddress.SelectedValue == "Address Check8")
        {
            ad1.Visible = true;
            ad22.Visible = true;
            ad33.Visible = true;
            Add4.Visible = true;
            Add5.Visible = true;
            Add6.Visible = true;
            Add7.Visible = true;
            Add8.Visible = true;
            Page.Validate();
        }

    }

    protected void drpcrichk_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpcrichk.SelectedValue == "0")
        {
            ad2.Visible = false;
            crt2.Visible = false;
            crt3.Visible = false;
            cri4.Visible = false;
            cri5.Visible = false;
            cri6.Visible = false;
            cri7.Visible = false;
            cri8.Visible = false;
        }
        if (drpcrichk.SelectedValue == "Court Check1")
        {
            ad2.Visible = true;
            crt2.Visible = false;
            crt3.Visible = false;
            cri4.Visible = false;
            cri5.Visible = false;
            cri6.Visible = false;
            cri7.Visible = false;
            cri8.Visible = false;
            Page.Validate();
        }

        if (drpcrichk.SelectedValue == "Court Check2")
        {
            ad2.Visible = true;
            crt2.Visible = true;
            crt3.Visible = false;
            cri4.Visible = false;
            cri5.Visible = false;
            cri6.Visible = false;
            cri7.Visible = false;
            cri8.Visible = false;
            Page.Validate();
        }
        if (drpcrichk.SelectedValue == "Court Check3")
        {
            ad2.Visible = true;
            crt2.Visible = true;
            crt3.Visible = true;

            cri4.Visible = false;
            cri5.Visible = false;
            cri6.Visible = false;
            cri7.Visible = false;
            cri8.Visible = false;
            Page.Validate();
        }
        if (drpcrichk.SelectedValue == "Court Check4")
        {
            ad2.Visible = true;
            crt2.Visible = true;
            crt3.Visible = true;
            cri4.Visible = true;


            cri5.Visible = false;
            cri6.Visible = false;
            cri7.Visible = false;
            cri8.Visible = false;

            Page.Validate();
        }
        if (drpcrichk.SelectedValue == "Court Check5")
        {
            ad2.Visible = true;
            crt2.Visible = true;
            crt3.Visible = true;
            cri4.Visible = true;
            cri5.Visible = true;


            cri6.Visible = false;
            cri7.Visible = false;
            cri8.Visible = false;

            Page.Validate();
        }
        if (drpcrichk.SelectedValue == "Court Check6")
        {
            ad2.Visible = true;
            crt2.Visible = true;
            crt3.Visible = true;
            cri4.Visible = true;
            cri5.Visible = true;
            cri6.Visible = true;


            cri7.Visible = false;
            cri8.Visible = false;
            Page.Validate();
        }
        if (drpcrichk.SelectedValue == "Court Check7")
        {
            ad2.Visible = true;
            crt2.Visible = true;
            crt3.Visible = true;
            cri4.Visible = true;
            cri5.Visible = true;
            cri6.Visible = true;
            cri7.Visible = true;


            cri8.Visible = false;

            Page.Validate();
        }
        if (drpcrichk.SelectedValue == "Court Check8")
        {
            ad2.Visible = true;
            crt2.Visible = true;
            crt3.Visible = true;
            cri4.Visible = true;
            cri5.Visible = true;
            cri6.Visible = true;
            cri7.Visible = true;
            cri8.Visible = true;
            Page.Validate();
        }

    }

    protected void dropFresherexp_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (dropFresherexp.SelectedValue == "0")
        {
            Cmp1.Visible = false;
            drpnoofcompany.Enabled = false;
            radiobuttoncurrentemp.Enabled = false;
        }
        if (dropFresherexp.SelectedValue == "Fresher")
        {
            Cmp1.Visible = false;
            drpnoofcompany.Enabled = false;
            radiobuttoncurrentemp.Enabled = false;
        }
        if (dropFresherexp.SelectedValue == "Experienced")
        {
            Cmp1.Visible = true;
            drpnoofcompany.Enabled = true;
            radiobuttoncurrentemp.Enabled = true;
        }
    }
    protected void FillCandidateData()
    {


        btnSave.Visible = true;
        //btnSave.Enabled = true;





        RequiredFieldValidator4.EnableClientScript = false;

        string ChkMode = Request.QueryString["mode"];
        int Id = 0;
        //string ses = Session["RefID"].ToString();


        //&& Request.QueryString["bgcview"] != "vv"
        if (Request.QueryString["mode"] == "Update")
        {


            string s = Request.QueryString["cid"].ToString();
            if ((s == "undefined") || (s == "") || (s == "0"))
            {


            }
            else
            {

                Id = Convert.ToInt32(Request.QueryString["cid"]);
                txtFirstName.Enabled = false;
                txtcandidatemobile.Enabled = false;

            }
        }
        if (Request.QueryString["mode"] == "View")
        {
            string sss = Request.QueryString["cid"].ToString();

            //con.Open();
            //SqlDataAdapter adap = new SqlDataAdapter("select checktype from candidatedetails where  candidateid='" + sss + "'", con);
            //DataSet dS = new DataSet();
            //adap.Fill(dS);
            //con.Close();
            //if (dS.Tables[0].Rows.Count > 0)
            //{
            //    Session["checktype"] = dS.Tables[0].Rows[0]["checktype"].ToString();

            //}

            //string checktype = Session["checktype"].ToString();
            //if (checktype == "ALL Checks")
            //{
            //    doctd.Visible = true;
            //    tddrug.Visible = true;
            //    tdedu.Visible = true;
            //    tdemp.Visible = true;
            //    tdcibil.Visible = true;
            //    tdcri.Visible = true;
            //}

            //else if (checktype == "Criminal Check")
            //{
            //    doctd.Visible = true;
            //    tddrug.Visible = false;
            //    tdedu.Visible = false;
            //    tdemp.Visible = false;
            //    tdcibil.Visible = false;
            //    tdcri.Visible = true;

            //}

            //    else
            //    {
            //       doctd.Visible = false;
            //    }





            txtFirstName.Enabled = false;
            txtcandidatemobile.Enabled = false;

            //btnSave.Enabled = true;



            string s = Request.QueryString["cid"].ToString();
            if ((s == "undefined") || (s == ""))
            {
            }
            else
            {
                Id = Convert.ToInt32(Request.QueryString["cid"]);
            }

            if (Request.QueryString["bgcview"] != "vv")
            {

                txtFirstName.ReadOnly = false;
                txtcandidatemobile.ReadOnly = false;
            }
            if (Request.QueryString["bgcview"] == "vv")
            {

                grdFileUploadDownload.Visible = true;
                txt_Edu1_CollageName.Enabled = false;
                txt_Edu1_UniversityName0.Enabled = false;
                txtEdu1Address.Enabled = false;
                txtedu1Rollno.Enabled = false;
                txt_Edu1_YearOfPassing0.Enabled = false;
                txt_Edu1_EducationalQualification.Enabled = false;
                CheckBox1.Enabled = false;
                txtcmpy1nameloction.Enabled = false;
                txtcmp1lastpostin.Enabled = false;
                RadioButtonemp1noticeperiodYN.Enabled = false;
                txtcmp1Std.Enabled = false;
                txtcmp1hrdesignation.Enabled = false;
                txtemp1supervisorlevel1STD.Enabled = false;
                txtemp1supervisorlevel1number.Enabled = false;
                txtcmp1supervisordesignation.Enabled = false;
                txtemp1supervisorlevel2STD.Enabled = false;
                txtemp1supervisorlevel2number.Enabled = false;
                dropFresherexp.Enabled = false;
                txtcmp1number.Enabled = false;
                txtcmp1department.Enabled = false;
                txtemp1officeaddress.Enabled = false;
                txtemp1employecode.Enabled = false;
                txtcmpny1expinyear.Enabled = false;
                periodofemployment1.Enabled = false;
                periodofemptilldate1.Enabled = false;
                txtemp1namedesignationofsupervisorlevel1.Enabled = false;
                txtemp1supervisorlevel1moblie.Enabled = false;
                txtemp1supervisorlevel1email.Enabled = false;
                txtemp1namedesignationofsupervisorlevel2.Enabled = false;
                txtemp1supervisorlevel2mobile.Enabled = false;
                txtemp1supervisorlevel2email.Enabled = false;
                RadioButtoncmp1emptype.Enabled = false;
                emp1agencydetail.Enabled = false;
                emp1remunerationsalary.Enabled = false;
                emp1reasonofleaving.Enabled = false;
                emp1referenceYN.Enabled = false;

                txtRef1RefName.Enabled = false;
                txtRef1CompanyName.Enabled = false;
                txtRef1Designation.Enabled = false;
                txtRef1EmailId.Enabled = false;
                txtRef1Contact.Enabled = false;
                txtRef2RefName.Enabled = false;
                txtRef2CompanyName.Enabled = false;
                txtRef2Designation.Enabled = false;
                txtRef2EmailId.Enabled = false;
                txtRef2Contact.Enabled = false;
                ddlref.Enabled = false;
                ddlcibil.Enabled = false;
                txtCIBILFullName.Enabled = false;
                dtpCIBILDOB.Enabled = false;
                ddlCIBILgender.Enabled = false;
                txtCIBILEmail.Enabled = false;
                txtCIBILContact.Enabled = false;
                txtCIBILPanCard.Enabled = false;
                txtCIBILpasportno.Enabled = false;
                txtCIBILvoterid.Enabled = false;
                txtCIBILlience.Enabled = false;





            }

        }
        else
        {




        }


        DataSet dsEmployeeInfo = new DataSet();
        CandidateDetails objinfo = new CandidateDetails();
        dsEmployeeInfo = objinfo.SelectData(Id);
        if (dsEmployeeInfo.Tables[0].Rows.Count > 0)
        {


            if (grdFileUploadDownload.Rows.Count > 0)
            {
                btnSave.Enabled = true;
            }





            string coe = dsEmployeeInfo.Tables[0].Rows[0]["COE"].ToString();
            //if (drpPOJ.SelectedItem.Text != "--Select--")
            //{
            //    //CompareValidator2.EnableClientScript = false;
            //}






            txtcandidateremarks.Text = dsEmployeeInfo.Tables[0].Rows[0]["CandidateRemarks"].ToString();










            txtFirstName.Text = dsEmployeeInfo.Tables[0].Rows[0]["FirstName"].ToString();
            txtMiddleName.Text = dsEmployeeInfo.Tables[0].Rows[0]["MiddleName"].ToString();
            txtLastName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Surname"].ToString();
            txtfathername.Text = dsEmployeeInfo.Tables[0].Rows[0]["FatherName"].ToString();
            txtcandidateDOB.Text = dsEmployeeInfo.Tables[0].Rows[0]["DOB"].ToString();
            txtcandidatealternateno.Text = dsEmployeeInfo.Tables[0].Rows[0]["FatherName"].ToString();
            txtGender.Text = dsEmployeeInfo.Tables[0].Rows[0]["Gender"].ToString();
            txtmaritalstatus.Text = dsEmployeeInfo.Tables[0].Rows[0]["MaritalStatus"].ToString();



            txtcandidatemobile.Text = dsEmployeeInfo.Tables[0].Rows[0]["Mobile"].ToString();

            Courtcountry1.Text = dsEmployeeInfo.Tables[0].Rows[0]["Courtcountry1"].ToString();
            Courtcountry2.Text = dsEmployeeInfo.Tables[0].Rows[0]["Courtcountry2"].ToString();
            Courtcountry3.Text = dsEmployeeInfo.Tables[0].Rows[0]["Courtcountry3"].ToString();
            Courtcountry4.Text = dsEmployeeInfo.Tables[0].Rows[0]["Courtcountry4"].ToString();
            Courtcountry5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Courtcountry5"].ToString();
            Courtcountry6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Courtcountry6"].ToString();
            Courtcountry7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Courtcountry7"].ToString();
            Courtcountry8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Courtcountry8"].ToString();




            if (dsEmployeeInfo.Tables[0].Rows[0]["educationcheck"].ToString() != "")
            {
                drpeducation.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["educationcheck"].ToString();

            }
            else
            {
                drpeducation.SelectedItem.Text = "--Select--";
            }

            txt_Edu1_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu1_CollegeName"].ToString();
            txt_Edu1_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu1_UniversityName"].ToString();
            txtEdu1Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu1_Address"].ToString();
            txtedu1Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu1_RollNo"].ToString();
            txt_Edu1_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing"].ToString();
            txt_Edu1_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu1_EducationalQualification"].ToString();

            txt_Edu2_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu2_CollegeName"].ToString();
            txt_Edu2_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu2_UniversityName"].ToString();
            txtEdu2Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu2_Address"].ToString();
            txtedu2Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu2_RollNo"].ToString();
            txt_Edu2_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing2"].ToString();
            txt_Edu2_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu2_EducationalQualification"].ToString();

            txt_Edu3_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu3_CollegeName"].ToString();
            txt_Edu3_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu3_UniversityName"].ToString();
            txtEdu3Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu3_Address"].ToString();
            txtedu3Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu3_RollNo"].ToString();
            txt_Edu3_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing3"].ToString();
            txt_Edu3_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu3_EducationalQualification"].ToString();

            txt_Edu4_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu4_CollegeName"].ToString();
            txt_Edu4_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu4_UniversityName"].ToString();
            txtEdu4Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu4_Address"].ToString();
            txtedu4Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu4_RollNo"].ToString();
            txt_Edu4_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing4"].ToString();
            txt_Edu4_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu4_EducationalQualification"].ToString();

            txt_Edu5_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu5_CollegeName"].ToString();
            txt_Edu5_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu5_UniversityName"].ToString();
            txtEdu5Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu5_Address"].ToString();
            txtedu5Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu5_RollNo"].ToString();
            txt_Edu5_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing5"].ToString();
            txt_Edu5_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu5_EducationalQualification"].ToString();

            txt_Edu6_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu6_CollegeName"].ToString();
            txt_Edu6_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu6_UniversityName"].ToString();
            txtEdu6Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu6_Address"].ToString();
            txtedu6Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu6_RollNo"].ToString();
            txt_Edu6_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing6"].ToString();
            txt_Edu6_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu6_EducationalQualification"].ToString();

            txt_Edu7_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu7_CollegeName"].ToString();
            txt_Edu7_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu7_UniversityName"].ToString();
            txtEdu7Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu7_Address"].ToString();
            txtedu7Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu7_RollNo"].ToString();
            txt_Edu7_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing7"].ToString();
            txt_Edu7_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu7_EducationalQualification"].ToString();

            txt_Edu8_CollageName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu8_CollegeName"].ToString();
            txt_Edu8_UniversityName0.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu8_UniversityName"].ToString();
            txtEdu8Address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu8_Address"].ToString();
            txtedu8Rollno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu8_RollNo"].ToString();
            txt_Edu8_YearOfPassing0.Text = dsEmployeeInfo.Tables[0].Rows[0]["YearofPassing8"].ToString();
            txt_Edu8_EducationalQualification.Text = dsEmployeeInfo.Tables[0].Rows[0]["Edu8_EducationalQualification"].ToString();
            if (dsEmployeeInfo.Tables[0].Rows[0]["CriminalCheck"].ToString() != "")
            {
                drpcrichk.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["CriminalCheck"].ToString();
            }
            else
            {
                drpcrichk.SelectedItem.Text = "--Select--";


            }

            txtaddress1parmanent.Text = dsEmployeeInfo.Tables[0].Rows[0]["PermanentAddress"].ToString();

            txtAddressparmentstate.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_State"].ToString();

            txtadd1parmanentcity.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_City"].ToString();

            //txt_parmanetSTD.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_AddressPhoneNo"].ToString();

            txtadd1parmanentlandmark.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_Landmark"].ToString();

            if (dsEmployeeInfo.Tables[0].Rows[0]["Per_LivingSince"].ToString() != "")
            {
                txtadd1livingsince.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_LivingSince"].ToString();
            }
            else
            {
                txtadd1livingsince.SelectedItem.Text = "--Select--";

            }
            //txtadd1livingsince.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_LivingSince"].ToString();

            txtadd1policestation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_PoliceStation"].ToString();

            txtadd1pincode.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_PostOffice"].ToString();

            txtadd1logeststay.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_address"].ToString();


            if (txtadd1logeststay.Text == "Same as Permanent")
            {

                RadioButtonList222.SelectedValue = "Same";
                txtadd1logeststay.Text = "Same as Permanent";
                txtadd1logeststay.ReadOnly = true;
                txtaddlongstaystate.Enabled = false;
                txtaddlongeststaycity.ReadOnly = true;
                txtlongstaylandmark.ReadOnly = true;
                txtlongstaylivingsince.Enabled = false;
                txtlongstaypolicestation.ReadOnly = true;
                txtlongstaypincode.ReadOnly = true;
                txtlogstaySTd.ReadOnly = true;
                txtlongstayNumber.ReadOnly = true;


                RequiredFieldValidator28.EnableClientScript = false;
                RequiredFieldValidator27.EnableClientScript = false;
                // RequiredFieldValidator29.EnableClientScript = false;
                //RequiredFieldValidator32.EnableClientScript = false;
                RequiredFieldValidator33.EnableClientScript = false;
                //RequiredFieldValidator38.EnableClientScript = false;
                RegularExpressionValidator6.EnableClientScript = false;
                RequiredFieldValidator39.EnableClientScript = false;
            }

            txtaddlongstaystate.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_State"].ToString();

            txtaddlongeststaycity.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_City"].ToString();

            //txtlogstaySTd.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_PhoneNo"].ToString();

            txtlongstaylandmark.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_Landmark"].ToString();

            if (dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_LivingSince"].ToString() != "")
            {
                txtlongstaylivingsince.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_LivingSince"].ToString();
            }
            else
            {
                txtlongstaylivingsince.SelectedItem.Text = "--Select--";

            }

            // txtlongstaylivingsince.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_LivingSince"].ToString();

            txtlongstaypolicestation.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_PoliceStation"].ToString();

            txtlongstaypincode.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_Pincode"].ToString();

            txtaddcurrentaddres.Text = dsEmployeeInfo.Tables[0].Rows[0]["CurrentAddress"].ToString();


            if (txtaddcurrentaddres.Text == "Same as Permanent")
            {

                // RadioButtonList222.SelectedValue = "Same";
                txtaddcurentSTD.Text = "";
                txtaddcurrentnumber.Text = "";
                txtaddcurrentaddres.Text = "Same as Permanent";
                txtaddcurrentstate.SelectedItem.Text = "";
                txtaddcurentcity.Text = "";

                txtaddcurentSTD.ReadOnly = true;
                txtaddcurrentnumber.ReadOnly = true;
                txtaddcurrentaddres.ReadOnly = true;
                txtaddcurrentstate.Enabled = false;
                txtaddcurentcity.ReadOnly = true;


                RequiredFieldValidator43.EnableClientScript = false;
                RequiredFieldValidator45.EnableClientScript = false;
                RequiredFieldValidator44.EnableClientScript = false;
                //  RequiredFieldValidator46.EnableClientScript = false;

            }

            if (txtaddcurrentaddres.Text == "Same as Longest Stay")
            {

                // RadioButtonList222.SelectedValue = "Same";
                txtaddcurentSTD.Text = "";
                txtaddcurrentnumber.Text = "";
                txtaddcurrentaddres.Text = "Same as Longest Stay";
                txtaddcurrentstate.SelectedItem.Text = "";
                txtaddcurentcity.Text = "";

                txtaddcurentSTD.ReadOnly = true;
                txtaddcurrentnumber.ReadOnly = true;
                txtaddcurrentaddres.ReadOnly = true;
                txtaddcurrentstate.Enabled = false;
                txtaddcurentcity.ReadOnly = true;


                RequiredFieldValidator43.EnableClientScript = false;
                RequiredFieldValidator45.EnableClientScript = false;
                RequiredFieldValidator44.EnableClientScript = false;
                //  RequiredFieldValidator46.EnableClientScript = false;

            }

            txtaddcurrentstate.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Curr_State"].ToString();

            txtaddcurentcity.Text = dsEmployeeInfo.Tables[0].Rows[0]["Curr_City"].ToString();

            string currphone = dsEmployeeInfo.Tables[0].Rows[0]["Curr_PhoneNo"].ToString();

            string parmanetSTD = dsEmployeeInfo.Tables[0].Rows[0]["Per_AddressPhoneNo"].ToString();

            string longstaySTD = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_PhoneNo"].ToString();

            if (longstaySTD.Contains("-"))
            {
                string[] currindex = longstaySTD.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtlogstaySTd.Text = c1;
                txtlongstayNumber.Text = c2;


            }

            if (parmanetSTD.Contains("-"))
            {
                string[] currindex = parmanetSTD.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txt_parmanetSTD.Text = c1;
                txt_parmanent_PhoneNo.Text = c2;


            }




            if (currphone.Contains("-"))
            {
                string[] currindex = currphone.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtaddcurentSTD.Text = c1;
                txtaddcurrentnumber.Text = c2;


            }
            //criminal


            if (dsEmployeeInfo.Tables[0].Rows[0]["CriminalCheck"].ToString() != "")
            {
                drpcrichk.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["CriminalCheck"].ToString();
            }
            else
            {
                drpcrichk.SelectedItem.Text = "--Select--";


            }




            TextCriPerAdd.Text = dsEmployeeInfo.Tables[0].Rows[0]["PermanentAddress1"].ToString();

            DropDownList2.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_State1"].ToString();

            TextCriPercityAdd.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_City1"].ToString();

            TextBox4.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_AddressPhoneNo1"].ToString();

            TextBox5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_Landmark1"].ToString();

            if (dsEmployeeInfo.Tables[0].Rows[0]["Per_LivingSince1"].ToString() != "")
            {
                DropDownList3.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_LivingSince1"].ToString();
            }
            else
            {
                DropDownList3.SelectedItem.Text = "--Select--";

            }
            DropDownList3.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_LivingSince1"].ToString();

            TextBox6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_PoliceStation1"].ToString();

            TextBox7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Per_PostOffice1"].ToString();

            TextBox8.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_address1"].ToString();




            DropDownList4.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_State1"].ToString();

            TextBox9.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_City1"].ToString();

            TextBox11.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_PhoneNo1"].ToString();

            TextBox12.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_Landmark1"].ToString();

            if (dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_LivingSince1"].ToString() != "")
            {
                DropDownList4.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_LivingSince1"].ToString();
            }
            else
            {
                DropDownList4.SelectedItem.Text = "--Select--";

            }

            DropDownList4.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_LivingSince1"].ToString();

            TextBox13.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_PoliceStation1"].ToString();

            TextBox14.Text = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_Pincode1"].ToString();



            if (txtaddcurrentaddres.Text == "Same as Longest Stay")
            {

                // RadioButtonList222.SelectedValue = "Same";
                txtaddcurentSTD.Text = "";
                txtaddcurrentnumber.Text = "";
                txtaddcurrentaddres.Text = "Same as Longest Stay";
                txtaddcurrentstate.SelectedItem.Text = "";
                txtaddcurentcity.Text = "";

                txtaddcurentSTD.ReadOnly = true;
                txtaddcurrentnumber.ReadOnly = true;
                txtaddcurrentaddres.ReadOnly = true;
                txtaddcurrentstate.Enabled = false;
                txtaddcurentcity.ReadOnly = true;


                RequiredFieldValidator43.EnableClientScript = false;
                RequiredFieldValidator45.EnableClientScript = false;
                RequiredFieldValidator44.EnableClientScript = false;
                //  RequiredFieldValidator46.EnableClientScript = false;

            }

            DropDownList6.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Curr_State1"].ToString();
            TextBox15.Text = dsEmployeeInfo.Tables[0].Rows[0]["Currentaddress1"].ToString();

            TextBox16.Text = dsEmployeeInfo.Tables[0].Rows[0]["Curr_City1"].ToString();

            TextBox17.Text = dsEmployeeInfo.Tables[0].Rows[0]["Curr_PhoneNo1"].ToString();

            TextBox18.Text = dsEmployeeInfo.Tables[0].Rows[0]["Curr_PhoneNo1"].ToString();

            txtcourtland3.Text = dsEmployeeInfo.Tables[0].Rows[0]["Court3land"].ToString();

            drpcourtduration3.Text = dsEmployeeInfo.Tables[0].Rows[0]["Court3duration"].ToString();

            txtcourtpolice3.Text = dsEmployeeInfo.Tables[0].Rows[0]["Court3police"].ToString();

            txtcourtpin3.Text = dsEmployeeInfo.Tables[0].Rows[0]["Court3pin"].ToString();


            TextBox49.Text = dsEmployeeInfo.Tables[0].Rows[0]["Add3landmark"].ToString();

            DropDownList14.Text = dsEmployeeInfo.Tables[0].Rows[0]["Add3livingduration"].ToString();

            TextBox50.Text = dsEmployeeInfo.Tables[0].Rows[0]["add3police"].ToString();

            TextBox51.Text = dsEmployeeInfo.Tables[0].Rows[0]["add3pincode"].ToString();

            string longstaySTD1 = dsEmployeeInfo.Tables[0].Rows[0]["LogestStay_PhoneNo1"].ToString();


            if (longstaySTD.Contains("-"))
            {
                string[] currindex = longstaySTD.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtlogstaySTd.Text = c1;
                txtlongstayNumber.Text = c2;


            }

            if (parmanetSTD.Contains("-"))
            {
                string[] currindex = parmanetSTD.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txt_parmanetSTD.Text = c1;
                txt_parmanent_PhoneNo.Text = c2;


            }




            if (currphone.Contains("-"))
            {
                string[] currindex = currphone.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtaddcurentSTD.Text = c1;
                txtaddcurrentnumber.Text = c2;


            }




            //////////////////////////////////////////////Add4/////////////////////


            txtadd4.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address4Add"].ToString();

            txtadd4city.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address4City"].ToString();

            drpadd4.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address4State"].ToString();

            txtadd4con.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address4Contact"].ToString();

            txtadd4contact.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address4Contact"].ToString();

            txtadd4land.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address4Landmark"].ToString();

            drpadd4duration.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address4Duration"].ToString();

            txtadd4police.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address4Police"].ToString();

            txtaddpincode.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address4Pincode"].ToString();

            //////////////////////////////////////////////////////////////////////////


            //////////////////////////////////////////////Add5/////////////////////


            textadd5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address5Add"].ToString();

            txtcity5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address5City"].ToString();

            drp5add.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address5State"].ToString();

            txtcon5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address5Contact"].ToString();

            txtcontact5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address5Contact"].ToString();

            txtlandmark5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address5Landmark"].ToString();

            drplivingduration5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address5Duration"].ToString();

            txtpolice5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address5Police"].ToString();

            txtpincode5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address5Pincode"].ToString();

            //////////////////////////////////////////////////////////////////////////

            //////////////////////////////////////////////Add6/////////////////////


            txtadd6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address6Add"].ToString();

            txtcity6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address6City"].ToString();

            drpadd6.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address6State"].ToString();

            txtcon6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address6Contact"].ToString();

            txtcontact6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address6Contact"].ToString();

            txtlandmark6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address6Landmark"].ToString();

            drplivngduration6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address6Duration"].ToString();

            txtpolice6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address6Police"].ToString();

            txtpincode6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address6Pincode"].ToString();



            //////////////////////////////////////////////////////////////////////////


            //////////////////////////////////////////////Add7/////////////////////


            txtadd7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address7Add"].ToString();

            txtcity7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address7City"].ToString();

            drpadd7.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address7State"].ToString();

            txtcon7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address7Contact"].ToString();

            txtcontact7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address7Contact"].ToString();

            txtlandmark7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address7Landmark"].ToString();

            drplivingduration7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address7Duration"].ToString();

            txtpolice7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address7Police"].ToString();

            txtpincode7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address7Pincode"].ToString();

            //////////////////////////////////////////////////////////////////////////


            //////////////////////////////////////////////Add8/////////////////////


            txtadd8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address8Add"].ToString();

            txtcity8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address8City"].ToString();

            drpadd8.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address8State"].ToString();

            txtcon8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address8Contact"].ToString();

            txtcontact8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address8Contact"].ToString();

            txtlandmark8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address8Landmark"].ToString();

            drplivingduration8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address8Duration"].ToString();

            txtpolice8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address8Police"].ToString();

            txtpincode8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Address8Pincode"].ToString();

            //////////////////////////////////////////////////////////////////////////

            //////////////////////////////////////////////Cort4/////////////////////


            txtcourt4.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal4Add"].ToString();

            txtcourtcity4.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal4City"].ToString();

            drpcri4.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal4State"].ToString();

            txtcourtcon4.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal4Contact"].ToString();

            txtcourtcontact4.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal4Contact"].ToString();

            txtcourtland4.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal4Landmark"].ToString();

            drpcourtduration4.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal4Duration"].ToString();

            txtcourtpolice4.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal4Police"].ToString();

            txtcourtpin4.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal4Pincode"].ToString();

            //////////////////////////////////////////////////////////////////////////


            //////////////////////////////////////////////Cort5/////////////////////


            txtcourt5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal5Add"].ToString();

            txtcourtcity5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal5City"].ToString();

            drpcri5.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal5State"].ToString();

            txtcourtcon5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal5Contact"].ToString();

            txtcourtcontact5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal5Contact"].ToString();

            txtcourt5land.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal5Landmark"].ToString();

            drpcourtduration5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal5Duration"].ToString();

            txtcourtpolice5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal5Police"].ToString();

            txtcourtpin5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal5Pincode"].ToString();

            //////////////////////////////////////////////////////////////////////////

            //////////////////////////////////////////////Cort6/////////////////////


            txtcourt6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal6Add"].ToString();

            txtcourtcity6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal6City"].ToString();

            drpcri6.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal6State"].ToString();

            txtcourtcon6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal6Contact"].ToString();

            txtcourtcontact6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal6Contact"].ToString();

            txtcourtland6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal6Landmark"].ToString();

            drpcourtduration6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal6Duration"].ToString();

            txtcourtpolice6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal6Police"].ToString();

            txtcourtpin6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal6Pincode"].ToString();

            //////////////////////////////////////////////////////////////////////////


            //////////////////////////////////////////////Cort7/////////////////////


            txtcourt7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal7Add"].ToString();

            txtcourtcity7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal7City"].ToString();

            drpcri7.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal7State"].ToString();

            txtcourtcon7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal7Contact"].ToString();

            txtcourtcontact7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal7Contact"].ToString();

            txtcourtland7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal7Landmark"].ToString();

            drpcourtduration7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal7Duration"].ToString();

            txtcourtploice7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal7Police"].ToString();

            txtcourtpin7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal7Pincode"].ToString();

            //////////////////////////////////////////////////////////////////////////


            //////////////////////////////////////////////Cort8/////////////////////


            txtcourt8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal8Add"].ToString();

            tctcourtcity8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal8City"].ToString();

            drpcri8.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal8State"].ToString();

            txtcourtcon8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal8Contact"].ToString();

            txtcourtcontact8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal8Contact"].ToString();

            txtcourtland8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal8Landmark"].ToString();

            drpcourtduration8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal8Duration"].ToString();

            txtcourtpolice8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal8Police"].ToString();

            txtcourtpin8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Criminal7Pincode"].ToString();
            //ddlaccount.Text = dsEmployeeInfo.Tables[0].Rows[0]["CheckType"].ToString();




            //////////////////////////////////////////////////////////////////////////

            dropFresherexp.SelectedIndex = 0;
            if (dsEmployeeInfo.Tables[0].Rows[0]["Fresher_experience"].ToString() == "Experienced")
            {
                dropFresherexp.SelectedIndex = 1;
                Cmp1.Visible = true;
                drpnoofcompany.Enabled = true;
                radiobuttoncurrentemp.Enabled = true;
            }
            else
            {
                Cmp1.Visible = false;
                drpnoofcompany.Enabled = false;
                radiobuttoncurrentemp.Enabled = false;
            }

            if (dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString() != "")
            {

                if (dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString() == "Company1")
                {
                    drpnoofcompany.SelectedItem.Text = "1";

                }
                if (dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString() == "Company2")
                {
                    drpnoofcompany.SelectedItem.Text = "2";
                }
                if (dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString() == "Company3")
                {
                    drpnoofcompany.SelectedItem.Text = "3";
                }
                if (dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString() == "Company4")
                {
                    drpnoofcompany.SelectedItem.Text = "4";
                }
                if (dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString() == "Company5")
                {
                    drpnoofcompany.SelectedItem.Text = "5";
                }


                //drpnoofcompany.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString();
            }
            else
            {
                drpnoofcompany.SelectedItem.Text = "--Select--";
            }


            txtcmpy1nameloction.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_CompnayNameandLocation"].ToString();

            txtcmp1lastpostin.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_LastPositionHeldnDepartmentName"].ToString();

            string EmpHis1_TelephoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_TelephoneNo"].ToString();

            if (EmpHis1_TelephoneNo.Contains("-"))
            {
                string[] currindex = EmpHis1_TelephoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtcmp1Std.Text = c1;
                txtcmp1number.Text = c2;

                //txtaddcurrentnumber.Text = c2;

            }

            txtemp1officeaddress.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_Address"].ToString();



            txtemp1employecode.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_EmployeeCode"].ToString();
            txtcmpny1expinyear.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_Experienceinyear"].ToString();
            periodofemployment1.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_PeriodofEmployment"].ToString();
            periodofemptilldate1.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_PeriodofEmploymentTillDate"].ToString();
            txtemp1namedesignationofsupervisorlevel1.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl1_NameDesignatinOfSupervisor"].ToString();

            string EmpHis1RLvl1_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl1_TelepnoneNo"].ToString();
            if (EmpHis1RLvl1_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis1RLvl1_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp1supervisorlevel1STD.Text = c1;
                txtemp1supervisorlevel1number.Text = c2;

            }


            txtemp1supervisorlevel1moblie.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl1_MobileNo"].ToString();
            txtemp1supervisorlevel1email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl1_EmailId"].ToString();
            txtemp1namedesignationofsupervisorlevel2.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl2_NameDesignatinOfSupervisor"].ToString();
            string EmpHis1RLvl2_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl2_TelepnoneNo"].ToString();
            if (EmpHis1RLvl2_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis1RLvl2_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp1supervisorlevel2STD.Text = c1;
                txtemp1supervisorlevel2number.Text = c2;

            }



            txtemp1supervisorlevel2mobile.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl2_MobileNo"].ToString();
            txtemp1supervisorlevel2email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1RLvl2_EmailId"].ToString();
            RadioButtoncmp1emptype.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_TempPerma"].ToString();
            emp1agencydetail.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_AgencyDetails"].ToString();
            emp1remunerationsalary.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_RemunerationOrSalary"].ToString();
            emp1reasonofleaving.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_ReasonOfLeaving"].ToString();
            emp1referenceYN.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_referenceYN"].ToString();
            //emp1incaseofgap.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_IncaseOfGap"].ToString();
            RadioButtonemp1noticeperiodYN.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis1_NoticePeriodorNot"].ToString();

            //company 2
            txtemp2compnyname.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_CompnayNameandLocation"].ToString();

            txtemp2lastposition.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_LastPositionHeldnDepartmentName"].ToString();

            string EmpHis2_TelephoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_TelephoneNo"].ToString();

            if (EmpHis2_TelephoneNo.Contains("-"))
            {
                string[] currindex = EmpHis2_TelephoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                emp2cmpSTD.Text = c1;
                emp2cmpnumber.Text = c2;
            }




            txtemp2officeaddress.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_Address"].ToString();
            txtemp2employeecode.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_EmployeeCode"].ToString();
            txtemp2experience.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_Experienceinyear"].ToString();
            periodofemployment2.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_PeriodofEmployment"].ToString();
            periodofemptilldate2.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_PeriodofEmploymentTillDate"].ToString();
            txtemp2namedesignationofsupervisorlevel1.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl1_NameDesignatinOfSupervisor"].ToString();

            string EmpHis2RLvl1_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl1_TelepnoneNo"].ToString();
            if (EmpHis2RLvl1_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis2RLvl1_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp2supervisorlevel1STD.Text = c1;
                txtemp2supervisorlevel1number.Text = c2;
            }



            txtemp2supervisorlevel1moblie.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl1_MobileNo"].ToString();
            txtemp2supervisorlevel1email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl1_EmailId"].ToString();
            txtemp2namedesignationofsupervisorlevel2.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl2_NameDesignatinOfSupervisor"].ToString();
            string EmpHis2RLvl2_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl2_TelepnoneNo"].ToString();
            if (EmpHis2RLvl2_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis2RLvl2_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp2supervisorlevel2STD.Text = c1;
                txtemp2supervisorlevel2number.Text = c2;
            }


            txtemp2supervisorlevel2mobile.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl2_MobileNo"].ToString();
            txtemp2supervisorlevel2email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2RLvl2_EmailId"].ToString();
            RadioButtoncmp2emptype.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_TempPerma"].ToString();
            emp2agencydetail.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_AgencyDetails"].ToString();
            emp2remunerationsalary.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_RemunerationOrSalary"].ToString();
            emp2reasonofleaving.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_ReasonOfLeaving"].ToString();
            emp2referenceYN.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_referenceYN"].ToString();
            //emp2incaseofgap.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_IncaseOfGap"].ToString();
            RadioButtonemp2noticeperiodYN.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis2_NoticePeriodorNot"].ToString();

            //company 3

            txtemp3companyname.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_CompnayNameandLocation"].ToString();
            txtemp3lastposition.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_LastPositionHeldnDepartmentName"].ToString();
            string EmpHis3_TelephoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_TelephoneNo"].ToString();
            if (EmpHis3_TelephoneNo.Contains("-"))
            {
                string[] currindex = EmpHis3_TelephoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                emp3cmpSTD.Text = c1;
                emp3cmpnumber.Text = c2;
            }




            txtemp3officeaddress.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_Address"].ToString();
            txtemp3employeecode.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_EmployeeCode"].ToString();
            txtemp3experienceinyear.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_Experienceinyear"].ToString();
            periodofemployment3.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_PeriodofEmployment"].ToString();
            periodofemptilldate3.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_PeriodofEmploymentTillDate"].ToString();
            txtemp3namedesignationofsupervisorlevel1.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl1_NameDesignatinOfSupervisor"].ToString();

            string EmpHis3RLvl1_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl1_TelepnoneNo"].ToString();
            if (EmpHis3RLvl1_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis3RLvl1_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp3supervisorlevel1STD.Text = c1;
                txtemp3supervisorlevel1number.Text = c2;
            }



            txtemp3supervisorlevel1moblie.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl1_MobileNo"].ToString();
            txtemp3supervisorlevel1email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl1_EmailId"].ToString();
            txtemp3namedesignationofsupervisorlevel2.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl2_NameDesignatinOfSupervisor"].ToString();
            string EmpHis3RLvl2_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl2_TelepnoneNo"].ToString();
            if (EmpHis3RLvl2_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis3RLvl2_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp3supervisorlevel2STD.Text = c1;
                txtemp3supervisorlevel2number.Text = c2;
            }


            txtemp3supervisorlevel2mobile.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl2_MobileNo"].ToString();
            txtemp3supervisorlevel2email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3RLvl2_EmailId"].ToString();
            RadioButtoncmp3emptype.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_TempPerma"].ToString();
            emp3agencydetail.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_AgencyDetails"].ToString();
            emp3remunerationsalary.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_RemunerationOrSalary"].ToString();
            emp3reasonofleaving.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_ReasonOfLeaving"].ToString();
            emp3referenceYN.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_referenceYN"].ToString();
            //emp3incaseofgap.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_IncaseOfGap"].ToString();
            RadioButtonemp3noticeperiodYN.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis3_NoticePeriodorNot"].ToString();

            //company 4


            txtemp4companyname.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_CompnayNameandLocation"].ToString();
            txtemp4lastpostion.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_LastPositionHeldnDepartmentName"].ToString();

            string EmpHis4_TelephoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_TelephoneNo"].ToString();
            if (EmpHis4_TelephoneNo.Contains("-"))
            {
                string[] currindex = EmpHis4_TelephoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                emp4cmpSTD.Text = c1;
                emp4cmpnumber.Text = c2;
            }


            txtemp4officeaddress.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_Address"].ToString();
            txtemp4employeecode.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_EmployeeCode"].ToString();
            txtemp4experience.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_Experienceinyear"].ToString();
            periodofemployment4.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_PeriodofEmployment"].ToString();
            periodofemptilldate4.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_PeriodofEmploymentTillDate"].ToString();
            txtemp4namedesignationofsupervisorlevel1.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl1_NameDesignatinOfSupervisor"].ToString();

            string EmpHis4RLvl1_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl1_TelepnoneNo"].ToString();
            if (EmpHis4RLvl1_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis4RLvl1_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp4supervisorlevel1STD.Text = c1;
                txtemp4supervisorlevel1number.Text = c2;
            }



            txtemp4supervisorlevel1moblie.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl1_MobileNo"].ToString();
            txtemp4supervisorlevel1email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl1_EmailId"].ToString();
            txtemp4namedesignationofsupervisorlevel2.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl2_NameDesignatinOfSupervisor"].ToString();
            string EmpHis4RLvl2_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl2_TelepnoneNo"].ToString();
            if (EmpHis4RLvl2_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis4RLvl2_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp4supervisorlevel2STD.Text = c1;
                txtemp4supervisorlevel2number.Text = c2;
            }


            txtemp4supervisorlevel2mobile.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl2_MobileNo"].ToString();
            txtemp4supervisorlevel2email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4RLvl2_EmailId"].ToString();
            RadioButtoncmp4emptype.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_TempPerma"].ToString();
            emp4agencydetail.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_AgencyDetails"].ToString();
            emp4remunerationsalary.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_RemunerationOrSalary"].ToString();
            emp4reasonofleaving.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_ReasonOfLeaving"].ToString();
            emp4referenceYN.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_referenceYN"].ToString();
            // emp4incaseofgap.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_IncaseOfGap"].ToString();
            RadioButtonemp4noticeperiodYN.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis4_NoticePeriodorNot"].ToString();


            //company 5

            txtemp5companyname.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_CompnayNameandLocation"].ToString();
            txtemp5lastposition.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_LastPositionHeldnDepartmentName"].ToString();

            string EmpHis5_TelephoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_TelephoneNo"].ToString();
            if (EmpHis5_TelephoneNo.Contains("-"))
            {
                string[] currindex = EmpHis5_TelephoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                emp5cmpSTD.Text = c1;
                emp5cmpnumber.Text = c2;
            }


            txtemp5officeaddress.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_Address"].ToString();
            txtemp5employeecode.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_EmployeeCode"].ToString();
            txtemp5experience.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_Experienceinyear"].ToString();
            periodofemployment5.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_PeriodofEmployment"].ToString();
            periodofemptilldate5.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_PeriodofEmploymentTillDate"].ToString();
            txtemp5namedesignationofsupervisorlevel1.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl1_NameDesignatinOfSupervisor"].ToString();

            string EmpHis5RLvl1_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl1_TelepnoneNo"].ToString();
            if (EmpHis5RLvl1_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis5RLvl1_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp5supervisorlevel1STD.Text = c1;
                txtemp5supervisorlevel1number.Text = c2;
            }



            txtemp5supervisorlevel1moblie.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl1_MobileNo"].ToString();
            txtemp5supervisorlevel1email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl1_EmailId"].ToString();
            txtemp5namedesignationofsupervisorlevel2.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl2_NameDesignatinOfSupervisor"].ToString();
            string EmpHis5RLvl2_TelepnoneNo = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl2_TelepnoneNo"].ToString();
            if (EmpHis5RLvl2_TelepnoneNo.Contains("-"))
            {
                string[] currindex = EmpHis5RLvl2_TelepnoneNo.Split("-".ToCharArray());
                string c1 = currindex[0].ToString();
                string c2 = currindex[1].ToString();
                txtemp5supervisorlevel2STD.Text = c1;
                txtemp5supervisorlevel2number.Text = c2;
            }


            txtemp5supervisorlevel2mobile.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl2_MobileNo"].ToString();
            txtemp5supervisorlevel2email.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5RLvl2_EmailId"].ToString();
            RadioButtoncmp5emptype.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_TempPerma"].ToString();
            emp5agencydetail.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_AgencyDetails"].ToString();
            emp5remunerationsalary.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_RemunerationOrSalary"].ToString();
            emp5reasonofleaving.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_ReasonOfLeaving"].ToString();
            emp5referenceYN.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_referenceYN"].ToString();
            // emp5incaseofgap.Text = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_IncaseOfGap"].ToString();
            RadioButtonemp5noticeperiodYN.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["EmpHis5_NoticePeriodorNot"].ToString();
            radiobuttoncurrentemp.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["CurrentEmploymentStatus"].ToString();



            if (dsEmployeeInfo.Tables[0].Rows[0]["RefCheck"].ToString() != "")
            {
                ddlref.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["RefCheck"].ToString();

            }
            else
            {
                ddlref.SelectedItem.Text = "--Select--";
            }
            //if (dsEmployeeInfo.Tables[0].Rows[0]["CibilCheck"].ToString() != "")
            //{
            //    ddlcibil.SelectedValue = dsEmployeeInfo.Tables[0].Rows[0]["CibilCheck"].ToString();

            //}
            //else
            //{
            //    ddlcibil.SelectedItem.Text = "--Select--";
            //}
            txtRef1RefName.Text = dsEmployeeInfo.Tables[0].Rows[0]["RefCheck1AppName"].ToString();
            txtRef1CompanyName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref1Company"].ToString();
            txtRef1Designation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref1Desi"].ToString();
            txtRef1EmailId.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref1Email"].ToString();
            txtRef1Contact.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref1CN"].ToString();

            txtRef2RefName.Text = dsEmployeeInfo.Tables[0].Rows[0]["RefCheck2AppName"].ToString();
            txtRef2CompanyName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref2Company"].ToString();
            txtRef2Designation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref2Desi"].ToString();
            txtRef2EmailId.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref2Email"].ToString();
            txtRef2Contact.Text = dsEmployeeInfo.Tables[0].Rows[0]["Ref2CN"].ToString();

            txtCIBILContact.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cibilcontact"].ToString();
            dtpCIBILDOB.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cibildob"].ToString();
            txtCIBILEmail.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cibilmail"].ToString();
            txtCIBILFullName.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cibilname"].ToString();
            ddlCIBILgender.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cibilgender"].ToString();
            txtCIBILPanCard.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cibilpanno"].ToString();
            txtCIBILpasportno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cibilpassportno"].ToString();



            txtCIBILvoterid.Text = dsEmployeeInfo.Tables[0].Rows[0]["CibilvoterID"].ToString();
            txtCIBILlience.Text = dsEmployeeInfo.Tables[0].Rows[0]["CibilDrivinglicense"].ToString();

            //rejected remarks and commnets....



            txtcmp1department.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp1Department"].ToString();
            txtcmp2department.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp2Department"].ToString();
            cmp3department.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp3Department"].ToString();
            txtcmp4department.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp4Department"].ToString();
            txtcmp5department.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp5Department"].ToString();

            txtcmp1hrdesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp1HRdesignation"].ToString();
            txtcmp2hrdesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp2HRdesignation"].ToString();
            txtcmp3hrdesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp3HRdesignation"].ToString();
            txtcmp4hrdesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp4HRdesignation"].ToString();
            txtcmp5hrdesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp5HRdesignation"].ToString();

            txtcmp1supervisordesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp1RMdesignation"].ToString();
            txtcmp2supervisordesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp2RMdesignation"].ToString();
            txtcmp3supervisordesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp3RMdesignation"].ToString();
            txtcmp4supervisordesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp4RMdesignation"].ToString();
            txtcmp5supervisordesignation.Text = dsEmployeeInfo.Tables[0].Rows[0]["Emp5RMdesignation"].ToString();

            countrylist2.Text = dsEmployeeInfo.Tables[0].Rows[0]["CountryList"].ToString();


            //drpdruglist.SelectedIndex = drpdruglist.Items.IndexOf(drpdruglist.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["DrugList"].ToString()));
            //if (drpdruglist.SelectedItem.Text == "Drug")
            //{

            //    Drug.Visible = true;
            //}
            dropaddress.SelectedIndex = dropaddress.Items.IndexOf(dropaddress.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["addresschecks"].ToString()));
            if (dropaddress.SelectedItem.Text == "Address Check1")
            {

                ad1.Visible = true;


            }


            drpcrichk.SelectedIndex = drpcrichk.Items.IndexOf(drpcrichk.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["CriminalCheck"].ToString()));
            if (drpcrichk.SelectedItem.Text == "Court Check-1")
            {

                ad2.Visible = true;


            }
            if (drpcrichk.SelectedItem.Text == "Court Check-2")
            {

                ad2.Visible = true;
                crt2.Visible = true;


            }
            if (drpcrichk.SelectedItem.Text == "Court Check-3")
            {

                ad2.Visible = true;
                crt2.Visible = true;
                crt3.Visible = true;


            }


            drpeducation.SelectedIndex = drpeducation.Items.IndexOf(drpeducation.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["educationcheck"].ToString()));
            if (drpeducation.SelectedItem.Text == "Education 1")
            {

                edu1.Visible = true;
                edu2.Visible = false;
                edu3.Visible = false;
                edu4.Visible = false;
                edu5.Visible = false;
                edu6.Visible = false;
                edu7.Visible = false;
                edu8.Visible = false;

            }


            dropaddress.SelectedIndex = dropaddress.Items.IndexOf(dropaddress.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["addresschecks"].ToString()));
            if (dropaddress.SelectedItem.Text == "Address Check-1")
            {

                ad1.Visible = true;


            }
            if (drpeducation.SelectedItem.Text == "Education 2")
            {

                edu1.Visible = true;
                edu2.Visible = true;
                edu3.Visible = false;
                edu4.Visible = false;
                edu5.Visible = false;
                edu6.Visible = false;
                edu7.Visible = false;
                edu8.Visible = false;

            }
            if (drpeducation.SelectedItem.Text == "Education 3")
            {

                edu1.Visible = true;
                edu2.Visible = true;
                edu3.Visible = true;
                edu4.Visible = false;
                edu5.Visible = false;
                edu6.Visible = false;
                edu7.Visible = false;
                edu8.Visible = false;

            }
            if (drpeducation.SelectedItem.Text == "Education 4")
            {

                edu1.Visible = true;
                edu2.Visible = true;
                edu3.Visible = true;
                edu4.Visible = true;
                edu5.Visible = false;
                edu6.Visible = false;
                edu7.Visible = false;
                edu8.Visible = false;

            }
            if (drpeducation.SelectedItem.Text == "Education 5")
            {

                edu1.Visible = true;
                edu2.Visible = true;
                edu3.Visible = true;
                edu4.Visible = true;
                edu5.Visible = true;
                edu6.Visible = false;
                edu7.Visible = false;
                edu8.Visible = false;

            }
            if (drpeducation.SelectedItem.Text == "Education 6")
            {

                edu1.Visible = true;
                edu2.Visible = true;
                edu3.Visible = true;
                edu4.Visible = true;
                edu5.Visible = true;
                edu6.Visible = true;
                edu7.Visible = false;
                edu8.Visible = false;

            }
            if (drpeducation.SelectedItem.Text == "Education 7")
            {

                edu1.Visible = true;
                edu2.Visible = true;
                edu3.Visible = true;
                edu4.Visible = true;
                edu5.Visible = true;
                edu6.Visible = true;
                edu7.Visible = true;
                edu8.Visible = false;

            }
            if (drpeducation.SelectedItem.Text == "Education 8")
            {

                edu1.Visible = true;
                edu2.Visible = true;
                edu3.Visible = true;
                edu4.Visible = true;
                edu5.Visible = true;
                edu6.Visible = true;
                edu7.Visible = true;
                edu8.Visible = true;

            }
            dropaddress.SelectedIndex = dropaddress.Items.IndexOf(dropaddress.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["addresschecks"].ToString()));
            if (dropaddress.SelectedItem.Text == "Address Check")
            {
                ad1.Visible = true;
            }


            drpcrichk.SelectedIndex = drpcrichk.Items.IndexOf(drpcrichk.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["criminalcheck"].ToString()));
            if (drpcrichk.SelectedItem.Text == "Criminal Check")
            {
                ad2.Visible = true;
            }
            drpnoofcompany.SelectedIndex = drpnoofcompany.Items.IndexOf(drpnoofcompany.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["Noofcompany"].ToString()));

            if (drpnoofcompany.SelectedItem.Text == "1")
            {
                Cmp1.Visible = true;
                Cmp2.Visible = false;
                Cmp3.Visible = false;
                Cmp4.Visible = false;
                Cmp5.Visible = false;

            }
            if (drpnoofcompany.SelectedItem.Text == "2")
            {
                Cmp1.Visible = true;
                Cmp2.Visible = true;
                Cmp3.Visible = false;
                Cmp4.Visible = false;
                Cmp5.Visible = false;

            }
            if (drpnoofcompany.SelectedItem.Text == "3")
            {
                Cmp1.Visible = true;
                Cmp2.Visible = true;
                Cmp3.Visible = true;
                Cmp4.Visible = false;
                Cmp5.Visible = false;

            }
            if (drpnoofcompany.SelectedItem.Text == "4")
            {
                Cmp1.Visible = true;
                Cmp2.Visible = true;
                Cmp3.Visible = true;
                Cmp4.Visible = true;
                Cmp5.Visible = false;

            }
            if (drpnoofcompany.SelectedItem.Text == "5")
            {
                Cmp1.Visible = true;
                Cmp2.Visible = true;
                Cmp3.Visible = true;
                Cmp4.Visible = true;
                Cmp5.Visible = true;

            }
            ddlref.SelectedIndex = ddlref.Items.IndexOf(ddlref.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["RefCheck"].ToString()));
            if (ddlref.SelectedItem.Text == "Reference1")
            {

                ref1.Visible = true;
                ref2.Visible = false;


            }
            if (ddlref.SelectedItem.Text == "Reference2")
            {

                ref1.Visible = true;
                ref2.Visible = true;

            }
            //ddlcibil.SelectedIndex = ddlcibil.Items.IndexOf(ddlcibil.Items.FindByText(dsEmployeeInfo.Tables[0].Rows[0]["CibilCheck"].ToString()));
            //if (ddlcibil.SelectedItem.Text == "Cibil")
            //{
            //   cibil.Visible = true;
            //}



            if (dsEmployeeInfo.Tables[0].Rows[0]["cricheck"].ToString() != "")
            {
                ddlcri.SelectedItem.Text = dsEmployeeInfo.Tables[0].Rows[0]["cricheck"].ToString();
            }
            else
            {
                ddlcri.SelectedItem.Text = "--Select--";


            }


            Txtcri1address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri1Address"].ToString();
            Dprcri1state.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri1State"].ToString();
            Txtcri1city.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri1City"].ToString();
            Txtcri1contactno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri1Contact"].ToString();
            Txtcri1landmark.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri1Landmark"].ToString();
            Dprcri1livingsince.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri1Livingsince"].ToString();
            Txtcri1police.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri1police"].ToString();
            Txtcri1pincode.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri1Pincode"].ToString();
            countrycri1.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri1Country"].ToString();


            Txtcri2address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri2Address"].ToString();
            Dprcristate2.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri2State"].ToString();
            Txtcri2city.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri2City"].ToString();
            Txtcri2contacno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri2Contact"].ToString();
            Txtcri2landmark.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri2Landmark"].ToString();
            Dprcri2livingsince.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri2Livingsince"].ToString();
            Txtcri2police.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri2police"].ToString();
            Txtcri2pincode.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri2Pincode"].ToString();
            countrycri2.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri2Country"].ToString();



            Txtcri3address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri3Address"].ToString();
            Dprcri3state.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri3State"].ToString();
            Txtcri3city.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri3City"].ToString();
            Txtcri3contactno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri3Contact"].ToString();
            Txtcri3landmark.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri3Landmark"].ToString();
            Dprcri3livingsince.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri3Livingsince"].ToString();
            Txtcri3police.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri3police"].ToString();
            Txtcri3pincode.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri3Pincode"].ToString();
            countrycri3.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri3Country"].ToString();


            Txtcri4address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri4Address"].ToString();
            Dprcri4state.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri4State"].ToString();
            Txtcri4city.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri4City"].ToString();
            Txtcri4contactno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri4Contact"].ToString();
            Txtcri4landmark.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri4Landmark"].ToString();
            Dprcri4livingsince.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri4Livingsince"].ToString();
            Txtcri4police.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri4police"].ToString();
            Txtcri4pincode.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri4Pincode"].ToString();
            countrycri4.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri4Country"].ToString();


            Txtcri5address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri5Address"].ToString();
            Dprcri5state.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri5State"].ToString();
            Txtcri5city.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri5City"].ToString();
            Txtcri5contactno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri5Contact"].ToString();
            Txtcri5landmark.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri5Landmark"].ToString();
            Dprcri5livingsince.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri5Livingsince"].ToString();
            Txtcri5police.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri5police"].ToString();
            Txtcri5pincode.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri5Pincode"].ToString();
            countrycri5.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri5Country"].ToString();



            Txtcri6address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri6Address"].ToString();
            Dprcri6state.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri6State"].ToString();
            Txtcri6city.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri6City"].ToString();
            Txtcri6contactno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri6Contact"].ToString();
            Txtcri6landmark.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri6Landmark"].ToString();
            Dprcri6livingsince.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri6Livingsince"].ToString();
            Txtcri6police.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri6police"].ToString();
            Txtcri6pincode.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri6Pincode"].ToString();
            countrycri6.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri6Country"].ToString();


            Txtcri7address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri7Address"].ToString();
            Dprcri7state.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri7State"].ToString();
            Txtcri7city.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri7City"].ToString();
            Txtcri7contactno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri7Contact"].ToString();
            Txtcri7landmark.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri7Landmark"].ToString();
            Dprcri7livingsince.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri7Livingsince"].ToString();
            Txtcri7police.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri7police"].ToString();
            Txtcri7pincode.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri7Pincode"].ToString();
            countrycri7.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri7Country"].ToString();


            Txtcri8address.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri8Address"].ToString();
            Dprcri8state.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri8State"].ToString();
            Txtcri8city.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri8City"].ToString();
            Txtcri8contactno.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri8Contact"].ToString();
            Txtcri8landmark.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri8Landmark"].ToString();
            Dprcri8livingsince.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri8Livingsince"].ToString();
            Txtcri8police.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri8police"].ToString();
            Txtcri8pincode.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri8Pincode"].ToString();
            countrycri8.Text = dsEmployeeInfo.Tables[0].Rows[0]["Cri8Country"].ToString();




            if (ddlcri.SelectedItem.Text == "--Select--")
            {
                divcriminal.Visible = false;
                divcriminal2.Visible = false;
                divcriminal3.Visible = false;
                divcriminal4.Visible = false;
                divcriminal5.Visible = false;
                divcriminal6.Visible = false;
                divcriminal7.Visible = false;
                divcriminal8.Visible = false;
            }
            if (ddlcri.SelectedItem.Text == "CriminalCheck-1")
            {
                divcriminal.Visible = true;
                divcriminal2.Visible = false;
                divcriminal3.Visible = false;
                divcriminal4.Visible = false;
                divcriminal5.Visible = false;
                divcriminal6.Visible = false;
                divcriminal7.Visible = false;
                divcriminal8.Visible = false;

            }
            if (ddlcri.SelectedItem.Text == "CriminalCheck-2")
            {
                divcriminal.Visible = true;
                divcriminal2.Visible = true;
                divcriminal3.Visible = false;
                divcriminal4.Visible = false;
                divcriminal5.Visible = false;
                divcriminal6.Visible = false;
                divcriminal7.Visible = false;
                divcriminal8.Visible = false;

            }
            if (ddlcri.SelectedItem.Text == "CriminalCheck-3")
            {
                divcriminal.Visible = true;
                divcriminal2.Visible = true;
                divcriminal3.Visible = true;
                divcriminal4.Visible = false;
                divcriminal5.Visible = false;
                divcriminal6.Visible = false;
                divcriminal7.Visible = false;
                divcriminal8.Visible = false;


            }

            if (ddlcri.SelectedItem.Text == "CriminalCheck-4")
            {
                divcriminal.Visible = true;
                divcriminal2.Visible = true;
                divcriminal3.Visible = true;
                divcriminal4.Visible = true;
                divcriminal5.Visible = false;
                divcriminal6.Visible = false;
                divcriminal7.Visible = false;
                divcriminal8.Visible = false;

            }


            if (ddlcri.SelectedItem.Text == "CriminalCheck-5")
            {
                divcriminal.Visible = true;
                divcriminal2.Visible = true;
                divcriminal3.Visible = true;
                divcriminal4.Visible = true;
                divcriminal5.Visible = true;

                divcriminal6.Visible = false;
                divcriminal7.Visible = false;
                divcriminal8.Visible = false;


            }
            if (ddlcri.SelectedItem.Text == "CriminalCheck-6")
            {
                divcriminal.Visible = true;
                divcriminal2.Visible = true;
                divcriminal3.Visible = true;
                divcriminal4.Visible = true;
                divcriminal5.Visible = true;
                divcriminal6.Visible = true;

                divcriminal7.Visible = false;
                divcriminal8.Visible = false;


            }
            if (ddlcri.SelectedItem.Text == "CriminalCheck-7")
            {
                divcriminal.Visible = true;
                divcriminal2.Visible = true;
                divcriminal3.Visible = true;
                divcriminal4.Visible = true;
                divcriminal5.Visible = true;
                divcriminal6.Visible = true;
                divcriminal7.Visible = true;

                divcriminal8.Visible = false;


            }
            if (ddlcri.SelectedItem.Text == "CriminalCheck-8")
            {
                divcriminal.Visible = true;
                divcriminal2.Visible = true;
                divcriminal3.Visible = true;
                divcriminal4.Visible = true;
                divcriminal5.Visible = true;
                divcriminal6.Visible = true;
                divcriminal7.Visible = true;
                divcriminal8.Visible = true;

            }
        }
    }
    public void uploaddetail()
    {
        candidateobj.FirstName = txtFirstName.Text.ToString();
        candidateobj.MiddleName = "";
        candidateobj.Surname = "";
        candidateobj.FatherName = "";
        candidateobj.Mobile = txtcandidatemobile.Text.ToString();

        candidateobj.saveband4CandidateDetails(candidateobj);

    }
    public void uploadFile()
    {
        uploadfiles.uploaddownloadfiles up = new uploadfiles.uploaddownloadfiles();
        if (fileuploadedu.HasFile == true)
        {
            string filename = fileuploadedu.PostedFile.FileName;
            int i = -1;
            string[] filepathSplit = filename.Split('\\');
            foreach (string arrStr in filepathSplit)
            {
                i++;
            }
            string file = filepathSplit[i].ToString();
            string Checkype = "BGC form along with LOA";
            //save the file to the server
            string fileRename = file + System.DateTime.Now.ToString("ddMMyyyyhhmmss");
            fileuploadedu.PostedFile.SaveAs(Server.MapPath("~\\Uploaded\\") + fileRename);
            //lblStatus.Text = "File Saved to: " + Server.MapPath("~\\Uploaded\\") +EmpID+Checkype+ file;
            string Filename = Server.MapPath("~\\Uploaded\\") + fileRename;
            up.ActiveStatus = "1";
            up.BackgroundType = Checkype;
            up.CandidateID = "0";
            up.FileName = fileRename;
            up.UploadStatus = "1";
            up.FileSize = "NA";
            up.FirstName = txtFirstName.Text.ToString();
            up.MiddleName = "";
            up.Surname = "";
            up.FatherName = "";
            up.Mobile = txtcandidatemobile.Text.ToString();
            try
            {
                up.saveFile(up);
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
        else
        {
            //Response.Write("ss");
            Response.Write("<script>alert('Please Choose a File !');</script>");
        }

    }
    public void ShowFile()
    {
        CandidateInfonamespace.CandidateDetails candidateobj = new CandidateInfonamespace.CandidateDetails();
        DataSet ds = new DataSet();
        candidateobj.FirstName = txtFirstName.Text.ToString();
        candidateobj.MiddleName = "";
        candidateobj.Surname = "";
        candidateobj.FatherName = "";
        candidateobj.Mobile = txtcandidatemobile.Text.ToString();
        ds = candidateobj.showfile(candidateobj);
        grdFileUploadDownload.DataSource = ds;
        grdFileUploadDownload.DataBind();
    }

    protected void grdFileUploadDownload_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string filename = Convert.ToString(e.CommandArgument);
        if (filename != "")
        {
            string FolderPath = Server.MapPath("~\\Uploaded\\");
            string path = FolderPath + filename;
            System.IO.FileInfo file = new System.IO.FileInfo(path);
            if (file.Exists)
            {

                Response.Clear();
                Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);
                Response.AddHeader("Content-Length", file.Length.ToString());
                Response.ContentType = "application/octet-stream";
                Response.WriteFile(file.FullName);
                Response.End();
            }

            else

                //aq
                Response.Write("");
            //Response.Redirect("FileM.aspx");



        }

    }
    protected void logoutbtn_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Redirect("../Login.aspx");
    }
    protected void grdFileUploadDownload_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        CandidateInfonamespace.CandidateDetails candidateobj = new CandidateInfonamespace.CandidateDetails();
        DataSet ds = new DataSet();
        candidateobj.FirstName = txtFirstName.Text.ToString();
        candidateobj.MiddleName = "";
        candidateobj.Surname = "";
        candidateobj.FatherName = "";
        candidateobj.Mobile = txtcandidatemobile.Text.ToString();

        //int key = Convert.ToInt32(grdFileUploadDownload.DataKeys[e.RowIndex].Value);
        string key = grdFileUploadDownload.Rows[e.RowIndex].Cells[1].Text;
        candidateobj.key = key.ToString();

        candidateobj.deleteupload(candidateobj);
        ShowFile();
        if (int.Parse(grdFileUploadDownload.Rows.Count.ToString()) != 0)
        {
            btnSave.Enabled = true;
        }
        else
        {
            btnSave.Enabled = false;
        }

    }

    protected void grdFileUploadDownload_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (Request.QueryString["mode"] == "View")
        {
            e.Row.Cells[4].Visible = false;
        }
        else
        {
            e.Row.Cells[4].Visible = true;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Server.Transfer("BGCForm.aspx");
    }
    protected void RadioButtoncmp1emptype_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (RadioButtoncmp1emptype.SelectedValue == "Permanent")
        {
            emp1agencydetail.ReadOnly = true;
            emp1agencydetail.BackColor = System.Drawing.Color.LightCoral;
        }
        if (RadioButtoncmp1emptype.SelectedValue == "Temporary")
        {
            emp1agencydetail.ReadOnly = false;
            emp1agencydetail.BackColor = System.Drawing.Color.White;

        }

        if (RadioButtoncmp2emptype.SelectedValue == "Permanent")
        {
            emp2agencydetail.ReadOnly = true;
            emp2agencydetail.BackColor = System.Drawing.Color.LightCoral;

        }
        if (RadioButtoncmp2emptype.SelectedValue == "Temporary")
        {
            emp2agencydetail.ReadOnly = false;
            emp2agencydetail.BackColor = System.Drawing.Color.White;
        }

        if (RadioButtoncmp3emptype.SelectedValue == "Permanent")
        {
            emp3agencydetail.ReadOnly = true;
            emp3agencydetail.BackColor = System.Drawing.Color.LightCoral;
        }
        if (RadioButtoncmp3emptype.SelectedValue == "Temporary")
        {
            emp3agencydetail.ReadOnly = false;
            emp3agencydetail.BackColor = System.Drawing.Color.White;
        }

        if (RadioButtoncmp4emptype.SelectedValue == "Permanent")
        {
            emp4agencydetail.ReadOnly = true;
            emp4agencydetail.BackColor = System.Drawing.Color.LightCoral;
        }
        if (RadioButtoncmp4emptype.SelectedValue == "Temporary")
        {
            emp4agencydetail.ReadOnly = false;
            emp4agencydetail.BackColor = System.Drawing.Color.White;
        }

        if (RadioButtoncmp5emptype.SelectedValue == "Permanent")
        {
            emp5agencydetail.ReadOnly = true;
            emp5agencydetail.BackColor = System.Drawing.Color.LightCoral;
        }
        if (RadioButtoncmp5emptype.SelectedValue == "Temporary")
        {
            emp5agencydetail.ReadOnly = false;
            emp5agencydetail.BackColor = System.Drawing.Color.White;
        }
    }

    protected void drpeducation_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (drpeducation.SelectedValue == "0")
        {
            edu1.Visible = false;
            edu2.Visible = false;
            edu3.Visible = false;
            edu4.Visible = false;
            edu5.Visible = false;
            edu6.Visible = false;
            edu7.Visible = false;
            edu8.Visible = false;

        }
        if (drpeducation.SelectedValue == "Education 1")
        {
            edu1.Visible = true;
            edu2.Visible = false;
            edu3.Visible = false;
            edu4.Visible = false;
            edu5.Visible = false;
            edu6.Visible = false;
            edu7.Visible = false;
            edu8.Visible = false;


            Page.Validate();
        }
        if (drpeducation.SelectedValue == "Education 2")
        {
            edu1.Visible = true;
            edu2.Visible = true;
            edu3.Visible = false;
            edu4.Visible = false;
            edu5.Visible = false;
            edu6.Visible = false;
            edu7.Visible = false;
            edu8.Visible = false;


            Page.Validate();
        }
        if (drpeducation.SelectedValue == "Education 3")
        {
            edu1.Visible = true;
            edu2.Visible = true;
            edu3.Visible = true;
            edu4.Visible = false;
            edu5.Visible = false;
            edu6.Visible = false;
            edu7.Visible = false;
            edu8.Visible = false;


            Page.Validate();
        }
        if (drpeducation.SelectedValue == "Education 4")
        {
            edu1.Visible = true;
            edu2.Visible = true;
            edu3.Visible = true;
            edu4.Visible = true;
            edu5.Visible = false;
            edu6.Visible = false;
            edu7.Visible = false;
            edu8.Visible = false;


            Page.Validate();
        }
        if (drpeducation.SelectedValue == "Education 5")
        {
            edu1.Visible = true;
            edu2.Visible = true;
            edu3.Visible = true;
            edu4.Visible = true;
            edu5.Visible = true;
            edu6.Visible = false;
            edu7.Visible = false;
            edu8.Visible = false;


            Page.Validate();
        }
        if (drpeducation.SelectedValue == "Education 6")
        {
            edu1.Visible = true;
            edu2.Visible = true;
            edu3.Visible = true;
            edu4.Visible = true;
            edu5.Visible = true;
            edu6.Visible = true;
            edu7.Visible = false;
            edu8.Visible = false;


            Page.Validate();
        }
        if (drpeducation.SelectedValue == "Education 7")
        {
            edu1.Visible = true;
            edu2.Visible = true;
            edu3.Visible = true;
            edu4.Visible = true;
            edu5.Visible = true;
            edu6.Visible = true;
            edu7.Visible = true;
            edu8.Visible = false;


            Page.Validate();
        }
        if (drpeducation.SelectedValue == "Education 8")
        {
            edu1.Visible = true;
            edu2.Visible = true;
            edu3.Visible = true;
            edu4.Visible = true;
            edu5.Visible = true;
            edu6.Visible = true;
            edu7.Visible = true;
            edu8.Visible = true;


            Page.Validate();
        }

    }

    protected void RadioButtonList222_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (RadioButtonList222.SelectedValue == "Same as Permanent")
        {

            txtadd1logeststay.Text = "Same as Permanent";

            txtadd1logeststay.ReadOnly = true;
            txtaddlongstaystate.Enabled = false;
            txtaddlongeststaycity.ReadOnly = true;
            txtlongstaylandmark.ReadOnly = true;
            txtlongstaylivingsince.Enabled = false;
            txtlongstaypolicestation.ReadOnly = true;
            txtlongstaypincode.ReadOnly = true;
            txtlogstaySTd.ReadOnly = true;
            txtlongstayNumber.ReadOnly = true;


            RequiredFieldValidator28.EnableClientScript = false;
            RequiredFieldValidator27.EnableClientScript = false;
            // RequiredFieldValidator29.EnableClientScript = false;
            //RequiredFieldValidator32.EnableClientScript = false;
            RequiredFieldValidator33.EnableClientScript = false;
            //RequiredFieldValidator38.EnableClientScript = false;
            RegularExpressionValidator6.EnableClientScript = false;
            RequiredFieldValidator39.EnableClientScript = false;



        }
        if (RadioButtonList222.SelectedValue == "New")
        {
            txtadd1logeststay.Text = "";
            txtaddlongstaystate.SelectedItem.Text = "";
            txtaddlongeststaycity.Text = "";
            txtlongstaylandmark.Text = "";
            txtlongstaylivingsince.SelectedItem.Text = "";
            txtlongstaypolicestation.Text = "";
            txtlongstaypincode.Text = "";
            txtlogstaySTd.Text = "";
            txtlongstayNumber.Text = "";


            txtadd1logeststay.ReadOnly = false;
            txtaddlongstaystate.Enabled = true;
            txtaddlongeststaycity.ReadOnly = false;
            txtlongstaylandmark.ReadOnly = false;
            txtlongstaylivingsince.Enabled = true;
            txtlongstaypolicestation.ReadOnly = false;
            txtlongstaypincode.ReadOnly = false;
            txtlogstaySTd.ReadOnly = false;
            txtlongstayNumber.ReadOnly = false;

            RequiredFieldValidator28.EnableClientScript = true;
            RequiredFieldValidator27.EnableClientScript = true;
            //RequiredFieldValidator29.EnableClientScript = true;
            //RequiredFieldValidator32.EnableClientScript = true;
            RequiredFieldValidator33.EnableClientScript = true;
            //RequiredFieldValidator38.EnableClientScript = true;
            RegularExpressionValidator6.EnableClientScript = true;
            RequiredFieldValidator39.EnableClientScript = true;

        }

    }



    protected void Radiocurrentaddress_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Radiocurrentaddress.SelectedValue == "Same as Permanent")
        {

            txtaddcurentSTD.Text = "";
            txtaddcurrentnumber.Text = "";
            txtaddcurrentaddres.Text = "Same as Permanent";
            txtaddcurrentstate.SelectedItem.Text = "";
            txtaddcurentcity.Text = "";

            txtaddcurentSTD.ReadOnly = true;
            txtaddcurrentnumber.ReadOnly = true;
            txtaddcurrentaddres.ReadOnly = true;
            txtaddcurrentstate.Enabled = false;
            txtaddcurentcity.ReadOnly = true;


            RequiredFieldValidator43.EnableClientScript = false;
            RequiredFieldValidator45.EnableClientScript = false;
            RequiredFieldValidator44.EnableClientScript = false;
            //RequiredFieldValidator46.EnableClientScript = false;




        }
        if (Radiocurrentaddress.SelectedValue == "Same as Longest Stay")
        {

            txtaddcurentSTD.Text = "";
            txtaddcurrentnumber.Text = "";
            txtaddcurrentaddres.Text = "Same as Longest Stay";
            txtaddcurrentstate.SelectedItem.Text = "";
            txtaddcurentcity.Text = "";


            txtaddcurentSTD.ReadOnly = true;
            txtaddcurrentnumber.ReadOnly = true;
            txtaddcurrentaddres.ReadOnly = true;
            txtaddcurrentstate.Enabled = false;
            txtaddcurentcity.ReadOnly = true;

            //txtaddcurentSTD.Text = txtlogstaySTd.Text.ToString();
            //txtaddcurrentnumber.Text = txtlongstayNumber.Text.ToString();

            //txtaddcurrentaddres.Text = txtadd1logeststay.Text.ToString();
            //txtaddcurrentstate.Text = txtaddlongstaystate.Text.ToString();
            //txtaddcurentcity.Text = txtaddlongeststaycity.Text.ToString();

            RequiredFieldValidator43.EnableClientScript = false;
            RequiredFieldValidator45.EnableClientScript = false;
            RequiredFieldValidator44.EnableClientScript = false;
            // RequiredFieldValidator46.EnableClientScript = false;
        }

        if (Radiocurrentaddress.SelectedValue == "New")
        {

            txtaddcurentSTD.ReadOnly = false;
            txtaddcurrentnumber.ReadOnly = false;
            txtaddcurrentaddres.ReadOnly = false;
            txtaddcurrentstate.Enabled = true;
            txtaddcurentcity.ReadOnly = false;


            txtaddcurentSTD.Text = "";
            txtaddcurrentnumber.Text = "";
            txtaddcurrentaddres.Text = "";
            txtaddcurrentstate.SelectedItem.Text = "";
            txtaddcurentcity.Text = "";

            RequiredFieldValidator43.EnableClientScript = true;
            RequiredFieldValidator45.EnableClientScript = true;
            RequiredFieldValidator44.EnableClientScript = true;
            //  RequiredFieldValidator46.EnableClientScript = true;

        }
    }

    protected void BtnAuthorizationLetter_Click(object sender, EventArgs e)
    {
        string FolderPath = Server.MapPath("~\\LOA\\LOA.pdf");
        System.IO.FileInfo file = new System.IO.FileInfo(FolderPath);
        if (file.Exists)
        {
            Response.Clear();
            Response.AddHeader("Content-Disposition", "attachment;filename=\"" + file.Name + "\"");
            Response.AddHeader("Content-Length", file.Length.ToString());
            Response.ContentType = "application/octet-stream";
            Response.WriteFile(file.FullName);
            Response.End();
        }
    }
    protected void btnuploadedu_Click(object sender, EventArgs e)
    {
        uploadFile();
        ShowFile();
        btnSave.Enabled = true;
    }
    protected void btnempdocs_Click(object sender, EventArgs e)
    {
        uploadfiles.uploaddownloadfiles up = new uploadfiles.uploaddownloadfiles();
        if (fileempdocsupload.HasFile == true)
        {
            string filename = fileempdocsupload.PostedFile.FileName;
            int i = -1;
            string[] filepathSplit = filename.Split('\\');
            foreach (string arrStr in filepathSplit)
            {
                i++;
            }
            string file = filepathSplit[i].ToString();
            string Checkype = "Govt. Id";
            //save the file to the server
            string fileRename = file + System.DateTime.Now.ToString("ddMMyyyyhhmmss");
            fileempdocsupload.PostedFile.SaveAs(Server.MapPath("~\\Uploaded\\") + fileRename);
            //lblStatus.Text = "File Saved to: " + Server.MapPath("~\\Uploaded\\") +EmpID+Checkype+ file;
            string Filename = Server.MapPath("~\\Uploaded\\") + fileRename;
            up.ActiveStatus = "1";
            up.BackgroundType = Checkype;
            up.CandidateID = "0";
            up.FileName = fileRename;
            up.UploadStatus = "1";
            up.FileSize = "NA";
            up.FirstName = txtFirstName.Text.ToString();
            up.MiddleName = "";
            up.Surname = "";
            up.FatherName = "";
            up.Mobile = txtcandidatemobile.Text.ToString();
            try
            {
                up.saveFile(up);
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
        else
        {
            //Response.Write("ss");
            Response.Write("<script>alert('Please Choose a File !');</script>");
        }
        ShowFile();
    }
    protected void btnfileuploadcri_Click(object sender, EventArgs e)
    {
        uploadfiles.uploaddownloadfiles up = new uploadfiles.uploaddownloadfiles();
        if (fileuploadcri.HasFile == true)
        {
            string filename = fileuploadcri.PostedFile.FileName;
            int i = -1;
            string[] filepathSplit = filename.Split('\\');
            foreach (string arrStr in filepathSplit)
            {
                i++;
            }
            string file = filepathSplit[i].ToString();
            string Checkype = "Others docs";
            //save the file to the server
            string fileRename = file + System.DateTime.Now.ToString("ddMMyyyyhhmmss");
            fileuploadcri.PostedFile.SaveAs(Server.MapPath("~\\Uploaded\\") + fileRename);
            //lblStatus.Text = "File Saved to: " + Server.MapPath("~\\Uploaded\\") +EmpID+Checkype+ file;
            string Filename = Server.MapPath("~\\Uploaded\\") + fileRename;
            up.ActiveStatus = "1";
            up.BackgroundType = Checkype;
            up.CandidateID = "0";
            up.FileName = fileRename;
            up.UploadStatus = "1";
            up.FileSize = "NA";
            up.FirstName = txtFirstName.Text.ToString();
            up.MiddleName = "";
            up.Surname = "";
            up.FatherName = "";
            up.Mobile = txtcandidatemobile.Text.ToString();
            try
            {
                up.saveFile(up);
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
        else
        {
            //Response.Write("ss");
            Response.Write("<script>alert('Please Choose a File !');</script>");
        }
        ShowFile();
    }
    protected void ddlref_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlref.SelectedItem.Text == "Reference1")
        {

            ref1.Visible = true;
            ref2.Visible = false;


        }
        if (ddlref.SelectedItem.Text == "Reference2")
        {

            ref1.Visible = true;
            ref2.Visible = true;

        }

        if (ddlref.SelectedItem.Text == "--Select--")
        {

            ref1.Visible = false;
            ref2.Visible = false;

        }


    }
    protected void periodofemptilldate1_TextChanged(object sender, EventArgs e)
    {
        if (periodofemployment1.Text == "")
        {

            Response.Write("<script>alert('Please choose From date first!!')</script>");
            periodofemptilldate1.Text = "";
        }
        else

            if (periodofemployment1.Text != "" && periodofemptilldate1.Text != "")
            {

                const string DateFormat = "dd/MM/yyyy";
                DateTime From = DateTime.ParseExact(periodofemployment1.Text, DateFormat, null);
                DateTime To = DateTime.ParseExact(periodofemptilldate1.Text, DateFormat, null);

                if (From > To)
                {
                    Response.Write("<script>alert('To date must be greater than the From date!!')</script>");
                    periodofemptilldate1.Text = "";

                }
                else
                {
                    TimeSpan Span = To - From;

                    DateTime Total = DateTime.MinValue + Span;

                    int Years = Total.Year - 1;
                    int Months = Total.Month - 1;
                    int Days = Total.Day - 1;
                    txtcmpny1expinyear.Text = Years + "year " + Months + "months " + Days + "days";
                }


            }
    }
    protected void periodofemptilldate2_TextChanged(object sender, EventArgs e)
    {
        if (periodofemployment2.Text == "")
        {

            Response.Write("<script>alert('Please choose From date first!!')</script>");
            periodofemptilldate2.Text = "";
        }
        else

            if (periodofemployment2.Text != "" && periodofemptilldate2.Text != "")
            {
                const string DateFormat = "dd/MM/yyyy";
                DateTime From = DateTime.ParseExact(periodofemployment2.Text, DateFormat, null);
                DateTime To = DateTime.ParseExact(periodofemptilldate2.Text, DateFormat, null);

                if (From > To)
                {
                    Response.Write("<script>alert('To date must be greater than the From date!!')</script>");
                    periodofemptilldate2.Text = "";

                }
                else
                {
                    TimeSpan Span = To - From;


                    DateTime Total = DateTime.MinValue + Span;



                    int Years = Total.Year - 1;
                    int Months = Total.Month - 1;
                    int Days = Total.Day - 1;
                    txtemp2experience.Text = Years + "year " + Months + "months " + Days + "days";
                }



            }
    }
    protected void periodofemptilldate3_TextChanged(object sender, EventArgs e)
    {
        if (periodofemployment3.Text == "")
        {

            Response.Write("<script>alert('Please choose From date first!!')</script>");
            periodofemptilldate3.Text = "";
        }
        else

            if (periodofemployment3.Text != "" && periodofemptilldate3.Text != "")
            {
                const string DateFormat = "dd/MM/yyyy";
                DateTime From = DateTime.ParseExact(periodofemployment3.Text, DateFormat, null);
                DateTime To = DateTime.ParseExact(periodofemptilldate3.Text, DateFormat, null);


                if (From > To)
                {
                    Response.Write("<script>alert('To date must be greater than the From date!!')</script>");
                    periodofemptilldate3.Text = "";

                }
                else
                {
                    TimeSpan Span = To - From;


                    DateTime Total = DateTime.MinValue + Span;



                    int Years = Total.Year - 1;
                    int Months = Total.Month - 1;
                    int Days = Total.Day - 1;
                    txtemp3experienceinyear.Text = Years + "year " + Months + "months " + Days + "days";
                }



            }
    }
    protected void periodofemptilldate4_TextChanged(object sender, EventArgs e)
    {
        if (periodofemptilldate4.Text == "")
        {

            Response.Write("<script>alert('Please choose From date first!!')</script>");
            periodofemptilldate4.Text = "";
        }
        else

            if (periodofemployment4.Text != "" && periodofemptilldate4.Text != "")
            {
                const string DateFormat = "dd/MM/yyyy";
                DateTime From = DateTime.ParseExact(periodofemployment4.Text, DateFormat, null);
                DateTime To = DateTime.ParseExact(periodofemptilldate4.Text, DateFormat, null);


                if (From > To)
                {
                    Response.Write("<script>alert('To date must be greater than the From date!!')</script>");
                    periodofemptilldate4.Text = "";

                }
                else
                {
                    TimeSpan Span = To - From;


                    DateTime Total = DateTime.MinValue + Span;



                    int Years = Total.Year - 1;
                    int Months = Total.Month - 1;
                    int Days = Total.Day - 1;
                    txtemp4experience.Text = Years + "year " + Months + "months " + Days + "days";
                }



            }
    }
    protected void periodofemptilldate5_TextChanged(object sender, EventArgs e)
    {
        if (periodofemptilldate5.Text == "")
        {

            Response.Write("<script>alert('Please choose From date first!!')</script>");
            periodofemptilldate5.Text = "";
        }
        else

            if (periodofemployment5.Text != "" && periodofemptilldate5.Text != "")
            {
                const string DateFormat = "dd/MM/yyyy";
                DateTime From = DateTime.ParseExact(periodofemployment5.Text, DateFormat, null);
                DateTime To = DateTime.ParseExact(periodofemptilldate5.Text, DateFormat, null);


                if (From > To)
                {
                    Response.Write("<script>alert('To date must be greater than the From date!!')</script>");
                    periodofemptilldate5.Text = "";

                }
                else
                {
                    TimeSpan Span = To - From;


                    DateTime Total = DateTime.MinValue + Span;



                    int Years = Total.Year - 1;
                    int Months = Total.Month - 1;
                    int Days = Total.Day - 1;
                    txtemp5experience.Text = Years + "year " + Months + "months " + Days + "days";
                }



            }
    }
}
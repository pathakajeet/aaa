﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MainPage : System.Web.UI.MasterPage
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserType"] == null)
            {
                Response.Redirect("HrLogin.aspx");

            }
            else
            {
                lblUserName.Text = Session["userName"].ToString().Trim();

                //DataTable ds = new DataTable();
                //con.Open();
                //SqlCommand cmd = new SqlCommand();
                //SqlDataAdapter da = new SqlDataAdapter();
                //cmd.Connection = con;
                //cmd.CommandType = CommandType.Text;
                //cmd.CommandText = "select * from LoginUsers where Clientname =" + "'" + lblUserName.Text + "'";
                //da.SelectCommand = cmd;
                //da.Fill(ds);
              
            }
        }

    }
}

﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DataAccess;
using procall1;
using Casestatus;
using System.Drawing;
using IISERVZCLASS;
using System.Text;


public partial class OfferDropReport : System.Web.UI.Page
{
    procall pc = new procall();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        string str = Session["UserType"].ToString();
        if (str == "Admin")
        {
            home.Visible = false;
            td1.Visible = false;
            td2.Visible = true;
            rj.Visible = false;
            fc.Visible = false;
            rj.Visible = false;
            od.Visible = true;
            odr.Visible = true;

        }
        if (str == "Hiring")
        {
            home.Visible = false;
            td1.Visible = false;
            td2.Visible = false;
            rj.Visible = false;
            fc.Visible = false;
            rj.Visible = false;
            od.Visible = false;
            odr.Visible = false;
        }
        if (str == "ClientPlusReject")
        {
            home.Visible = false;
            td1.Visible = false;
            td2.Visible = false;
            rj.Visible = true;
            fc.Visible = true;
            od.Visible = true;
            odr.Visible = true;
        }


          if (!IsPostBack)
        {
            DateTime dt = System.DateTime.Now;
            string str1 = dt.ToString("dd/MM/yyyy");
            txtFromDate.Text = str1;
            txtToDate.Text = str1;
            string fromdate = "";
            string todate = "";
            if (txtFromDate.Text.Length > 0 && txtToDate.Text.Length > 0)
            {
                fromdate = txtFromDate.Text;
                todate = txtToDate.Text;

                ds = pc.OfferDropList(Session["userName"].ToString(), Session["UserType"].ToString(), fromdate, todate);
                GridView1.DataSource = ds;
                GridView1.DataBind();
            }
        }        
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {

         procall pc = new procall();
        DataSet ds = new DataSet();
        
        if (txtFromDate.Text != "" && txtToDate.Text != "")
        { 
            
            string fromdate = "";
            string todate = "";
            fromdate = txtFromDate.Text;
            todate = txtToDate.Text;
           ds = pc.OfferDropList(Session["userName"].ToString(), Session["UserType"].ToString(), fromdate, todate);
                GridView1.DataSource = ds;
                GridView1.DataBind();
        }
        else
        {
            Response.Write("<Script Language='javascript'> alert('Please Select Date!')</Script>");
        }
    }
    
    protected void btnexporttoexcel_Click(object sender, EventArgs e)
    {
        if (GridView1.Rows.Count > 0)
        {

            //for (int i = 0; i < GridView1.Rows.Count; i++)
            //{
            //    GridView1.HeaderRow.Cells[0].Visible = false;
            //    GridView1.HeaderRow.Cells[1].Visible = false;

            //    GridViewRow row = GridView1.Rows[i];
            //    row.Cells[0].Visible = false;
            //    row.Cells[1].Visible = false;

            //}

            GridView1.HeaderStyle.BackColor = System.Drawing.Color.White;
            GridView1.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            GridView1.ForeColor = System.Drawing.Color.Black;
            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=OfferDropReport"  + DateTime.Now.ToString("dd-MM-yyyy") + ".xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.xls";
            this.EnableViewState = false;
            System.IO.StringWriter stringWrite = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
            HtmlForm form1 = new HtmlForm();
            this.Controls.Add(form1);

            form1.Controls.Add(GridView1);
            form1.RenderControl(htmlWrite);

            Response.Write(stringWrite.ToString());
            Response.End();
        }
        else
        {
            Response.Write("<Script Language='javascript'> alert('No Rows!')</Script>");
        }

    }
}

﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using IISERVZCLASS;


public partial class Hr : System.Web.UI.Page
{
    #region Global Connection
    private SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {



            Session.Abandon();
            Session.Clear();
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1));
            Response.Cache.SetNoStore();
        }

        if (!IsPostBack)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
        }
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        ValidateLogin login = new ValidateLogin();

        DataTable dt = new DataTable();
        dt = login.ValidateUserLogin(txtUserName.Text.Trim(), txtPassword.Text.Trim());
        if (dt.Rows.Count > 0)
        {
            lblmsg.Visible = true;
            lblmsg.Text = "Invalid Credentials.Please Try Again";
            Session["userName"] = dt.Rows[0]["UserName"].ToString();
            Session["userID"] = dt.Rows[0]["UserID"].ToString();
            //Session["roleID"] = dS.Tables[0].Rows[0]["RoleID"].ToString();
            //Session["roleName"] = dS.Tables[0].Rows[0]["roleName"].ToString();
            //Session["UserBranchId"] = dS.Tables[0].Rows[0]["BranchId"].ToString();
            Session["UserType"] = dt.Rows[0]["UserType"].ToString();
            Session["UserName"] = dt.Rows[0]["UserName"].ToString();
            Session["PortalUSerType"] = dt.Rows[0]["PortalUSerType"].ToString();
           
            //Session["JoiningType"] = "Pre";
            string user = Session["UserType"].ToString();
            //if (user == "Admin")
            //{
            //    Response.Redirect("AcceptReject.aspx");
            //}
            //if (user == "ClientPlusReject")
            //{
            //    Response.Redirect("createuser.aspx");
            //}

            Response.Redirect("DashBoard.aspx");
        }

        else
        {
            lblmsg.Visible = true;
            lblmsg.Text = "Invalid Credentials.Please Try Again";

        }
    }
}

﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using IISERVZCLASS;

public partial class candidate1 : System.Web.UI.Page
{
    #region Global Connection
    private SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
    #endregion

    protected void Page_Load(object sender, EventArgs e)
   {
        if (!IsPostBack)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
        }
    }
   
    protected void ImageBtn_Click(object sender, ImageClickEventArgs e)
    {
        ValidateLogin login = new ValidateLogin();

        DataTable dt = new DataTable();
        dt = login.ValidateCandidateLogin(txtUserName.Text.Trim(), txtPassword.Text.Trim());
        if (dt.Rows.Count > 0)
        {
            lblmsg.Visible = false;
            Session["UserName"] = dt.Rows[0]["CandidateName"].ToString();
            Session["Password"] = dt.Rows[0]["password"].ToString();
            Session["MiddleName"] = dt.Rows[0]["MiddleName"].ToString();
            Session["Lastname"] = dt.Rows[0]["LastName"].ToString();
            Session["MobileNo"] = dt.Rows[0]["MobileNo"].ToString();
            Session["UserType"] = dt.Rows[0]["UserType"].ToString();
            string strrefid = dt.Rows[0]["refid"].ToString();
            Session["ClosedStatus"] = dt.Rows[0]["ClosedStatus"].ToString();
            Session["dateofjoining"] = dt.Rows[0]["dateofjoining"].ToString();
            Session["placeofjoining"] = dt.Rows[0]["placeofjoining"].ToString();
            Session["DateofBirth"] = dt.Rows[0]["DateofBirth"].ToString();
            Session["FatherName"] = dt.Rows[0]["FatherName"].ToString();
            Session["category"] = dt.Rows[0]["category"].ToString();

            string stractivestatus = Convert.ToString(Session["ActiveStatus"] = dt.Rows[0]["ActiveStatus"].ToString());
            Session["Mode"] = "Reject";

            if (string.IsNullOrEmpty(strrefid))
            {
                Session["RefID"] = "0".ToString();
            }
            else
            {
                Session["RefID"] = dt.Rows[0]["refid"].ToString();
            }
            //Session["ClosedStatus"] = dS.Tables[0].Rows[0]["ClosedStatus"].ToString();
            if (stractivestatus == "Partial" || stractivestatus == "")
            {
                //Response.Redirect("GeneralInstructions.aspx");
                Response.Redirect("Instruction.aspx");
            }
            else
            {
                Response.Redirect("saveinfo.aspx");
            }
            //Response.Write("<script>alert('Login Successfully')</script>");
        }
        else
        {
            lblmsg.Visible = true;
            lblmsg.Text = "Invalid Credentials.Please Try Again";
        }
    }
}

﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Globalization;
using System.IO;
using System.Collections.Generic;
//using System.Linq;


public partial class BulkUploads : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        string str = Session["UserType"].ToString();
        string username = Session["UserName"].ToString();

        if (Session["UserType"] == null)
        {
            Response.Redirect("HrLogin.aspx");
            return;
        }

        if (Session["UserName"].ToString() == "iiservz")
        {
            Response.Redirect("OldReports.aspx");
            return;
        }
       


        if (!IsPostBack)
        {
            BindSearchDateData();
            BindCountData();

        }

    }

    public void BindCountData()
    {
        try
        {
            string CS = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(CS);
            DataSet ds = new DataSet();
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "BulkUploadCount";
            da.SelectCommand = cmd;
            da.Fill(ds);
            con.Close();
            lblCount.Text = "Yesterday Uploaded-" + " " + "(" + ds.Tables[1].Rows[0]["TotalCount"].ToString() + ")";
            lblTodayCount.Text = "Today Uploaded-" + " " + "(" + ds.Tables[0].Rows[0]["Counts"].ToString() + ")";
            lblUnallocated.Text = "Un Allocated Cases-" + " " + "(" + ds.Tables[2].Rows[0]["UnAllocated"].ToString() + ")";
            lblStopcase.Text = "Stop Cases-" + " " + "(" + ds.Tables[3].Rows[0]["StopCase"].ToString() + ")";
        }
        catch (Exception ex)
        {
            string error = ex.Message;
        }


    }

    protected void btnupload_Click(object sender, EventArgs e)
    {
        if (txtCandidateid.Text == "")
        {
            lblerror.Text = "Please Plovide BgcId !";
            lblerror.ForeColor = System.Drawing.Color.OrangeRed;
            txtCandidateid.Focus();
            return;
        }

        if (txtCandidate.Text == "")
        {
            lblerror.Text = "Please Plovide Candidate Name !";
            lblerror.ForeColor = System.Drawing.Color.OrangeRed;
            txtCandidate.Focus();
            return;
        }

        uploadfiles.uploaddownloadfiles up = new uploadfiles.uploaddownloadfiles();
        try
        {
            HttpFileCollection hfc = Request.Files;
            for (int i = 0; i < hfc.Count; i++)
            {
                HttpPostedFile hpf = hfc[i];
                if (hpf.ContentLength > 0)
                {
                    try
                    {
                        //if (hpf.FileName == true)
                        //{
                        string filename = hpf.FileName;
                        string file = System.IO.Path.GetFileName(filename);
                        string extension = Path.GetExtension(file);
                        hpf.SaveAs(Server.MapPath("~\\BulkCases\\") + filename);
                        up.CandidateID = "";
                        up.FileName = filename.ToString();
                        try
                        {
                            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
                            con.Open();
                            SqlCommand cmd = new SqlCommand("BulkUploadCases_Insert", con);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@FileName", file);
                            cmd.Parameters.AddWithValue("@Uploaddate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@Name", txtCandidate.Text.Trim());
                            cmd.Parameters.AddWithValue("@CandidateId", txtCandidateid.Text.Trim());
                            cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text.Trim());
                            cmd.Parameters.AddWithValue("@Uan", txtUan.Text.Trim());

                            cmd.ExecuteNonQuery();
                            con.Close();
                            BindSearchDateData();
                            Response.Redirect("BulkUploads.aspx");

                        }
                        catch (Exception ex)
                        {
                            Response.Write("<script>alert('" + ex.Message + "');</script>");
                        }
                        lblmsg.Text = "File Uploaded Successfully";
                        lblerror.Text = "";

                    }


                    catch (Exception ex)
                    {
                        lblmsg.Text = "File Not Uploaded !";
                    }

                }
                else
                {
                    lblerror.Text = "Please select file for upload !";
                    lblerror.ForeColor = System.Drawing.Color.OrangeRed;
                    return;
                }
            }
        }
        catch (Exception)
        {

        }



    }
    protected void grdFileUploadDownload_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "FileDownload")
        {


            string filename = Convert.ToString(e.CommandArgument);
            if (filename != "")
            {
                string FolderPath = Server.MapPath("~\\BulkCases\\");
                string path = FolderPath + filename;
                System.IO.FileInfo file = new System.IO.FileInfo(path);
                if (file.Exists)
                {
                    Response.Clear();
                    Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/octet-stream";
                    Response.WriteFile(file.FullName);
                    Response.End();
                }

                else

                    Response.Write("");

            }
        }
    }

    protected void ddlClientStatus_SelectedIndexChanged(object sender, System.EventArgs e)
    {
        DropDownList ddl = sender as DropDownList;
        GridViewRow gvRow = (GridViewRow)ddl.NamingContainer;
        fnUpdateClientStatus(gvRow);
    }

    public void fnUpdateClientStatus(GridViewRow GvRow)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
        string intClientMasterId = ((Label)GvRow.FindControl("CandidateId")).Text.ToString();
        string intClientStatus = ((DropDownList)GvRow.FindControl("ddlClientStatus")).SelectedValue;
        string strSQL = "UPDATE BulkUploadCases SET ActiveStatus = '" + intClientStatus + "' WHERE CandidateId = '" + intClientMasterId + "' ";
        con.Open();
        SqlCommand cmd = new SqlCommand(strSQL, con);
        cmd.CommandType = CommandType.Text;
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Redirect("BulkUploads.aspx");
    }
    protected void grdFileUploadDownload_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.Cells[8].Text.Equals("Yes"))
        {
            e.Row.BackColor = System.Drawing.Color.Wheat;
            e.Row.ForeColor = System.Drawing.Color.Black;
            e.Row.Font.Bold = true;
            //e.Row.Cells[8].BackColor = System.Drawing.Color.PaleGreen;
            e.Row.Cells[8].ForeColor = System.Drawing.Color.Green;
        }

        if (e.Row.Cells[8].Text.Equals("Stop"))
        {
            e.Row.BackColor = System.Drawing.Color.Pink;
            e.Row.ForeColor = System.Drawing.Color.Black;
            e.Row.Font.Bold = true;
            //e.Row.Cells[8].BackColor = System.Drawing.Color.PaleGreen;
            e.Row.Cells[8].ForeColor = System.Drawing.Color.Red;
        }
    }

    public void BindSearchDateData()
    {
        try
        {
            string CS = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(CS);
            DataTable ds = new DataTable();
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "BulkUploadCases_Select";
            //cmd.Parameters.AddWithValue("@FromDate", txtfromdate.Text);
            da.SelectCommand = cmd;
            da.Fill(ds);
            con.Close();
            grdFileUploadDownload.DataSource = ds;
            grdFileUploadDownload.DataBind();
            //lblTotalCount.Text = "Record -" + " " + "(" + GridView1.Rows.Count.ToString() + ")";
        }
        catch (Exception ex)
        {
            string error = ex.Message;
        }


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (grdFileUploadDownload.Rows.Count > 0)
        {

            for (int i = 0; i < grdFileUploadDownload.Rows.Count; i++)
            {
                grdFileUploadDownload.HeaderRow.Cells[0].Visible = false;
                grdFileUploadDownload.HeaderRow.Cells[1].Visible = false;
                grdFileUploadDownload.HeaderRow.Cells[2].Visible = false;
                grdFileUploadDownload.HeaderRow.Cells[3].Visible = false;

                GridViewRow row = grdFileUploadDownload.Rows[i];
                row.Cells[0].Visible = false;
                row.Cells[1].Visible = false;
                row.Cells[2].Visible = false;
                row.Cells[3].Visible = false;

            }

            grdFileUploadDownload.HeaderStyle.BackColor = System.Drawing.Color.White;
            grdFileUploadDownload.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            grdFileUploadDownload.ForeColor = System.Drawing.Color.Black;
            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=HclBulkCases" + DateTime.Now.ToString("dd-MM-yyyy") + ".xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.xls";
            this.EnableViewState = false;
            System.IO.StringWriter stringWrite = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
            HtmlForm form1 = new HtmlForm();
            this.Controls.Add(form1);

            form1.Controls.Add(grdFileUploadDownload);
            form1.RenderControl(htmlWrite);

            Response.Write(stringWrite.ToString());
            Response.End();
        }
        else
        {
            Response.Write("<Script Language='javascript'> alert('No Rows!')</Script>");
        }
    }
}
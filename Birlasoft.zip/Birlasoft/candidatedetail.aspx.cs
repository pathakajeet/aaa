﻿using System;
using System.Configuration;
using System.Data;
//using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
//using System.Xml.Linq;
using System.Data.SqlClient;
using IISERVZCLASS;
using DataAccess;
using classgen1;
using EmployeeInfonamespace;
using CandidateInfonamespace;

public partial class _Default : System.Web.UI.Page 
{
    
     SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
     CandidateInfonamespace.CandidateDetails candidateobj = new CandidateInfonamespace.CandidateDetails();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        tdhome.Visible = false;
        string str = Session["UserType"].ToString();
        if (str == "Admin")
        {
            td1.Visible = false;
            td2.Visible = true;
            rj.Visible = false;
            fc.Visible = false;
            rj.Visible = false;
            od.Visible = false;

        }
        if (str == "Hiring")
        {
            td1.Visible = false;
            td2.Visible = false;
            rj.Visible = false;
            fc.Visible = false;
            rj.Visible = false;
            od.Visible = false;
        }
        if (str == "ClientPlusReject")
        {
            td1.Visible = false;
            td2.Visible = false;
            rj.Visible = true;
            fc.Visible = true;
            od.Visible = false;
        }
        if (!IsPostBack)
        {
            Page.Validate();
            ds = getDataset("select UserID,UserName from LoginUsers where activestatus=1 ");
            drpHiring.DataTextField = "UserName";
            drpHiring.DataValueField = "UserID";
            drpHiring.DataSource = ds;
            drpHiring.DataBind();
            drpHiring.Items.Insert(0, new ListItem("Select", "0"));
          drpHiring.Items.Insert(1, new ListItem("Others"));


            ds = getDataset("select COEID,COEName from COElist where activestatus=1 ");
            drpCOE.DataTextField = "COEName";
            drpCOE.DataValueField = "COEID";
            drpCOE.DataSource = ds;
            drpCOE.DataBind();
            drpCOE.Items.Insert(0, new ListItem("Select", "0"));
            drpCOE.Items.Insert(1, new ListItem("Others"));

           
        }
    }

     

    private DataSet getDataset(string query)
    {
        DataSet tempDataSet = new DataSet();
        SqlDataAdapter dap = new SqlDataAdapter(query, con);
        dap.Fill(tempDataSet);
        return tempDataSet;
    }
    public static string CreateRandomPassword(int PasswordLength)
    {
        string _allowedChars = "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ";
        Random randNum = new Random();
        char[] chars = new char[PasswordLength];
        int allowedCharCount = _allowedChars.Length;
        for (int i = 0; i < PasswordLength; i++)
        {
            chars[i] = _allowedChars[(int)((_allowedChars.Length) * randNum.NextDouble())];
        }
        return new string(chars);
    }
    protected void btn_Click(object sender, EventArgs e)
    {
       
            btn.Attributes.Add("OnClientClick", "if (! confirm(''Are you sure you want to add this estimate data??')) return false;");
            //COE
            if (drpCOE.SelectedItem.Text == "--Select--")
            {
                candidateobj.band4coe = "";
            }
            else
                if (drpCOE.SelectedItem.Text == "Others")
                {
                    candidateobj.band4coe = txtCOE.Text.ToString();
                }
                else
                {
                    candidateobj.band4coe = drpCOE.SelectedItem.Text.ToString();
                }
            //Place of Joining

            if (drpPOJ.SelectedItem.Text == "--Select--")
            {
                candidateobj.PlaceofJoing = "";
            }
            else
                if (drpPOJ.SelectedItem.Text == "Others")
                {
                    candidateobj.PlaceofJoing = txtotherlocation.Text.ToString();
                }
                else
                {
                    candidateobj.PlaceofJoing = drpPOJ.SelectedItem.Text.ToString();
                }

            //Recuriter Name

            if (drpHiring.SelectedItem.Text == "--Select--")
            {
                candidateobj.band4hiring = "";
            }
            else
                if (drpHiring.SelectedItem.Text == "Others")
                {
                    candidateobj.band4hiring = txtHiring.Text.ToString();
                }
                else
                {
                    candidateobj.band4hiring = drpHiring.SelectedItem.Text.ToString();
                }


            candidateobj.band4candidatename = txtCandidateName.Text.ToString();
            candidateobj.band4emailid = txtEmail.Text.ToString();
            candidateobj.band4mobile = txtMobile.Text.ToString();
            //candidateobj.band4hiring = drpHiring.SelectedItem.Text.ToString();
            //candidateobj.PlaceofJoing = drpPOJ.SelectedItem.Text.ToString();
            candidateobj.DateofJoining = txtDateOfJoining.Text.ToString();

            // Random rnd = new Random();
            // byte[] GenPassword = new byte[9];
            // for (int i = 0; i <= 7; i++)
            // {
            //     GenPassword[i] = (byte)rnd.Next(65, 90);
            // }

            //string password= System.Text.Encoding.UTF8.GetString(GenPassword);



            string password = CreateRandomPassword(8);

            uploadfiles.uploaddownloadfiles up = new uploadfiles.uploaddownloadfiles();


            if (FileUpload1.HasFile == true)
            {
                string filename = FileUpload1.PostedFile.FileName;
                int i = -1;
                string[] filepathSplit = filename.Split('\\');
                foreach (string arrStr in filepathSplit)
                {
                    i++;
                }
                string file = filepathSplit[i].ToString();
                //string Checkype = ddlType.SelectedItem.Value.ToString();
                //save the file to the server
                string fileRename = file + System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                FileUpload1.PostedFile.SaveAs(Server.MapPath("~\\Uploaded\\") + fileRename);
                //lblStatus.Text = "File Saved to: " + Server.MapPath("~\\Uploaded\\") +EmpID+Checkype+ file;
                string Filename = Server.MapPath("~\\Uploaded\\") + fileRename;
                up.ActiveStatus = "1";
                up.BackgroundType = "";
                //up.CandidateID = "0";
                up.FileName = fileRename;
                up.UploadStatus = "1";
                up.FileSize = "NA";
                up.FirstName = txtCandidateName.Text.ToString();
                up.Mobile = txtMobile.Text.ToString();
                up.FatherName = txtEmail.Text.ToString();

                up.saveBand4File(up);

            }


                 int dc = candidateobj.doublecheck(candidateobj);
                 if (dc != 0)
                 {
                     Response.Write("<Script Language='javascript'> alert('Data already Exists !')</Script>");

                 }
                 else
                 {
                     int dtInsert = candidateobj.candidateband4info(candidateobj, password);

                     if (dtInsert == 0)
                     {
                         Response.Write("<Script Language='javascript'> alert('Detail Saved ! and Infomation will be send to candidate soon')</Script>");
                         Server.Transfer("candidatedetail.aspx");

                     }
                     else if (dtInsert == -2)
                     {

                         Response.Write("<Script Language='javascript'> alert('Already Data Saved !')</Script>");
                     }
                     else if (dtInsert == -1)
                     {

                         Response.Write("<Script Language='javascript'> alert('Error In Procedure...InsertEmployeeInfo!')</Script>");
                     }
                 }

       
    }
   
}

﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using CandidateInfonamespace;
using System.Data.SqlClient;
using DataAccess;
using System.Security.Principal;
using System.Collections.Generic;
using System.Text;
using System.IO;
using procall1;
using Casestatus;

public partial class BulkUploadDragDrop : System.Web.UI.Page
{
    procall pc = new procall();
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        //tdhome.Visible = false;

        string str = "";
        if (!Page.IsPostBack)
        {
            if (Session["UserType"] == null)
            {
                Response.Redirect("HRLogin.aspx");
            }
            else
            {
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");
            }

            str = Session["UserType"].ToString();
            if (str == "Hiring")
            {
                Response.Redirect("CandidateLogin.aspx");
            }
        }
        string username = Session["UserName"].ToString();
        if (username == "arun" && str == "ClientPlusReject")
        {
            fc.Visible = false;

        }
        else
        {
            fc.Visible = true;

        }
        if (username == "client" && str == "ClientPlusReject")
        {
            //td2.Visible = true;
            fc.Visible = true;
        }
        else
        {
            // td2.Visible = false;
            fc.Visible = true;
        }
        if (str == "Admin")
        {
            td1.Visible = false;
            //td2.Visible = true;
            rj.Visible = false;
            fc.Visible = false;
            rj.Visible = false;


        }
        if (str == "Hiring")
        {
            td1.Visible = false;
            //td2.Visible = false;
            rj.Visible = false;
            fc.Visible = false;
            rj.Visible = false;

        }
        if (str == "ClientPlusReject")
        {
            td1.Visible = true;
            //td2.Visible = false;
            rj.Visible = true;


        }

        if (!IsPostBack)
        {
            procall pc = new procall();
            DataSet ds = new DataSet();
        }

    }
    protected void ddlaccount_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["ddlaccountName"] = ddlaccount.SelectedItem.Text.ToString();
    }
}